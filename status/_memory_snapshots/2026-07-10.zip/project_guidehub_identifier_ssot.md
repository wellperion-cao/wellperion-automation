---
name: ssot
description: 가이드허브 메뉴/문서/URL 식별자는 data-id 하나로 단일화(S1·S2·T1·G1 등). 옛 별칭 data-doc은 폐지 — 라우터·문서 id·탭 모두 data-id 기준. 옛 주소(#g10)는 LEGACY_TO_ID 안전망으로만 변환.
metadata: 
  node_type: memory
  type: project
  originSessionId: 53b64db4-aecb-45f0-8341-87c1406eeb0d
---

가이드허브(`3. 웰페리온 가이드/wellperion_guide(main).html`)의 식별 체계 = **식별자(data-id) 단일** (2026-06-13 GM "사람=코드 이름 일치" B안으로 별칭 이중구조 폐지).

**식별자 = 사람·코드 공통 단일 이름** (홈 "사용법" 표 머리글자):
- S1=공통가이드라인 S2=AI C-Level운영 S3=업무&결재현황SSOT
- F1=지출현황 H1=취업규칙 / O1=운영통합체계 O2=공지/안내문 O3=재등록대시보드
- M1=공식채널 M2=콘텐츠제작 M3=오프라인홍보물 M4=마케팅대시보드 M5=콘텐츠검수·자동업로드
- T1=기술인프라 T2=업무자동화 T3=AI교육 / G1=김남욱GM
- (home·dashboard·g9는 메뉴 미등록 문서 — 식별자 없이 옛 id 유지)

**구조 (이중매핑 제거됨):**
- 메뉴 `<a>` = `data-id`만 (옛 `data-doc` 속성 폐지). home은 `data-id="home"`.
- 본문 문서 `<article>`의 `id` = 식별자(예: `id="S2"`). data-tabs도 식별자.
- 라우터 JS: 모든 셀렉터·해시·active 토글이 `data-id`/식별자 기준. 옛 `PUB_TO_DOC`/`DOC_TO_PUB` 런타임 매핑 삭제.
- URL 해시 = 식별자(`#S2`·`#S2/ceo`). 옛 별칭 주소(`#g10` 등 외부 북마크·워드프레스)는 `LEGACY_TO_ID` 맵 한 줄이 식별자로 변환(하위호환 안전망, 사람 눈엔 안 보임).

**보존(통일 범위 외 — 사람이 안 보는 내부):** 함수명 `gm1FetchSsot`, CSS 하위 id `gm1-todo-section`·`gm1-review-section`, 탭 독립이름 `cmopub-ch`, 미등록 문서 `g9`·`dashboard`. = 손대지 않음.

**How to apply:** 가이드 링크·딥링크는 식별자(`#S2`)로 작성. 새 가이드 = 홈 표에 식별자 행 + nav에 `data-id` + article `id="식별자"` + `data-tabs="식별자"`. data-doc은 더 이상 쓰지 않는다. 옛 별칭(g10 등) 신규 링크 금지 — 안전망은 기존 외부 링크용. 배포=GitHub Pages, 라이브 URL엔 `3. 웰페리온 가이드/` 접두사 없음([[reference_pages_url_no_guide_prefix]]), commit+push+라이브 실측까지가 완료([[feedback_guidehub_commit_must_push_and_live_verify]]). 동시 세션 커밋 직렬화([[feedback_git_commit_atomic_vs_watcher_reset]]·[[reference_guidehub_concurrent_commit_corruption]]).
