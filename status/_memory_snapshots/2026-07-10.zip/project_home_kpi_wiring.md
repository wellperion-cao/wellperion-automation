---
name: project_home_kpi_wiring
description: home 대시보드 매출·지출·이슈(VOC) 자동집계 연동 상태 + 지출 시트 구조 문제(집계 불가)
metadata: 
  node_type: memory
  type: project
  originSessionId: 644d85ba-fbd1-4fc9-8170-ce95d1fcc47a
---

2026-06-08 deep-interview로 요구사항 확정 후 구축. 명세: `.omc/specs/deep-interview-home-financial-voc-wiring.md`.

**엔드포인트:** 기존 todo GAS(.deploy-todo) 확장 — `{TODO_API_URL}?action=home_kpi` → JSON {sales,expense,voc,asOf}. base 검증본: script.google.com/macros/s/AKfycbxDwFkrxK1YIaEoSNcuw2MiHiZQ-7o5N6311ytksSyeEd86ZFOhLknOWqQgNArQvZ-7/exec. home JS가 fetch해 ID 채움(heroSales*·heroExp*·kpiIssue*). 운영 현황 상세 상단에 매출·지출, 4카드(업무·결재·문의·이슈 현황) 2×2.

**매출 (시트 1oG63rj17-RMk2cdiVbwp4TOp-yN73uc04jDV7RfN9BI):** ✅ 정확 검증됨. 월별 탭(현재월 자동선택, 7월 추가 시 자동)→최신 날짜 블록 "✅ 총 매출 합계" 행: 오늘=금일/이번달=누적/달성률=목표달성률, 연간=월탭 합산. 6/7 값(755,000·150,317,501·591,000,000·25.43%) 일치.

**이슈 VOC (시트 1akZLs7…gid=1576318230):** 오늘신규=타임스탬프 today, 처리완료='진행 상황'에 '완료' 포함, 미처리=나머지, 처리율=완료/전체. 미처리 261은 과거 누적분 포함 — GM "사실 자료 그대로" 유지 결정. [[reference_voc_issue_intake]]

**⚠️ 지출 (시트 1umSF9rf3K0TuAvR5l0F_gvXHxcOLVKKvkSUfTtbRhdc) — 자동집계 불가, "집계 보완 중"으로 내림(2026-06-08 GM):**
- 거래 1행=1건 로그(가격·구매진행상황). 집계규칙=승인건 가격합(오늘/당월/연간), 예산 대비 집행률(월예산=GAS 상수, 미설정).
- **근본 문제: 시트 행마다 칸이 어긋남**(병합·열 밀림 — '구매진행상황' 칸에 날짜가 섞여 들어온 행 수십개). 자동집계가 들쭉날쭉. GAS=6월 309,400/연간 104.7M, 웰리 독립집계=6월 0/연간 95.8M(1월13.6M·2월1.5M·3월71.8M·4월8.9M, 5·6월 승인표기 없거나 열밀림으로 0). **둘 다 못 믿음.**
- 코드 버그 아님 = **원천 데이터(시트) 구조 문제.** 해결하려면 시트 입력 정리(승인 표기·열 정렬 일관화) 또는 시트 실태 맞춤 집계 재설계 후 재연결 필요(후속).

**보안 과제(미해결):** home_kpi·todo API 모두 무인증 개방. home=GitHub Pages(공개 추정)에 매출·회원 노출. 재무 노출 위험 — 별도 보안 과제 [[project_todo_api_open_security_gap]]. 웰리 솔직평가(2026-06-08)에서 ERP 최우선 약점으로 지목.

연관: [[project_guidehub_ssot]] · [[feedback_report_final_value_decision_support]] · [[project_coo_issue_sheet_name]].
