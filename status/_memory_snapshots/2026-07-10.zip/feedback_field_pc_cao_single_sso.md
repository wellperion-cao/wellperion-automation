---
name: field-pc-cao-single-sso
description: "실무진 PC Claude Code CLI 로그인은 cao@wellperion.com 단일 SSO. 비밀번호 직접 전달 금지, GM님 1회 현장 로그인 후 세션 유지 방식."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 93a84c2a-e50c-474c-b762-4be73565075e
---

C-Level `Start-AI {역할}.bat` 런처를 실무진 PC에 배포할 때 Claude Code CLI 로그인은 `cao@wellperion.com` 단일 SSO를 사용한다. 실무진 본인 별도 Anthropic 계정은 사용하지 않는다.

**Why:** (1) Notion MCP·Telegram MCP·Google Drive MCP 권한이 cao 계정에 일치화되어 있어(메모리 `reference_notion_integrations`) 즉시 동작, (2) Claude Max 추가 구독 비용 불필요, (3) 권한·감사 라인 단일화. 모든 로그가 cao로 기록되는 점은 GM님 명시 인지·승인 (2026-05-20).

**How to apply:**
- 실무진 PC 셋업 시 GM님이 **현장에서 1회 직접 로그인** 수행 (`claude login` 브라우저 OAuth). 비밀번호·세션 토큰을 텔레그램/이메일로 평문 전달 절대 금지 (메모리 `feedback_credentials_policy`).
- 한 번 로그인하면 OS Keychain/Credential Manager에 토큰 저장 → 이후 실무진이 .bat 더블클릭만으로 사용.
- 실무진 PC에서 GM님 명의 활동이 발생하므로 작업 범위는 해당 C-Level R/R로 제한(메모리 `feedback_no_speculative_action`). C-Level 페르소나 프롬프트가 .bat에 하드코딩되어 자동 제한된다.
- 권한 회수 필요 시 GM님이 `claude logout` 1회 또는 cao 계정에서 해당 디바이스 세션 강제 만료.
- 관련: [[reference-notion-integrations]], [[feedback-credentials-policy]].
