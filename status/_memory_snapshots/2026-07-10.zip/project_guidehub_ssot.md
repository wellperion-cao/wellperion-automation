---
name: project-guidehub-ssot
description: 가이드허브(Netlify 웹앱) = GM님 업무·루틴·건강관리·자동태스크 통합 SSOT (2026-05-26 v2.2).
metadata: 
  node_type: memory
  type: project
  originSessionId: 88d13af2-5d51-4abb-9ca4-a3a6b3714259
---

가이드허브 = Netlify 배포 웹앱이 GM님의 단일 참조 문서(SSOT).

소스 파일: `3. 웰페리온 가이드(netlify)/wellperion_guide(main).html`
배포 URL: https://wellperion-guide.netlify.app/

**GM님 할일 SSOT = 가이드허브 「김남욱」 페이지 (2026-05-27 확정)**
- 김남욱 페이지의 "오늘 할 일" 영역이 GM님 개인 할일의 유일한 기준
- 매 세션 시작 시 이 영역을 확인하고, 전날 완료 건 정리 + 오늘 할 일 갱신
- 세션 종료 전 다음날 할 일을 여기에 기록해서 인수인계
- 완료·보류·삭제 3버튼으로 처리, 완료/보류는 토글에 시간 기록 보관
- Notion·메모리·텔레그램 인박스 등 다른 곳은 보조 참고만. 김남욱 페이지가 최종 기준

v2.2 추가 섹션 (2026-05-26):
1. 오늘·이번달 업무 (GM 할 일 SSOT)
2. 보충제·루틴·건강 기록 (CHRO 검토 기반, 탭 3개)
3. 자동 태스크 현황 (실제 가동 기준, 불일치 표시)

**Why:** GM님이 자주 잊어버려서 한 곳에서 확인하고 싶다는 요구. Notion GM TODO LIST 중복 관리 부담 제거.

**How to apply:**
- 업무·루틴·건강 변경 시 이 HTML 파일을 직접 수정
- 세션 시작: 김남욱 > 오늘 할 일 확인 → 갱신
- 세션 종료: 내일 할 일 기록 → 인수인계
- Netlify 자동 배포(git push 또는 Netlify MCP)
- 최종 목표: "일과 일상이 하나되는 루틴" — GM님 실제 일과표 받은 후 반영
- 관련: [[project-gm-todo]]
