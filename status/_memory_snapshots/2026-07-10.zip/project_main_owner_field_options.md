---
name: ssot-6
description: "Start 기획DB와 운영 아카이브[결과물DB]의 `실무진(최종 책임자)` select 필드 옵션 6명 단일 진실 원본."
metadata: 
  node_type: memory
  type: project
  originSessionId: 63d35c3d-04dd-4095-be62-d069a93c7814
---

Start 기획DB(`3430407d-a948-8156-afde-e663227cb7a1`) + 운영 아카이브[결과물DB](`3430407d-a948-819d-8769-f739221cf4c8`)에 신설된 `실무진(최종 책임자)` select 필드 옵션 SSOT.

**옵션 6명 (2026-05-20 GM님 확정):**
| 옵션 | 색상 | 역할 |
|---|---|---|
| 김남욱 GM | red | General Manager (GM님 본인) |
| 이경연 실장 | orange | 실장 |
| 나우열M | yellow | Manager |
| 최준용M | green | Manager |
| 임정은M | blue | Manager |
| 윤병현AM | purple | Assistant Manager |

**Why:** 메모리 [[feedback_role_inversion_main_support]] 전사 R/R 대전환에 따라 최종 책임자 = 실무직원으로 통일. 옵션 통제로 자유 입력·오기 차단.

**How to apply:**
- DB 신규 레코드 생성 시 본 6옵션 중 1명 선택 의무.
- 신규 실무직원 합류·이탈 시 본 메모리 + DB select 옵션 동시 patch 의무 (CEO 자율).
- AI C-Level 페르소나 명칭(예: "AI CEO", "AI CHRO")은 본 필드 입력 금지 — 그건 `담당자` relation 필드 영역.
- 호칭 표준: GM님 호칭은 "GM님" ([[feedback_principal_address_gm]]).
