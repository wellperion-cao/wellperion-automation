---
name: reference_sales_kpi_annual_wiring
description: home 매출 KPI 월/연간 데이터 소스·연간 연동 구조 (8.33억 중복합산 버그 수정 후)
metadata: 
  node_type: memory
  type: reference
  originSessionId: f4d15087-26db-48d5-a6f7-3cf3f29256b1
---

home 매출 KPI 데이터 소스·산출 구조 (**2026-07-02 GM 지시로 AV열 단일 정본 통합**):

- **매출 정본 = "26년 매출 분석" 시트 AV열 단일** (`KPI_SALES_ANALYSIS_SHEET_ID = 1gCQNny8TDls5SjrtMkINu4HCltvFkoXmkTeXO_c3q58`, 탭 "26년 매출 분석" gid 195790960). **AV3=1월 … AV8=6월 … AV14=12월** (월별 마감값). GM이 매달 이 AV열만 채우면 됨.
- **연간 매출** = `_kpiSales()`가 `openById`로 **AV3:AV14(getRange(3,48,12,1))** 읽어 **값>0인 달만 합산** → 달 채워질수록 자동 누적. 실패 시 null("집계 보완 중").
- **월(당월) 매출** = **현재월 AV 셀** = 행(현재월+2). 예 7월→AV9. 값 없으면 null·hasCurMonth=false("이번달 미마감" 표기, 스테일 이전달 금지).
- **"보고" 탭(`KPI_SALES_SHEET_ID 1oG63rj17-…`)은 매출 KPI 산출에서 폐기**(2026-07-02). 과거 분산 SSOT(보고탭 6월~ + AV 1~5월)가 6월 스테일·연간 급락 폭탄 원인이었음 → AV 단일화로 근본 제거. (breakdown 주차만 parking_revenue.json 별도 유지.)
- **연 목표(yearTarget)=72억**, 라이브 실측 2026-07-02: 연간=35억 700만(1~7월 누적)·당월 7월=2,434만·달성률 48.7%.
- **배포**: `.deploy-todo/업무&결재 현황.js` clasp, 라이브 deploymentId=`AKfycbxD…QvZ-7`(/exec 고정). clasp 재배포 필요(push≠deploy). MCP 시트 직독 차단→GAS openById만, 검증=home_kpi 라이브 curl.
- (폐기 이력) 8.33억 중복합산 버그(옛 보고탭 로직)·AV3:AV7 5월한정 범위는 위 통합으로 종료. 관련: [[reference_parking_revenue_integration]] · [[reference_clasp_webapp_redeploy]] · [[project_home_kpi_wiring]]
