---
name: project_principles_s2_single_source
description: C-Level 운영 원칙 단일 출처 = S2 가이드허브 g10. 원칙 추가·수정은 S2에만. CLAUDE.md·메모리에 중복 나열 금지
metadata: 
  node_type: memory
  type: project
  originSessionId: a2933fe1-0bb3-4e71-9864-a81843b644b1
---

2026-06-03 GM 결정·완료. C-Level 운영 원칙이 4곳(CLAUDE.md·S2·메모리182·에이전트md)에 흩어져 중복·드리프트로 매일 혼란 → **S2 가이드허브 g10 단일 출처로 통합**.

## 단일 출처 규칙 (강제)
- **운영 원칙·R/R = S2 g10(공통탭 + 본인탭)이 유일 원본.** 원칙 추가·수정은 S2에만 한다.
- CLAUDE.md = 얇은 인덱스(회사정보·로스터·거버넌스·토큰라우팅·훅·SSOT포인터). 원칙 상세 하드코딩 금지.
- 메모리 = 프로젝트 상태·포인터(B) + 기술 함정(C)만. **운영 원칙(feedback형 규칙)을 메모리에 새로 쌓지 말 것** — S2에 넣어라.
- 부팅: 에이전트md(페르소나) → CLAUDE.md(인덱스) → **S2 g10에서 원칙·R/R 흡수** → status.

## 정리 결과
- 메모리 182 → **64** (운영원칙 119개 S2 흡수 후 `memory/_archive_S2단일화_20260603/`로 가역 아카이브, 영구삭제 0)
- S2 공통탭: "전 C-Level 통합 원칙" 9테마 표 신설(보고소통·자율결정·데이터위생·검증·고도화·효율·파이프라인·보안·토큰라우팅)
- S2 역할탭 7개: 역할 고유 원칙 흡수 + COO·CTO·CHRO·CPO Do/Don't·세션부팅 체크리스트 신규
- 작업 플랜·삭제대조 체크리스트: `.omc/specs/deep-interview-원칙-S2단일화.md`
- 아카이브는 가역 — 영구삭제는 GM 최종 확인 후 별도. CPO Do/Don't는 메모리 부재로 추정(S2에 'GM 검토 대상' 표시).

**Why:** 같은 규칙이 3~5곳에 흩어져("실측검증" 5중·"CEO직접실행금지" 3중) "어느 게 진짜?"가 매일 발생 → GM 소통 혼란. 단일 출처 = 한 곳만 고치면 전 C-Level 반영, 드리프트 0.

**How to apply:** 새 원칙·피드백이 생기면 메모리가 아니라 S2 g10 공통탭(전체) 또는 본인탭(역할)에 1줄로 추가. 메모리는 상태·기술함정만. [[feedback_dual_ssot_only]] [[project_guidehub_ssot]] [[project_master_framework_page]]
