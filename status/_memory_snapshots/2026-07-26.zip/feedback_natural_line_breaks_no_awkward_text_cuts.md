---
name: feedback_natural_line_breaks_no_awkward_text_cuts
description: 콘텐츠·카피는 문장/단어가 어색하게 중간에 잘려 내려가면 안 됨 — 자연스러운 문장·문단 경계에서만 끊고 단어 중간 잘림 0. GM이 품격 디테일로 강조
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9300c057-51fc-40a2-8f89-2c12fcf8b748
  modified: 2026-07-22T08:54:05.361Z
---

GM 강한 지적(2026-07-22, "웰리야" 직접 호명): "제발 글 맥락 좀 끊지 말아줘. 회사 소개하고 비즈니스를 성공시키려면 이런 디테일한 부분 절대 놓치면 안 돼."

**문제:** 발행물(폼·회사소개서·페이지)에서 텍스트가 어색하게 줄바꿈돼 **문장·단어가 중간에 잘려 다음 줄로 내려감**. 예:
- 회사소개서 03장: "...시작됐습니다." 바로 뒤에 "2017년, 한남동이 그 출발점이 되었습니다."가 어정쩡하게 붙거나 잘림 → **문장이 끝나면 한 칸 내려(문단 간격) 새 문장을 시작**해야 자연스러움.
- "완성도" 같은 단어가 "완" / "성도"로 **단어 중간에서 잘려 내려감**.
- 영문폼 'lesson consultations'에서 'consultations'만 다음 줄로 떨어진 것도 같은 문제(반복).

**How to apply (전 발행물·GM 표면 공통):**
1. **문장·문단 경계에서만 줄바꿈**. 의미가 바뀌는 곳은 명시적 문단 구분(빈 줄/간격), 앞 문장에 어정쩡하게 붙이지 말 것.
2. **단어 중간 잘림 0** — 한국어 `word-break:keep-all`, 영어 적정 `overflow-wrap`. 어절이 통째로 넘어가게.
3. `text-wrap: balance/pretty` + 필요 시 명시적 `<br>`/`<p>`로 의도한 줄·문단. 한 단어만 외롭게 떨어지는 것(orphan) 방지.
4. 제작 후 **모든 텍스트 블록을 렌더로 눈으로 확인** — 어색한 끊김 전수 점검(정적 검증만으론 부족).
5. ★품격 디테일: 회사 소개·브랜드·발행물의 완성도는 이 줄바꿈에서 갈린다. 관련 [[wellperion-brand]]·[[feedback_gm_page_completion_a3_print_readable]]·[[feedback_content_realism_drives_engagement]].
