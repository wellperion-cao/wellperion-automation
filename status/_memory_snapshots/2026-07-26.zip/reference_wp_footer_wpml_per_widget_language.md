---
name: reference_wp_footer_wpml_per_widget_language
description: 웰페리온 WP 다크 푸터 = Salient footer-area 위젯 + WPML per-widget 언어필터 구조·영문화 방법
metadata: 
  node_type: memory
  type: reference
  originSessionId: 9300c057-51fc-40a2-8f89-2c12fcf8b748
  modified: 2026-07-22T07:35:19.784Z
---

웰페리온(wellperion.com) 사이트 전역 **다크 푸터**는 Salient 테마의 4개 위젯 영역(`footer-area-1..4`)에 든 **Custom HTML 위젯**으로 구성. 언어별 표시는 **WPML per-widget 언어필터**(각 위젯 편집폼 안 `<select name="wpml_language">` = en/ko/all, `wpml-language-nonce` 동봉)로 제어 — 메뉴/String Translation 아님.

구조(2026-07-22 영문화 후):
- `footer-area-1`: `media_image-2` 로고 = **all**(한/영 공통)
- `footer-area-2`: `custom_html-2` Addr.(**ko**) + `custom_html-5` Addr.(**en**)
- `footer-area-3`: `custom_html-3` Info.(**ko**) + `custom_html-6` Info.(**en**)
- `footer-area-4`: `custom_html-4` Contact.(**ko**, 원래 all이었음) + `custom_html-7` Contact.(**en**)

영문 내용: Addr.="B1-B2, Bldg 101, 413 Seobinggo-ro, Yongsan-gu, Seoul, Korea" · Info.="CEO Jeon Eung-jun / Business Reg. No. 260-81-00732" · Contact.="Inquiry info@… / Business & Others cao@…"(문의/상담→Inquiry, 비즈니스/기타→Business & Others).

**자동화 요령(함정):** wp-admin 고전 위젯화면. ① 푸터 sidebar holder는 기본 **collapsed(display:none)** → Playwright가 select 못 봄 → JS로 `.widgets-holder-wrap`의 `closed` 제거 + 위젯 `.widget-inside` 표시 먼저. ② 위젯 DOM id 접두 `widget-<N>_`는 **페이지 로드마다 바뀜(휘발)** → 안정 식별자는 접미 `custom_html-<instance>`. ③ WPML 언어는 JS `sel.value=` 로는 저장 안 됨 → **Playwright native `select_option` + 위젯 Save** 클릭해야 영속(select가 form 안에 있어 저장됨). ④ 신규 위젯은 chooser(`.widgets-chooser-button[aria-label*=이름]`→`.widgets-chooser-add`)로 추가 후 즉시 내용·en·Save(추가 직후 기본 all이라 잠깐 KO에도 노출됨).

롤백: `custom_html-5/6/7` 위젯 삭제 + `custom_html-4`를 all로 되돌림(Appearance→Widgets, 1분·가역). 리포 커밋 없음(WP DB 설정). 증거·스크립트: scripts/poc-evidence/footer_diag.json·footer_en_*.py(scratchpad). [[reference_wp_published_page_edit_goes_live_immediately]]
