---
name: reference_no_manual_pull_rebase_let_watchers_push
description: 워처 많은 이 repo에선 수동 git pull --rebase 금지 — 커밋만 하고 워처가 push하게 둔다
metadata: 
  node_type: memory
  type: reference
  originSessionId: 2b991edb-ada2-4a9e-ae12-8a9a9c3b07d6
  modified: 2026-07-21T02:34:23.909Z
---

이 repo는 자동 커밋·push 워처가 상시 여러 개 돈다(커밋마다 auto-log·queue-mirror·erp/cpo 스냅샷 등). 여기서 **수동 `git push`가 거부(non-fast-forward)됐다고 `git pull --rebase --autostash`로 밀어붙이면 안 된다.**

2026-07-21 사고: 수동 push 거부 → `pull --rebase --autostash` 실행 → 미추적 프리뷰 png들이 incoming 트래킹 파일과 충돌해 rebase가 "could not reset --hard"로 크래시 → `.git/rebase-merge`에 `autostash`만 남은 **깨진 부분 rebase 상태** + 여러 autostash 누적 + `.git/index.lock` 경합. `git rebase --abort`도 head-name 없어 실패. 라이브 git.exe 4개(워처)가 돌아 락·rebase-merge 강제 삭제도 위험.

**올바른 패턴:**
- 내 파일은 HEAD 기반 임시 인덱스([[reference_temp_index_must_readtree_head_not_copy_live]])로 **커밋만** 한다. push는 시도하되 거부되면 **거기서 멈춘다.**
- 워처들이 정상 사이클에서 내 로컬 커밋을 조상으로 보존한 채 rebase→push해 원격에 올려준다(실측: HEAD가 adea6be7→a30e2cd9로 전진해도 내 커밋 fe9be3f9는 계속 ancestor로 보존됨).
- 예약 스케줄 작업은 워킹트리 파일(디스크)로 실행되므로, 로컬 커밋+디스크 실재면 원격 push 전이라도 다음날 실행은 보장된다.
- 락(`index.lock`)·`rebase-merge`가 남아도 **라이브 git 프로세스가 있으면 절대 손대지 마라**(동시커밋 손상). 파이프라인이 살아있으면(HEAD 전진·lock 자동해제) 스스로 수렴한다. 진짜 프리즈면 CMO가 아니라 시토(git 인프라)에 넘긴다. 관련: [[feedback_git_commit_atomic_vs_watcher_reset]]·[[feedback_no_destructive_git_in_shared_worktree]]·[[reference_guidehub_concurrent_commit_corruption]]
