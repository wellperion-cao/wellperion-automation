---
name: reference_publish_url_recovery_failure_is_not_publish_failure
description: "네이버 블로그·카페 발행 시 \"URL 회수 실패\"를 \"발행 실패\"로 오도장 → 재발행하면 중복 게시. 2026-07-20 실사고."
metadata: 
  node_type: memory
  type: reference
  originSessionId: fb16db35-b38f-4047-9fc6-af74039e997a
  modified: 2026-07-20T03:51:33.375Z
---

네이버 블로그·카페 업로더는 **게시는 성공했는데 공개 URL 회수 폴링(12초)에 실패**하면 비정상 종료코드를 반환한다. 워처가 이를 그대로 `발행실패`로 도장 → 큐 기록과 현실이 어긋나고, **재발행 시 같은 글이 두 번 올라간다.**

**2026-07-20 실사고**: 필라테스 L4 — 블로그(11:52)·카페(11:54) 실제 발행 완료 상태인데 큐엔 `발행실패`. 재발행 직전 GM이 "발행 다 됐는데 왜 또 하냐"고 잡아 중복 게시를 막음. 텔레그램 디제스트 링크도 2개만 나갔던 원인이 이것.

**교훈**: 큐 상태값을 믿지 말고 **실제 채널을 열어 확인**한 뒤 발행하라 ([[feedback_live_verify_always_then_taper_with_trust]]·약속 L03). 특히 네이버 카페는 삭제글도 200 → [[reference_naver_cafe_deleted_post_returns_200]].

**수리 (2026-07-20)**: exit 8(URL 미회수·게시 성공)을 exit 7(진짜 실패)과 분리해 새 상태 `확인필요(발행됨·URL미회수)` 도입. 이 상태는 `APPROVED_STATES`에 없어 **재발행되지 않고**, `scripts/reconcile_published.py`가 나중에 URL만 재회수해 발행완료로 자동 전환. 관련: `scripts/ig_review_publish_watcher.py`·`naver_blog_upload_playwright.py`·`cafe_upload_playwright.py`.

발행 루프 전체 맥락 → [[project_naver_danggn_publish_fortress]]·[[project_publish_verify_before_done]]
