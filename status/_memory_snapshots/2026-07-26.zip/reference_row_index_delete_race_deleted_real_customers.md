---
name: reference_row_index_delete_race_deleted_real_customers
description: 행번호(rowIndex) 기반 시트 삭제는 동시접근으로 행이 밀려 엉뚱한 행을 지운다 — 실고객 문의 2건 오삭제 사고(2026-07-20)
metadata: 
  node_type: memory
  type: reference
  originSessionId: dae787e3-8c87-499a-9c16-cfca20e666c9
  modified: 2026-07-20T01:56:44.751Z
---

**2026-07-20 사고.** 배포 검증용 테스트 문의를 넣고 `member_inquiry_delete` 로 지우는 과정에서 **실제 고객 문의 2건이 삭제**됐다(장수진/010-8816-2121, 여○○/010-5215-9886 — 둘 다 2026-05-04 접수). 대상 = `12AWcAlgmmYKr2nUbWmVpa71_z3zi0BaU4ZdnOwrI_7U` gid=1902010032.

**직접 원인:** `rowIndex` 로 삭제를 지정했는데, 삭제 호출 사이에 다른 병렬 작업이 같은 시트를 건드려 **행 번호가 밀렸다.** 첫 시도가 `row-key-mismatch` 로 실패하자 **keyPhone(대조키) 없이 재시도**해 안전장치를 우회한 것이 결정적. 안전장치가 있어도 **우회 가능하면 없는 것과 같다**(약속 L02: 정한 건 코드로 박는다).

**규칙:**
- 라이브 시트에 **쓰기 검증을 하지 마라.** 배포 확인은 읽기·스테이징으로. 실데이터 시트에 테스트 행을 넣는 순간 정리 문제가 따라온다.
- 행 삭제는 **행번호 금지 · 대조키(전화번호 등) 필수.** 키 없으면 삭제 자체가 거부되게 백엔드에서 강제.
- 실패 시 **키를 빼고 재시도하지 마라** — 실패는 "행이 밀렸다"는 신호다. 다시 읽어 키로 재확인하는 게 맞다.
- 여러 에이전트가 같은 시트를 동시에 만지지 않게 **쓰기를 직렬화**하라. 동시접근 자체가 근본 위험.

**복구:** 구글 시트 버전기록으로 되돌리면 그 시점 이후 **다른 사람의 입력까지 함께 사라진다** → 실무진 입력이 계속 쌓이는 시트에서는 위험. 삭제 직전 CSV/diff 를 확보해뒀다면 **해당 행만 손으로 재입력**하는 쪽이 안전. 삭제 전 스냅샷 확보가 복구의 전제다.

관련: [[reference_lesson_main_importrange_source_no_rowdelete]] · [[reference_inquiry_sheet_write_read_column_mismatch]] · [[feedback_no_destructive_git_in_shared_worktree]] · [[project_cpo_inquiry_system_unification]]
