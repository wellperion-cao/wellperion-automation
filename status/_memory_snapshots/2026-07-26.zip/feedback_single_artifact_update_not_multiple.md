---
name: feedback_single_artifact_update_not_multiple
description: 아티팩트는 한 번에 하나만 — 새 URL을 계속 만들지 말고 기존 전사 보드 하나를 갱신한다 (2026-07-24 GM 지적)
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d4744632-7c64-4bdd-91ba-dc18da1f6bdd
  modified: 2026-07-24T03:10:57.840Z
---

**아티팩트는 1개씩만 띄운다.** 새 주제가 생겨도 새 URL을 만들지 말고 **기존 아티팩트에 섹션으로 얹어 같은 링크를 갱신**한다.

**Why:** 2026-07-24 하루에 웰리가 항해일지·S2 읽기진단 2개를 각각 다른 URL로 발행 → GM "너 자꾸 아티팩트 2개씩 띄우던데 1개씩좀 띄워줘". 링크가 늘면 어느 게 최신인지 GM이 판단해야 하고, 그 판단 비용이 곧 안 보게 되는 이유가 된다. 약속 L19(부서 아티팩트 하나로 수렴·같은 링크 갱신)의 실행 위반이었다.

**How to apply:** 웰리(전사) 아티팩트 = **항해일지 1개**가 정본. 제안·진단·시안도 그 안의 섹션으로 넣고 같은 file_path로 재발행한다. 이미 흩어진 것은 다음 갱신 때 본문으로 흡수하고 링크를 하나로 줄인다. 관련: [[feedback_artifact_overwrite_same_link_on_upgrade]] · [[feedback_gm_prefers_designed_artifact_proposals]]
