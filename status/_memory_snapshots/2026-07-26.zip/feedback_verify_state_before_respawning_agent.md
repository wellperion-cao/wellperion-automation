---
name: feedback_verify_state_before_respawning_agent
description: "위임한 담당이 유휴(idle) 알림을 보내도 '안 했다'는 뜻이 아니다 — 새 담당을 붙이기 전에 커밋·라이브 상태로 실제 완료 여부를 먼저 확인한다"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 42954d51-e0d3-4802-a0d8-3e551a2e51ec
  modified: 2026-07-20T03:11:23.558Z
---

2026-07-20 세션에서 웰리가 **같은 작업을 두 담당에게 중복 배정한 사고가 하루 3회** 발생했다(영문 문의 상단 띠 · WPML 자동 리다이렉트 · 그 외). 매번 원인이 같았다: 담당이 `idle_notification`을 보내자 "작업을 안 하고 있다"고 판단해 새 에이전트를 스폰했는데, 실제로는 그 담당이 곧 완료했거나 이미 완료한 상태였다.

**Why:** 유휴 알림은 "지시를 못 받았다/멈췄다"가 아니라 단순히 그 시점에 턴이 비었다는 신호다. 이걸 미완료로 읽으면 중복 실행이 발생하고, 라이브 사이트·전역 설정처럼 부작용이 있는 대상에서는 서로 덮어쓰거나 원복시킬 위험이 있다. 실제로 WPML 전역 설정을 두 담당이 각각 토글했다(값이 같아 결과적으로 무해했을 뿐이다).

**How to apply:**
1. 유휴 알림을 받으면 새 담당을 붙이기 **전에** 실제 상태를 먼저 확인한다 — `git log`/`git status`로 커밋 여부, 산출물 파일 존재, 라이브 페이지 렌더.
2. 상태가 애매하면 새로 스폰하지 말고 **기존 담당에게 SendMessage로 한 번 더 확인**한다(이름으로 보내면 트랜스크립트째 재개된다).
3. 그래도 진행이 없을 때만 새 담당을 붙이고, 붙일 때는 **기존 담당에게 즉시 중단 지시**를 함께 보낸다.
4. 라이브 사이트·전역 설정·외부 전송처럼 **중복 실행이 해로운 대상**은 특히 이 순서를 건너뛰지 않는다.

[[feedback_delegate_mechanical_work_clean_screen]] · [[feedback_welly_verification_standard]] · [[reference_guidehub_concurrent_commit_corruption]] 와 같은 계열 — 위임은 하되 상태 확인은 웰리 몫이다.
