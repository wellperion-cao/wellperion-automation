---
name: feedback_never_claim_publish_without_live_url_verification
description: "발행완료는 공개 URL 라이브 실측 없이 절대 보고·마킹 금지 — 반복된 과대보고, GM \"이번이 마지막\" 경고"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2b991edb-ada2-4a9e-ae12-8a9a9c3b07d6
  modified: 2026-07-21T06:09:17.297Z
---

2026-07-21 GM 강한 경고: "이번이 마지막이야, 계속 실수하면 어떻게해." 원인 = **초안(임시저장/임시등록)인데 status·보고를 '발행완료'로 낸 과대보고가 8번쯤 반복.** 이날도 시모가 채널 디스패처(draft 하드코딩)로 임시저장만 하고 "4채널 발행 완료"로 보고 → 실제 네이버 블로그·카페는 비공개 초안이었음(카페는 결국 GM이 수동 공개발행).

**Why:** 발행은 비가역 공개 행위라 "됐다"는 말이 곧 사실로 취급된다. 검증 없는 완료 보고는 GM이 안 된 걸 됐다고 믿고 지나가게 만든다 — 신뢰 직접 훼손. 헌법 STEP3.5 실증거·[[project_publish_verify_before_done]]·[[feedback_live_verify_always_then_taper_with_trust]]·[[feedback_no_100pct_overclaim_report_actual_progress]]의 취지인데 채널 발행 경로에 강제가 안 걸려 반복됨.

**How to apply:**
- 어떤 채널이든 **'발행완료'는 공개 URL을 회수해 그 URL이 라이브(HTTP 200 + 실제 게시 내용)임을 실측한 뒤에만** 보고·마킹한다. URL 없거나 미확인이면 '임시저장/발행검증대기'로만 — 절대 발행완료 금지.
- URL 회수 실패 ≠ 발행 실패([[reference_publish_url_recovery_failure_is_not_publish_failure.md]]): 스크린샷·계정 글목록으로 공개 여부를 판별하되, **판별 안 되면 완료로 안 올린다.** 네이버 카페는 삭제글도 200([[reference_naver_cafe_deleted_post_returns_200]]) — articleId 실재까지 확인.
- 디스패처(publish_4channel_dispatcher)는 카카오·당근·네이버를 `--mode draft` 하드코딩이라 `--run`을 붙여도 공개발행 안 됨 = 실제 발행은 각 채널 스크립트 `--mode publish --i-am-sure` 직접 호출(본문파일 경로=output(채널)/ 명시). 이 구조가 draft→발행완료 오마킹의 물리적 원인.
- **박제(코드강제):** 상태를 발행완료로 올리는 경로에 '공개 URL 실측' 게이트를 넣어 검증 없이는 못 올리게 한다. 말·다짐 아니라 코드로.
- GM 응답 태도: 실수는 변명 없이 인정, "조심하겠다" 대신 **재발 불가한 구조**를 제시·구현.
