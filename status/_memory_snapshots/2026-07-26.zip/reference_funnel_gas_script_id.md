---
name: reference_funnel_gas_script_id
description: "마케팅 퍼널/문의 GAS 라이브 정본 = v2(1BezMSW, /exec AKfycbyk…, .deploy-funnel-v2). v1(1A77oDR)은 200버전 상한 은퇴(2026-07-18)"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 9300c057-51fc-40a2-8f89-2c12fcf8b748
  modified: 2026-07-22T03:47:22.685Z
---

마케팅 퍼널/문의·멤버십 GAS(intake_submit·period_breakdown·funnel_conversion·member_* 등)의 Apps Script.

## ★라이브 정본 = v2 (2026-07-22 실측 정정)
- **scriptId(v2): `1BezMSW_rGi57IrC9IoxoQzczsATVzqwFa039cigvhad0wpCBdOmhHTjQ`**
- **/exec(v2): `AKfycbykgMyFc-g_KG7x3HoKStKBwerKhYYfmbqNeFqCL5O1b_4-1nng4wEiKhkNJtfB4BWo`**
- **로컬 정본 파일: `.deploy-funnel-v2/Survey.js`** (587KB). clasp = `.deploy-funnel-v2/.clasp.json`.
- **판별 근거(실측·재현):** 라이브 멤버십/문의폼(`cpo/member/문의회원.html`·`membership.html`)이 실제로 POST하는 엔드포인트 = `AKfycbyk…`(v2). fix-utm이 v2 /exec에 라이브 POST 테스트 → 시트 기록 확인(2026-07-22).
- 멤버십 원천 시트 = "1-1) 멤버십 문의 관리(26년도)" `12AWcAlgmmYKr2nUbWmVpa71_z3zi0BaU4ZdnOwrI_7U`. 강습 시트 = `1b0XU1o…`(분리).

## ⚠️ v1은 은퇴 — 편집·배포 금지
- **v1 scriptId `1A77oDR…` / /exec `AKfycbzd…` / `.deploy-funnel/Survey.js`(373KB)** 는 **2026-07-18 GAS 200버전 상한 도달로 은퇴·백업 전용**([[reference_gas_funnel_version_limit_200]]). 07-18에 v2로 이관됨.
- ★함정(2026-07-22 2회 반복): 옛 기억·스펙이 v1을 "정본"이라 가리켜 inquiry-design 스펙·휴회 빌드가 v1(.deploy-funnel)에 작성됨 → 라이브 반영 안 됨. **폼/intake_submit/member_* 수정은 반드시 `.deploy-funnel-v2/Survey.js`.** 편집 대상 확정 전 라이브 폼의 POST /exec를 실측(추측 금지).
- 가이드 사본 `cmo/survey/apps_script_survey.js`도 드리프트본 — 라이브 아님.

## 배포
`cd .deploy-funnel-v2 && clasp push -f && clasp deploy -i <v2 deploymentId> -d "설명"` (in-place → /exec URL 유지). 트리거는 에디터서 1회. clasp 연동됨. 관련 [[reference_clasp_webapp_redeploy]] · [[feedback_gas_deploy_notepad_chrome_pair]] · [[reference_funnel_gas_script_id]].
