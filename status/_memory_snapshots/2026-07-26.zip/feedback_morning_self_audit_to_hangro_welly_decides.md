---
name: feedback_morning_self_audit_to_hangro_welly_decides
description: "각 C-Level은 아침에 본인 소유 모듈·파이프라인 문제점을 스스로 찾아 항로에 올리고, 웰리가 그걸 모아 GM 스타일대로 효율적 해결책을 판단·결정해 자율화로 밀어올린다 (2026-07-24 GM 지시)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d4744632-7c64-4bdd-91ba-dc18da1f6bdd
  modified: 2026-07-24T00:25:34.250Z
---

**상시 운영 리듬 (2026-07-24 GM 지시)**

1. **각 C-Level = 아침에 자가점검.** 본인이 소유·관리하는 모듈과 파이프라인의 **문제점을 스스로 찾아** `status/_queue.json`에 배로 올린다. GM이 지적해서 발견되는 구조가 아니라, 담당이 먼저 찾아내는 구조.
2. **웰리 = 그 배들을 확인해 판단·결정.** 무엇을 어떤 순서로, **가장 효율적이고 GM 스타일에 맞는 방식**으로 해결할지 정한다. 금지항목(💰결제·🔒보안·🚫금지·전략·공식값)은 결정하지 않고 GM 결재로 올린다.
3. **목표 = 자율화 진행 → 북극성.** 개별 수리가 목적이 아니라, 반복을 자동화해 본질에 집중하는 방향으로 누적시키는 것.
4. **GM이 PC 앞일 때 = 아티팩트로.** 진행할 내용을 아티팩트로 명확히 정리해 보여드린다(모바일일 때는 탭 인터뷰·짧은 표).

**Why:** ERP가 GM 독단으로만 커지고 되돌아오는 신호가 없다는 문제(배9806)의 조직 버전. 담당이 자기 영역 결함을 스스로 표면화하지 않으면 GM이 유일한 감지기가 되고, 그러면 GM이 검증자로 전락한다.

**How to apply:** 부팅 시 항로 표출 직후 자가점검 단계를 넣는다 — 본인 모듈 등록부(`status/module_registry.json`의 `{role}-*`)를 훑어 이상·미완·죽은 경로를 배로 올린다. 웰리는 부팅 시 그 배들을 모아 분류·결정한다. 문서가 아니라 부팅 코드 경로에 박아야 실제로 돈다([[feedback_recurring_mistakes_are_root_cause_work_not_point_fix]] · 약속 L02). 관련: [[project_northstar_g1_orchestration_erp]] · [[feedback_welly_delegate_not_execute]] · [[feedback_gm_prefers_designed_artifact_proposals]] · [[project_erp_self_improvement_loop]]
