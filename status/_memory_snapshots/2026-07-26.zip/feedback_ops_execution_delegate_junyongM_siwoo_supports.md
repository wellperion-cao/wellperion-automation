---
name: feedback-ops-execution-delegate-junyongm-siwoo-supports
description: 종합접수처 등 운영 실무 수리는 준용M가 직접 운영·시우(COO)는 직접 지시받아 실행하지 말고 준용M가 잘 굴리도록 지원·검수만
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 38434089-69dc-4af2-ba3f-2c15523f63f8
  modified: 2026-07-21T02:10:27.768Z
---

GM 방침(2026-07-21): "가능하면 시우한테 직접 지시 말고, 준용M(최준용 매니저)가 잘 운영할 수 있도록 도와줘." 종합접수처(O2) 보드 버그 수리 등 **운영 실무 실행**은 준용M 소관.

**Why:** GM은 운영 실무를 실무진(준용M)이 직접 소유·운영하는 지속 구조를 원함. 매번 시우가 대신 코드를 고치는 것 = GM이 시우한테 직접 지시하는 흐름 → GM이 줄이고 싶어 함.

**How to apply:**
- 시우 역할 = 실행자 아님. **준용M 지원·검수자.** ①붙여넣기용 프롬프트 문서 정비(비기술 언어·검증단계·최신 상태 유지) ②준용M가 수리·푸시하면 시우가 라이브 검수만.
- 시우가 직접 코드 수정 금지(준용M 소관 건은).
- 준용M는 cao 계정 AI(클로드)에 프롬프트 복붙 방식으로 실행([[feedback_field_pc_cao_single_sso]]).
- 관련 배: ship 9334 종합접수처 O2 버그 3건. 프롬프트 = status/briefs/최준용M_종합접수처_처리자버그_프롬프트_20260720.md.
- 운영 4부서 내부는 시우 소유이나([[feedback_coo_owns_ops_4dept_interior]]), 실무 실행은 실무진에게 위임하고 시우는 정비·검수로 물러선다.
