---
name: project_content_intake_module_m1
description: "콘텐츠 접수 모듈(M1) — 강사/현장 콘텐츠 상시 접수 폼→반자동 시안→검수→발행. P1(폼) 라이브, P2·P3 후속"
metadata: 
  node_type: memory
  type: project
  originSessionId: 91ff9f02-6f3c-4969-8895-f9fb96592d41
  modified: 2026-07-22T06:14:47.505Z
---

M1 "콘텐츠 접수 모듈" — 현장 콘텐츠(사진·영상·소개)를 상시 접수해 공식 톤 시안 제작→검수→발행하는 재사용 파이프라인 (2026-07-22 GM 발의, ship1197/ship747 계열).

- **P1 라이브 완료:** 접수 폼 `3. 웰페리온 가이드/cmo/intake/instructor_intake.html`(파일명은 유지·GAS_PROD 박힘). 필드=이름·분류(select, `id="f_team"`/body `team` 키)·사진 multiple(≤5, base64)·영상(≤50MB, 초과 시 드라이브 링크 폴백)·소개·회원가치·동의. Content-Type text/plain(preflight 회피).
- **백엔드 = 신규 전용 GAS**(문의 Survey와 독립). 소스 정본 `.deploy-instructor/instructor_intake.js`(doPost: base64→Drive createFile·MIME 화이트리스트·시트 appendRow·_notifyTelegram). **배포는 GM 구글계정**(Apps Script UI). exec URL 라이브 검증 완료(폼→시트 행+드라이브 폴더 실측 ok:true).
- **GM 리소스(GM 소유):** 「마케팅 접수」 시트 `INTAKE_SHEET_ID`=`1b0XU1oTHlXzBhEzUOar5GEm44vjopdO25qfsh-awDXw` · 드라이브 폴더 `INTAKE_DRIVE_FOLDER_ID`=`1ZvUrmWDemRELA_4Vm5t6RDLJ48EIlfZU` (공유드라이브 2.운영부/마케팅&회원 문의 관리/마케팅 접수). ScriptProperties에 이 2개 등록됨. 알림용 `BOT_TOKEN`·`INTAKE_CHAT_ID`는 미등록(후속=접수 텔레그램 알림).
- **M1 허브 연결:** M1 `#m1-hub` '콘텐츠 접수' 박스가 이 폼 링크. [[project_marketing_dashboard_merged_into_m1]]
- **후속:** P2=반자동 시안(접수→compose_html 캐러셀·make_reel 릴스→review_queue 검수대기→발행) / P3=M1 접수 현황 패널. 스펙 `docs/superpowers/specs/2026-07-22-강사콘텐츠-접수시안모듈-design.md` · 계획 `docs/superpowers/plans/2026-07-22-강사콘텐츠-접수모듈-P1.md`.
- **캠페인 공지:** 부서장 카톡방 발송 대기(GM 결재) — 초안 `instagram/_강사콘텐츠캠페인_공지.md`. 발송=시모 카톡전송기. [[project_ai_daily_series_official_design]]
