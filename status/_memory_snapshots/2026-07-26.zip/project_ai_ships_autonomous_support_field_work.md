---
name: project_ai_ships_autonomous_support_field_work
description: "G1의 AI 배는 자율로 쳐내고, AI의 무게중심은 실무진 실제 업무(업무&결재 SSOT·월간운영계획)가 잘 마무리되도록 서포트하는 쪽으로 이동 (2026-07-24 GM 방향)"
metadata: 
  node_type: memory
  type: project
  originSessionId: d4744632-7c64-4bdd-91ba-dc18da1f6bdd
  modified: 2026-07-24T03:11:19.071Z
---

**GM 방향 (2026-07-24)**

1. **G1에 잡힌 배들은 자율화로 쳐낸다.** AI가 만든 배·AI가 처리할 배는 GM 화면에서 판단을 요구하지 않고 스스로 굴러가 닫혀야 한다. G1이 AI 작업 목록으로 채워지면 GM이 봐야 할 것이 묻힌다.
2. **AI의 무게중심 = 실무진 업무 서포트.** 업무&결재 SSOT(S3)·월간운영계획 등 **사람이 실제로 하는 일**이 잘 마무리되도록 돕는 쪽으로 옮긴다. AI 자체 개선은 배경에서 자율로 돌고, 전면에는 실무진 일이 온다.

**Why:** AI가 자기 개선 작업으로 G1을 채우면 GM 화면이 AI 진척 보고판이 된다. GM이 보고 싶은 건 회사 일이 되고 있느냐다. 2026-07-24 하루에 웰리가 띄운 배만 10척 가까이였고 대부분 AI 내부 정비였다.

**How to apply:** 웰리는 ①AI 도메인 배는 자율 판정·실행·검증까지 사람 개입 없이 닫는 경로로 보내고(예약 러너·관문 가드), GM 결재 5종만 올린다 ②새 배를 띄울 때 "이게 실무진 일을 진전시키나, 아니면 AI 살림인가"를 먼저 묻는다 ③실무진 일(업무&결재 SSOT·월간운영계획)의 막힌 지점을 먼저 찾아 서포트 배를 띄운다. 관련: [[project_gm_key_surfaces_three_groups]] · [[feedback_welly_delegate_not_execute]] · [[project_northstar_g1_orchestration_erp]] · [[feedback_coo_stewards_monthly_ops_truth_and_progress]]
