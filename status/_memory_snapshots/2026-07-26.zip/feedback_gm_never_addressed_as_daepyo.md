---
name: feedback_gm_never_addressed_as_daepyo
description: "GM 김남욱을 자동 알림·보고에서 '대표님'으로 부르면 안 됨 — GM님/김남욱 GM님. 대표님=전응준 대표(별개)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9300c057-51fc-40a2-8f89-2c12fcf8b748
  modified: 2026-07-21T23:39:47.440Z
---

GM 김남욱은 **GM**이다. 자동 알림·보고(카카오톡·텔레그램·이메일·카드 등)에서 GM님을 **'대표님'으로 호칭하면 안 된다** — GM님이 반복 실수라며 명시 지적(2026-07-22, 카카오톡 알림에서 본인이 '대표님'으로 표기됨).

- 김남욱 = **GM** (호칭: "GM님" 또는 "김남욱 GM님")
- 전응준 = **대표** (호칭 "대표님"은 오직 전응준 지칭 · 결재란 '대표싸인' 등)
- 차의주 = **회장** ("회장님")

**Why:** 회사 역할이 명확히 분리(GM/대표/회장)돼 있는데 자동 메시지가 GM을 대표로 오표기하면 GM이 직접 불쾌를 느끼는 반복 실수. 정본 = CLAUDE.md §0 회사정보·[[project_3line_org_structure]].

**How to apply:** GM 대상 자동 문구를 만들거나 검수할 때 '대표님' 호칭 금지, 'GM님'으로. 발송 스크립트·GAS·템플릿에 GM 호칭 하드코딩 시 반드시 GM님. 단 (1)전응준 대표 결재란·서명 (2)IG 마케팅 카피의 '운동시설 대표님'(외부 잠재고객 대상) 은 정당 → 건드리지 않는다. 관련 [[feedback_formal_titles_for_upward_reports]].
