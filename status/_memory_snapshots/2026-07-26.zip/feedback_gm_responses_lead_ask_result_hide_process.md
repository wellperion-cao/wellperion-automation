---
name: feedback_gm_responses_lead_ask_result_hide_process
description: "GM 응답은 '내가 뭘 시켰나 + 결과가 뭔가'를 한눈에 찾게 — 맨 위에 GM 지시 되짚기+결과, 중간 러닝·작업·위임·에이전트 왕복은 화면 밖"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9300c057-51fc-40a2-8f89-2c12fcf8b748
  modified: 2026-07-22T08:35:17.799Z
---

GM 반복 지적(2026-07-22): "피드백 전달하고 작업 시작하면 중간에 러닝 내용이나 작업 내용들이 다 나와서, 내가 뭘 전달하고 어떤 결과가 나왔는지 잘 못 찾겠다."

**문제:** 웰리(및 C-Level)가 GM 응답에 위임 서술('~에 위임합니다')·중간 과정·에이전트 왕복 보고·'대기합니다'·러닝 내용을 화면에 늘어놓아 → GM의 **입력(무엇을 시켰나)**과 **결과(무엇이 나왔나)**가 묻힌다.

**Why:** L10·L12·L17·L18([[wellperion-gm-report]] 스킬)이 이미 "기계 작업은 서브에이전트로 화면 밖·결과 중심"을 규정하는데 실제로 안 지킴. GM은 스캔해서 자기 지시와 결과를 즉시 찾아야 함.

**How to apply (엄수):**
1. GM 응답 **맨 위 = 📌 GM이 시킨 것 되짚기 → ✅ 결과**. 이 둘이 항상 최상단·한눈에.
2. **중간 러닝·위임·에이전트 왕복·검증 과정은 화면에 나열 금지** — 서브에이전트로 조용히 처리(화면 밖). '~에 위임합니다'·'대기합니다'·에이전트 보고 원문 relay 금지.
3. 여러 건이면 각 건을 [지시→결과] 한 줄로. 진행 중이면 '진행중' 한 줄만(과정 덤프 X).
4. 상세·근거는 접거나 GM이 물을 때만. 정본 = [[wellperion-gm-report]] 스킬 + [[feedback_gm_reports_short_scannable]]·[[feedback_report_pages_minimal_helper_text]].
