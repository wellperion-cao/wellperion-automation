---
name: project_marketing_dashboard_merged_into_m1
description: "콘텐츠→문의 성과 대시보드 = 독립 페이지 cmo/funnel/콘텐츠문의현황.html (2026-07-22 M1에서 추출). M1은 O1식 박스 허브로 단순화·박스가 이 페이지 링크"
metadata:
  node_type: memory
  type: project
  originSessionId: f473f4b7-788a-4030-bbff-6564ce545024
  modified: 2026-07-22T06:14:00.402Z
---

콘텐츠→문의 성과 대시보드의 위치 이력·현행.

- **[2026-07-18] M2 삭제 → M1 인라인(`#m1-dash`) 통합**: 구 `cmo/funnel/마케팅현황대시보드.html`(M2) 삭제·재생성 금지(이 파일명은 지금도 404 정상).
- **[★2026-07-22 현행] GM 지시로 M1을 O1식 네모박스 허브로 단순화 → `#m1-dash` 인라인 대시보드(~1000줄)를 독립 페이지 `3. 웰페리온 가이드/cmo/funnel/콘텐츠문의현황.html`로 추출.** 이제 **정본 = 콘텐츠문의현황.html (standalone)**. M1의 `#m1-dash` 인라인은 **제거됨**. M1은 `#m1-hub`(박스 6개: 콘텐츠 접수·콘텐츠 문의 현황·기반·검수·발행·문의 진입점)에서 박스로 이 페이지 링크. 커밋 6e5d7bea.
- **추출 페이지 구조:** M2 JS 전체가 하나의 IIFE로 격리(onclick=`window.M2DASH.{switchPeriod,shiftMonth,toggleCustomRange,runCustomQuery,loadYearToDate,printDash}`), CSS는 `#m1-dash` 스코프 자기완결(전역 의존 없음 — 그래서 추출해도 안 깨짐, 라이브 실측 확인). fetch 경로는 새 위치 기준 조정됨: `../review/review_queue.json`, `월간마케팅보고서.html`(동일 폴더). GAS(funnel_conversion)·IG원장은 절대 URL.
- **데이터 지연:** GAS 집계 ~10초 → 초기 스켈레톤 후 채워짐(정상). 검증은 15초+ 대기 후. period-status 단일 소스=`refreshPeriodSections()`(조기 '완료' 표기 금지).
- **④ 게시글별 성과 = 삭제 유지·재추가 금지(2026-07-18 GM).** 이유: IG·당근은 게시글별 추적 URL 없이 bio 링크로 문의 접수 → 게시글별 문의 귀속 원천 불가. 채널 단위(③)가 최선. 블로그·카페만 부분 가능.
- **폼 일반화(같은 세션):** M1 접수 폼 `cmo/intake/instructor_intake.html`은 '강사 콘텐츠 접수'→'콘텐츠 접수'로 일반화(파일명·GAS_PROD·`id="f_team"`·body `team` 키는 유지=백엔드 무변경). M1 허브 '콘텐츠 접수' 박스가 링크. 상세 [[project_content_intake_module_m1]].
- 관련 [[project_conversion_funnel_leak_diagnosis]] · [[feedback_cmo_mission_dashboard_normalization]] · [[reference_guidehub_concurrent_commit_corruption]](원샷 커밋 필수·공용 인덱스 스윕 주의).
