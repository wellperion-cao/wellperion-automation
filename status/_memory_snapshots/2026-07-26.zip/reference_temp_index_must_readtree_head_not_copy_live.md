---
name: reference_temp_index_must_readtree_head_not_copy_live
description: 격리 커밋용 임시 인덱스는 라이브 인덱스 복사 말고 read-tree HEAD로 시작해야 자기 파일만 커밋된다
metadata: 
  node_type: memory
  type: reference
  originSessionId: 2b991edb-ada2-4a9e-ae12-8a9a9c3b07d6
  modified: 2026-07-20T21:24:35.254Z
---

파일 하나만 격리 커밋하려고 임시 인덱스를 만들 때 **라이브 `.git/index`를 복사(cp)하면 이미 staged된 남의 변경이 전부 딸려온다.** 2026-07-21 사고: `cp .git/index tmp && GIT_INDEX_FILE=tmp git add 내파일.md && commit` 했더니, 그 시점 shared index에 이미 staged돼 있던 Survey.js·_queue_archive.json(3355줄)·backups 삭제 3종까지 한 커밋에 묶여 push됨(라벨은 "docs(cmo) 채널귀속"뿐). 데이터 손실·손상은 없었으나 커밋 라벨이 실제 내용보다 넓어짐. push+워처 후속커밋까지 끝나 되돌리기 불가(파괴적 git 금지).

**올바른 방법:** 임시 인덱스를 **HEAD 트리로 초기화**해서 staging을 비운 뒤 내 파일만 add.
```
TMPIDX="$(git rev-parse --git-dir)/tmp-idx"
GIT_INDEX_FILE="$TMPIDX" git read-tree HEAD   # cp 아님 — HEAD로 빈 staging 시작
GIT_INDEX_FILE="$TMPIDX" git add "내파일"
GIT_INDEX_FILE="$TMPIDX" git commit -m "..."
rm -f "$TMPIDX"
```
이러면 shared index의 pre-staged 변경과 무관하게 자기 파일만 커밋된다. 관련: [[reference_temp_index_commit_leaves_stale_shared_index]]·[[feedback_git_commit_atomic_vs_watcher_reset]]·[[reference_guidehub_concurrent_commit_corruption]]
