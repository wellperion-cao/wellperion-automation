---
name: feedback_staff_room_messages_introduce_ai_persona
description: "실무진 방에 나가는 AI 안내는 항상 어느 AI인지 소개하고, 첫 셋업 안내는 질책이 아닌 \"이제부터 이렇게 안내한다\" 어조로"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: a6d504f5-1648-421d-95bc-8d09d51cd1b5
  modified: 2026-07-23T01:36:43.321Z
---

실무진 단체방으로 나가는 AI 자동 안내는 **항상 어느 AI가 보내는지 밝히며 시작**한다
(예: "안녕하세요, 웰페리온 AI 마케팅 담당 시모입니다."). 그리고 어떤 항목이 쌓여 있는
상태를 처음 안내할 때는 **질책이 아니라 셋업 공지 어조**로 쓴다 — "지금 쌓인 건은 그동안
안내 체계가 없어서 모인 것이라 어느 분의 잘못도 아니다 / 앞으로는 이렇게 챙겨 알려드리겠다".

**Why:** 정체불명 자동 메시지로 읽히면 받는 분이 누구에게 되물어야 할지 모른다. 또 첫 안내가
질책조면 도입 자체에 반감이 생긴다 — 쌓인 적체는 사람 잘못이 아니라 체계가 없던 결과다.
(GM 2026-07-23, 미배정 문의 51건 배정 독려 안내 셋업 때 지시)

**How to apply:** 실무진 방 발신 모듈에 소개 문구를 상수로 두고 본문 맨 앞에 붙인다
(`scripts/unassigned_nudge.py` 의 `AI_INTRO`가 첫 사례). 배정·독려류 안내에는 **바로 갈 수
있는 화면 링크와 입장 코드**까지 함께 넣는다 — 화면이 갈려 있으면(멤버십/강습) 링크를 따로
준다. 테스트 발송은 언제나 GM 개인 봇방(8254867551)으로 먼저 보내 확인받은 뒤 실무진 방으로
전환한다. 관련: [[feedback_test_sends_go_to_report_room]] ·
[[feedback_publish_digest_standard_and_staff_room_quality]] ·
[[feedback_content_tone_gentle_inform_not_sell]]
