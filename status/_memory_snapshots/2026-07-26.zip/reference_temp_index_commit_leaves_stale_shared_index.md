---
name: reference_temp_index_commit_leaves_stale_shared_index
description: GIT_INDEX_FILE 임시 인덱스로 커밋하면 공용 인덱스에 옛 blob이 남아 자동커밋이 그 커밋을 되돌린다 — 끝에 git reset -- <파일> 필수
metadata: 
  node_type: memory
  type: reference
  originSessionId: dae787e3-8c87-499a-9c16-cfca20e666c9
  modified: 2026-07-20T09:49:58.537Z
---

R8 임시 인덱스 커밋 프로토콜(`GIT_INDEX_FILE=$T/idx` → `commit-tree` → `update-ref HEAD`)은
**HEAD만 갱신하고 공용 인덱스는 손대지 않는다.** 그래서 커밋 직후 공용 인덱스에는 **커밋 직전의 옛 blob**이 남는다.

증상: `git status`가 해당 파일을 `MM`으로 표시(staged=인덱스vsHEAD 역방향 diff + unstaged=워킹트리).
위험: 이 상태에서 공용 인덱스를 쓰는 자동발행/자동커밋 스크립트가 돌면 **방금 만든 커밋이 통째로 되돌아간다.**
2026-07-20 실제 발생 — 커밋 `19a622aa` 직후 인덱스 blob이 커밋 이전 버전이었다.

**해결: 임시 인덱스 커밋 뒤 반드시 붙인다.**
```
git reset -q -- <내파일>
```
인덱스 엔트리만 HEAD에 맞춘다. 워킹트리는 안 건드리므로 **다른 워커의 미커밋 작업이 같은 파일에 있어도 보존된다.**
확인: `git ls-files -s -- <파일>`의 blob == `git rev-parse HEAD:<파일>`, `git diff --cached -- <파일>`이 비어야 한다.

주의: 공용 워크트리에서 ` M`으로 남은 변경이 **내 것이라고 단정하지 마라.** 위 사고 때 남은 ` M`은
시모(CMO)의 미커밋 작업(`renderAllChannels`)이었다. 커밋 전 `git diff HEAD -- <파일>`로 내용을 확인한다.

관련: [[feedback_git_commit_atomic_vs_watcher_reset]] · [[feedback_no_destructive_git_in_shared_worktree]]
