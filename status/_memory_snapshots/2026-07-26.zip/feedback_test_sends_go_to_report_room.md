---
name: feedback_test_sends_go_to_report_room
description: 텔레그램 알림 테스트 발송은 항상 업무보고방(Chat ID 8254867551)으로 — 실무진 방 아님
metadata: 
  node_type: memory
  type: feedback
  originSessionId: dae787e3-8c87-499a-9c16-cfca20e666c9
  modified: 2026-07-20T03:51:49.303Z
---

새 알림·발송물을 시험할 때는 **항상 업무보고방**(@namuki_report_bot · Chat ID 8254867551)으로 먼저 보낸다. 실무진 방·핵심멤버 방으로 바로 쏘지 않는다. (2026-07-20 GM: "테스트는 항상 업무보고방에 넣어줘")

**Why:** 실무진 방에 시험 메시지가 섞이면 신뢰가 깎이고, 형식이 덜 다듬어진 채 나가면 사람들이 알림 자체를 무시하게 된다. 업무보고방은 GM이 보는 곳이라 형식·내용을 먼저 합의하고 내보낼 수 있다.

**How to apply:** 새 알림을 만들면 ①업무보고방으로 1회 발송 → ②GM 확인·수정 → ③확정 후에만 실무진 방 배선. 정기 발송 자동화는 시토(CTO) 소관이므로 내용 확정 후 인계한다(내용=각 C-Level, 배선·스케줄=시토).

관련: [[project_telegram_3room_split]] · [[feedback_cto_owns_telegram_issues]] · [[feedback_publish_digest_standard_and_staff_room_quality]] · [[reference_telegram_burst_send_flood]]
