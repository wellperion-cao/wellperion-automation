---
name: feedback_exhaust_automation_before_asking_gm
description: 수동 단계(clasp login 등)를 GM께 떠넘기기 전 직접 끝까지 시도. clasp invalid_rapt는 일시적
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 11a755b4-f00e-4ff6-979f-4e7dac9012cd
  modified: 2026-07-20T08:27:32.682Z
---

GM 피드백("로그인 되어있을텐데 너무 나한테 시키는거 아니냐?") — clasp 재배포 시 서브에이전트가 `invalid_grant / invalid_rapt`(reauth) 에러를 받자 곧바로 GM께 `clasp login` 수동 실행을 요청했는데, GM이 직접 재시도하라 지적. 메인에서 `clasp push -f` 직접 재실행하니 **바로 성공**(Pushed 3 files) → deploy @105까지 무인 완료.

**Why:** clasp의 `invalid_rapt`는 일시적 reauth 신호일 때가 많아 재시도로 풀린다. 한 번 실패했다고 사람 손으로 넘기면 불필요하게 GM 시간을 뺏는다. 웰리는 위임·검증이 본업이나(=[[feedback_welly_delegate_not_execute]]), GM에게 수동작업을 떠넘기는 것과는 별개 — 자동화로 끝낼 수 있는 건 끝까지.

**How to apply:** 인증·배포·네트워크 류 에러는 GM 액션으로 올리기 전 ① 메인/서브에서 직접 1~2회 재시도 ② 다른 경로(직접 명령) 시도. 진짜 사람만 가능한 대화형(브라우저 동의 신규) 단계가 확실할 때만 GM께. funnel 재배포 절차 정본=[[reference_funnel_gas_script_id]].

**보강 (2026-07-20 GM):** "배포 대기가 아니라 뚫어야지. 그리고 내 도움이 필요하면 도움 요청을 해야하고." → **"배포 대기"·"권한 필요" 같은 미완 상태로 보고를 끝내지 말 것.** 끝까지 뚫거나, 정말 사람만 가능한 지점이면 **GM이 그대로 따라 할 수 있는 구체적 한 줄**("브라우저에서 `<정확한 명령>` 1회 실행")로 도움을 요청한다. 막연한 대기 보고 = 일을 GM에게 떠넘긴 채 멈춘 것.
