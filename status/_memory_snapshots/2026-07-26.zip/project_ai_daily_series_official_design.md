---
name: project_ai_daily_series_official_design
description: 개인계정 AI하루 시리즈 = 공식 디자인·소프트 마무리·AIDAY 매일 드립 (2026-07-22 GM 방향확정)
metadata: 
  node_type: memory
  type: project
  originSessionId: 91ff9f02-6f3c-4969-8895-f9fb96592d41
  modified: 2026-07-22T03:21:59.721Z
---

개인계정(@namuk.wellperion) "AI하루 — 폰 하나로 회사를 본다" 시리즈(ship9457, 실전사례 종결 후속)의 확정 사양 (2026-07-22 GM).

- **디자인 = 공식계정과 동일** (`compose_html.py` paper 템플릿, account="official": 베이지·W풀로고·볼드 헤드라인·`[[단어]]` 손그림 동그라미 강조·회색 본문·"WELLPERION·한남동" 풋터·카운터). 정본 참조 = `instagram/260714_L시리즈_성인강습_paper/L6_그룹.json`. **손글씨 다이어리(render_hand_slides) 폐기 — GM이 명시적으로 공식 디자인으로 전환.**
- **내용 = 간결** (헤드라인 + 본문 1~2줄). 실무(AI가 항로·현황 정리·보고) × 마음·이타(정리되면 차분→방향이 조급함 줄임→여유가 곁에도)를 뒤 1~2장에만 은근히. 긍정·철학은 슬로건 아니라 실무 이야기에서 우러나게. 자기계발 클리셰·설교조·자랑 금지.
- **마지막 슬라이드 = 소프트 마무리** (판매/문의 CTA 금지). "저도 아직 배우는 중이에요" 류. 공식 L시리즈의 '문의 : ...' CTA는 개인 AI하루엔 안 넣음.
- **발행 = 매일 아침 드립** (반무인·게이트 유지). 9편을 `-AIDAY0N` id + status `검수대기`로 review_queue 등록 → `ai_daily_series_card.py`가 07:30 주중 최저회차 1장 검수카드 드립(start_ig_series_producer.bat) → GM 텔레그램 [승인] → 발행. 주말 스킵. 자동발행 아님.
- 각 편 spec = `<폴더>/ep0N_official_spec.json`. 관련 [[project_namuk_operator_case_series]] [[project_ig_personal_publish_0730_m5]] [[reference_handwriting_slide_engine]](구 디자인).
