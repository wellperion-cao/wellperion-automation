---
name: project_gm_key_surfaces_three_groups
description: "GM 핵심 관리 표면 = 3묶음(자율현황 / 헌법한장&S2 / G1항로&업무결재SSOT&월간운영계획). 살아있는 표면(라이브 현황+지속 개선·단순화)이지 '완료'가 아님"
metadata: 
  node_type: memory
  type: project
  originSessionId: 9300c057-51fc-40a2-8f89-2c12fcf8b748
  modified: 2026-07-22T08:29:40.566Z
---

GM(김남욱)이 직접 관리·주시하는 핵심 표면 = **3묶음**(2026-07-22 GM 확정):
1. **자율현황** — 자동화가 실시간 뭘 하는지 (자율작업현황 보드·T2 병합·module_registry 직독)
2. **헌법한장 & S2** — 원칙·약속·R/R·운영헌법·구조헌법·교육 (S2=웰페리온 ERP 운영가이드 / 헌법한장=CONSTITUTION.md 구조 메타층)
3. **G1 항로 & 업무결재 SSOT & 월간 운영계획** — 오늘 할일(G1) + 결재 현황(업무&결재 SSOT S3/S4) + 월간 운영계획(시우 배9678)

**★핵심 원칙 — 이것들은 '완료/최종'이 아니라 '살아있는 표면'이다:**
- ① **계속 라이브로 현황**을 볼 수 있어야 한다(실시간 데이터).
- ② **계속 개선·단순화**돼야 한다(예: 2026-07-22 소통 약속 축약+wellperion-gm-report 스킬화, 4대 페이지 감사 정리).
- '정착'이라 부를 수 있는 건 **구조(뼈대)의 안정**뿐 — 내용은 끝나지 않는다. GM이 "4개 최종 정착"이라는 표현을 정정: "구조 얘기냐? 계속 라이브·개선·단순화돼야 한다."

**How to apply:** GM 핵심 표면 작업 시 '완료' 프레임 금지 — 라이브 현황 정확성 + 지속 개선·단순화 관점으로. 이들 표면을 라이브 전환할 땐 additive·드리프트 0·라이브 현황 실측 검증. 관련 [[project_erp_self_improvement_loop]](ERP 스스로개선 루프)·[[feedback_always_structure_simplify_advance]]. 5개로 쪼개지 말고 GM의 3묶음 모델로 소통.
