---
name: project_hangro_review_destination_brain
description: "웰리 항로 검수·종착지 두뇌 모듈(hangro_review) — GM 2026-07-21 지시로 신설, 게이트 OFF 휴면, 자율현황 등록"
metadata: 
  node_type: memory
  type: project
  originSessionId: 432738aa-b346-4305-a003-23ed1d699b26
  modified: 2026-07-21T02:50:40.300Z
---

GM 2026-07-21 지시: "항로의 각 배에 종착지(다음 한 수+최종 북극성)를 AI가 추천 제안하는 파이프라인". 흩어진 북극성추천·표류감지·next촉구를 **단일 모듈로 통합**. 배는 아무 C-Level이나 띄우되 **검수+종착지 생성=웰리, 당분간 GM과 함께 결정**(제안만). 배별 즉시 핑.

**산출물 (마스터 반영·origin 푸시 완료):**
- `scripts/hangro_review.py` — 검수 5종(done_look_not_done·stale·drift·mislabel·no_destination, read-only) + `generate_destination`(LLM 두뇌·저확신 라벨·규칙 폴백) + dedup 원장(`status/hangro_decisions.jsonl`, key=ship_no+문맥해시·날짜미포함) + `ping_gm`(간격제어 429방어) + `apply_on_approval`(게이트 뒤 `clevel_post_action --next` 배관) + CLI(`--dry-run` 기본/`--send`/`--audit-only`).
- `scripts/hangro_review.bat` + `launchers/hangro_review_hidden.vbs`(ASCII·기본 dry-run) · `tests/test_hangro_review.py`(23 passed).
- `status/module_registry.json` → **`ceo-hangro-review`** 등록(front_card=자율현황·layer-autonomy·autonomy=propose·휴면). GM은 자율현황 보드만 보면 됨.
- 스펙 `docs/superpowers/specs/2026-07-21-웰리-항로-검수-종착지-두뇌-design.md` · 계획 `docs/superpowers/plans/2026-07-21-...두뇌.md`.

**핵심 안전:** 게이트 **`HANGRO_APPLY` 기본 OFF = 라이브 델타 0**(제안만·큐/발송 0). 라이브 발효(카드 실발송·항로 반영)=**GM go 후에만**. 검수 read-only. 저확신/파싱실패=정직 라벨(거짓 종착지 금지). Opus 최종리뷰 통과(Critical 0).

**라이브 발효 전/후속 잔여:**
- 5분 폴러 트리거 미구현(스펙 §8) · 아침 06:30 역할 북극성 추천 카드 승격(층 A·GM 결정 UI 일원화).
- **Task 9(BLOCKED-ON-CTO)**: `gm_aide_scan.py`의 next_augment placeholder 은퇴→hangro_review 일원화 = **시토 배9420(자율화 모듈 병합) 완료 후에만** 착수. 지금은 gm_aide_scan 무변경(충돌 방어).
- verdict별 status 매핑 이미 반영(COMPLETION_VERDICTS=drift/done_look_not_done만 완료·활성 배 오완료 방지).

**빌드 교훈:** 격리 워크트리(`.claude/worktrees/hangro-review-brain`)에서 subagent-driven TDD로 빌드. 공유 워크트리 훅(auto-log·auto-push·mirror-sync)이 매 커밋마다 `_queue.json` 오염+커밋 생성 → 리뷰 diff는 모듈 파일 pathspec 스코프로 잡음 배제. 마스터 반영 시 index.lock 경쟁 극심(5 C-Level 세션 동시 커밋·hung git 프로세스 76s+) → 락 대기 재시도로 관통. module_registry는 동시 세션(시토)이 덮어써 1회 유실→JSON 로드-삽입-쓰기로 재추가. 관련: [[reference_guidehub_concurrent_commit_corruption]] [[feedback_git_commit_atomic_vs_watcher_reset]] [[project_gm_aide_autonomy]] [[project_bridge_mechanized]] [[project_daily_northstar_recommender]]
