---
name: reference_pc_auto_shutdown_2330
description: PC가 매일 22:30 조기종료하던 미스터리 — 진범=숨은 SYSTEM 예약작업. 2026-06-16 삭제·00:30 단일화로 해결(INC-002 GUARDED)
metadata: 
  node_type: memory
  type: reference
  originSessionId: 294203ff-a3e2-4cfa-a593-9766af39a0f4
---

**✅ 해결(2026-06-16).** PC가 매일 22:30:01에 죽던 진짜 원인 = **숨은 SYSTEM 권한 예약작업 `\cto-daily-pc-power-cycle-shutdown`**(시간트리거 22:30:00 → `shutdown.exe /s /f /t 0`, 실행계정 NT AUTHORITY\SYSTEM). AI CTO(시토)가 만든 유령 자동화로 추정. **관리자 UAC로 `schtasks /delete` 삭제 + 재조회 부재확정.** 종료작업은 `\Welperion\Auto-Shutdown-2330`(00:30) **단 1개로 단일화**(다음 실행 매일 00:30, 23:00 보고 뒤라 안전).

**🔑 왜 3일+ 미해결이었나 (핵심 교훈):** 옛 진단의 "예약작업 389개 전수 스캔, 22:30 트리거 0건"이 **틀렸다** — `Get-ScheduledTask`·`schtasks`·작업파일(`C:\Windows\System32\Tasks\...`)은 **SYSTEM 권한 작업을 비관리자 세션에 아예 안 보여준다**(전부 Access Denied). 그래서 진범이 스캔에 안 잡혔고 헛다리(`Auto-Shutdown-2330` 23:30→00:30)만 만졌다. '−1h 버그'는 두 작업 시각차(23:30 vs 22:30) **우연**이었지 오프셋 버그가 아님.

**✅ 진범을 잡은 방법(재현 가능):** `Microsoft-Windows-TaskScheduler/Operational` 운영로그를 종료시각 ±2분으로 필터 → **이벤트 107(시간트리거 launch)·129(프로세스 생성)·200(액션 실행)** 가 실행된 작업 경로·액션을 정확히 지목한다. 비관리자라도 oplog는 읽힌다. → **숨은 SYSTEM 종료작업 추적 = Get-ScheduledTask 말고 oplog 107/129/200.**

**운영 팁:** 종료시각 정답 = 트리거 표시값 아니라 **System 이벤트 1074**(종료 개시 프로세스·계정 포함) + 6006(로그 중지=종료 순간). 작업 삭제/생성은 진짜 관리자(UAC RunAs) 필요.

**⚡ 자동 켜기(전원 ON) = BIOS RTC 알람, Windows 아님(2026-07-10 확인).** 밤 00:30 `shutdown /s`로 **완전 종료(S5)**되므로 아침 부팅은 Windows 예약작업이 못 한다(S5는 소프트웨어가 못 깨움) — 매일 아침 자동 부팅은 **BIOS RTC Alarm Power On**이 담당. 메인보드 **ASRock B760M-HDV/M.2**(AMI UEFI, F2/Del 진입 → Advanced → ACPI Configuration → `RTC Alarm Power On`). 하이버네이트(S4) 비활성·S3만 지원. **RTC 시각 변경은 펌웨어라 OS/원격 불가 = GM 물리 BIOS 수동.** 현재 기본 06:00 자동켜기(→GM 2026-07-10 05:00로 변경 요청). 이 RTC 부팅이 06:30 보좌스캔·08:00 CEO보고 등 아침 무인 자동화의 전제. ※소프트웨어로 하려면 밤 완전종료→S3 절전 전환 필요(GM은 완전종료 유지 선호).

**잔여:** INC-002 = GUARDED. 최종 행동확인(오늘밤 22:30 미종료·23:00 보고 생존·00:30 단일종료)은 `CEO-2026-06-16-PC-SHUTDOWN-VERIFY-OVERNIGHT` 항로로 내일 아침 oplog 실측.

링크: [[feedback_auto_task_trigger_policy]] · [[reference_powershell_scheduledtasks_limitation]] · [[reference_scheduled_task_hidden_window]] · [[project_ssot_canon_incidents]]
