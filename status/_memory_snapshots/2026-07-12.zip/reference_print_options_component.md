---
name: reference_print_options_component
description: 전 가이드 페이지 공용 인쇄 옵션 드롭다운 컴포넌트 (A4/A3·세로/가로·항목선택)
metadata: 
  node_type: memory
  type: reference
  originSessionId: ac72b438-1642-4dbf-ace0-7a583b563e64
---

가이드 페이지 인쇄 옵션 드롭다운 = 공용 컴포넌트 `3. 웰페리온 가이드/_assets/print_options.js` (자체완결·외부의존0). 2026-07-04 GM 요청, 26페이지 롤아웃 완료.

**적용법:** 페이지 `</body>` 직전에 `<script src="/wellperion-automation/_assets/print_options.js"></script>` 한 줄. (절대경로 — Pages는 `3. 웰페리온 가이드/`를 루트로 배포하므로 `/wellperion-automation/_assets/...`가 정본. [[reference_pages_url_no_guide_prefix]])

**동작:** ①기존 인쇄 트리거([onclick*=print]·🖨️/인쇄 텍스트) 탐지→드롭다운 승격 ②트리거 없으면 우상단 **플로팅 버튼 폴백** ③옵션=용지 A4/A3·방향 세로/가로·인쇄 항목 체크(h2/section 자동 감지) ④`<style id="po-page-style">@page{size:..}</style>` 동적 주입(페이지 자체 @page보다 뒤=우선) ⑤미선택 섹션=`po-print-hide` 클래스로 @media print 숨김 ⑥localStorage `wlp_print_opts` 기억. 인쇄 시 버튼 숨김.

**주의:** `_assets/`는 반드시 `3. 웰페리온 가이드/` 하위(레포 루트 아님=Pages 404). 컴포넌트는 비파괴(DOM 재배치 없음·클래스만).

**미해결(별도):** `chro/hub/index.html`이 마스터에서 파일 잘림(JS 중간 끊김·닫는태그 없음) = 손상 페이지·include 제외. git 이력 복원 수리 필요.

**예외 — 4부서 체계 페이지(2026-07-07 GM "인쇄 버튼 1개"):** `coo/check/{지원부·시설부·운영부·주차관리부} 체계.html`은 A3 완성문서(가이드라인·매뉴얼·온보딩·점검부서 월간보고/휴관 등)가 많아 **커스텀 「🖨 인쇄 ▾」 단일 드롭다운**(openTabDropdown/closeAllDropdowns + #printDropdownBtn/#printDropdownMenu)으로 통일. print_options.js가 만든 #po-toggle-btn과 **2개 공존이 GM 지적** → 이 4페이지에선 **print_options.js include 제거**, 용지·방향 대신 각 A3 함수가 이미 자기 @page 지정. "현재 화면 그대로 인쇄"(window.print())는 드롭다운 맨 아래 항목으로 흡수. 낱개·본문 인쇄버튼 전부 이 하나로 수렴(커밋 a47075ba·7cf7a506·1c8e86d0·주차 15363895). 즉 문서선택형=커스텀 드롭다운 / 단순 화면인쇄형=print_options.js 컴포넌트로 용도 분리.
