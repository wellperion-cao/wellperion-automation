---
name: project_approval_pin_key_parity
description: 결재 부서장 PIN 키 결정 순서 = 프론트 deptHeadNameOf와 서버 _mid가 반드시 동일(결재요청→담당자→카테고리)
metadata: 
  node_type: memory
  type: project
  originSessionId: 98446150-8164-4f2d-937e-995ad0ca3057
---

결재현황 SSOT의 부서장 결재에서 **프론트가 표시하는 부서장**과 **서버가 비번을 대조하는 부서장**은 같은 순서로 계산돼야 한다. 어긋나면 "비밀번호가 일치하지 않습니다" 거부가 난다(비번이 맞아도).

- **정본 순서: ① 결재요청(GM 지정 최우선) → ② 담당자 → ③ 카테고리.**
- 프론트: `3. 웰페리온 가이드/coo/todo/결재 현황 SSOT.html` `deptHeadNameOf()`
- 서버: `.deploy-todo/업무&결재 현황.js` + 작업본 `…/coo/todo/apps_script_todo.js` 의 `role==='부서장'` PIN 블록 `_mid`
- 부서장→키: 이경연 실장=`APPROVAL_PIN_OPS` / 이정헌 소장=`APPROVAL_PIN_FAC` / 나우열M=`APPROVAL_PIN_PARTNER`. 실제 PIN 값은 GAS ScriptProperties에만(서버), 코드엔 키 이름만.

**2026-06-15 버그**: 서버 _mid가 담당자 우선(담당자→카테고리→결재요청)이라, 시설 건(담당자=이경연/OPS, GM이 결재요청=이정헌/FAC 지정)에서 화면은 이정헌(FAC) 요구·서버는 OPS 대조 → FAC 비번 거부. 서버 순서를 프론트와 동일하게 정렬해 해결. 동시 보강: PIN 비교 `trim`(저장값/입력값 공백·개행 방어), 거부 응답에 `pinKey`(대조한 키 '이름'만, 값 미노출) 진단 반환.

**Why**: 두 파일이 같은 "누가 결재자인가"를 독립 계산하는데 순서가 달라 라벨↔검증이 분리됨. **How to apply**: deptHeadNameOf 또는 _mid 중 하나를 손대면 반드시 나머지도 같은 순서로 맞춘다. 수정 후 GAS 재배포 필수 — clasp 인증 신선해야 push 먹음(만료 시 조용히 실패), 기존 배포 id로 `clasp deploy -i <id>` 재배포해야 /exec URL 유지. [[reference_clasp_webapp_redeploy]] [[feedback_dept_system_link_parity]]
