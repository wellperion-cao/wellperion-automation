---
name: feedback_single_image_set_all_channels
description: 콘텐츠 이미지/영상은 채널별 개별 수정·복제 금지 — 수정된 단일 최종 세트 1벌을 만들고 모든 채널이 그걸 가져다 쓴다
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 644d85ba-fbd1-4fc9-8170-ce95d1fcc47a
---

GM 확정(2026-06-08). **다음번 콘텐츠 이미지&영상 작업부터 적용.**

원칙: 콘텐츠의 이미지·영상은 **수정된 최종본 1세트(단일 원본)** 만 만들고, 네이버블로그·카페·카카오·당근 등 **각 채널은 그 단일 세트를 '가져다' 사용**한다. 채널별 폴더에 사진을 따로 복제하거나 채널마다 개별 수정하지 않는다.

**Why:** 2026-06-08 바레 4채널에서 채널별 폴더에 이미지를 복제·개별 처리하다가 드리프트 사고 — litt.ly 수정이 일부 슬라이드/일부 채널에만 반영, 채널 폴더 장수 불일치(7/7/7/5), 깨진 참조(ig_01.jpg) 발생. 단일 원본이면 한 곳만 고치면 전 채널 일관.

**How to apply (다음 콘텐츠 슬라이드 제작분부터 — GM 2026-06-08 확정):**
- **슬라이드(이미지)+영상은 `output(인스타그램)/` 폴더에만 제작** = 단일 원본(SSOT). 인스타그램만 만든다.
- **다른 채널 폴더(블로그·카페·카카오·당근)에는 캡션·큐레이션 등 텍스트만** 둔다. 채널 폴더에 이미지/영상 복제하지 않는다.
- 모든 채널 업로드 시 이미지+영상은 **`output(인스타그램)`에서 가져와 반영.** review_queue 채널 엔트리 image_dir = `output(인스타그램)`로 통일.
- **표지 파일명은 정렬상 맨 앞**에 오게(예: `ig_00.jpg`). ⚠️ 교훈(2026-06-08 바레): 업로더가 파일명 정렬로 올려서 `ig_main`이 맨 뒤로 감 → 표지는 ig_00 등으로.
- 수정 발생 시 인스타그램 output 1세트만 고침 → 전 채널 자동 반영. 채널별 재작업 금지.
- 영상: 단일 mp4 1벌(output(인스타그램)) 공유. ※현재 네이버/카카오/당근 자동 업로더는 mp4 미지원 → **영상은 GM 수동 첨부** [[project_4channel_dispatcher]].

연관: [[project_ig_content_folder_standard]] · [[feedback_visual_reuse_reference_generator]] · [[project_slide_engine_canva_independence]].
