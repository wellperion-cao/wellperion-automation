---
name: COO 이슈 응답 시트 공식 명칭
description: 26년도 리셉션 업무 시트 내 컴플레인 접수 탭의 공식 명칭은 「이슈 응답」(GID 동적 조회). 기존 「회원 컴플레인」 명칭 폐기.
type: project
originSessionId: a276f2e8-00b0-4bbc-8729-5616391cdd5b
---
26년도 리셉션 업무 시트 내 컴플레인·이슈 접수 탭의 공식 명칭은 **「이슈 응답」**이다. 어제(2026-05-10) 셋업 시 임시 명칭 「회원 컴플레인」으로 PropertiesService에 박혀 있었으나, 2026-05-11 GM님이 정식 명칭을 「이슈 응답」으로 통일.

**Why:** "회원 컴플레인"은 부정적 어휘로 회원 응대 톤·내부 기록 톤 모두 부적합. "이슈 응답"이 선제적 서비스 철학(AI COO 페르소나)에 부합하는 중립 어휘.

**How to apply:**
- Apps Script `apps_script_coo_issue_notifier.gs` 및 PropertiesService `TARGET_SHEET_NAME`은 「이슈 응답」으로 유지.
- 신규 .bat·Notion SOP·텔레그램 보고 본문에서 시트 명칭을 명시할 때 「이슈 응답」으로 일관 사용. 「회원 컴플레인」 어휘는 폐기.
- 시트 GID는 PropertiesService에 동적 저장(시트 탭 재생성 시 변경됨) — 명시적 하드코딩 금지. `fixSheetName()` 일회성 함수로 재동기화.
