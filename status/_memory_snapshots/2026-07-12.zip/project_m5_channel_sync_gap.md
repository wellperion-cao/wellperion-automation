---
name: project_m5_channel_sync_gap
description: "M5(ERP review_queue) ↔ 실제 발행 채널 동기화 틈 + 자동 글목록 탐색의 '미발행' false-negative 주의"
metadata: 
  node_type: memory
  type: project
  originSessionId: 40d73238-177c-43ea-8f6c-aac7a4f79b10
---

M5(`3. 웰페리온 가이드/cmo/review/review_queue.json`)는 발행 스크립트가 글 올릴 때만 행을 써넣어 채워진다. **★정책(2026-07-10 GM 재확인): 블로그·카페 포함 5채널 전부 완전 자동 발행이 표준.** 네이버 블로그/카페 업로더는 `--mode publish`(GM-go 가드 `--i-am-sure`/`WELLPERION_PUBLISH_GO=1`) 지원 + 어제(07-09) 본문소실(링크카드가 CTA줄 삭제)·조립순서(이미지→링크카드 맨끝 Ctrl+End)·발행버튼(툴바 아닌 패널 안 '발행') 3버그 수정 완료. 구 '봇은 임시저장만·게시는 GM 수동'(2026-06-05 정책)은 **폐기**. ⚠️단, `ig_review_publish_watcher.py`는 아직 블로그·카페를 `--mode draft`로 강등하는 옛 정책이 남아있음(배826 잔여) → 자동발행은 업로더를 `--mode publish`로 직접 호출하거나 watcher 정책 갱신 필요.

**Why:** "발행 행위"와 "M5 기록"이 한 트랜잭션으로 안 묶인 구조적 틈(약속 L01·L02 미준수 지점). 채널=진실, M5=거울인데 거울이 비어버림.

**How to apply:**
- 발행 링크 정리 요청 시 M5만 믿지 말고 **채널 현실을 직접 실측**(약속 L03). 카페 URL=cafe.naver.com/ichon1dong/{id}, 블로그=blog.naver.com/wellperion/{logNo}, 카카오=pf.kakao.com/_cgxiKj/{postid}. id는 발행순 연번 → EP 사이 번호로 정합 교차검증 가능.
- ⚠️ Playwright 글목록 스크롤/검색으로 **'미발행' 단정 금지** — 스크롤 한계로 실제 발행글을 놓치는 false-negative 2회 발생(EP2 카페·카카오 오판). '못 찾음'과 '미발행'은 다르다.
- 근본 해법 후보(GM 결정 대기): A=콘텐츠 생성 시 5채널 행 '발행대기'로 선등록→발행 시 상태만 전환 / B=매일 채널↔M5 자동 대조·누락 알림. 관련 [[project_publish_verify_before_done]] [[project_4channel_dispatcher]].
- 당근 로그인=**Google SSO cao@wellperion.com 자동클릭**(QR 아님, 07-09 b9d6063b). 세션 만료 시 스크립트가 구글 계정 선택까지 자동, 그 클릭 실패 때만 사람 1회. URL 회수 자동(daangn.com/kr/business-posts/{postId}). 추측 URL 생성 금지. 정본 [[reference_danggn_full_auto_publish]].
