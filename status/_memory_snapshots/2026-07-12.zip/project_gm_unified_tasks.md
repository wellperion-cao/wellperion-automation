---
name: gm-unified-tasks
description: 김남욱 GM의 오늘 할 일·개인 캘린더·업무 현황 SSOT 통합 시스템 — CEO가 GM 자연어 입력을 받아 HTML 시드로 추가
metadata: 
  node_type: memory
  type: project
  originSessionId: 80777498-c2ef-4d1a-bdc6-40d7cfcb2d61
---

김남욱 GM 페이지의 3개 시스템(오늘 할 일·개인 캘린더·업무 현황 SSOT)을 단계적 통합한다.

**Why:** 2026-05-28 GM님 지시 — "내 개인캘린더랑 오늘 할일, 업무 현황 SSOT 다 통일 시킬 수 있는 방법이 없나 ... 나는 너에게 간단하게 주면 너가 추가해주는 방식으로 할거야". 분산 데이터로 같은 일을 3번 입력하는 비효율 해소.

**How to apply (CEO 운영 패턴):**

1. **Phase 1 (구축 완료 시점부터):** 오늘 할 일 ↔ 캘린더 localStorage 통합 (`gm1_unified_tasks` 키)
   - 데이터 모델: `{id, title, description, startDate, endDate, time, category, isToday, status, memo, ssotSynced}`
   - 오늘 할 일 = `startDate == 오늘 날짜` 또는 `isToday == true` 항목 자동 추출
   - 캘린더에 일정 등록 → 오늘 날짜면 자동으로 오늘 할 일에 합류
   - 오늘 할 일 완료/보류 → 캘린더 status 동기화

2. **CEO 입력 처리 패턴:**
   - GM이 자연어로 입력 (예: "내일 14시 황용석 팀장 인사 미팅 추가")
   - CEO가 데이터 모델로 변환
   - 가이드허브 HTML의 `gm1CalSeed()` 함수 내 시드 배열에 새 항목 추가 (id 유니크)
   - 커밋 + push
   - GM이 가이드허브 새로고침 시 시드가 localStorage에 자동 합류 (id 중복 체크)

3. **Phase 2 (장기):** Apps Script로 시트 단방향 동기화 (가이드허브 → 업무 현황 SSOT 시트). 시트 인증·CORS 처리 후 결재 받고 진행.

**관련:** [[feedback_prioritize_connect_over_create]] · [[feedback_ceo_essence_oversight_and_brief]] · [[project_guidehub_identifier_ssot]]
