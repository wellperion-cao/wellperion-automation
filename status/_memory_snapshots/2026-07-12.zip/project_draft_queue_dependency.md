---
name: draft-queue-dependency
description: 네이버 블로그 SmartEditor 본문 영역은 임시저장 큐가 0건일 때만 lazy load 활성화. 매 자동화 가동 전 임시저장 정리 의무 (2026-05-21 자율 R&D 11회 검증).
metadata: 
  node_type: memory
  type: project
  originSessionId: af7d1e65-7152-40af-be03-6acf6ee83a23
---

네이버 블로그 글쓰기 페이지의 본문 SmartEditor contenteditable이 **임시저장 큐가 누적된 환경**에서는 lazy load가 차단된다. mainFrame과 모든 sub-frame에서 contenteditable maxH=0으로 잡히며 type·clipboard paste 모두 본문에 들어가지 않는다. 글쓰기 페이지 진입 자체는 정상이고 placeholder click도 성공 보고하지만 실제 입력 사슬은 절단된다.

## 검증된 안정 경로
1. **GM 임시저장함 비우기 (1분 수동)** — 모든 임시저장 글 삭제
2. **`scripts/upload_with_images.py` v3.12 1회 가동** — production 3차(190335) 검증 패턴 (.se-text-paragraph click + page.keyboard.type)
3. 결과: 제목·본문·이미지 8장·슬라이드 모달 모두 정상 임시저장

## 진화 사슬 (실패 패턴 누적)
- v3.0 (production 3차 190335): 깨끗 큐에서 1회 성공
- v3.1~v3.4: 이어쓰기 dismiss·Tab·active element 진단 — 본문 합쳐짐 또는 timeout
- v3.5 (production 195716): JS focus 후 keyboard.type → 본문 텍스트 누락
- v3.6: locator.press_sequentially → 이모지 surrogate pair에서 timeout
- v3.7: clipboard Ctrl+V → caret 미정으로 본문 미입력
- v3.8: 1차/2차 fallback → 모두 textContent=0
- v3.9~v3.11: 모든 frame 진단 → contenteditable maxH=0 일관 발견 (임시저장 누적 환경)
- **v3.12 = v3.0 안정판 복원**

## 다음 R&D (v3.13+)
임시저장 큐 자동 정리 기능 — 글쓰기 진입 시 우상단 "저장 N" 카운트 버튼·임시저장 패널 셀렉터 식별 후 모든 글 X 버튼 자동 click. 학습 모드로 GM 직접 조작 캡처가 가장 빠른 진단 경로.

**Why:** 2026-05-21 자율 R&D 사이클 — 본문 입력 11회 시도 중 1회만 성공. 결정적 차이는 임시저장 큐 누적. SmartEditor가 누적 환경에서 본문 영역 lazy load를 다른 흐름으로 처리 (글감 검색·이어쓰기 모드 등으로 분기).

**How to apply:**
- 매 자동화 가동 전 임시저장 큐 0건 보장 (GM 수동 또는 v3.13+ 자동)
- v3.0/v3.12 단순 패턴 이상의 복잡한 caret 조작·JS focus·press_sequentially·clipboard paste는 모두 회귀 위험 — 추가 패치 시 깨끗 큐 환경에서 1회 검증 필수
- 본문 textContent 검증을 모든 가동의 안전판으로 의무화 (실패 조기 차단)
- 이모지 본문 — keyboard.type은 surrogate pair 대응. press_sequentially는 이모지 timeout 위험 (검증됨)
- [[feedback_no_lookback_tomorrow_only]] 회수 금지 원칙은 콘텐츠 영역. 자동화 R&D 검증 사이클은 별개.
