---
name: reference_ig_publish_curation_md_format_trap
description: "IG 발행실패 '게시 URL 미회수'가 실은 큐레이션_추천.md 악형식(## post 섹션 없음). 봇 DEVNULL이 진짜 사유 은폐"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 55d6c635-7b89-4ee9-8df5-4da3bce4ad45
---

IG 개인계정(namuk.wellperion) 발행이 `발행실패` + "게시 URL 미회수"로 뜨면 **URL 문제가 아닐 수 있다.** 2026-07-08 EP01 종합접수처 사고: 진짜 사유는 `[ERROR] 발행 대상 post 섹션 없음` — 폴더의 `큐레이션_추천.md`가 `## post A/B/C` 형식이 아니라 `# 제목+본문`형이라 `parse_curation_md`가 0슬롯 반환 → IG 도달 전 사망.

**발행기 입력 우선순위**(`scripts/instagram_upload_playwright.py`): (a) 폴더 `큐레이션_추천.md` 있으면 우선 파싱 (b) 없으면 `--caption-file`(큐 caption)로 post A 합성. 큐엔 항상 유효 caption이 있으니, md만 치우면(또는 유효 슬롯 없으면) caption 경로로 발행된다.

**재발방지 2건(2026-07-08 GUARDED):**
- 발행기: md 있어도 유효 `## post` 슬롯 없으면 죽지 말고 큐 caption 폴백(병목 방어·모든 제작기 md형식 면역).
- 봇(`telegram_bot/bot.py` cmd_publish_callback): 발행엔진 `--once`를 구 `DEVNULL`→`logs/ig_publish_engine.log`로 출력. DEVNULL이 진짜 실패사유를 'URL 미회수'로 둔갑시켜 진단을 지연시켰다(봇 재기동 시 발효).

**진단 순서:** 로그(watcher)만으론 "진짜 실패 vs URL만 못 긁음" 판별 불가 → `발행실패` 재현은 `.venv/Scripts/python.exe -u scripts/ig_review_publish_watcher.py --once`를 **출력 캡처**로 직접 돌려 실제 에러를 본다. 성공토스트 확인되면(rc==9) `발행검증대기`=발행됨(개인계정 URL 캐시지연 false-negative, 재발행 금지). 관련 [[project_ig_upload_ssot]] · [[feedback_welly_publish_verify_artifacts]] · INC-003.
