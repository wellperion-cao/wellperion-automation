---
name: feedback_report_pages_minimal_helper_text
description: 보고서·가이드 페이지는 제목 옆 짧은 안내만·아래칸 회색 부연 금지(가독성). 정직 꼬리표는 짧게 유지
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 30b5430a-c367-4bcd-966e-d8bd7d547be7
---

GM은 보고서/가이드 페이지에서 **설명·안내 텍스트가 칸을 차지해 읽기 불편한 걸 싫어함**. 표준:
- **제목 옆 안내(회색 stag)** = 1개 짧은 구절로 압축(소스·부연 설명 빼고 핵심 뜻만). 예: 매출 섹션 stag = "선택월·연간·부서별 · 목표 72억 대비".
- **블록/표/차트 아래 회색 부연·범례·footnote** = 제거(자리만 차지·가독성 저하). 데이터(수치·표)는 유지.
- ★예외: **정직 표기 꼬리표는 삭제 금지**(헌법 L05·INC-001) — "미도래월=정직 표기"·"참고값"·"데이터 축적 중"·"초안(GM 검토)" 등은 **짧은 인라인 태그로만** 남긴다.
- 지우기 애매한 안내(데이터성·상태 알림)는 **지우기 전 GM께 목록 보고**, GM이 결정.

**Why:** GM은 A3 인쇄 보고서를 눈으로 빠르게 읽음 — 장식·소스설명이 밀도를 높여 방해. 단 정직성은 헌법 최우선이라 안내라도 정직 꼬리표는 못 없앰.
**How to apply:** 페이지 작업 마무리 시 stag 축약 + 아래 footnote 제거 렌즈 적용. [[feedback_gm_reports_short_scannable]] · [[feedback_gm_page_completion_a3_print_readable]] · [[feedback_always_structure_simplify_advance]] 와 함께.
