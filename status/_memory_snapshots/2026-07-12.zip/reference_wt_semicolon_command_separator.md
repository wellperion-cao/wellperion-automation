---
name: reference_wt_semicolon_command_separator
description: Windows Terminal(wt) 명령행에서 세미콜론은 명령 구분자 — -Command 안에 넣으면 잘려서 0x80070002 오류
metadata: 
  node_type: memory
  type: reference
  originSessionId: bc9b5aa3-d1e2-4b66-852d-741695f3c021
---

Windows Terminal(`wt`) 명령행에서 `;`(세미콜론)은 wt 자체의 **명령 구분자**다. `wt new-tab ... powershell -NoExit -Command "git pull; claude '...'"` 처럼 `-Command` 문자열 안에 세미콜론을 넣으면, wt가 `;` 뒤를 별개 wt 하위명령으로 잘라내 `claude '...'` 부분이 깨지고 **0x80070002 (지정된 파일을 찾을 수 없습니다)** 오류가 난다.

**해결:** PowerShell 다중 명령(`A; B`)을 wt 새 탭에서 돌려야 하면, 세미콜론을 wt 안에 넣지 말고 **wt 호출 전 cmd(.bat) 단계로 분리**한다. 예: Start-AI {role}.bat에서 `cd /d "%WORK%"` + `git pull --rebase origin master`를 wt 줄 앞에 두고, `wt ... -Command "claude '...'"`에는 단일 명령만 남긴다.

2026-05-29 Start-AI C레벨.bat 6개에 부팅 git pull 추가 시 세미콜론으로 넣었다가 GM이 켤 때 0x80070002 발생 → cmd 단계 분리로 수정(commit 4f7e878). CEO.bat은 wt를 안 쓰고 claude 직접 실행이라 무관했음. 관련: [[feedback_self_verify_before_user_test]] — .bat 변경 후 GM 실행 전 자체 동작 검증 의무.
