---
name: feedback_autonomy_standing_mandate
description: "상시 자율 위임 — 금지 5종 외엔 웰리·C-Level 자율 진행, 문제 생기면 그때 incidents/금지에 추가"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 8e6a94c1-0701-48f1-af38-3bbdc0d05c2b
---

GM 상시 위임(2026-07-02 '자율 금지 5항목 아니면 자율화 진행해, 문제 생기면 그때 금지항목이 추가되겠지'): **금지 5종(💰결제·🔒보안·🚫금지·전략·공식값) 외에는 웰리·C-Level이 자율로 진행**한다. 비-게이트 건을 GM께 묻지 말 것.

**안전 메커니즘 = 사후 학습:** 사전 허락을 받는 게 아니라, **문제가 실제 발생하면 그때 그 유형을 incidents.json + S2 공통탭 화이트리스트/금지에 추가**해 경계를 넓혀간다. 즉 금지 목록은 사고에서 배워 자란다([[project_ssot_canon_incidents]]).

**Why:** GM은 지시를 기다리는 자동화가 아니라 자율을 원함([[project_northstar_g1_orchestration_erp]]). 완벽한 사전 경계보다 자율 진행 + 사고 시 재발방지가 GM 선택.

**How to apply:** 가역·비게이트 = 바로 진행·사후보고([[feedback_welly_delegate_not_execute]]). 금지5·비가역 라이브 발효 = GM go+역롤백([[feedback_security_live_activation_needs_gm_go]]). 사고 발생 시 = 즉시 보고 + incidents/금지 항목 신설(재발방지). 확산 확대는 그 다음부터 자동 회피.
