---
name: project_pii_gate_aggregates_public_no_key_ux
description: "회원 PII 보호. 2026-06-23 GM 인증 방향=JWT 세션 확정(자체 윈도우 서버 전제, 서버 생기면 착수·정박중). 2026-06-18 토큰 게이트 폐기·서버 TOKEN_ENFORCE 끔. 과거 옵션A 이력 본문 하단."
metadata: 
  node_type: memory
  type: project
  originSessionId: 0d43be27-1432-4903-847a-5765722b1984
---

★ **2026-06-23 GM 인증 방향 확정 = JWT 세션 기반 (단, 자체 윈도우 서버 전제).** PII 보호 인증 아키텍처를 **JWT 세션**으로 확정. 그러나 **자체 윈도우 서버 도입이 선결 조건** — GAS는 서명키 보관·세션 발급/만료/회수·접근로그가 반쪽이라, 서버 없이 짜면 폐기될 반쪽안. 따라서 시토 21번 배(CTO-2026-06-18-PII-PROTECTION-REDESIGN)는 **'자체 윈도우 서버 도입'까지 정박(보류)**, depends_on=서버. 서버 생기면 [[project_self_hosted_inquiry_db_goal]](ship_no 18)와 **한 틀로 동시 착수**. 로그인 수단·출입 대상·잠금 범위는 서버 도입 시점 재확정(현 cao 구글 SSO 재사용 유력). 기존 GAS TOKEN_ENFORCE/PII_GATE 게이트는 서버 전까지 휴면(OFF) 임시 안전망으로만 유지. **방향(JWT)은 확정·박제됨 — 다음 부팅 때 재논의 말 것.**

★ **2026-06-18 GM 순서 전략 (현행).** 자동화 먼저 전진 / 보안 접근통제는 **전반적 틀(자체 DB·인증 구조)이 선 뒤 한 번에 발효** — 부분 게이트 재시도 안 함(오늘 사고가 틀 없이 부분만 걸어 난 일). 그때까지 회원 PII 무인증 공개는 'GM이 알고 받는 위험', 단 **새 PII 공개 창구는 늘리지 않는다(악화 방지)**. 발효 시 헌장 축6=GM go+역롤백.

★ **2026-06-18 GM 롤백·재설계 지시.** 토큰 게이트가 라이브 발효(TOKEN_ENFORCE=1)돼 개인정보 화면이 잠기자 GM 당황 → **"더 큰 틀로 접근, 일단 서버에서도 삭제"**. 조치: ① 큐 CTO-2026-06-17-GAS-PII-ACCESS-GATE **폐기**(커밋 8e1caf20) ② 서버 GAS `TOKEN_ENFORCE` 속성 = GM이 끔(문의 1A77oDR…·VOC 1_jF5yh…, clasp 미연동 수동·재배포 불필요) ③ 게이트 코드는 휴면 잔존(off=전 액션 통과·무중단·무해), 재설계 시 정리 ④ 프론트 열쇠팝업은 이미 옵션A로 무동작. **회원 PII 보호는 자체 문의DB([[project_self_hosted_inquiry_db_goal]])와 묶어 큰 틀에서 재설계 = 시토 북극성 '보안 철저' 항로.**

---
**(이력) 2026-06-17 GM 옵션A** — 아래 방식이 한때 확정·발효됐으나 06-18 위 롤백으로 거둠:

- **서버 게이트 유지**: TOKEN_ENFORCE=1, VOC GAS(@8) + 문의 GAS(@29) 공유 ACCESS_TOKEN. `inquiry_list`·`voc_list`·`reg_list` 등 PII 읽기는 외부(무키) 차단. 라이브 검증 완료.
- **공개 대시보드 = 집계·마스킹만**: 마케팅현황대시보드 등은 `funnel_conversion`·`period_breakdown`·`reg_board`(마스킹) 등 공개면제 액션만 표시. **열쇠 불필요.**
- **원본 이름·전화 = 보호된 구글 시트**(로그인)에서 직접 본다. 대시보드엔 원본 PII 안 띄움(필요한 칸은 "—" 또는 "시트에서").
- 회원 제출 폼·공개보드는 공개면제 — 절대 막히면 안 됨.

★ **클라이언트 '열쇠 입력' UX(`_wpPromptKey`/`_wpGate` 프롬프트)는 폐기 — 다시 도입 금지.** 열쇠 방식은 공개주소+무로그인 임시방편이라 채택 안 함(입력창도 로드 ping이 공개액션이라 안 떴음). 서버 게이트만으로 충분.

연계: [[project_todo_api_open_security_gap]] · 시토 CTO-2026-06-17-GAS-PII-ACCESS-GATE.
