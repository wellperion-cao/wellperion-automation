---
name: project_publish_notify_lock_dual_keep
description: 발행 알림 중복·허위 사고 원인과 .publish.lock 직렬화 + 이중 일꾼 구조 유지 결정
metadata: 
  node_type: memory
  type: project
  originSessionId: 254e1f75-0568-4c09-8217-64bab6ba4cf8
---

2026-06-05 발레 4채널 발행 시 텔레그램 알림 22개 폭주(정상 4 + 중복·허위 18) 사고.

**원인:** 발행 일꾼이 동시 다중 실행됨 — 승인 클릭마다 `ig_review_publish_watcher.py --once` spawn(13초 내 4개) + `start_ig_publish_watcher.bat`의 상시 `--interval 120` watcher = 최대 5 프로세스가 같은 큐 무멱등 재처리. 매 실행이 결과요약(line 492)+채널수동알림(394/413) 재발신 → 중복. 두 일꾼이 같은 네이버 블로그/카페를 동시 Playwright 업로드하다 프로필 락 충돌 → 늦은 쪽 exit≠0을 "임시저장 실패"로 오보(실제 성공) → 허위. save_queue 통째 덮어쓰기 lost-update로 카카오·당근 status가 검수대기로 되돌아감.

**수정:** `ig_review_publish_watcher.py run_once()`에 `.publish.lock`(O_EXCL 원자적 배타, stale 1200초 자동회수, dry-run 미사용) 직렬화 락. 중복·충돌(허위)·lost-update 3원인 동시 차단. 커밋 74ca1b3.

**GM 결정(2026-06-05):** 상시 watcher + 승인 spawn **이중 구조 그대로 유지**. 락이 안전망이라 충분. 상시 2분 watcher는 락 경합으로 스킵된 승인의 재처리 안전망 역할 → **임의 폐기 금지**(폐기하면 승인 핸들러에 재시도/락대기 추가 필요). [[reference_ig_personal_publish_pipeline]] [[project_ig_watcher_retired_ondemand]]

**미해소(정상 동작):** 네이버 일시오류로 진짜 단발 exit≠0 시 ⚠️ 알림 가능 — 충돌 아닌 실제 실패라 정상.
**로그 한계:** bot.log는 발신 메시지 본문 미저장 → 사고 시 22개 전문은 로그+커밋 증거로 재구성해야 함. 발신 로깅 추가 시 다음 사고 추적 쉬워짐(미구현, GM 보류 가능).
