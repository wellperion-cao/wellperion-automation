---
name: reference_pages_url_no_guide_prefix
description: Pages 라이브 URL 규칙 통합 — 가이드 접두사 금지(404) + 한글경로 NFC 필수
metadata: 
  node_type: memory
  type: reference
  originSessionId: e4974790-ef30-4c7a-8bab-a27369911016
---

GitHub Pages 배포 워크플로(`.github/workflows/pages.yml`)는 `cp -r "3. 웰페리온 가이드/." _pages_build/`로 **폴더 '내용'을 _pages_build 루트에 복사**한다. 따라서 라이브 URL에는 `3. 웰페리온 가이드/` 접두사가 **없다**.

- 레포 경로: `3. 웰페리온 가이드/cmo/funnel/마케팅현황대시보드.html`
- 라이브 URL: `https://wellperion-cao.github.io/wellperion-automation/cmo/funnel/마케팅현황대시보드.html` (접두사 제거)
- 홈: 루트 `index.html`(245B 리다이렉트 stub) → `wellperion_guide(main).html`(루트).

라이브 검증 시 레포 경로를 그대로 붙이면 **404(9379B 404페이지)**가 나온다 — 접두사 빼고 검증할 것. Pages는 쿼리스트링으로 CDN 캐시가 안 깨진다(경로 기준 캐싱). 동시 다중 C-level 커밋 시 각 push가 pages 배포를 cancel-in-progress로 취소→최신 1건만 성공. 깨끗한 재배포는 `gh workflow run pages.yml --ref master`.

## 한글 경로 NFC 검증 필수

GitHub Pages는 경로를 **바이트 정확 매칭**하며 유니코드 정규화를 하지 않는다.
- **NFC(완성형)** 로 요청 → **200** (정상)
- **NFD(자모 분해형)** 로 요청 → **404** (가짜 — 파일은 멀쩡한데 경로 매칭 실패)

**함정:** bash에서 raw 한글을 `curl`에 직접 넣으면 NFD로 변질될 수 있어 **존재하는 파일도 404**로 나온다. 브라우저·정상 링크 클릭은 NFC라 200. 2026-06-17 시모가 이걸로 마케팅 대시보드 `/cmo/` 전체가 404라 **오진해 배포 사고로 잘못 인계**(실제 라이브 정상)했다.

**올바른 검증법:** Python으로 `unicodedata.normalize('NFC', 파일명)` 후 `urllib.parse.quote`로 요청. 또는 브라우저/playwright(정상 NFC) 사용.
```python
import urllib.request, urllib.parse, unicodedata
p = unicodedata.normalize('NFC', '마케팅현황대시보드.html')
url = base + urllib.parse.quote(p)
```

**부수 사실:** `/cmo/` 같은 index.html 없는 폴더 직접 접근은 항상 404(정상). pages.yml은 artifact 방식 배포(Jekyll 우회)라 `.nojekyll` 부재 무해.
