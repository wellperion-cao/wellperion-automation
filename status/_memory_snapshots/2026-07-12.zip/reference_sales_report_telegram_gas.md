---
name: reference_sales_report_telegram_gas
description: 매출보고 텔레그램 자동발송 GAS(GM 개인계정)—scriptId·원본시트·구조·범위고정 함정·clasp재인증
metadata: 
  node_type: memory
  type: reference
  originSessionId: ad99fb66-a4cb-4307-a74d-8af5352ac8d8
---

**매출보고 자동발송 GAS** — 우리 SSOT 밖(GM 개인 구글계정 소유). 2026-07-06 cao@wellperion.com에 편집자 공유받음.

- scriptId: `1f7Py-qdO6gSDC94k1eQBEUWE2mG5Q6Zzp5MuyD9kXx35aU5MQi7R-PLo` (컨테이너 바인딩)
- 원본 스프레드시트(parentId): `1ycSEBbXjcU_suNu9B5HsEXQW0XosaW8fGtO0XfGprqc`, 보고 탭명 `'보고'`
- 파일: `매출보고_자동발송.js`(발송 로직 v3.1) + `매크로.js`(시트정리 매크로)
- 동작: 매일 09:00 KST → `'보고'!REPORT_RANGE` → **PDF**(export: A3·landscape·scale=4=fit-to-page·여백0.05) → **PNG(Google Drive 내장 썸네일)** → 텔레그램 `sendPhoto`. 봇=`8297784147`(@namuki_report_bot) · chat=`8254867551`(GM 개인). 봇토큰이 회사 telegram_bot/.env와 별개로 GAS CONFIG에 하드코딩됨.
- **범위 고정 함정:** `REPORT_RANGE` 하드코딩. 보고가 밑으로 늘면 하단 잘림(칸=가로와 무관·세로 문제). 정본값 = **`H2:S21`**(PNG생성기 scripts/generate_sales_report_image.py SHEET_RANGE와 일치해야 함). 또 늘면 한 글자 bump 또는 마지막행 자동감지로 근본화 가능.
- **⚠️ 백업 stale 되돌림 함정(2026-07-08):** paste 정본 백업 `tmp/sales_report_GAS_FULL.js`(gitignore·토큰포함)가 07-06 이후 갱신 안 돼 **`H2:S20` 옛값**이었음 → 이걸 통째 붙여넣으면 라이브 S21이 S20으로 **되돌아감**. 07-08 버튼제거 붙여넣기 때 실제 발생, GM이 S21로 재수정. 교훈=백업 붙여넣기 전 REPORT_RANGE·최신변경 대조 필수, 또는 **GM 붙여넣기 대신 clasp(cao)로 직접 배포**(scriptId 위 기재)해 stale 백업 경유 회피. 백업은 S21로 갱신함.
- **버튼 제거(2026-07-08):** 9시 매출보고 텔레그램의 「📤 카톡 3방 전송」 인라인버튼(sendTelegramPhoto의 reply_markup/kakao_send) 제거 완료(GM 결정 — 9:30 무인 카톡발송으로 대체, 클릭 불필요). bot.py cmd_kakao_send_callback 핸들러는 잔존(무해·다음 재기동 시 정리 가능).
- **PNG 짤림/흐림 근본:** Drive 썸네일은 해상도 상한(268KB=저해상 증거)+가로형 PDF 크롭 가능. 인라인 사진 유지하며 완전해결하려면 썸네일 방식 탈피 필요(PDF sendDocument 등). 발송형태는 GM 취향=인라인 사진 유지 결정(2026-07-06).
- **clasp 함정:** clasp 3.3.0이 아는 ID도 "Invalid script ID"로 거부 = 실은 **cao 인증 만료(invalid_rapt)**. 해결=GM이 세션에서 `! clasp login`(cao 선택) 재인증 1회 → clone·push·Drive/AppsScript API 전부 열림. 토큰 직독=`~/.clasprc.json` tokens.default.access_token.
- 원격 test 실행 불가: `clasp run`은 API executable 배포 필요(이 GAS엔 없음). 검수=실제 09:00 발송 또는 편집기 `testSendNow` 수동. Sheets API는 clasp GCP프로젝트에 미개통(403)이라 시트 직독 불가.
