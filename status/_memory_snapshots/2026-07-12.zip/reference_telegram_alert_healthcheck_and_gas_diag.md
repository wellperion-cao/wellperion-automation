---
name: reference_telegram_alert_healthcheck_and_gas_diag
description: 텔레그램 알림 신뢰성 자동화 위치 — 헬스체크 스크립트 + 3 GAS diag 액션 + chat_id drift 가드
metadata: 
  node_type: memory
  type: reference
  originSessionId: 206aa4b5-8a14-4305-a2dd-33da8ac95a76
---

2026-06-30 종합접수처 분실물 알림 '조용한 실패'(VOC GAS 토큰/chat_id 미설정 시 말없이 통과) 사고 후 구축한 텔레그램 신뢰성 자동화. 시토 소유([[feedback_cto_owns_telegram_issues]]).

- **헬스체크:** `scripts/telegram_health_check.py` — 봇 getMe·그룹 3방 getChatMember(점검 -5136037543/문의 -5516675010/종합접수처 -5065206276)·당일 발송원장(`logs/telegram_sent-*.log`) 리컨실·3 GAS diag ping. 문제 시에만 OWNER(8254867551) 경보, 정상이면 침묵. `--dry-run` 지원. 매일 13:00 예약(Task `Wellperion-Telegram-HealthCheck-1300`, 런처 `launchers/telegram_health_check_hidden.vbs`+`scripts/telegram_health_check.bat`).
- **GAS 원격 진단:** 각 GAS에 `?action=diag` 읽기전용 액션 — 비밀값 없이 `hasToken/hasChatId` 불리언만 반환. VOC(apps_script_voc.js)·문의(Survey.js diag/test)·점검(`.deploy-check/지원팀 일일점검.js` handleCheckDiag, @134). 헬스체크가 매일 ping → GAS측 설정누락(원격에서만 안 보이던 silent-fail)을 탐지. getChatMember는 '봇 방추방'만 잡고 GAS 설정누락은 못 잡으므로 diag가 그 구멍을 메움.
- **drift 가드:** `scripts/check_chatid_drift.py`(pre-commit, warn-only·fail-open) — `telegram_bot/.env`를 chat_id 정본으로 폴백 리터럴(daily_scheduler·watcher·health_check·점검.js·Survey.js) 불일치 시 커밋 경고.
- **보류:** 봇 토큰이 .env 여러 곳 평문 → 토큰 로테이션은 GM 보류(보안 별도 과제). chat_id 런타임 SSOT 단일화도 미실시(가드만).
- **점검 알림 누락 특성(2026-06-30 진단·GM 수용):** 지원부 점검 텔레그램은 점검 페이지 `submitRound`가 `if(!_isAdd && ONLINE)` 조건으로 **최초 제출 1회·제출 순간 온라인일 때만** 발송(client fetch, catch{} 무음). 제출 순간 오프라인/끊김이면 **데이터·제출도장은 남아도 알림만 영영 유실(재시도 없음)**. GAS notify_round는 발송로그 미적재라 헬스체크 사각. 2026-06-30 남 오전 누락=박호균과장 기기 순간끊김(여 오전은 정상도착) → 손 보정 재발송(데이터 today_live·dump_zone에서 재구성). 근본해결(서버측 제출시 발송)은 GM이 일회성으로 보고 보류. 재발 반복 시 재제안. 손 보정 시 양식=점검자·근무자(duty)·소요시간(chkAt)·완료·이슈 전부 채울 것(근무자·소요시간 누락 주의).

VOC 접수ID는 통합 순번 VOC-N(ScriptProperties VOC_SEQ 단조카운터+LockService, `reg_renumber` 마이그레이션). G1 상시소유 배=CTO-2026-06-30-TELEGRAM-RELIABILITY-OWNERSHIP(ship 102).
