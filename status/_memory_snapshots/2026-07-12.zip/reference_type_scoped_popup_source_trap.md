---
name: reference_type_scoped_popup_source_trap
description: 유형별(멤버십/강습) 현황 팝업 지표는 funnel_conversion(전채널 합) 금지·유형 native 소스로 스코프
metadata: 
  node_type: memory
  type: reference
  originSessionId: 2d4e87ae-9654-4073-be1d-3d8d31261a8c
---

CPO 문의회원.html 멤버십/강습 "문의 현황" 팝업 지표는 **페이지 유형 native 소스**로 세야 정직하다.

**함정:** ①이번달 성과를 `funnel_conversion`(마케팅 퍼널 정본)에 물리면 멤버십+강습+렌트+비즈+랜딩폼 **전 채널을 합산**해 과대집계된다. 2026-07 실측: 팝업 "신규문의 53"은 전 채널 합, **멤버십만 = 10**(성인강습 17·유소년 13 등이 얹힘). 올해누적 1,734 > 총 607 모순이 신호였다(분모 소스가 다름).

**정본 소스:**
- 멤버십 = `member_inquiry_list`('26년 신규문의' gid 1902010032) + `member_registered_list`(유효회원 등록일). `_mdashInScope()`=프로그램 미기재 포함·플래티넘/노블레스만 인정, `cpo_today_stats.monthInquiry` 로직 재현.
- 강습 = `lesson_stats`/`lesson_registry_list`/`lesson_registered_roster`(성인·유소년 유형별). 전화·직접문의 포함이라 폼 기준(funnel)보다 native가 정확.
- 강습은 병목(stage_funnel 강습 단계 신호 미분리·붕괴)·이탈(churn=멤버십 전용)·전환율(코호트 매칭 액션 없음) 측정 불가 → 섹션째 정직하게 뺌.
- 전환율=이번달 가입/이번달 문의 단순비율(코호트 정밀매칭 액션 없음, 캐비어 명시). 연간=올해 누적 합계만(추세X).

관련 [[reference_stage_funnel_source_composition_trap]] · [[feedback_cmo_mission_dashboard_normalization]] · [[project_funnel_stage_pages]]
