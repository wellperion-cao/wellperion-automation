---
name: feedback_queue_migration_lessons
description: "AI배 _queue→시트 이관은 폐기됨(2026-06-16). _queue.json이 단일 SSOT. 재개 금지 + 단계검증 교훈"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: bbe8dc19-5dc1-4064-b35e-2ad390f94ad1
---

**결론(2026-06-16): "AI C레벨 배 _queue→구글시트 SSOT 이관"은 영구 폐기됨.** `status/_queue.json`이 단일 SSOT 그대로. GM이 「AI배(C레벨)」 시트 탭 수동 삭제 + 죽은 스캐폴딩(scripts/queue_sync_from_sheet.py·queue_seed_to_sheet.py + docs/queue_*_migration_*.md 5건) 삭제 완료. **이 이관을 다시 시작하지 말 것** — GM이 새로 지시하기 전엔 시트=SSOT 시도 금지.

**Why 폐기:** 이관은 로드베어링(8시 보고·결재 라우팅·브릿지가 다 _queue 읽음)이라 사고나기 쉬웠다. 2026-06-07 시토 백그라운드가 2단계를 한 번에 처리하다 AI배를 시트에 넣고 _queue에서 안 빼서 G1·hangro_board가 2번씩 집계(항로 14→23). 6/8~6/13 시드까지 갔으나 "원본이 시트냐 _queue냐" 모호·쓰기충돌 위험으로 보류, 6/16 완전 종료. (라이브는 끝까지 _queue.json만 읽어 무사.)

**How to apply (남는 일반 교훈):**
- 큰 자동작업 1회로 금지. **잘게 쪼개 단계마다 직접 검증→커밋**(센티넬 동반).
- **단일 SSOT 못박기:** 두 저장소가 둘 다 '진실'이면 사고. reader 소스전환과 데이터 이관은 같은 커밋에서 원자적으로.
- 죽은 마이그레이션 스캐폴딩은 보류로 방치 말고 결정 시 정리(git 이력 보존).

관련: [[feedback_background_agent_truncation_defense]] · [[feedback_welly_verification_standard]] · [[project_g1_ai_ship_readonly]] · [[feedback_cleanup_merge_relocate_delete]]
