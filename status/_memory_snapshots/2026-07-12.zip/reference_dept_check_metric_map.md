---
name: reference_dept_check_metric_map
description: "4부서 점검 지표 지도 — 완료율은 지원부만, 시설=입력률, 운영=VOC, 주차=제외 (억지 통일 금지)"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 46770c63-3022-422d-b677-ad41a31f15b6
---

4부서를 **한 줄 '완료율'로 억지 통일하지 말 것**(약속 L05 위반). 부서마다 점검 구조가 달라 맞는 지표가 다르다 (2026-07-04 코드 실측 지도):

| 부서 | 점검 구조 | 맞는 지표 |
|---|---|---|
| **지원부** | 조×성별×시프트 체크 원장 | ✅ **점검 완료율** (유일한 진짜 완료율·today_live 라이브) |
| **시설부** | 측정값 입력형(온도·수질 25종, save_facility_measure) | **입력률**(값 채운 항목/전체) + **기준이탈 건수** — 완료율 아님(회차마다 항목 구성 달라 왜곡). 월간만 있음(monthly_report&dept=facility), 일일 today_live는 support 전용 |
| **운영부** | 매뉴얼 체크박스=localStorage만(서버 미전송) | 완료율 불가 → 실질=**VOC 접수/처리 건수** |
| **주차** | 점검 탭 전면 제거(2026-06-12, [[project_parking_dept_standalone]]) | **대상 아님**(의도적 제외·되살리지 말 것) |

코드 못박음: `지원팀 일일점검.js` handleTodayLive가 `dept!=='support'`면 에러(실시간 완료율=지원부 전용). facility monthly denomNote='완료율=입력률'. 운영부 체계.html 주석 'VOC 탭이 점검 역할'. 관련: [[reference_check_completion_rate_untrustworthy_multisource]] · [[project_support_check_single_source_page]].
