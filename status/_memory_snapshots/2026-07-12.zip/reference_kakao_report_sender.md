---
name: reference_kakao_report_sender
description: 카톡 매출보고 원클릭 전송기(배488)—카카오톡 PC UI 자동화 함정·구조·파일
metadata: 
  node_type: memory
  type: reference
  originSessionId: ad99fb66-a4cb-4307-a74d-8af5352ac8d8
---

**카톡 매출보고 원클릭 전송기** (배488). 텔레그램 매출보고 아래 "📤 카톡 3방 전송" 버튼 탭 → 봇이 이미지를 로컬 저장(archive) + 카카오톡 PC UI 자동조작으로 3방에 이미지+방별캡션 전송. 관련=[[reference_sales_report_telegram_gas]](그 GAS가 텔레그램 발송·이 전송기가 카톡으로 확장).

## 파일
- `scripts/kakao_report_sender.py` — 전송기 코어. `scripts/kakao_rooms.json` — 방목록 `{name, prefix}` + `archive_dir`. `telegram_bot/bot.py` — `cmd_kakao_send_callback`(버튼 콜백). 스펙=`docs/superpowers/specs/2026-07-06-카톡-매출보고-원클릭-전송기-design.md`.
- 런타임=`C:\Python314\python.exe`(pywinauto/pyautogui/pyperclip/pywin32/PIL). archive=`1. AI학습자료_아카이브\10_매출보고\YYYY-MM\`(이미 .gitignore `1. AI학습자료_아카이브/`로 GitHub 제외=매출데이터 보호).
- 방별 캡션: prefix+원본캡션. 예 "차의주 회장님"방 prefix="회장님, " → "회장님, 7.5(일) 매출 및 운영사항 보고드립니다.". 다른 방 prefix="".

## 카카오톡 PC UI 자동화 함정 (하드원·재도전 시 필독)
- 열린 방 = **독립 최상위 창, class `EVA_Window_Dblclk`, title=방이름**(메인창 title="카카오톡"). 창-제목 완전일치로 찾음(오발송 방지 핵심). win32gui EnumWindows.
- **검색 Edit는 비활성 시 폭0으로 붕괴** → UIA `descendants(Edit)`로 못 찾음(최초 실패 원인). 메인창 우상단 돋보기 아이콘을 **고정픽셀 클릭(우끝-112px·상+57px)**으로 활성화 후 `EnumChildWindows`에서 class=="Edit"·visible·폭>0 필터로 특정. ★픽셀 의존 → 카톡 업데이트로 아이콘 위치 바뀌면 깨짐(그땐 RoomNotOpenError 명확실패+GM 수동열기 폴백).
- **Ctrl+A가 전역단축키(친구추가 다이얼로그)로 가로채짐** → 편집칸 전체선택 안 됨. 지우기=END→SHIFT+HOME→DELETE, 검색어=클립보드+Ctrl+V(한글IME 우회).
- **이미지 Ctrl+V는 메인입력 아닌 별도 "클립보드 이미지 전송" 팝업**(제목없음·캡션칸 50자·버튼 UIA미노출) 띄움 → 팝업 직접 찾아 Enter확정/Esc취소.
- `SetForegroundWindow` 오류183(포그라운드 잠금) → pywinauto `set_focus()` 우회.
- **방 자동열기 구현됨**: 방 창 없으면 검색으로 자동 열고 전송(재부팅 후 방 안 열어둬도 됨).

## 텔레그램 동일 이미지 자체 생성(텔레그램 사진 없이) — 2026-07-07 확보
봇 콜백은 텔레그램 9시 사진을 그대로 쓰지만, 그 사진이 없을 때(CLI 테스트 등) **GAS와 동일한 범위 export로 자체 생성** 가능. GAS는 '보고' 시트(`1ycSEBbXjcU_suNu9B5HsEXQW0XosaW8fGtO0XfGprqc`) **탭 '보고' gid=`2009735088`**의 범위 **`H2:S21`**를 A3 가로로 PDF export→PNG. 재현법: cao 구글세션이 붙은 `profiles/danggn` Playwright 퍼시스턴트 컨텍스트로 `context.request.get`:
`https://docs.google.com/spreadsheets/d/1ycSEBbXjcU.../export?format=pdf&gid=2009735088&range=H2:S21&size=A3&portrait=false&scale=4&top_margin=0.05&bottom_margin=0.05&left_margin=0.05&right_margin=0.05&gridlines=false&printtitle=false&sheetnames=false&fzr=false` → pymupdf(fitz) dpi=300 렌더. **함정: 시트 전체를 렌더하면(MCP 기본 PDF export=전체 워크북 191p·보고=30p) 7/5+7/6+전부서 다 나와 텔레그램과 다름 — 반드시 range=H2:S21로 범위지정.** gid는 시트탭 클릭 후 url `#gid=` 로 확인(danggn 프로필 세션 유효 확인됨 2026-07-07). CLI 단방 테스트=`kakao_report_sender.py --only-room "김남욱" --image <png>`(GAS 방목록 3방 override는 --only-room이 무시하고 단일 방 강제).

## 완전자동 9:30 무인 파이프라인 — 2026-07-07 발효
`scripts/kakao_auto_daily_report.py`(오케스트레이터)+`scripts/generate_sales_report_image.py`(자체생성)+킬스위치 `status/kakao_auto_send.json`(`{enabled}`). 예약작업 `Wellperion-Kakao-Sales-Report-0930`(매일 09:30·런처 `launchers/kakao_auto_daily_report_hidden.vbs`→`scripts/kakao_auto_daily_report.bat`). 흐름=시트 범위export→PNG→archive→3방(GAS정본) 전송, 실패시 OWNER 텔레그램 경보(구글세션만료 등엔 stale 안 보냄). 역롤백=킬스위치 enabled:false 또는 예약작업 삭제. 3방=차의주 회장님(prefix "회장님, ")·웰페리온 관리부·**★ 운영부**(구 "웰페리온 운영부"에서 GM이 개명—검색 모호성 해소, GAS·로컬 반영). 오케스트레이터 옵션: `--rooms "A,B"`(수동 즉시·킬스위치무시), `--as-of YYYYMMDD`(시뮬), `--dry-run`. 텍스트전용=sender `--message TEXT`(--image 없이).

## 휴관일 인지 보고 규칙(GM 확정 2026-07-07)
매일 09:30 보고=**전날(어제)** 매출 기준. 전날이 휴관이면 이미지 대신 **안내문만** 3방 전송. 휴관 판정=`scripts/close_days.py` `is_closed()`: 신정(1/1)·**매월 2·4째 일요일**(자동: (day-1)//7+1 ∈ {2,4})·설/추석은 `status/close_days.json` dates 수동등록(음력). 안내문 예:"6/28(일)은 휴관일이었습니다. 화요일에 월요일분부터 이어서 매출·운영사항 보고드리겠습니다."(조사 은/는=요일 받침 자동·resume=biz+1 영업일). ⚠️설/추석 날짜는 close_days.json에 채워야 실반영.

## 보안 방향(GM 결정 2026-07-07)
계정·PC 노출 우려 → **근본 해결=자체 서버 이전**(현 GM 개인 PC UI자동화 → 상시 서버의 전용 계정/세션으로). ship101([[project_self_hosted_server_setup]]) 도입(~9월) 때 함께 이전. **미래 실행안(GM 확정 2026-07-07): 자체 서버에 법인폰 카카오톡을 설치·운용** — 법인폰 계정=GM 개인계정 노출 차단(전용 계정) + 서버 상시성(GM PC 꺼도 무인 발송) 동시 해결. 그전까지 현행 GM PC 방식 유지(단기 전용계정 분리·PC 강화는 채택 안 함, 서버+법인폰으로 근본화). 카톡 단톡방=공식 API 부재라 UI자동화 불가피가 전제.

## 실사용 조건
카톡 PC 로그인+자동실행(GM 설정 완료). 웹에서 추가하는 방 이름은 **실제 카톡 방 이름과 정확히 일치**해야 찾음(이름만 지어도 방 안 생김). 관리 UI=T2 자율현황 링크 페이지(방 추가/삭제→.deploy-todo GAS 저장→봇이 읽음, 폴백=로컬 kakao_rooms.json).
