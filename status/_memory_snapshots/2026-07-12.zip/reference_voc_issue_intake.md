---
name: reference_voc_issue_intake
description: 회원 VOC 이슈 접수 폼 + 응답 시트 URL·구조. 운영부 체계 페이지의 접수→처리 흐름 원천
metadata: 
  node_type: memory
  type: reference
  originSessionId: 644d85ba-fbd1-4fc9-8170-ce95d1fcc47a
---

웰페리온 회원 VOC(이슈) 접수·처리 자료 (GM 제공 2026-06-08). 운영부(AI COO·이경연 실장) 소관.

**접수 폼 = "웰페리온 멤버의 소리 VOC"** (애정 있는 멤버 건의를 접수 직원이 기록 → 운영팀 전달)
https://docs.google.com/forms/d/e/1FAIpQLSd7mDzTyZT5FSXVcxmpMCaqv7M-RR3EmEu2lFqGRksUE77osA/viewform
- 입력 항목: 직원&회원명*, 연락처, 이슈 내용, 불편했던 장소*(중복선택), 접수자*, 전달 부서*. (*=필수)

**응답 시트 = 리셉션 업무 시트 VOC/이슈 응답 탭** (탭 명칭 정본 = 「이슈 응답」 [[project_coo_issue_sheet_name]])
https://docs.google.com/spreadsheets/d/1akZLs7ITs3FZWFIzMQvSYrdRucGQglmerOvTC2TLEcQ/edit?gid=1576318230
- ⚠️ 이 시트는 멀티탭(후문 출입카드 불출대장·예치금 관리 등 리셉션 업무 다수). Drive read_file_content는 기본 탭만 반환 → gid로 특정 탭 직접 봐야 함.

**불편 장소 분류 14:** 카페·운영부·프론트·주차장·사우나·헬스장·필라테스룸·G.X룸·골프장·수영장·스쿼시장·뮤지컬룸·키즈샤워실·본에스티스
**전달 부서 분류 11:** 운영·관리·시설·지원·P.T·필라테스·수영·골프·스쿼시·체조&트램폴린·기타

처리 흐름: 회원 건의 → 직원 접수(폼 기록) → 장소·부서 분류 → 해당 부서 전달 → 처리 → 회신.

**호스팅:** 이 접수→처리 체계는 운영부 체계 페이지(coo/check/운영부 체계.html, 2026-06-08 신규)에 구조화됨. [[project_facility_dept_roles]](4부서 체계) · [[feedback_marketing_conversion_bottleneck]](VOC는 노출→전환과 별개 운영 채널).
