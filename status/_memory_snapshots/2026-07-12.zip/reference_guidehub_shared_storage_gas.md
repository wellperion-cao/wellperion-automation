---
name: reference_guidehub_shared_storage_gas
description: "가이드허브 정적페이지에 '전 PC 공용' 저장 붙이는 법 — todo GAS(.deploy-todo) 확장 + no-cors POST + 텍스트셀"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 029ac1fc-343f-44e9-a8fc-23f8d6533501
---

가이드허브(GitHub Pages 정적)는 서버가 없어 localStorage는 PC별 개별. "전 PC 공유 저장"이 필요하면 기존 todo GAS 웹앱을 확장한다.

**백엔드(GAS):** `.deploy-todo/업무&결재 현황.js` (scriptId 1VUMgK-…), 프로덕션 /exec = `AKfycbxDwFkrxK1YIaEoSNcuw2MiHiZQ-7o5N6311ytksSyeEd86ZFOhLknOWqQgNArQvZ-7`.
- action 라우팅(doGet/doPost) + `_json()` 헬퍼. 새 기능은 `if(action.startsWith('xxx_'))` **순수 추가**(기존 무영향). doGet에 POST우회 블록, doPost에 prefix 분기 둘 다 추가해야 GET·POST 공용.
- 전용 시트탭(`ss.insertSheet`)에 저장. **셀 자동변환 주의**: "2026-06-10"·"18"·locale 날짜문자열이 Date/Number로 강제변환됨 → 불러올 때 date input 복원 실패. 방지: 저장 시 `대상행 range.setNumberFormat('@')` 후 `setValues`(appendRow는 포맷 무시함). 값은 `String()`으로 감싸 기록.

**배포:** clasp 3.x. 인증 만료(invalid_rapt) 잦음 → GM이 `npx clasp login`(브라우저 OAuth, cao@wellperion.com) 1회. 그 후 `.deploy-todo`에서 `clasp push -f` + **기존 배포ID로** `clasp deploy -i <deploymentId> -d "..."` (새 배포 만들지 말 것 — URL 바뀜). deploymentId는 `clasp deployments`.

**프런트(HTML):** 서버 우선 + localStorage 폴백. 본문 큰 HTML은 GET 쿼리 한계라 **저장=no-cors POST**(`fetch(url,{method:'POST',mode:'no-cors',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify})` — text/plain이라 preflight 없음, 응답 못읽으니 저장후 list 재조회로 확인). 읽기=GET `?action=..._list`(JSON 읽기 가능). 저장은 list확인에 의존하지 말고 항상 POST. 한글은 브라우저 fetch면 UTF-8 정상(단 **Windows curl 한글인자는 깨짐** — 테스트는 Playwright로).

관련: [[reference_clasp_webapp_redeploy]] [[reference_appsscript_korean_write]] [[todo_api_response_envelope]] [[reference_gas_file_upload_must_post]].
