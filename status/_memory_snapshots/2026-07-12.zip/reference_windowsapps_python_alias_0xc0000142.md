---
name: reference_windowsapps_python_alias_0xc0000142
description: 바탕화면 python.exe 0xc0000142 오류의 근본원인·수리법 (WindowsApps 죽은 별칭 스텁)
metadata: 
  node_type: memory
  type: reference
  originSessionId: fa033a56-3475-467f-8d71-a1ac59a8982d
---

**⚠️ 원인 2종 — 헷갈리지 말 것. 0xc0000142가 python뿐 아니라 git·schtasks 등 여러 exe에서 동시에 뜨면 (2)번(시스템 자원)이 진짜 원인, python만이면 (1)번(별칭).**

**(1) python 별칭 스텁 (python 단독일 때):** `C:\Users\jjky0\AppData\Local\Microsoft\WindowsApps\python.exe`·`python3.exe`가 0바이트 App Execution Alias 스텁(Store Python 미설치인데 별칭만 살아있음). bare `python` 실행 시 PATH가 이 스텁으로 잡히면 0xc0000142. 수리=스텁 삭제 + bare python→전체경로. `where.exe python`으로 진단.

**(2) 시스템 자원(데스크톱 힙) 고갈 (여러 exe 동시일 때 · 2026-07-09 실제 원인):** python·git·schtasks 등 서로 무관한 exe가 5분 주기로 계속 0xc0000142. 진단 증거: ①schtasks.exe(특이 의존성 없는 기본 도구)까지 실패=앱 DLL 문제 아님 ②메모리는 정상(여유 GB) ③System 이벤트로그 Application Popup(ID 26)이 exe명·주기 그대로 기록 ④daily_scheduler 5분 job(push_sweeper→git 등)이 자식 프로세스 spawn 시 실패. 뿌리=실행 프로세스 309개(claude 11·chrome 16·node 7)로 세션 데스크톱 힙(SharedSection 2번째 값=20480KB) 빠듯 + 5분 자동화 storm이 임계 초과. **즉시완화=재부팅(힙 초기화). 근본수리=SharedSection 상호작용 힙 증대(20480→40960↑)+재부팅.** ★HKLM Session Manager SubSystems Windows 값은 부팅 임계 키 — 나머지 문자열 완전보존, 오타=부팅 손상 위험. GM go 필수.

이 오류는 WER/Application Error(event 1000) 로그를 안 남김(초기화 전 실패) → **System 로그 Application Popup(ID 26)** 로 exe명·주기·빈도를 잡는 게 정석 진단.

진짜 python은 `C:\Python314\python.exe`(3.14.3) 정상. 대화상자는 이미 죽은 프로세스라 확인 눌러 닫아도 무해.

**수리(2026-07-09 완료):** ① 죽은 스텁 2개 삭제 `Remove-Item ...WindowsApps\python.exe,python3.exe -Force` (가역·성공). ② bare `python` 호출 예약작업을 전체경로로 하드닝 — Wellperion-AI-Education-Weekly Execute `python`→`C:\Python314\python.exe`(New-ScheduledTaskAction는 WorkingDirectory="" 빈문자열 넘기면 throw → 조건부 생략). 결과: `where.exe python`=C:\Python314 단일.

**재발 방지 규칙:** 모든 .bat/.vbs/예약작업/스크립트에서 python은 전체경로(`C:\Python314\python.exe`)로 호출. bare `python` 금지 — WindowsApps 스텁 부활 위험. 관련: [[reference_powershell_scheduledtasks_limitation]] · [[reference_python_console_utf8_env]]
