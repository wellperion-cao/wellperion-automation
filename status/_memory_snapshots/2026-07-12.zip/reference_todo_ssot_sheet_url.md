---
name: reference_todo_ssot_sheet_url
description: 업무&결재 현황 SSOT 구글시트 실제 URL/ID — todo_list·hangro·AI배 이관 대상
metadata: 
  node_type: memory
  type: reference
  originSessionId: 644d85ba-fbd1-4fc9-8170-ce95d1fcc47a
---

업무&결재 현황 SSOT(=업무현황 S3 = GAS `todo_list` = hangro_board 소스)의 실제 구글시트.

- URL: https://docs.google.com/spreadsheets/d/1aqZGHpxzjAMqQvWQDrBWxrVtrFdZhFMxqFudNFlGnTk/edit
- Spreadsheet ID: `1aqZGHpxzjAMqQvWQDrBWxrVtrFdZhFMxqFudNFlGnTk`
- GAS(컨테이너 바인딩): `.deploy-todo` (scriptId 1VUMgK-vJvxCUO_mjQPpTFLjtv3NWWt8ESkCHH-l3QyCYrpBw2RXsYFFg), `SpreadsheetApp.getActiveSpreadsheet()` 사용 → 소스에 ID 미하드코딩이라 코드에서 자동 회수 불가(2026-06-08 GM이 직접 회수해 제공).
- clasp는 cao@wellperion.com 로그인 상태. `clasp open-container`는 Parent ID 미설정으로 실패 → Drive 검색("업무&결재 현황 SSOT")이 가장 빠른 열기 경로.

AI 배 이관: 이 스프레드시트 안 신규 탭 `AI배(C레벨)`로 분리 진행(2026-06-08 GM 결정). 계획=docs/queue_migration_new_tab_plan_20260608.md. 관련 [[project_g1_vs_업무현황_분리]] · [[feedback_queue_migration_lessons]].
