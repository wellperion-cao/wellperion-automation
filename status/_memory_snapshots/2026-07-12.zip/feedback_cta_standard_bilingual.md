---
name: feedback_cta_standard_bilingual
description: 전 채널 표준 CTA = "문의 : wellperion.com/ko/inquiry" 한 줄(한국어). 영어 줄 폐기(2026-06-08). litt.ly 폐기
metadata:
  node_type: memory
  type: feedback
  originSessionId: 2370e909-23da-4dbd-a077-61e32e4bb950
---

GM 확정. 웰페리온 **모든 채널(IG·네이버블로그·네이버카페(동부이촌동)·카카오채널·당근) 콘텐츠 CTA 표준 = 한 줄, 한국어만**:

```
문의 : wellperion.com/ko/inquiry
```

**Why:** GM 2026-06-08 — 영어 문의 줄(`/en/inquiry`)은 불필요하니 빼고 한 줄로 통일. (이전 한·영 2줄 방침 폐기). `litt.ly/wellperion` 단일 CTA도 폐기됨. 문의 단일 진입점 = wellperion.com/ko/inquiry.

**How to apply:** 신규 생성하는 모든 채널 콘텐츠 캡션·본문 말미에 위 **한 줄만** 삽입. `(한)/(영)` 라벨·영어 줄 넣지 말 것. 과거 발행물은 이력이라 불변(소스 정리만). 표기는 `http://` 없이 `wellperion.com/ko/inquiry`(사람이 읽는 텍스트), 클릭 링크 필요한 곳(워드프레스 등)은 `http://wellperion.com/ko/inquiry/` 풀경로.

**당근 추가 제약:** 당근 소식 제목칸 ~27자 제한 → 짧은 제목 별도 필요. 연관 [[reference_inquiry_funnel_map]] [[project_4channel_standard]] [[project_danggn_manual_b_confirmed]].
