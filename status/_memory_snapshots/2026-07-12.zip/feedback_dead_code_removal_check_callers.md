---
name: feedback_dead_code_removal_check_callers
description: GAS 액션 제거 시 그 액션을 호출하는 프론트엔드도 반드시 같이 점검·교체
metadata: 
  node_type: memory
  type: feedback
  originSessionId: aada9a37-c277-456a-853a-4e6c29976195
---

GAS 액션을 dead code로 판단해 제거할 때, 회귀검증을 기존 액션(todo_list 등)만 확인하면 부족하다. **그 액션을 호출하는 프론트(JS saveMatrix 등)까지 왕복 검증**해야 한다.

사례(2026-06-23): matrix_get/matrix_set을 GAS @87에서 제거했으나 S2 saveMatrix가 여전히 matrix_set을 호출 → 저장 기능 깨짐. 웰리가 saveMatrix를 commit_file로 복구.

**Why:** GAS 액션 제거 = 서버 인터페이스 변경. 클라이언트(HTML JS)에서 그 액션을 참조하는 곳을 grep으로 먼저 확인하고, 없애거나 대체한 뒤 제거해야 회귀가 없다.

**How to apply:** 액션 제거 전 `grep -n "action.*제거할액션명"` 으로 HTML·JS 호출부 전수 확인 → 호출부 먼저 교체 → 그 다음 GAS 제거 → 왕복(저장·조회 실제 동작) 검증.

[[feedback_always_structure_simplify_advance]] · [[feedback_welly_verification_standard]]
