---
name: feedback-cleanup-merge-relocate-delete
description: 정리(클린업)는 _archive 남발 말고 케이스별 병합·이관·삭제 우선. 비SSOT/중복/죽은것 판별 후 정본으로 일원화.
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f3c8a5d0-02a4-4185-b9c3-8d6fb46df4bb
---

**★근본 원칙 (2026-06-16 GM 강조):** 현재 모든 정리가 안 되는 **근본 문제 = 산발(scatter)·중복**이다. 그러니 **새로 만들기 전에 항상 "이미 어딘가 있나?"부터 확인** → 있으면 거기를 단일출처로 쓰고 **포인터/링크만**, 절대 같은 걸 또 만들지 않는다. 무분별하게 추가 금지. 작업의 기본자세 = **추가가 아니라 통합**(중복 제거·단일화). 실제 사례: ERP '시스템 현황'에 '각 AI 맡은 일'을 넣었다가 G1 항로와 중복이라 GM이 지적 → 제거하고 G1 포인터로 교체(2026-06-16). [[project_ssot_dedup_2026_06_06]]

GM 지시(2026-06-15): 정리할 때 **아카이브(_archive) 남발보다 "병합·이관·삭제"가 우선**.

**케이스별 동사:**
- **같은 내용 2곳+ (중복)** → **병합**: 한 곳을 정본으로, 나머지는 1줄 포인터.
- **잘못된 위치의 유용 콘텐츠** → **이관**: 정본 섹션으로 옮김 (예: IG 발행 파이프라인 T2→M5, 기술 토글 T2→T1).
- **죽은 일회용·백업·복사본·미적용 placeholder** → **삭제**: git 이력이 보존하니 _archive 불필요 (예: 스테일 가이드 복사본·운영부 페이지 수정 일회용 스크립트·노션 이관 트래시).
- **_archive는 진짜 기록보존이 필요한 1회성 산출물만** (예: shutdown_fix 실행본).

**Why:** _archive에 다 밀어넣으면 _archive만 비대해지고 정본은 안 깨끗해짐. 한 주제=한 곳 단일화([[project_ssot_dedup_2026_06_06]])의 실행 원칙.

**How to apply (안전):**
1. 삭제 전 **미참조 검증**(grep — 코드/문서/스케줄 참조 0 확인). .omc/project-memory.json 같은 로그성 참조는 무시.
2. **공식문서·타 C레벨 영역·동시편집 중인 파일은 추측 삭제 금지** → 정본 판단을 소유자/GM에게. (회사소개서 정본 결정=CEO/GM, M섹션=시모 라이브편집 등)
3. 동시편집 핫파일(가이드 HTML) 대형 블록 이동 = **마커 기반 결정적 파이썬 스크립트 1커밋**(삭제+삽입 동시 → truncation 가드 통과) → 즉시 pull --rebase --autostash → push. [[reference_guidehub_concurrent_commit_corruption]]
