---
name: reference_handwriting_slide_engine
description: "개인계정 손글씨 슬라이드 = 종이질감+나눔손글씨 펜(본문)/붓(강조), HTML/CSS 기반. GM이 '진짜 손글씨·AI티 제거'로 확정한 룩"
metadata: 
  node_type: memory
  type: reference
  originSessionId: d877bbef-e82d-4a4c-b3c8-f578d2ba6410
---

GM 2026-07-07 확정 룩(여러 시안 끝에): **종이에 먹, 손글씨 폰트 자동.** AI 티 나던 요소(카드·시트러스 레일·모노 auto-run 신호줄·형광 밑줄·펄스 점) 전부 폐기.

**구성:**
- 바탕/종이 = 따뜻한 린넨 off-white(#e6e1d5 / 종이 #efeae0), SVG feTurbulence 노이즈로 종이 결. **AI 크림(#F4F1EA) 회피.**
- 먹 = 따뜻한 near-black #26221c, `text-shadow`로 종이 스밈(먹 번짐).
- 손글씨 폰트 = **나눔손글씨 펜(본문)** + **나눔손글씨 붓(강조)** — 상업용 무료(OFL). 강조=붓+`-webkit-text-stroke`로 눌러 쓴 굵기.
- google/fonts raw TTF → `pyftsubset`(fonttools+brotli)로 사용 글자만 woff2 subset(~150KB/폰트) → `@font-face` data URI 임베드. `.venv`에 fonttools·brotli 설치됨.
- 인간미 장치: 날짜는 첫 장 1회만·페이지넘버 없음·장마다 글 시작 높이 다름·종이 미세 회전(rotate ±.5deg)·고쳐/끼워 쓴 자국(취소선+비스듬 삽입).
- 강조 문구는 소스 span `.hit`(붓) / `.u`(손그린 먹 밑줄). 편당 1~2곳만.
- 비율 4:5. 헤더/설명은 명조(serif), 슬라이드 본문만 손글씨.

**빌드:** `scratchpad/build_hand.py`가 `namuk_ep01_diary.html`(소스) 읽어 폰트 subset·임베드→`namuk_ep01_hand.html` 생성. 아티팩트로 미리보기.

**실제 IG 제작(다음)**: HTML→PNG(Playwright 스샷, .sheet당 1080×1350)로 굳혀야 함(승인 룩 그대로 재현). PIL compose와 별개 경로.
