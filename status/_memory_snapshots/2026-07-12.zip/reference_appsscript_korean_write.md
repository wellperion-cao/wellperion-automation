---
name: reference_appsscript_korean_write
description: GAS API 호출 통합 — 한글 UTF-8 POST·파일업로드 POST 필수·응답키={ok,count,data}
metadata: 
  node_type: memory
  type: reference
  originSessionId: c06aac3f-ecc6-413f-8616-9d748f9e52cd
---

업무&결재 Apps Script(`AKfycbxDwFkr.../exec`, scriptId 1VUMgK…)에 todo를 쓸 때:

- **액션**: `todo_add`(생성·영문키→한글컬럼 자동매핑 _mapFields), `todo_update`, `todo_done`(완료), `todo_delete`. GET·POST 모두 가능(doGet이 todo_ 액션을 doPost 로직으로 우회).
- **영문 파라미터 키 사용**: `title`→업무명, `owner`→담당자, `category`→카테고리, `content`→내용, `status`→상태, `startDate`→시작일. (한글 키 `업무명=`은 URL에서 깨져 **빈 값**으로 저장됨)
- **한글 값은 반드시 UTF-8로**: bash/PowerShell `curl --data-urlencode` 인자에 한글 값을 넣으면 Windows 로케일 때문에 **깨짐**. → Write로 깨끗한 UTF-8 파이썬 스크립트를 만들고 `.venv` python의 `urllib`로 `json.dumps(payload, ensure_ascii=False).encode('utf-8')` POST(Content-Type: application/json; charset=utf-8)가 안전.
- todo_list는 **쓰기 직후 캐시 지연** — 추가/완료 직후 즉시 조회하면 안 보일 수 있음. 수 초 후 재조회로 검증.

## GAS 파일 업로드=POST 필수

Apps Script(GAS) 백엔드 폼의 **파일 첨부 업로드는 GET으로 보내면 안 된다.** base64 인코딩 파일을 `?key=val` 쿼리스트링에 실으면 URL 길이 한계를 초과 → 요청 실패 → 파일이 Drive에 안 올라가고 시트 칸도 안 써져 **그냥 '날아간다'**(에러도 조용히 묻힘).

**증상:** 첨부 넣으면 시트 기록 0·파일 사라짐.
**해결:** base64/file 페이로드만 분기해 **POST 본문**(`fetch(url,{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify(params),redirect:'follow'})`)으로 전송. `text/plain`=CORS preflight(OPTIONS) 회피. GAS `doPost`→`_processTodoAction`가 동일 action 처리.
**주의:** 읽기 action(todo_list 등)이 `doGet`에만 있으면 그건 GET 유지 — 무조건 전체 POST 전환 금지.
**검증 함정:** curl `-L`은 GAS의 302(→googleusercontent 단발 URL) POST 본문을 떨궈 411 오류 → POST 종단검증 불가. 브라우저 fetch는 정상. 최종 확인은 라이브 브라우저 실측.

## todo API 응답 키=data

`action=todo_list` 응답 = `{ ok, count, data: [...] }` — **배열 키는 `data`** (`tasks`/`items` 아님). 행 객체는 한글 헤더 키(`업무명`·`담당자`·`파일URL`·`난이도` 등) 그대로.

프론트(`업무 현황 SSOT.html`)는 `normalizeTask`로 영문 alias 부여: `파일URL→t.fileUrl`, `링크→t.link` 등. **raw 응답엔 fileUrl이 비어보여도 정상**(alias는 프론트 정규화 후 생김). 이 API를 테스트할 땐 **먼저 응답 키를 `Object.keys(res)`로 찍어 확인**한 뒤 단정하라. 2026-06-03 `res.tasks`(존재 안 함)를 읽어 멀쩡한 첨부 기능을 "버그"로 오판해 불필요하게 재배포한 사례 있음.
