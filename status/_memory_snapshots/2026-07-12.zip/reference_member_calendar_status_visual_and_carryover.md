---
name: reference_member_calendar_status_visual_and_carryover
description: 통합회원(문의회원.html) 상태 시각 규칙 + 등록 carry-over 동작
metadata: 
  node_type: memory
  type: reference
  originSessionId: f30d651b-de57-46fc-b95e-3e818a8fc470
---

통합 회원 관리 페이지(`3. 웰페리온 가이드/cpo/member/문의회원.html`, 라이브 URL은 가이드 접두사 없이 `.../cpo/member/문의회원.html`) 상태 표현·등록 흐름 규칙.

**상태 시각 규칙(달력·문의현황·등록현황 일관):**
- 🟦 금일 = 청록(teal) 테두리 / 🟩 방문(status='방문') = 녹색 ✓ / 🟡 등록(SUC·단기SUC) = 금색(--accent #B79F8A) ♛ + 금색 링·좌측 띠. 둘 다면 등록(금색) 우선.
- 등록현황 카드: 금일 등록(member.regDate=오늘) = 금색 'NEW' 배지.
- 문의현황 grid '미등록만 보기' 토글(`dbHideRegistered`): 켜면 SUC·단기SUC·결제완납·LOSS 숨김(데이터 삭제 아님, 기본 OFF).

**등록(SUC) carry-over (서버 Survey.js member_inquiry_update):**
- status가 SUC/단기SUC면 `_regUpsert_`가 '26년 등록현황' 탭에 오늘 등록일 도장 + 텔레그램 '등록 전환' 알림. carry-over는 **시트 행 직독**(body 우선, 없으면 행)으로 이름·전화·프로그램·담당 가져옴 — 달력 모달은 status만 보내므로 body.phone 부재 시 등록 미반영·알림 빈칸 버그였음(2026-06-29 행직독+멱등으로 해결). _regUpsert_는 멱등이라 재저장으로 과거 누락 복구 가능, 알림은 실제 전환 1회만.
- 달력 상담 모달: 방문 완료/등록 완료 둘 다 체크 가능(둘 다면 등록 우선). 일정 칸 시간 설정=slot(tour/exp1·2·3/visit2) 단일셀 날짜+시간 왕복.

회원·문의·등록 도메인 구현=시포(CPO). funnel GAS 재배포=clasp deploy --deploymentId AKfycbzdwSC…ddA4IAvsNfelg0xA. 관련: [[project_cpo_inquiry_system_unification]] [[reference_funnel_gas_script_id]] [[project_publish_verify_before_done]]
