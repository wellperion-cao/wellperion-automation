---
name: project_cpo_owns_post_inquiry_funnel
description: 시포=문의 이후(상담·등록·회원) 현황+월간보고 소유. 시모=마케팅 유입까지. 문의수·채널은 단일소스 공유 필수
metadata: 
  node_type: memory
  type: project
  originSessionId: 32a8877a-e132-4ec6-8f61-3e603e934d91
---

GM 2026-07-08 R/R 분업 결정. 한 퍼널을 이음새에서 반씩 나눔:
[노출·클릭]→[문의 유입]→[상담·등록]→[회원]

- **시모(CMO)** = 마케팅 현황 = 노출→클릭→**문의 유입까지** (채널·전환율·ROI). 페이지=`cmo/funnel/마케팅현황대시보드.html`.
- **시포(CPO)** = **문의 이후** = 상담(1차 컨택)→등록→회원 전환의 처리율·전환율·현재 상태 + 그쪽 **월간 보고서**(이달 문의처리·등록·회원획득 성과). 이미 소유한 문의회원(등록前)·회원관리(등록後)·문의 5종 단일체계 위에 얹음.

**Why:** 문의·마케팅은 한 퍼널이라 주인을 이음새에서 나눠야 중복·혼선 없음.

**How to apply:**
- ★이음새 최우선: '문의 수·채널' 지표는 **시모 대시보드와 같은 단일 소스**를 봐야 함. 각자 집계=숫자 어긋남=대시보드 신뢰 깨는 최대 함정(실제 사고 이력 [[reference_check_completion_rate_untrustworthy_multisource]]). **시모와 협의해 문의 데이터 소스 하나로 맞춘 뒤** 각자 반대편을 그린다.
- 원칙: 분모 정합·소스 단일·라이브 실측 대조 · 실무진 눈높이 · 정직 꼬리표(측정/부분/미측정/표본부족) · 화면 고치면 즉시 커밋·푸시 · 시크릿 크롬 검수.
- 관련 [[project_cpo_inquiry_system_unification]] [[project_funnel_stage_pages]] [[feedback_cmo_mission_dashboard_normalization]] [[project_cmo_marketing_pipeline_loop]]
