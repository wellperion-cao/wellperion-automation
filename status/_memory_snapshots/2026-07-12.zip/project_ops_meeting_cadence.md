---
name: project_ops_meeting_cadence
description: "운영부 정기 회의 2종 주기(월별) + 업무 SSOT [8] 회의 카테고리로 일원화"
metadata: 
  node_type: memory
  type: project
  originSessionId: d3de3966-d733-4b0d-a746-313d92b9381c
---

운영부(이경연 실장 준비 책임) 정기 회의 2종, 2026-06부터 매월 고정:
- **당월 넷째 주 화요일** = 익월(다음 달) 운영·매출 **기획안** 보고·진행
- **익월 첫째 주 화요일** = 전월(지난 달) 운영·매출 **결과보고** 보고·진행
- 첫 사이클: 7월 기획안 → 2026-06-23(화) / 6월 결과보고 → 2026-07-07(화)

**관리 방식 = 업무 SSOT 일원화 (별도 양식 페이지 X).** GM 결정으로 독립 인쇄 양식(구 O3) 폐기하고, `coo/todo/업무 현황 SSOT.html`에 `[8] 회의` 카테고리 추가. 회의 카테고리 선택 시 본문에 회의록 양식(📌안건·👥참석자·✅결정사항·📋후속조치) 자동 프리필. 회의는 이 SSOT에 업무로 등록·추적.

관련: [[feedback_prioritize_connect_over_create]], [[project_3line_org_structure]], [[feedback_improvement_not_rebuild]]
