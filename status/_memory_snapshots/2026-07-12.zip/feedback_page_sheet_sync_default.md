---
name: feedback_page_sheet_sync_default
description: "페이지(프론트)와 시트(서버) 동기화는 시우 기본 책임 — 부분 동기화 금지, 항상 전 필드 맞춤"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 4c9549b3-9d0d-4817-88ca-9048cac5588c
---

점검/매뉴얼처럼 페이지(프론트 하드코딩)와 시트·서버(GAS·스프레드시트)가 같은 데이터를 다룰 때, **둘을 일치시키는 건 시우가 매번 알아서 해야 하는 기본**이다. GM이 시킬 때까지 기다리거나, 항목만 추가하고 회차·일정·시간대 같은 필드를 비워두는 **부분 동기화는 금지**.

**Why:** 2026-06-16 GM 지적 — 매뉴얼 시트에 항목은 넣었으나 회차라인(rounds)·일정(sched)·시간대(slot)를 비워둬 페이지와 어긋남. "이제 스스로 해줘 페이지랑 시트(서버)랑 맞추는게 당연한거잖아."

**How to apply:** 매뉴얼·점검 데이터를 바꿀 때 항상 (1) 페이지 소스(WEEKDAY/ROUND_MAP/sched 등)와 (2) 시트(지원_매뉴얼 등) 전 필드를 함께 맞춘다. 한쪽만 고치면 안 됨. 동기화 후 양쪽 실측 대조. 관련 [[project_support_check_zone_routing]] · [[feedback_cleanup_merge_relocate_delete]].
