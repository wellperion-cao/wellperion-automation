---
name: project_g1_sources_no_queue_unification
description: G1 항로=큐(AI)+시트(GM개인4)+결재(시트) 유지. 큐 일원화 보류 — 큐 읽기전용이라 GM 편집성 손실 방지(2026-06-17)
metadata: 
  node_type: memory
  type: project
  originSessionId: 0d43be27-1432-4903-847a-5765722b1984
---

2026-06-17 GM 결정. G1 '오늘의 항로' 데이터 소스는 **3겹 머지 유지**(일원화 안 함):

1. **_queue.json** — AI C레벨 ship(PENDING·IN_PROGRESS). G1에서 **읽기전용**(브라우저 쓰기 백엔드 없음 → 코드/agent/CLI만 편집·커밋).
2. **시트 GAS todo_list 중 담당자=김남욱GM/AI C레벨**(`_isG1Owner`, wellperion_guide(main).html ~line 7835) → **GM 개인 4건**(GM-01 다이슨 대안·GM-02 쓰쿠루 계약해지·GM-03 4부서 셋업·GM-04 기구 A/S). GM이 G1 수정·완료 버튼으로 **직접 편집**(todo_update GAS).
3. 시트 **결재**(진행 중) → 🔴 GM 차례 + ⏳ 진행중 배너.

**"항로=큐 단일 일원화" 검토 후 보류한 이유:** 큐는 브라우저에서 못 고쳐(쓰기 백엔드 부재) GM 4건을 옮기면 **읽기전용으로 강등** → GM이 자기 프로젝트를 G1에서 직접 편집 불가. 연동 fragility(오늘 푸시랙·큐 발행경로 404)는 [[project_g1_sources_no_queue_unification]] 동반 작업인 **연동 다리 자가점검 가드(integration_health.py)** 로 이미 해결돼 일원화 불필요. 진짜 일원화하려면 **큐 쓰기 백엔드 신설 선행**(후속·보안과제, [[project_todo_api_open_security_gap]] 연계).

시트에 'G1' 칸/라벨은 없음 — G1 합류 기준은 **담당자가 GM이거나 AI C레벨이냐**(`_isG1Owner`)다. 관련: [[project_g1_vs_업무현황_분리]] · [[project_g1_ai_ship_readonly]].
