---
name: project-12-slot-facility-status
description: 12시 텔레그램 슬롯 = 시설·지원·주차 점검 현황 (트렌드 브리핑 폐기)
metadata: 
  node_type: memory
  type: project
  originSessionId: 314d921a-1885-4af1-80e5-e572cc2e31a3
---

12시 자동 보고 슬롯이 "트렌드 브리핑(미구현 빈칸)"에서 "시설·지원·주차 점검 현황"으로 교체됨.

**Why:** GM님이 12시 트렌드는 의미 없다고 판단. 실시간 운영 현황 파악이 더 유용.

**How to apply:**
- daily_scheduler.py `_build_12_body()` 함수가 구현 완료
- 데이터 소스: Google Sheets API (CHECKLIST_API_URL) 우선, Notion COO DB (COO_CHECKLIST_DB_ID) 보조
- .env에 COO_CHECKLIST_DB_ID=a410bf93-7d7a-412f-9194-411b7103e420 추가 완료
- CHECKLIST_API_URL은 Apps Script v3 배포 후 GM님이 입력
- apps_script_v3.js (3시트 구조) 로컬 작성 완료, GM님 수동 배포 필요
