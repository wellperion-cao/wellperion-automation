---
name: feedback_git_commit_atomic_vs_watcher_reset
description: 동시 실행 watcher/세션이 작업 트리를 리셋해 미커밋 편집을 날림 → 편집은 한 커밋으로 즉시 기록 + rebase는 --autostash
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 713d60b8-b992-4f64-9f62-d9c437c55021
---

이 repo는 여러 세션·watcher(예: CEO verify watcher, morning update, 자동 changelog 봇)가 동시에 master에 커밋·체크아웃한다. 미커밋 working-tree 편집은 동시 프로세스의 HEAD 리셋/체크아웃에 의해 조용히 날아갈 수 있다(2026-05-29 세션: build_slides.py·gm1 토글 편집 2회 유실). 또한 working-tree에 무관한 대규모 미스테이징 변경(brand 폴더 reorg·notion-c-level-agents→wellperion-agents 이름변경)이 상주해 수동 `git stash` 댄스가 충돌·유실을 유발.

**Why:** 수동 stash push/pull/pop 댄스를 4회+ 반복하다 토글 커밋이 통째로 유실되고 stash 충돌 발생. 근본 원인은 (a) 동시 프로세스의 트리 리셋, (b) 상주 미스테이징 변경이 rebase를 막음.

**How to apply:**
- 편집은 **원샷으로 즉시 커밋**: 한 Bash 호출 안에서 (파일 수정 → `git add <경로>` → `git commit`) 묶어 처리. 커밋된 히스토리는 트리 리셋에도 살아남음. Edit 후 한참 뒤 커밋하면 그 사이 watcher가 되돌릴 수 있음
- 원격 동기화는 수동 stash 금지, **`git pull --rebase --autostash`** 사용 (dirty tree 자동 처리·원자적)
- 커밋은 항상 **명시 경로만** add (`git add -A` 금지 — 상주 reorg 변경 휩쓸림)
- 마무리 검증: `git rev-parse HEAD` == `origin/master` + `git show HEAD:<파일>`에 변경 존재 확인 + 라이브 URL [[feedback_verify_deployed_not_local]]
- 반복 시 CTO에 watcher 충돌(동시 트리 리셋) 점검 지시 — [[project_ceo_verify_watcher]]

**가이드허브(wellperion_guide(main).html) 고빈도 동시편집 추가 교훈 (2026-06-03):**
- **Edit 툴 "modified since read" 반복** = 파일이 초 단위로 바뀜(타 세션 + changelog 훅이 커밋마다 가이드허브 재작성·재스테이징). Read→Edit 사이 경합 불가피. → **Python 디스크 치환**(`p.read_text`→`str.replace`(존재 시 1회)→`p.write_text`)으로 우회. Edit 툴 상태추적을 안 거쳐 경합 면역. 치환은 idempotent하게(old 존재할 때만).
- **commit "no changes added"(exit 1)인데 grep으론 편집이 파일에 존재** = changelog 훅이 가이드허브를 자동 스테이징하면서 내 미커밋 편집을 **인접 세션 커밋에 흡수**시킨 것. 실패 아님. `git diff --cached --stat` 비고 + 작업파일 grep=1이면 이미 HEAD 반영. origin up-to-date 확인으로 종결.
