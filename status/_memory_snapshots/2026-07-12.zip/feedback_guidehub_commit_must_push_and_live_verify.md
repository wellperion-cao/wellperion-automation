---
name: feedback_guidehub_commit_must_push_and_live_verify
description: "가이드허브 SSOT UI 수정은 commit만으론 라이브 반영 안 됨 — origin push + 라이브 __PV/실측까지 확인해야 '완료'. 검수=헤드리스 브라우저 클릭 테스트"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 254e1f75-0568-4c09-8217-64bab6ba4cf8
---

**2026-06-05 사고: 같은 UI 수정을 "완료"라 3번 보고했는데 GM 화면은 '변함없음'.** 진짜 원인 = **커밋은 했지만 origin에 push가 안 돼**(`master ahead of origin/master`), GitHub Pages(pages.yml은 origin/master 기준 배포)가 옛 버전을 서빙. 코드는 맞았으나 세상에 안 나간 상태.

**Why:** 코드 추론으로 "맞으니 됐다"고 단정 → 라이브 실측 생략. 게다가 동시 커밋 폭주(changelog 훅+타 에이전트) 속에서 내 마지막 커밋들의 push가 누락됨.

**How to apply (가이드허브/SSOT html UI 수정 시 '완료' 정의):**
1. **push 확인 필수** — `git status -sb`에 `ahead of origin/master` 없어야. 비FF면 `git pull --rebase --autostash origin master` 후 push (`|cat`은 실패코드 가리니 금지).
2. **라이브 __PV 폴링** — `urllib`로 배포본 fetch해 `window.__PV` 값과 핵심 코드 문자열이 내 버전인지 확인(배포 ~40s~2min, pages.yml `cancel-in-progress`라 지연 가능).
3. **검수 = 헤드리스 브라우저 클릭 테스트** — `.venv/Scripts/python.exe` + Playwright로 라이브 로드→실제 클릭→DOM 카운트(예: 칸반 `.kanban-col` 수 before/after). 결과 JSON 파일로 덤프(콘솔 cp949가 한글·— 깨뜨림). 스크린샷 `qa_screenshots/`.
4. 이 셋 다 통과 전엔 "완료" 보고 금지. [[feedback_welly_publish_verify_artifacts]] · [[reference_clasp_webapp_redeploy]](GAS는 별도 재배포) · [[feedback_git_commit_atomic_vs_watcher_reset]]와 동일 정신.
5. **"1~2분 뒤 새로고침" 식 안내 금지(GM 2026-06-16).** 배포를 사용자에게 떠넘기지 말고, 내가 라이브 폴링으로 반영 확인한 *뒤에* "새로고침하세요"를 요청한다. 화면이 그대로면 보통 브라우저 캐시 → 하드 리프레시(Ctrl+Shift+R) 안내.

해당 사건 수정 라이브검증: 결재현황 이경연 클릭 → 7칸→1칸('이경연 서명대기 2건'), 버튼수=카드수=2 (Playwright 실측 PASS, push 857ca00).
