---
name: feedback_gm_verify_via_incognito_chrome
description: GM에게 라이브 결과를 확인시킬 때는 항상 시크릿(incognito) 크롬 창으로 해당 라이브 URL을 띄운다
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b3359991-443e-4181-85a5-99e1e854838f
---

GM에게 라이브 결과(웹페이지·발행물·교체·링크 등)를 확인시킬 때는 **항상 시크릿(incognito) 크롬 창으로 해당 라이브 URL을 띄워서** 보여준다. 캡처·말로만 보고하지 말고 GM이 직접 진짜 라이브를 보게.

**Why:** 캐시·로그인 없이 사용자가 실제로 보는 진짜 라이브(After)를 GM이 직접 확인하게 하기 위함. 약속 L03(시크릿 검수)의 연장 — 웰리 자체 검수뿐 아니라 GM 확인 단계도 시크릿창으로.

**How to apply:** `Start-Process "chrome.exe" "--incognito <URL>"` (Windows). 링크 교체·발행·페이지 수정 등 GM 확인을 요청하는 모든 순간에 매번 적용. 한글 경로 URL은 NFC 정규화 후 요청. [[feedback_always_state_record_location]]

**웰리·서브에이전트 자체 검증도 비로그인 필수(2026-06-30 박제):** Playwright/스샷으로 레이아웃·헤더를 검증할 때 **로그인 세션으로 찍으면 WP 관리자 바(상단 ~32px)가 헤더를 아래로 밀어내 로고 잘림 등 헤더 결함을 가린다.** reception 페이지 로고 잘림을 디자이너가 로그인 상태로 찍어 두 번 놓친 사례. → 반드시 `browser.new_context()`(쿠키 없는 기본 컨텍스트 = GM 시크릿과 동일 조건)로 찍고, `adminBar:false` 확인. 디자인 변경은 모바일+데스크톱 둘 다 비로그인으로 실측.
