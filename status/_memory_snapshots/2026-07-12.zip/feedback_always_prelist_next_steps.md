---
name: feedback_always_prelist_next_steps
description: 작업 마무리마다 웰리가 다음 단계를 선택 가능한 카드로 미리 제시 (GM 바로 선택)
metadata: 
  node_type: memory
  type: feedback
  originSessionId: c2a5b59a-b1a8-4b2c-8f11-75e007bf80af
---

GM 지시(2026-07-04): **항상 작업이 마무리되면 웰리가 다음 단계를 미리 리스트업**해 GM이 바로 선택할 수 있게 한다.

**Why:** GM이 매번 "뭐 하지" 고민 없이 즉시 결정·진행. 표류 금지(약속 L11)·항로점(다리 놓기). GM은 안 선택되는 줄글보다 클릭 카드를 선호.

**How to apply:** 모든 완료 보고 끝에 **다음 단계 2~4개를 AskUserQuestion 클릭 카드**로 제시한다(추천이 있으면 첫 옵션+"(추천)"·각 카드에 KPI→북극성 함의 한 줄). '지금 유휴 유지/오늘 입항' 옵션도 항상 포함해 계속/중단을 GM이 고르게. 단발 조회·사소한 답변엔 불필요.

**[[feedback_minimize_gm_participation_batch_auth]]와 조화(중요):** 작업 *실행*은 여전히 자율(되돌릴 일은 안 여쭙고 바로). 이 카드는 '해도 되나요?'가 아니라 **'다음 어디로 갈까'(방향 선택)** — 방향은 GM 몫. 즉 자율 실행 + 종료 시 GM이 다음 항로를 클릭 선택. 모순 아님. [[feedback_offer_numbered_options]] [[project_bridge_mechanized]] [[feedback_gm_reports_short_scannable]] [[feedback_gm_decides_by_seeing_kpi_path]]
