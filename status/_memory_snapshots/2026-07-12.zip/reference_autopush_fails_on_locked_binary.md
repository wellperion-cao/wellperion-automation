---
name: reference_autopush_fails_on_locked_binary
description: 자동 push non-fast-forward 실패가 반복되고 .git/rebase-merge에 autostash만 남은 고아 상태일 때 — 원인은 열린 앱(PowerPoint 등)이 바이너리 파일을 잠근 것. merge로 우회
metadata: 
  node_type: memory
  type: reference
  originSessionId: 9464646a-9562-4441-b0f0-380a920c50dd
---

자동 push 스위퍼의 `pull --rebase --autostash`가 반복 실패하고 `.git/rebase-merge`에 `autostash` 파일만 남은 **고아 rebase 상태**(제어파일 git-rebase-todo·done·onto 전부 없음, "all conflicts fixed: run continue"라 떠도 continue가 "edit all merge conflicts" 거부, `git ls-files -u`는 빈 값)가 되는 진짜 원인 = **열린 데스크톱 앱이 워킹트리 바이너리 파일을 잠금**. 증거 = 같은 폴더에 `~$파일명.pptx` 잠금파일 존재.

**왜 실패하나:** rebase/autostash는 시작 시 워킹트리를 `onto`로 `reset --hard` 함 → 잠긴 파일 unlink 시도 → Windows `Invalid argument` → 중간에 죽고 rebase-merge 디렉터리 고아로 남음. 잠긴 동안은 rebase·checkout·reset 모두 같은 이유로 무조건 실패.

**복구 절차:**
1. `rm -rf .git/rebase-merge` (고아 제어 디렉터리 제거 — HEAD는 안 옮겨졌으니 안전. autostash SHA는 백업으로 메모/태그)
2. 원격이 잠긴 파일을 건드리는지 확인: `git diff --name-only HEAD origin/master`. 안 건드리면(대부분) →
3. `git merge --no-edit origin/master` — merge는 워킹트리 reset을 안 하므로 잠긴 파일을 안 건드리고 통합됨. 열린 파일·작업 변경 그대로 보존.
4. `git push`.

원격이 그 잠긴 파일을 실제로 건드리면 merge도 막힘 → 그땐 GM께 해당 앱(PowerPoint 등) 닫기 요청이 유일.

**근본해결 박제됨(2026-06-22, GM deep-interview '열린 파일은 건너뛰게' 선택):** 이 폴더는 '로봇 자동백업(git)'+'GM 라이브 편집(PowerPoint/PDF)' 겸용 → 둘 충돌이 진짜 원인. 2층 방어:
1. **커밋 시점**(커밋 ed6d7512) — `scripts/precommit_skip_open_office.py` 신규, pre-commit.hook ①-2.3 단계. 잠긴 작업문서(`~$` 사이드카 OR 자기참조 rename 실패로 판정, 작업문서 확장자만)를 커밋 직전 unstage → 이번엔 건너뛰고 **닫히면 다음 주기에 자동 백업**. `git add -A`(clevel.bat)·지정경로 둘 다 커버. fail-open.
2. **동기화 시점**(커밋 2c3317dd) — `post_commit_push.py` `_reconcile`: 워킹트리 dirty면 rebase 건너뛰고 곧장 `merge --no-edit`(열린 파일 안 건드림), 깨끗하면 rebase→merge 폴백 + 고아 rebase-merge 강제삭제(`_clear_orphan_rebase`).
3. `.gitignore`에 `~$*` 등 오피스 잠금/임시 영구 무시.

이제 GM이 파일 열어둬도 로봇이 안 부딪힘 → 알림 안 뜸. 손복구는 merge도 실패(진짜 내용충돌·원격이 그 잠긴파일 수정)할 때만. 관련: [[feedback_git_commit_atomic_vs_watcher_reset]] · [[reference_guidehub_concurrent_commit_corruption]] · [[feedback_security_live_activation_needs_gm_go]]
