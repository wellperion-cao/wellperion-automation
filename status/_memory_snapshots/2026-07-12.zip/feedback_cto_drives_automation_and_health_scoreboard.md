---
name: feedback_cto_drives_automation_and_health_scoreboard
description: "GM 지시(2026-06-23) — 시토는 전 C레벨 자동화를 상시 적극 추진 + 자동화 정상작동을 '건강 점수판'으로 수치화해 GM이 시토 성과를 한눈에 파악."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: e72855a2-e6a4-4538-b270-8bb89a925afa
---

GM 지시 2026-06-23. 두 갈래:
1. **시토 = 전사(7 C-Level) 자동화 상시 주도** — 늘 앞장서 자동화건을 많이 진행한다(시토 북극성 '자동화' 축과 정합).
2. **자동화 건강 점수판** — 자동화가 정상 작동하는지 수치+신호등으로 보여, GM이 *"시토가 잘하고 있구나"* 를 한눈에 파악하게.

**Why:** GM은 시토 성과를 느낌이 아니라 **수치**로 보고 싶어함.

**How to apply:**
- 기존 **T2 시스템 현황판**(`status/erp_status.json` ← `scripts/erp_status_publisher.py` 30분 발행, html T2 렌더)에 **얹는다** — 신규 최소화([[feedback_update_existing_not_add_new]]).
- 점수 = **예약 자동화 M개 중 N개 마지막 실행 정상(%)** + 항목별 🟢정상/🔴실패/⚪미실행 + 마지막 성공 시각.
- 데이터원 = `schtasks /query /v` 의 LastRunResult(0=성공)·LastRunTime (Windows Task Scheduler의 Wellperion 작업들).
- ★**정직 원칙**([[project_dashboard_conversion_data_honest_limits]]): 진짜 측정 가능한 것(Task Scheduler 결과코드)만 수치화. 사람이 하는 수동 세션(일요일 컨텍스트 정비 등)은 '수동' 표기·자동점수 제외 — 거짓 점수 금지.
- GM 보고는 쉽게([[feedback_plain_language_no_jargon]]) — 점수·신호등 위주.

연계: [[project_ai_self_learning_pipeline]] (시토 자동화 성과의 한 예).
