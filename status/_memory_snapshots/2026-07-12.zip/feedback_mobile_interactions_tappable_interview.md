---
name: feedback_mobile_interactions_tappable_interview
description: 모바일(원격) 상호작용은 탭 가능한 인터뷰 형식(AskUserQuestion)으로 제시
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ea07bb26-4d5d-47c0-bb0a-4bf74f184be8
---

GM이 모바일(원격 Claude Code)로 응답할 때는 **결정·선택지를 AskUserQuestion 카드(탭 가능한 인터뷰 형식)**로 제시한다. 텍스트 표에 "한 줄 답 주세요"로 두지 말 것 — 모바일에서 타이핑 대신 **버튼 탭**으로 답할 수 있게.

**Why:** GM이 퇴근·이동 중 모바일로 승인/결정을 처리 → 타이핑 부담 없이 탭 한 번으로 진행. 2026-07-09 명시 지시.

**How to apply:** GM 결정 대기 항목(배포 go·툴 택1·디자인 OK 등)이 여러 건이면 한 번에 여러 질문(최대 4)으로 묶어 카드로. 각 질문 2~4 선택지, 첫 옵션=추천(근거 있을 때만). 데스크톱 CLI에선 기존대로 표·텍스트 OK. [[feedback_offer_numbered_options]] · [[feedback_gm_prefers_designed_artifact_proposals]] · [[feedback_remote_control_always_on]] 연장선.
