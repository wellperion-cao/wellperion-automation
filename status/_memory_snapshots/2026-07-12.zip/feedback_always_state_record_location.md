---
name: feedback_always_state_record_location
description: "일·결과를 보고할 때마다 '어디에 기록했는지' 위치를 항상 같이 알려준다"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ff42501c-1a21-4c23-b063-a4f7a97fd7b2
---

GM께 일·결과를 보고할 때마다 **그 내용을 어디에 기록했는지 위치를 한 줄로 항상 같이 알려준다.** 끝에 "이건 ○○에 기록했습니다" 형태.

**Why:** GM 명시(2026-06-16). 진행한 내용이 어디 남았는지 GM이 추적할 수 있어야 함. 사람·AI가 같이 보는 공용 자리(운영 가이드·항로)에 남겼는지, AI만 보는 메모인지도 구분해 밝힐 것 — AI 전용에만 박아두는 실수를 GM이 반복 지적함. 공유돼야 할 규칙·약속은 공용 운영 가이드(ssot/약속.json→ERP)에 둔다. [[feedback_plain_language_no_jargon]]

**How to apply:** 기록 위치 5종 — ①오늘의 항로/업무 보드(GM 화면) ②공용 약속·사고(운영 가이드 ssot/, GM 화면) ③깃 변경이력 ④콘텐츠 폴더 ⑤AI 메모(AI 전용). 보고 끝에 해당 위치 명시. 내부 코드·번호(약속번호·사고번호·작업ID)는 GM 화면에 노출 금지(사람 말로 풀거나 뺀다).
