---
name: project_official_facility_series_unified_main_page
description: 공식 시설 시리즈(F1·F2·F3…) — 다음번부터 통일된 메인(표지) 페이지 도입. 통일감 중요
metadata: 
  node_type: memory
  type: project
  originSessionId: 55d6c635-7b89-4ee9-8df5-4da3bce4ad45
---

GM 방향(2026-07-08): 공식 @wellperion 시설 시리즈에 **통일된 '메인(표지) 페이지'**를 도입한다. 이번 3편(F1 운동·F2 편의시설·F3 회복)은 메인 페이지 없이 진행했지만, **다음번부터는 각 편 첫 장에 통일된 메인/표지가 있으면 좋겠다** — 시리즈 전체의 **통일감(브랜드 일관성)이 중요**하다는 취지.

적용 대상: 공식 시설·강습 시리즈 슬라이드 1p(표지). 개인계정 메인 템플릿([[project_main_slide_template]] — 65/35 분할·W로고+컬러칩)처럼 **색만 바꿔 고정하는 재사용 표지 템플릿** 방향이 GM 선호와 부합. compose_barre(사진형 정본, [[project_ballet_design_canonical]]) 엔진에 통일 표지 레이어를 얹는 형태 검토.

지금은 미착수(이번 3편은 표지 없이 발행). 후속 배로 F2·F3 양산 시 또는 GM 재요청 시 통일 표지 템플릿 설계·적용. 관련 [[feedback_single_image_set_all_channels]](최종세트 1벌 전채널 공유) · [[project_namuk_operator_case_series]].
