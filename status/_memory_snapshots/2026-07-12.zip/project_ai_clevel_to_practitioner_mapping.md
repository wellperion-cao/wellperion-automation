---
name: ai-c-level-ssot
description: "AI 조직DB의 \"실무진(최종 책임자)\" 필드 관련 SSOT 통합: (1) 각 AI C-Level의 서포트 대상 실무직원 매핑, (2) Start 기획DB·결과물DB의 select 옵션 6명. AI는 실무진을 역할별로 서포트하는 포지션."
metadata: 
  node_type: memory
  type: project
  originSessionId: 63d35c3d-04dd-4095-be62-d069a913f146
---

AI 조직DB(`33f0407d-a948-80d2-ad27-000b132ef146`)의 `실무진(최종 책임자)` multi_select 필드에 각 C-Level별 서포트 대상 실무직원 매핑 SSOT. (2026-05-20 GM님 확정)

**전제 (R/R 대전환 적용):** AI는 실무진(최종 책임자)을 **각 역할별로 서포트**해주는 포지션. 메인 의사결정·진행·결과 책임은 실무진. 메모리 [[feedback_role_inversion_main_support]] 정합.

**매핑 (2026-05-20 GM 확정 — 전수 완료):**
| AI C-Level | 실무진(최종 책임자) | 서포트 영역 |
|---|---|---|
| AI CEO | 김남욱 GM | 전사 총괄·조정·중계 |
| AI CFO | 나우열M | 재무·세무·예산 |
| AI CHRO | 나우열M | 인사·채용·평가·온보딩 |
| AI COO | 최준용M, 윤병현AM | 현장 운영 (PT·GX·F&B) |
| AI CMO | 김남욱 GM | 마케팅·SNS·디지털 |
| AI CPO | 임정은M | 회원·CS·NPS·갱신 |
| AI CTO | 이정헌 소장 | 시설환경·IT·자동화 |

**실무진별 담당 AI C-Level 수 (역방향):**
- 김남욱 GM: 2개 (CEO·CMO)
- 이정헌 소장: 1개 (CTO) — 2026-05-25 신규 등록
- 나우열M: 2개 (CFO·CHRO)
- 최준용M: 1개 (COO)
- 윤병현AM: 1개 (COO)
- 임정은M: 1개 (CPO)
- 이경연 실장: 매출영업 전략 총괄 (COO+CPO 상위)

**필드 스키마 (DB별 차이):**
- AI 조직DB(`33f0407d-a948-80d2-ad27-000b132ef146`): 필드명 `실무진(최종 책임자)` (구성원 → 2026-05-20 RENAME), 타입 **multi_select** (1 AI : N 실무직원 매핑 가능)
- Start 기획DB(`3430407d-a948-8156-afde-e663227cb7a1`) + 운영 아카이브[결과물DB](`3430407d-a948-819d-8769-f739221cf4c8`): `실무진(최종 책임자)` **single select** (특정 기획 1건 = 책임자 1명)

**select 옵션 6명 (2026-05-20 GM님 확정 — Start 기획DB·결과물DB 공용 SSOT):**
| 옵션 | 색상 | 역할 |
|---|---|---|
| 김남욱 GM | red | General Manager (GM님 본인) |
| 이경연 실장 | orange | 실장 |
| 나우열M | yellow | Manager |
| 최준용M | green | Manager |
| 임정은M | blue | Manager |
| 윤병현AM | purple | Assistant Manager |

**Why:** 2026-05-20 GM님 직접 지시 — "AI는 실무진을 각 역할별로 서포트하는 포지션으로 변경". AI 단독 의사결정 권한 없음, 실무직원이 메인 책임. AI는 자동화·DB·집계·문서화·검증 후방 지원. 옵션 통제로 자유 입력·오기 차단.

**How to apply:**
- 모든 C-Level 자동화·산출물 보고서는 매핑된 실무직원 이름 명시
- C-Level 마스터페이지에 실무진 매핑 시각화
- 매핑 변경 시 본 메모리 + AI 조직DB 동시 patch
- DB 신규 레코드 생성 시 본 6옵션 중 1명 선택 의무
- 실무진 추가·이탈 시 6옵션 select + 본 메모리 동시 갱신 (CEO 자율)
- CFO/CMO 미지정 상태는 GM 명시 시 즉시 patch
- AI C-Level 페르소나 명칭(예: "AI CEO", "AI CHRO")은 본 필드 입력 금지 — 그건 `담당자` relation 필드 영역
- 호칭 표준: GM님 호칭은 "GM님" ([[feedback_principal_address_gm]])

**연동 메모리:** [[feedback_role_inversion_main_support]] · [[feedback_clevel_weekly_context_maintenance_scope]] · [[feedback_owner_field_mandatory]] · [[feedback_principal_address_gm]]
