---
name: reference_bot_elevated_restart
description: 텔레그램 봇은 elevated(Highest)로 떠 사용자세션서 kill 불가 — 재기동 2경로 + 폴링 생존판별법 + 헬스체크 사각 + Bad Gateway 사망(INC-002/INC-011)
metadata: 
  node_type: memory
  type: reference
  originSessionId: c6e4b150-97a2-43f4-aa60-d4fa1a119012
---

`telegram_bot/bot.py`는 예약작업 **`WellperionTelegramBot`(RunLevel=Highest, 로그온 트리거)** 가 elevated로 기동한다. 따라서 실행 중인 봇 PID는 **High IL** — CTO의 일반(medium IL) CLI 세션에서 `taskkill`/`Stop-Process` 시 **"Access is denied"** 로 못 죽인다.

- 봇은 `bot.pid` 기반 단일인스턴스(`_check_pid_lock`): 새 인스턴스가 구 PID를 kill 후 takeover. 단, **같은 권한레벨끼리만** kill 성공. 옛 봇이 **관리자 권한**이면 일반 권한(비elevated) 런처가 못 죽여 **둘이 겹쳐 409 무한충돌** → 관리자 런처 or **재부팅**(부팅 자동기동=관리자 단일)으로만 해소.
- 사용자세션서 `python bot.py` 직접 기동 시 → 구 elevated 봇을 못 죽여 **봇 2개 getUpdates 충돌**(409 Conflict) 유발. 하지 말 것.
- **폴링 생존 확진법(진단용 1회만):** 봇 토큰으로 `getUpdates` 1회 호출 → **409 Conflict**("terminated by other getUpdates request") = **봇이 실제 폴링 중(정상)**, **200 OK** = 아무도 폴링 안 함(폴링 사망). ⚠️ 상시로 쓰지 말 것 — 내 호출이 봇 폴링 슬롯을 뺏어 봇에 Conflict를 유발(bot.log에 찍힘). 상시 생존감시는 **하트비트 파일**(bot_heartbeat.txt, 5분 주기) 신뢰.
- **헬스체크 사각(INC-011, 2026-07-03 고침):** 헬스체크(scripts/telegram_health_check.py, 15분+매일13시)가 `getMe`(API 도달)만 확인해 **폴링이 죽어도 'OK'** 오보. → bot.py 하트비트(5분) + 헬스체크가 20분 미갱신 시 '폴링 정지 의심' 경보 추가(하트비트 미도입 시 오탐가드). erp_status의 "봇 조용함"(bot.log mtime, `erp_status_publisher.py _minutes_since`)이 이 사고를 유일하게 탐지했음.
- **사망 원인·방어:** PTB 21.6 `run_polling`(__run)은 KeyboardInterrupt/SystemExit 외 예외를 그대로 전파 → 일시 `NetworkError: Bad Gateway` 한 방에 프로세스 통째 사망. → `run_polling`을 감시 while 루프로 감싸 백오프 자동 재연결(정상종료·SIGINT는 통과, close_loop 후 새 이벤트루프). 라이브 발효=봇 재기동.
- **봇 코드 변경의 라이브 적용 = 재기동 필요 → 세 경로:** ① 다음 아침 부팅·로그온 자동 재기동(야간 PC종료로 선행봇 없어 충돌 없이 새 코드 자연 로드) ② GM 재부팅/elevated 재기동 ③ **[신설 2026-07-09] 원클릭 자가승격 재기동 `ops/restart_telegram_bot.bat`** — GM 더블클릭(또는 `! cmd //c ops/restart_telegram_bot.bat`, bash라 백슬래시 금지·`//c`) → UAC '예' → 승격된 `ops/restart_telegram_bot_core.ps1`가 `bot.pid`(구 PID) `Stop-Process -Force` 후 `Start-ScheduledTask WellperionTelegramBot`로 재기동(새 PID 확인). daily_scheduler(별 PID)는 미접촉. 재부팅 불필요. ※ ops/ = gitignore(로컬 전용). CTO 세션(medium IL)은 여전히 강제 못 함 — GM의 UAC 승인 1회 필요.
- **[관찰 2026-07-09] Bad Gateway 사망 재발:** 10:11 `NetworkError: Bad Gateway`로 폴링 사망→13:06 위 ③경로로 복구. line16의 'run_polling 감시 while 백오프' 방어가 이번에도 못 막음 → **그 watchdog가 실제 라이브 배포됐는지 미검증**(다음 세션 확인 요). 탐지=bot.log mtime 정지(10:11)+수신로그 공백.
- 같은 elevation 벽: [[reference_pc_auto_shutdown_2330]](INC-002, 숨은 SYSTEM 작업). GAS 15초 타임아웃 동류 방어 = daily_scheduler `_gas_get`(40s·3회재시도, [[reference_gas_post_curl_no_follow_redirect]]와는 별개).
