---
name: reference_voc_submit_token_gate
description: VOC/종합접수 위조방지 게이트 — 숨김토큰·속도제한·역롤백 스위치 위치
metadata: 
  node_type: memory
  type: reference
  originSessionId: 9b09999d-0254-4086-939a-1db5824ac1e0
---

VOC 종합접수 위조방지(시토 2026-06-29 GM go 발효). reg_submit·voc_submit는 **숨김토큰 `t`** 필요.

- **토큰값:** `wlp_voc_7b3f9a2e6c1d4085` — 정본 GAS `3. 웰페리온 가이드/coo/voc/apps_script_voc.js`의 `VOC_SUBMIT_TOKEN_DEFAULT` + 폼 `voc_mobile_form.html` payload `t`. **바뀌면 양쪽 동시 교체.** ScriptProperties `VOC_SUBMIT_TOKEN` 설정 시 그게 우선.
- **속도제한:** 전역 40/분 + 동일내용(category|contact|content) 60초 중복 차단 (CacheService). 정상 회원=내용 고유라 통과, 봇·연타·중복제출=차단(RATE_LIMIT).
- **역롤백(즉시·재배포 불요):** GAS ScriptProperties `VOC_GATE_OFF` = `1` → 게이트 해제. 되돌릴 땐 그 속성 삭제/0.
- **배포:** 정본=guide/coo/voc/apps_script_voc.js만 편집(git 추적). **라이브 GAS scriptId=`1_jF5yhXZfBgw7KX9adW17ER0t_lQ8xrVaGsZBraUJ5AZZPzfIGuFKw9Y`**, 라이브 프로젝트의 실제 파일명은 **`VOC_배포.js`**(디코이 아님 — clasp가 그 이름으로 저장). 배포 = 정본을 `.deploy-voc/VOC_배포.js`로 cp→`cd .deploy-voc && clasp push -f && clasp deploy -i AKfycbwk2XS1FND9…`(배포ID 재사용=폼 /exec URL 보존). ⚠️ `coo/voc/`엔 .clasp.json 없음 + `.deploy-voc/`는 **gitignore(로컬 staging)** → 서브에이전트가 coo/voc만 보고 "clasp 미연동·GM 수동배포"로 **오판하기 쉬움**. 배포 디렉터리=`.deploy-voc`임을 기억. 현재 @20 (2026-07-02: 사진 sendPhoto 실첨부·🆔ID제거·🕒접수일시 추가).
- **한계:** 토큰이 폼(클라이언트)에 노출 → 봇·무차별 위조만 막음, 소스 본 사람은 우회 가능. 진짜 인증=자체서버 JWT([[project_self_hosted_server_setup]] 시토 21, 2026-09 통합). [[feedback_security_live_activation_needs_gm_go]] 준수(GM go+역롤백 확보).
- 정본 단일 소스·디코이 함정 주의 = 점검 GAS와 동류([[reference_facility_check_live_gas]]).
