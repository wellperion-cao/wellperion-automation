---
name: project-asset-locations
description: 웰페리온 자산 위치 SSOT. 6 위치 분산 → 본 audit (2026-05-23) 후 통합·정리 완료.
metadata: 
  node_type: memory
  type: project
  originSessionId: 11519ba0-2bd5-41d2-a662-f8cd0e047d8e
---

# 자산 위치 SSOT (2026-05-23 audit 후)

마스터 INDEX 본체는 `C:\Users\jjky0\welperion-automation\INDEX.md`. 본 메모리는 그 요약 + 능동 감사 기준.

## 6 위치 결론

| 위치 | 크기 | 상태 | 정책 |
|---|---|---|---|
| `welperion-automation/` | 922 MB | 메인 SSOT | 절대 SSOT, 변경 신중 |
| Home `.welperion-*` 프로필 3 | 272 MB | Selenium/Playwright 경로 하드코딩 | **절대 이동 금지** |
| Desktop `_정리완료/` | 200 MB | 역사 archive | 보존, 변경 X |
| Desktop `웰페리온 AI 시스템/` | 0 MB (BAT 정리됨) | PDF 3종만 잔여 | 외부 참고용 보존 |
| Desktop top-level 정책 .md 3개 | 0.05 MB | 이관 후보 | GM 결재 대기 |
| Desktop `.omc/` | 폐기 완료 | - | - |

## 단일 SSOT

- **모든 키·토큰**: `welperion-automation\telegram_bot\.env` (3 위치 HardLink 통합 완료)
- **모든 정책·R/R**: 웰페리온 ERP S2 영역 (`3. 웰페리온 가이드/wellperion_guide(main).html` id="S2", 정본=`ssot/`) — Notion 마스터 프레임워크 페이지는 폐기(호출 금지)
- **할일·업무 단일 출처**: 🧭 오늘의 항로 = G1 + `status/_queue.json` 머지 (CLAUDE.md §3-1) — 구 Notion 「CEO 인박스」 DB(INB)·GM TODO는 폐기(호출 금지)
- **자산 위치 마스터 INDEX**: `welperion-automation\INDEX.md`

## 능동 감사 (CEO 본업)

매주 월 09:00 CPC cycle 합류 시 신규 자산이 6 위치 외 등장했는지 자동 scan. 발견 시 GM 1건 결재로 위치 결정.

## 2026-05-23 통합 R&D Phase 2 진행 사항

### 자율 진행 완료
1. 메인 repo root 임시 파일 (F1_*.txt 등) 폐기
2. 텔레그램 봇 WORKDIR 변수 fix: `bot.py:44` Desktop → welperion-automation (PID 23572 재기동, 12:39 exit=1 근본 원인 해소)
3. Home `.codex` (44 files / 258 KB / 38일 미수정) → `scripts/_archive/global_dot_folders_20260523/.codex` 이관
4. GM님이 직접 옮기신 `welperion-automation\2. 정리 파일\` 폴더 4 sub (01~04) 메인 repo SSOT 자리 확정

### 2026-05-23 GM 결재 일괄 처리 결과

| # | 항목 | 결과 |
|---|---|---|
| B1 | brand vs 1.brand | 병합 업데이트 — robocopy /E /XO 로 1.brand 신규만 brand에 추가 (24→30 files / 349.1→353.3 MB), 1.brand 폐기 |
| B2 | Home .gemini 1.9 GB | archive (scripts\_archive\global_dot_folders_20260523\.gemini) |
| B3 | Home .lmstudio 7.8 GB | 영구 보존 (0일 = 사용 중, 절대 이동 금지) |
| B4 | Home .claude / .omc global | 영구 예외 (CLI 본체. 절대 이동·archive 금지) |
| C1 | Playwright 3 + 11 파일 14 라인 patch | **완료** — Home .welperion-* 3 → welperion-automation/profiles/{instagram,naver-cafe,naver-blog}/ 이동. 봇 정지·11 파일 patch·py_compile PASS·재기동 (PID 9648 bot / 24212 sched). audit 추정 38이었으나 실측 11 파일. |

### 영구 보호 자산 SSOT (절대 이동·archive·폐기 금지)

1. Home .claude — Claude Code 글로벌 설정·메모리·세션·로그인
2. Home .omc — OMC 글로벌 상태·MCP 레지스트리·미션 상태
3. ~~Home .lmstudio~~ → **archive** (2026-05-23 GM "필요없다" 확인 후 미사용 archive, 7.8 GB → scripts/_archive/global_dot_folders_20260523/.lmstudio)
4. ~~Home .welperion-*~~ → **welperion-automation/profiles/{instagram,naver-cafe,naver-blog}/** (2026-05-23 통합 완료, hardcoded path 11 파일 patch 완료)

CEO는 위 자산을 자율 진행 list에 절대 포함 금지.

## Why
GM님 2026-05-23 지시 "무의미·불필요·중복 정리 + 한 곳 집결". 4 위치 분산 → 옵션 C (실용 결합) 적용. 자산 위치 SSOT 부재 시 CEO 능동 감사 불가능 → 본 메모리가 능동 감사 기준점.

## How to apply
- 신규 자산 등록 시 위 6 위치 외 생성 금지
- 생성 시 즉시 INDEX.md + 해당 폴더 `_README.md` patch
- 30일 후 `scripts/_archive/audit_20260523/`·`desktop_legacy_20260523/`·`telegram_report_bot_20260523/` 폐기 검토
