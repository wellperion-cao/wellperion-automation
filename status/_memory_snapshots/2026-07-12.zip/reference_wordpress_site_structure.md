---
name: reference_wordpress_site_structure
description: wellperion.com 워드프레스 편집 시 알아야 할 비자명한 구조·함정(HTTP전용·Salient/WPBakery·히어로버튼=메뉴)
metadata: 
  node_type: memory
  type: reference
  originSessionId: aea490b8-e1de-49aa-841c-d7a7ab765295
---

wellperion.com 워드프레스 자동 편집 시 핵심 사실 (Playwright 세션 로그인: `scripts/wordpress_admin_playwright.py`, 프로필 `profiles/wordpress`).

- **HTTP 전용**: HTTPS 연결 자체가 실패(SSL). 모든 URL은 `http://` 고정. https로 가면 엉뚱한 406 페이지 받음.
- **테마=Salient + WPBakery(고전 편집기)**. Gutenberg 아님. 다국어=WPML(/ko/, /en/).
- **커스텀 HTML 주입**은 `[vc_raw_html]` 숏코드로만 보존됨. 일반 본문에 인라인 `style=` 넣으면 KSES가 제거함. 인코딩: `base64_encode(rawurlencode(html))` (렌더 시 rawurldecode(base64_decode)). `_wrap_vc_raw_html` 참고.
- **상단 "메뉴"는 실제 nav 메뉴가 아님** = 홈페이지(page id 6) 히어로의 `[nectar_btn]` 숏코드 그리드. 멤버십/레슨/유소년/뮤지컬/스파/FAQ/더알아보기/방문예약 = 전부 nectar_btn. 새 항목 추가 = 홈 본문 vc_raw 편집(`더 알아보기` 버튼 뒤에 동일 nectar_btn 삽입). 반드시 본문 백업 먼저(`#content` 21k자).
- WP nav 메뉴 3개(56 Eng, 58 Eng2, 59 한국어메인)는 거의 비어있고 화면에 안 보임. 메뉴 편집은 헛수고 — 히어로 버튼을 고쳐야 함.
- **페이지 발행만으로는 히어로 버튼에 안 뜸**(버튼은 수동 nectar_btn). 페이지 menu_order는 전부 0.
- 문의 페이지 = id 8394, slug `inquiry`, 공개 URL `http://wellperion.com/ko/inquiry/`. 본문 SSOT=`3. 웰페리온 가이드/cmo/survey/wp_inquiry_block.html`(영상 placeholder 포함, 편집후 `--mode draft-inquiry --post-id 8394`로 재주입).
- 검증은 비로그인 프로필로 라이브 URL 스크린샷 육안(초안은 로그인必, 비로그인 시 404 정상).
- **헤더 로고·여백은 본문이 아니라 테마(Salient) 헤더 영역** = 본문 vc_raw_html의 padding으론 절대 안 움직임(본문만 내려가고 로고는 그대로 잘림). 해결: 본문 `<style>`에 **`body.page-id-8394` 스코프** 규칙 주입 → 페이지 한정으로 테마 헤더 제어(전역·CTO 영역 안 건드림). 로고 상단 잘림 예: `body.page-id-8394 #header-outer #logo{margin-top:32px}` (모바일 ≤1000px 별도, +22px). `<style>`도 vc_raw_html에 보존됨(`<script>` 클릭추적과 동일). draft-inquiry 재주입으로 적용. 커밋 d46290d. (2026-06-04, GM 2회 요청 미해결 원인=본문 여백만 만진 오진).
