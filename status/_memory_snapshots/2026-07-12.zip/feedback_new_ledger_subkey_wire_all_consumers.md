---
name: feedback_new_ledger_subkey_wire_all_consumers
description: 점검 원장에 새 회차/시프트 칸(sub.close 등) 추가 시 그 칸을 읽는 모든 소비처를 함께 배선·왕복검증
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 07f771a7-d857-40e5-83f6-38bfe72f103c
---

지원부 점검(지원부 체계.html + .deploy-check/지원팀 일일점검.js)에서 마감조(close1)를 서버 `led.sub.close`로 분리할 때, 저장·복원·로컬검증(submit/restore/today_live)만 고치고 **그 칸을 읽는 다른 소비처를 안 고쳐 반쪽 상태로 라이브 배포**했다(마감조가 시트엔 '미제출'로 남고, 관리자뷰 '-', PIN해제 후 재잠금). GM이 "백그라운드 문제 없냐"는 후속 수색에서 형제버그로 드러남.

**Why:** '동작만 되면 끝 아니다'(약속 L14). 한 사실을 저장하는 칸을 새로 만들면 그 값을 **읽는 곳이 코드 전역에 흩어져** 있다. 하나라도 옛 칸을 계속 보면 화면·시트·알림이 조용히 어긋난다(에러 안 남 → 실무자 모름).

**How to apply:** 점검 원장에 sub/subAt/회차 키를 추가·변경할 때, 배포 전 아래 소비처를 grep으로 전수 확인하고 같은 커밋에서 함께 배선한다:
1. 저장(`_updateCheckLedger`, `_buildPushPayload`) 2. 복원(`loadState`) 3. **시트 I열 라벨매핑(`_labelToShiftKey` → `_roundSubmitStatus`/`_roundDurationMin`)** 4. **관리자 대시보드(shiftRows·buildAdminShiftCard·submitterStats)** 5. **잠금해제(`unlockRound`의 시프트레벨 키 + localStorage 미러)** 6. V2Compat 경로(`_handleSaveV2Compat`) 7. 주말/평일 마스터(`ROUNDS`=평일만 → `roundsOfShift`) 8. 텔레그램 알림·스냅샷. 로컬 모의검증은 submit/restore뿐 아니라 위 소비처까지 시나리오에 포함. 라이브 화면 수술은 로컬검증 후 1회 배포·역롤백 유지. [[feedback_dead_code_removal_check_callers]] (제거의 짝 — 추가 버전) · [[project_support_check_single_source_page]]
