---
name: project_executive_decision_authority
description: 회장·대표·이사 3인 최종결정권 분장 + home 경영 담당
metadata: 
  node_type: memory
  type: project
  originSessionId: aa7d3533-5567-4cf5-a618-caa6aa6b6b04
---

웰페리온 최고 경영진 3인과 최종결정권 분장 (2026-06-06 GM):
- **차의주 회장** = 회사 **전사적 방향** 최종결정권자
- **전응준 대표** = 회사 **경영** 최종결정권자
- **주영희 이사** = **대표 보좌 및 재무회계 책임자**

home(ERP 칵핏) '경영(Executive)' 카드 담당 = 이 3인(김남욱 GM에서 교체). 보고 라인 위로는 6 C-Level → AI CEO(웰리) → GM → 이 경영진.

**⚠️ ERP 결재 라인 = GM 종착 (2026-06-16 GM 변경):** ERP(S3 업무&결재 SSOT) 결재 라인은 `부서장 → GM` **GM 종착**. 전응준 대표 결재 단계는 시스템에서 제거 — 대표 보고·승인은 오프라인 **페이퍼**로 처리(약속 [[L09]]). 회장(차의주)·이사(주영희)·대표(전응준) 모두 **ERP 결재 라인 대상 아님** — 위 3인 분장은 **실무 역할/거버넌스 정보로만** 기억하고 ERP 결재 흐름엔 반영하지 않는다. 단, 위 거버넌스상 대표=경영 최종결정권자라는 사실 자체는 유효(오프라인 결정). 관련 [[project_approval_final_approver_per_ssot]]
