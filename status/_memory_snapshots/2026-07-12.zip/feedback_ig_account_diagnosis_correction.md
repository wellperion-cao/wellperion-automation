---
name: 인스타 자동화 진단 정정 — Personal 오진 → 실제 프로페셔널
description: namuk.wellperion = 이미 프로페셔널 계정. 진짜 차단점은 페북 영구 삭제 정책 + Playwright publish 코드 미구현
type: feedback
originSessionId: f78db5ec-6ec0-4973-af2f-947079bf0ef0
---
namuk.wellperion 인스타 자동화 차단 사유는 계정 유형이 아니다. 실제 차단점 = (a) Meta Graph API의 페북 페이지 매개 필수 vs 페북 영구 삭제 정책(2026-05-03 GM님 결정) 충돌, (b) `scripts/instagram_upload_playwright.py` publish 모드 미구현(setup·dryrun만 완비). 계정 유형은 이미 프로페셔널(Business 또는 Creator)이므로 API 접근 자격은 충족.

**Why:** 2026-05-10 GM님 정정. 4.21 파이프라인 v1.21 본문 항목 3에 "Personal 계정. Graph API 접근 불가" 기록이 박혀 있어 그대로 보고했으나 실제는 잘못된 진단. CMO가 Notion 본문 한 줄을 그대로 인용하면 GM님께 잘못된 액션(계정 전환)을 요청하게 되어 시간 낭비 + 신뢰 손실. 메모리 `feedback_ceo_diagnostic_failure_pattern` 4규칙(유사 명칭 단정 금지·진단 정정 시 자율·결재 카테고리 엄격·log read 선행)을 인스타 영역에도 동일 적용.

**How to apply:**
- 인스타 자동화 차단 사유 보고 시 "Personal" 단정 금지. 의심되면 GM님께 1줄 확인하거나 인스타 앱 직접 조회 후 발화
- 4.21 파이프라인 v1.21 본문 항목 3은 **정정 patch** 완료 — 향후 본문 인용 시 정정본 기준
- 우회 경로 우선순위: A) Playwright publish 모드 구현 (CTO 본업·v1.15 P-1 결정과 정렬·App Review 대기 불필요) > B) Instagram Login API(페북 매개 없음·App Review 7~14 영업일 대기)
- Notion 본문에 잘못된 진단이 박혀 있을 가능성을 항상 염두 — log read·정정 patch 선행 후 발화

**2026-05-29 해소:** 차단점 (b) Playwright publish 미구현 = 해결. `instagram_upload_playwright.py` publish 모드 end-to-end 작동 확인(시드 #09, namuk.wellperion 5장 캐러셀 발행 → 게시물 화면 실측). 2026 인스타 UI 셀렉터 갱신: 진입="새로운 게시물"(aria-label) → "게시물" 하위메뉴 클릭, 캡션=aria-label*="문구", 공유=`div[role="button"]:text-is("공유하기")`. 단일 포스트(post A만)도 발행 허용. 로그인 만료 시 `--mode setup-auto`(자동 감지·Enter 불필요). 이 흐름은 회사 계정 콘텐츠 발행에도 재사용.
