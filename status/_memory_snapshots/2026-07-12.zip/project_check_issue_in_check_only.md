---
name: project_check_issue_in_check_only
description: 점검 이슈는 점검 안에서만 완결 — 시트 G열 기록 + 점검관리방 알림. 종합접수처 전송(자동·수동)은 전면 폐지
metadata: 
  node_type: memory
  type: project
  originSessionId: ed590564-eb13-435a-9716-cc9ddfeb363c
---

지원부 점검에서 발견된 이슈는 **점검 안에서만 완결**한다 (GM 결정 2026-06-25, 실무진과 합의).

- **기록:** 점검 시트의 그 항목 행 **G열('이슈')** 에 이슈 텍스트 저장 (과거 hide_issue_col로 숨겼던 G열 = show_issue_col로 표시). today_live `allIssues`도 `led.cr[k].iss` 단일소스로 집계해 대시보드 '기록된 이슈'에 표시.
- **알림:** 이슈 있는 제출 시 **점검관리방(-5136037543)** 으로 텔레그램 1건 (`_checkNotifyIssues`, 여러 건은 묶음).
- **종합접수처(-5065206276) 전송 = 자동·수동 둘 다 전면 폐지.** GAS `_checkSendIssuesToVoc`(자동 reg_submit) 삭제 + 페이지 수동 '접수처로 보내기'(sendIssueToVOC·reg_submit) 삭제. 단 '접수 현황 조회·관리' 뷰(REG_API·regUpdate)는 보존.
- 외부 접수·타부서 처리가 필요한 건은 점검과 무관한 **별도 경로**(실무진과 합의)로 간다.

**Why:** 점검 청결 이슈가 회원 VOC(종합접수처)를 가득 채워 섞이던 문제 + 회원 VOC와 운영 점검은 성격이 다름. 점검 이슈는 점검 라인에 모아야 일관됨.

**How to apply:** 점검 GAS(`.deploy-check/지원팀 일일점검.js`)나 점검 페이지(`coo/check/지원부 체계.html`)를 만질 때, 이슈를 종합접수처(reg_submit/VOC/-5065206276)로 보내는 코드를 **다시 추가하지 말 것.** 라이브 점검 GAS=@106(2026-06-25). 관련 [[project_telegram_3room_split]] · [[project_support_check_single_source_page]] · [[project_coo_issue_sheet_name]].
