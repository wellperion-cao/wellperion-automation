---
name: feedback_content_realism_drives_engagement
description: 콘텐츠는 현실에 맞는 구체적 내용으로 — 비현실·과장 설정 금지. 현실감이 조직 밖 좋아요까지 끈다
metadata: 
  node_type: memory
  type: feedback
  originSessionId: bbe8dc19-5dc1-4064-b35e-2ad390f94ad1
---

콘텐츠(특히 namuk 개인계정 AI 시리즈)는 **실제 현실에 맞는 구체적 내용**으로 만든다. 'AI가 당직 선다' 같은 **비현실·과장 설정 금지.**

**Why:** GM 확인(2026-06-07) — "현실에 맞추어 글이 올라가면 모르는 사람들도 내용만 보고 좋아요를 눌러준다." 현실감 = 조직 밖 자연 도달·공감. 반대로 비현실 컨셉('AI 당직')은 GM이 즉시 반려함.

**How to apply:** 슬라이드·캡션 기획 시 실제로 일어날 법한 장면·경험으로 구성하고, 멋있어 보여도 사실과 안 맞는 전제는 뺀다. 예: 'AI=대신 일한다/당직 선다' ❌ → 'AI=내가 놓친 것을 빠짐없이 모아주는 비서' ✅ 처럼 실제 동작에 충실하게. [[project_main_slide_template]] [[feedback_brand_voice_positioning]] [[feedback_welly_publish_verify_artifacts]]
