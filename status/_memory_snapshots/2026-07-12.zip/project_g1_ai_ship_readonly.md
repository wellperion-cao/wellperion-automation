---
name: project_g1_ai_ship_readonly
description: G1 AI 배(queue-*)는 일반 카드 버튼 유지(GM 원복). 정리는 GM이 웰리에 직접 지시
metadata: 
  node_type: memory
  type: project
  originSessionId: bbe8dc19-5dc1-4064-b35e-2ad390f94ad1
---

G1 항로의 AI 배(_queue.json 기원, id=`queue-*`)는 **일반 카드처럼 편집/완료/보류/삭제 버튼을 그대로 둔다**(GM 2026-06-07 원복).

경위: 2026-06-07 AI 배 삭제버튼 무반응(G1=브라우저라 _queue 파일 직접변경 불가) 발견 → '🤖 AI 배·웰리 관리' 칩 + '🧹 웰리에 정리요청'(클립보드) 읽기전용 UI 도입했으나, **GM이 곧바로 원복 지시**("ai 웰리관리랑 웰리가 정리하는건 다시 원복해줘"). 클러터·불필요 판단.

**현 상태/주의:**
- AI 배도 일반 버튼 노출. 단 _queue 정본을 브라우저서 못 고쳐 **삭제·편집은 실제 반영 안 됨**(기존 한계 그대로).
- **AI 배 정리(삭제)는 GM이 웰리에게 직접 지시**(예: "시로01 삭제하자")가 정본 흐름. 웰리가 _queue에서 `status:폐기`(disposed_at + note에 사유, 기록 보존)로 처리.
- 시트(ssot-*) 카드 삭제는 GAS todo_delete로 정상.

관련: [[project_g1_done_today_past_search]] · [[project_hangro_task_single_def]] · [[feedback_welly_delegate_not_execute]]
