---
name: feedback_cmo_mission_dashboard_normalization
description: 시모(CMO) 핵심 역할=마케팅 자동화 + 대시보드(실무진 눈높이) 정상화·정확 신뢰 데이터 (GM 2026-07-07 재확정)
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d877bbef-e82d-4a4c-b3c8-f578d2ba6410
---

GM이 2026-07-07 시모(AI CMO)의 역할을 재확정: **"마케팅 자동화 및 대시보드(실무진이 이해가 쉬운) 정상화 — 정확하고 신뢰할 수 있는 데이터."** 콘텐츠 제작 자체보다 이 축이 본업.

**Why:** GM은 마케팅 자동화 항목들을 직접 검증하기 어렵다고 느낌("뭘 확인할 수가 없네"). 신뢰의 근거 = 화면이 정확하고(분모 정합·소스 단일), 실무진이 봐도 바로 이해되는 것. 과거 사고(stage_funnel 분모폭증 [[reference_stage_funnel_source_composition_trap]]·완료율 다중소스 불일치 [[reference_check_completion_rate_untrustworthy_multisource]])가 신뢰를 갉음 → 정확·신뢰가 최우선.

**How to apply:** 대시보드 작업 시 ①데이터 정확성(분모 정합·소스 단일·라이브 실측 대조) ②실무진 가독성(전문용어·게이트·해석 난이도 낮추고 한눈에) ③정직 꼬리표 일관성(측정/부분/미측정/표본부족)을 항상 점검. 못 재는 건 정직하게 '미측정'([[project_conversion_funnel_leak_diagnosis]]). 미션 본진 배=545(대시보드 정상화). 관련 파이프라인 [[project_cmo_marketing_pipeline_loop]], 병목=노출→전환 [[feedback_marketing_conversion_bottleneck]].

**대시보드·월간보고 R/R 분업 (GM 2026-07-08 결정):** 문의와 마케팅은 한 퍼널이지만 이음새에서 주인을 반씩 나눈다. **시모=마케팅 현황(노출→클릭→문의 유입까지: 채널·전환율·ROI, M2 마케팅현황대시보드·마케팅 월간).** **시포=문의 이후(상담·등록·회원 현황·그쪽 월간, 문의회원 페이지 소유 [[project_cpo_inquiry_system_unification]]·[[feedback_member_domain_is_cpo_not_cto]]).** 이음새='문의 수·채널'을 **양쪽이 같은 단일 소스**로 봐야 숫자 안 어긋남(다중소스 불일치가 신뢰 깨는 최대 함정). 통째로 한 명에게 몰지 않는다(반대편 전문성 빠짐). 월간보고=성격별 분리 또는 한 보고서 두 섹션(마케팅→문의 | 문의→등록).
