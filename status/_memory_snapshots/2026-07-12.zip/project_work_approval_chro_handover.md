---
name: project_work_approval_chro_handover
description: "업무·결재 현황(S3) 관할 COO→CHRO 이관(2026-06-20 GM). 표기·결재종착 정합 완료, 결재정책 본문·인사평가 연동은 후속"
metadata: 
  node_type: memory
  type: project
  originSessionId: 6ee277dd-b914-4cd9-b329-a11c9b63a288
---

2026-06-20 GM 결정(deep-interview 5문 확정): 「업무&결재 현황 SSOT」(data-id=S3)를 **분리(split) 이관**. ★완전 이관 아님 — **페이지 소속·표기·인사평가 연동=CHRO(시로) / 결재 정책·운영 엔진(결재선 산출·승인·GAS 유지)=COO(시우) 유지**. 이유: 결재 운영을 인사로 통째 옮기면 ①4일전(06-16) 시우 인계 무효 ②인사 본업 아님 ③나우열M=결재대상자라 이해상충 → GM이 분리 선택.

**확정 정합** (wellperion_guide(main).html):
- ERP 메뉴 위치: '시작하기'→'AI CHRO 인사' 하위(Recruiting 아래). data-id 방식이라 S3 참조 3곳 무손상.
- S3 헤더 = "소속·인사평가=CHRO / 결재 운영=COO(시우)". 모듈카드 담당 = "🤖 AI CHRO (시로) / COO 운영". (운영 모듈카드 AI COO는 유지)
- S2 결재정책 섹션에 split note 1줄(소속·인사평가=CHRO / 정책·운영=COO).
- 결재 정책 **본문**은 S2 COO탭에 **유지**(운영=COO라 위치 정확), "정책 원본=S2 AI COO 탭" 참조 3곳 **유지**(수정 안 함).
- 결재 종착 stale 정정 완료: S2가 "결재현황=대표 종결" 옛 정보였음 → 약속 L09대로 "업무·결재 모두 GM 종결"로 정정. [[project_approval_final_approver_per_ssot]] 일치.
- 결재 GAS·로직 **무수정**.

**후속(인계 박제)**:
- 인사평가 가중점수 연동(C) = 큐 배 `CHRO-2026-06-20-WORK-EVAL-WEIGHT-LINK`(시로) PENDING. 인계 3항목(①데이터소스 집계법 ②반영비율 35점vs가산점 ③상등급 플래그). 비율·집계는 평가체계 정합 선행이라 시로 확정, 지금 수치 미박음.

**충돌 해소**: "결재현황 운영=시우(COO) 소유"(큐 COO-2026-06-16-APPROVAL-OWNERSHIP-HANDOVER)는 **유지** — 분리 모델이라 운영은 여전히 시우. 어긋남 없음.

**Why**: GM "메뉴만 옮기면 정리 안 된다, 막 옮기는 거 아니지?" → deep-interview로 안전한 분리 확정.
**How to apply**: 업무·결재 현황 = CHRO 소속이되 **결재 운영·정책 소유는 COO(시우)**. 둘을 합쳐 "CHRO가 결재 운영까지"로 오해 금지. 명세=`.omc/specs/deep-interview-work-approval-chro-handover.md`. [[feedback_dept_system_link_parity]]대로 S3 페이지명/URL 변경 시 참조 동반 수정.
