---
name: feedback_work_pipeline_interview_execute_simplify
description: 다단계 업무 표준 절차 — deep-interview(5%미만)→ralph/ulw/team→실무진이 바로 쓰는 수준 단순화
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ff42501c-1a21-4c23-b063-a4f7a97fd7b2
---

다단계 업무(구현·개선·수정 등 여러 단계 필요한 일)는 **표준 3단계 파이프라인**으로 처리한다:
1. **deep-interview**로 모호성을 **5% 미만**까지 내린다(못 내리면 실행 금지).
2. **ralph / ultrawork(ulw) / team** 중 작업 성격(크기·병렬성·반복검증 필요)을 보고 **AI가 자동 선택**해 끝까지 실행.
3. **단순화·고도화** — **실무진이 추가 설명 없이 바로 쓰는 수준** + 쉬운 사용법까지 만들어야 완료. 동작만 되면 완료 아님.

**Why:** GM 명시(2026-06-16, deep-interview로 확정). 4결정: 적용=다단계 업무 전부(단순 조회·한 줄 답변·설정확인 제외) / 실행기=AI 자동 선택 / 완료=실무진 바로 쓰는 수준 / 5%=전역 기본. GM 사유: "개선 작업이 너무 어려워" → AI가 또렷하게·끝까지·실무진이 쓸 수 있게 자율 완수하길 원함. [[feedback_always_sync_shared_docs]] [[feedback_plain_language_no_jargon]]

**How to apply:** 정본=S2 공통탭 '업무 수행 파이프라인' 표(모든 C레벨이 부팅 시 흡수) + 약속.json L14(사람용). ⚠️ settings.json의 omc.deepInterview.ambiguityThreshold=0.05 자동화는 Claude Code 스키마가 omc 키를 거부해 **불가** → 5% 기준은 이 흡수 지침으로 적용(스킬 기본값 20%를 업무 건에선 5%로 상향 적용). 단순 대화·trivial은 파이프라인 제외(과잉 프로세스 금지).
