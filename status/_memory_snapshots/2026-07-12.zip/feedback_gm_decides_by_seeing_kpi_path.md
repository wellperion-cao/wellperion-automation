---
name: feedback_gm_decides_by_seeing_kpi_path
description: "GM은 추천·제안을 'KPI→북극성 경로'가 눈에 보일 때만 승인한다 — 경로 없는 제안은 승인 안 함"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 45b9a8ec-723c-40bc-813c-63cbbd0af304
---

2026-07-02 발견. 일일 북극성 추천 카드가 3일 연속(6/29·6/30·7/1) GM 응답 0건·자동만료. GM 직접 답: **"북극성 도달을 KPI 지표로 직관적으로 보여주는 게 없으니, 괜히 승인했다 엉뚱한 길 갈까 봐 안 눌렀다."**

**Why:** GM은 근거 없이 승인하지 않는다. "이 작업 → 이 지표가 현재→목표 이만큼 → 북극성 한 걸음"이 한눈에 보여야 신뢰하고 결정한다. 카드를 예쁘게(웰리 통합 Top3) 바꾼 것만으론 부족 — 측정 가능한 KPI 경로가 핵심.

**How to apply:**
- 모든 선제 제안·추천은 **KPI→북극성 경로 한 줄**(작업→지표 델타 또는 배관 상태 전이→북극성 한 걸음)을 반드시 함께 제시. 경로 없으면 GM은 안 누른다.
- 근본 원인은 대개 **지표 자체가 미측정**이라는 것 — 경로를 못 보여주면 카드 형식이 아니라 측정 배관을 의심하라. (7역할 중 실측되는 KPI는 시토 인프라뿐이었음, 2026-07-02)
- 목표 숫자가 없으면 지어내지 말고(L05) "측정 개통"을 첫 목표로, 실측 쌓이면 GM이 숫자 확정 = 단계적·정직.
- GM 성향 일반화: **직접 보고 결정한다** — 말로 더 묻기보다 초안·표를 만들어 보여주는 게 GM 참여를 끈다(비응답 방지). 관련 [[project_gm_personal_northstar_routine]]=단순함 · [[project_northstar_g1_orchestration_erp]]=자율화 방향 · [[project_daily_northstar_recommender]]=추천기 배.
