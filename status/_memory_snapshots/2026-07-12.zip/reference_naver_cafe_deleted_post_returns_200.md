---
name: reference_naver_cafe_deleted_post_returns_200
description: "네이버 카페 삭제글도 HTTP 200 반환 — 200만으로 라이브 판별 불가, 발행링크 검증법"
metadata: 
  node_type: memory
  type: reference
  originSessionId: ad3d48ad-6510-4c51-82ae-0dc076e3ba8d
---

네이버 카페(cafe.naver.com/{cafe}/{articleId}) 글은 **삭제·비공개여도 curl이 HTTP 200을 반환**한다. 본문이 iframe/JS 렌더라 raw HTML grep으로 "삭제된 게시글" 문자열도 안 잡힌다 → **HTTP 200 = 라이브라고 믿으면 안 됨.**

2026-07-09 F2 편의시설 링크정리를 문의알림방(-5516675010)에 보낼 때, 카페 363539가 200이라 라이브로 판단해 발송 → GM이 "삭제된 링크"라 지적(정본=363541). editMessageText(message_id 3227)로 원본 정정.

**How to apply:** 발행 링크 정리·발송 전 카페 링크는 200이 아니라 ①GM/시모가 준 정본 articleId 우선 ②Playwright 렌더 후 본문·제목 실재 확인으로만 라이브 판별. 블로그는 `m.blog.naver.com/{id}` og:title이 비면 죽은 글(RSS 최신글 매칭이 정본). [[project_4channel_standard]] · [[feedback_guidehub_commit_must_push_and_live_verify]] · [[project_publish_verify_before_done]]
