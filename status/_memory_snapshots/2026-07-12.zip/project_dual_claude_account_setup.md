---
name: project_dual_claude_account_setup
description: cao→info Claude 구독 이중계정 계획 · 구글은 cao 유지 · 기억공유 · Fable 비용주의
metadata: 
  node_type: memory
  type: project
  originSessionId: ad99fb66-a4cb-4307-a74d-8af5352ac8d8
---

**계획 (2026-07-06, GM '있다가' 진행 예정):** cao@wellperion.com Claude Max 한도 부족 → **info@wellperion.com Max x20 추가 결제 후 Claude Code를 info로 전환**부터 시작.

**핵심 원칙 (전환 시 반드시):**
- **Claude 구독만 info로, 구글 계정은 cao 그대로 유지.** 둘은 완전 별개 시스템 — 구글 cao는 clasp·Drive·GAS·카톡/매출 자동화용이라, Claude 계정 바꿔도 무영향. clasp 인증=`~/.clasprc.json`(구글 cao, Claude 로그인과 무관).
- **멀티계정 방식 = `CLAUDE_CONFIG_DIR` 환경변수**로 계정별 폴더 분리(공식). 자격증명=`%USERPROFILE%\.claude\.credentials.json`. 각 폴더에서 최초 1회 `/login`. Max 구독=OAuth(ANTHROPIC_API_KEY 아님).
- **함정:** CLAUDE_CONFIG_DIR는 자격증명뿐 아니라 **memory·OMC·settings까지 통째 분리** → 그냥 나누면 두 계정이 딴 기억을 가짐. 해법=**기억(projects/)·OMC(plugins/)는 정션 링크로 공유하고 credentials만 분리**(계정 둘·두뇌 하나). cao=기본 폴더 유지, info=`.claude-info`에 공유링크+info 로그인. 웰리가 폴더·링크 미리 세팅 가능 → GM은 로그인만.

**자동 폴백 희망(cao 한도차면 info 자동사용):** Claude Code 네이티브 기능 없음. **래퍼로 구현 가능**(cao 실행→'한도초과' 신호 감지→info로 재실행). 주의=한도신호 정확 감지·작업중간 전환은 중복작업 위험이라 시작시점 판단 권장. 시토가 빌드·실측 검증 필요.

**Fable 비용 주의:** claude-fable-5 = 최상위·비쌈. 사용량 43% 목격(2026-07-06). 확인=자동화·봇은 이미 Haiku(무관)·설정에 Fable 기본값 없음 → **대화형 세션 모델선택에서 나옴**. 권장=대화형 기본=Opus 4.8, Fable은 전체스윕·일상 금지(`/model`로 전환·settings.json 고정 가능). 관련 [[project_differential_audit_autonomy]](ERP 전체 검수=토큰과다 → 변경분만 차등점검).
