---
name: reference_funnel_gas_script_id
description: "마케팅 퍼널 GAS = \"문의Survey\" 프로젝트 scriptId·에디터 URL (clasp 연동됨 → 자동 재배포)"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 260c4dac-9847-42a6-a1ac-9aeca99e374c
---

마케팅 퍼널/문의 GAS(=`cmo/survey/apps_script_survey.js`: period_breakdown·click_stats·funnel_conversion·_collectFormInquiries_)의 Apps Script 프로젝트:

- 프로젝트명: **문의Survey**
- scriptId: `1A77oDRaa21K25c3-M1AgewNfUzfW-zamfRhYWjlYUrvIdPCYazs8KQru`
- 에디터 URL: `https://script.google.com/d/1A77oDRaa21K25c3-M1AgewNfUzfW-zamfRhYWjlYUrvIdPCYazs8KQru/edit`
- 데이터 시트: 문의_survey(`1g9Ohmd8C_WxyvWt9EX58oEFZLiOAJ_EG7t7XteJFuGE`) · 멤버십 원천 = "1-1) 멤버십 문의 관리(26년도)"(`12AWcAlgmmYKr2nUbWmVpa71_z3zi0BaU4ZdnOwrI_7U`)
- 배포 URL(/exec): `AKfycbzdwSCCSSJ6JXLDoWuo7HG0JmBM2iy10TujFQ_O5JbTjnWaN7gOk-ddA4IAvsNfelg0xA`

✅ **clasp 연동됨** — 로컬 `.deploy-funnel/.clasp.json`에 이 scriptId(`1A77oDR…`) 있음. 코드 변경 시 자동 재배포:
`cd .deploy-funnel && clasp push -f && clasp deploy -i AKfycbzdwSCCSSJ6JXLDoWuo7HG0JmBM2iy10TujFQ_O5JbTjnWaN7gOk-ddA4IAvsNfelg0xA -d "설명"` (in-place → /exec URL 유지, 새 @버전). 라이브 정본=`.deploy-funnel/Survey.js`, 가이드 사본=`cmo/survey/apps_script_survey.js`. 2026-06-16 @22~24 이 방식으로 배포함. (clasp 3.3.0) 관련 [[reference_clasp_webapp_redeploy]] · [[feedback_gas_deploy_notepad_chrome_pair]].

⚠️ **미끼 주의(2026-06-23):** 두 파일은 이미 크게 드리프트함(Survey.js 85KB ≠ apps_script_survey.js 62KB, 상수·함수 위치 다름). **함수 수정은 반드시 라이브 `.deploy-funnel/Survey.js`에.** Explore·executor가 사본(apps_script_survey.js)을 라이브로 오인해 #3을 잘못 넣은 전례 있음 → 라이브로 이전 완료(커밋 bbc1fe1e). **듀얼 소스 일원화=후속 정리과제**(사본 폐기 또는 빌드로 자동 동기). 배포=`cd .deploy-funnel && clasp push -f && clasp deploy -i AKfycbz…A -d "설명"`(/exec URL 유지) + 트리거는 에디터서 1회 실행.
