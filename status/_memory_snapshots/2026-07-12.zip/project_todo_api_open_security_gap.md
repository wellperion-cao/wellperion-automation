---
name: project_todo_api_open_security_gap
description: 업무·결재 GAS API가 무인증 개방 — 별도 보안 과제 (2026-06-05 GM 인지)
metadata: 
  node_type: memory
  type: project
  originSessionId: bfbdcf2d-b7f2-4f95-9adf-bcaf04512e15
---

업무현황·결재현황 SSOT가 쓰는 GAS 웹앱(TODO_API_URL, /exec)이 **공개 github.io HTML에 그대로 노출**돼 있고, doGet/doPost가 `todo_add`·`todo_update`·`todo_delete`·`todo_reset`을 **인증 없이** 처리한다. PIN 검증은 `todo_sign`(승인/반려)에만 있고, 그마저 `todo_reset`은 2026-06-05 개방 수준으로 완화(버튼 실수방지용 PIN만, 직접 호출 허용 — [[reference_clasp_webapp_redeploy]] 통해 배포).

**즉 URL만 알면 누구나 회사 업무·결재 데이터를 변조·삭제 가능.** 공개 레포라 URL이 사실상 노출.

2026-06-05 GM께 인지 보고함(급한 건 아님). 향후 별도 보안 과제로:
- 옵션: GAS doGet/doPost에 공유 시크릿 토큰 게이트(ScriptProperties) + 프론트는 토큰 없이 읽기만/쓰기는 게이트, 또는 배포 접근권한(도메인 제한)·Apps Script 실행권한 재검토.
- 결재(approve/reject)는 이미 PIN 서버검증([[reference_appsscript_korean_write]] 경로) 유지.
