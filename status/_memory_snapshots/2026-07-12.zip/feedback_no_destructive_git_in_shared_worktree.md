---
name: git
description: executor 서브에이전트가 공유 작업 디렉터리에서 git reset --hard 를 실행해 미커밋 작업물을 소실시킨 사고 교훈. 격리 없는 파괴적 git 명령 금지.
metadata: 
  node_type: memory
  type: feedback
  date: 2026-06-26
  incident: INC-009
  originSessionId: b0cc2125-83ac-42cd-bfa5-35a8018a5c32
---

# 사고 한 줄

2026-06-26, 자율 웰리 루프 1관문 중 executor 서브에이전트가 공유 작업 디렉터리에서 `git reset --hard b68dcc53` 실행 → 미커밋 편집 6건 영구 소실.

# Why (근본원인)

- 서브에이전트가 파괴적 git 명령 실행 전 `git status` 로 미커밋 변경을 확인하지 않았다.
- 공유 작업 디렉터리를 "실험·검증 전용 sandbox" 로 오판 — 실제로는 GM 이 작업 중인 유일한 워킹트리였다.
- 격리(worktree/clone) 없이 파괴적 명령을 실행하면 미커밋 변경은 reflog 에도 저장되지 않아 복구 불가.

# How to Apply (적용 규칙)

1. **공유 작업 디렉터리에서 파괴적 git 명령 절대 금지** — `git reset --hard`, `git checkout --`, `git clean -f`, `git revert`(실험 목적) 전부 해당.
2. **파괴적 명령 전 상태 확인 의무** — `git status` 실행 → 미커밋 변경이 1건이라도 있으면 즉시 중단·GM 보고.
3. **격리 실험은 worktree 또는 별도 clone** — `git worktree add ../tmp-experiment HEAD` 후 그 안에서만 파괴적 명령 허용.
4. **서브에이전트 디스패치 시 `isolation=worktree`** — Agent 도구 호출 시 파일 변조가 예상되는 경우 반드시 `isolation: "worktree"` 지정.
5. **미커밋 작업물은 커밋 후 위임** — 작업 중 다른 에이전트를 디스패치할 경우 먼저 커밋·푸시하여 보호.

# 관련 참조

- [[reference_queue_archive_split]] — 데이터 급감이 '손실'처럼 보여도 아닐 수 있다 (오판 패턴 유사)
- [[feedback_git_commit_atomic_vs_watcher_reset]] — 원샷 커밋+autostash: 동시 watcher 리셋 대응
- ssot/incidents.json INC-009 — 사고 정본 기록
