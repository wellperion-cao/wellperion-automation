---
name: project_support_check_single_source_page
description: 지원부 점검 시스템 통합 — 단일기준·저장경로·라이브GAS·항목ID정규화·4부서격차
metadata: 
  node_type: memory
  type: project
  originSessionId: b08134eb-3a71-4280-b75b-18f11a8a3c5c
---

지원부 점검 "시트·서버·페이지가 항상 안 맞는다"의 근본원인·해법 (2026-06-23 GM deep dive).

**근본원인 = 항목 마스터 3곳 분산·드리프트:**
- 페이지(`지원부 체계.html`): 하드코딩 시드 `WEEKDAY/WEEKEND/NIGHT_*`(42항목) + `ROUND_MAP`(회차) — **정본(단일 기준)**.
- 서버 GAS(`.deploy-check/지원팀 일일점검.js`): `_TL_ROUND_MAP`이 페이지 ROUND_MAP의 **손동기 복사본** → 드리프트. ★폴백 함정: `_TL_ROUND_MAP`에 id 있으면 시트 rounds 무시 → 시트·페이지 고쳐도 서버는 옛 표만 봄.
- 시트(`지원_매뉴얼`): `CUSTOM_ITEMS`+shadow만. 시드 42항목은 페이지 JS에만 있고 시트엔 없음.

**GM 결정 = 페이지가 단일 기준.** 시트·서버는 페이지 따라옴.

**영구 단일출처 완성(2026-06-23, Part1+2 배포):**
- **Part1(@94)**: GAS `ITEM_HEADERS`에 '시드'열+`_isSeedRow`+`syncSeedItems` 엔드포인트(payload 키=`seeds`·멱등 upsert·seed='Y' 격리행). 페이지 `pushSeedItemsToSheet()`+'⟳ 시드 동기화' 버튼(편집모드·수동).
- **Part2(@95)**: `_countTodaySchedule` else-if 반전(시트 rounds 우선·`_TL_ROUND_MAP`은 폴백 강등)+seed-skip 해제(seed행 분모 합류)+**임계폴백 `_SEED_MIN=30`**(지원부 seed<30이면 레거시 회귀 차단). support 전용.
- ★ 운용: 페이지 ROUND_MAP(코드) 변경 시 **'시드 동기화' 1회 트리거**하면 시트→서버 자동 반영.

**분모 부풀림 완전 정합(@96, 2026-06-24):**
- 증상: today_live 분모=**259**(마스터 53항목의 3.5배). 오전조 남54·여54(가짜 대칭).
- 해법: `_countTodaySchedule` 폐기→`_buildTodayMaster` 신설. getItems와 동일 모집단(non-seed 53항목)을 읽어 각 항목 **rounds 첫 회차(대표버킷)에 1회만** 계상. 하드코딩 `_TL_ROUND_MAP`·`_TL_DAY_FOCUS_CNT`·`_TL_NIGHT_CNT`·`_SEED_MIN` 전부 삭제(-52줄).
- 검증(라이브 실측): total **259→76**, am 남28·여29(비대칭 정상), 7요일 74~82. 커밋 1d748bf5.

## 지원부 저장 경로·zone 라우팅

- **라이브 GAS 소스 = `.deploy-check/지원팀 일일점검.js`(clasp scriptId 1FLQAzjq…).** `coo/check/apps_script_v3.js`(863줄·Jun6)는 다부서 확장 전 **stale 갈라짐본** — 수정 금지·혼동 주의.
- **프론트 `_buildPushPayload`는 `zone`을 안 보냄**(genderTab만) → 서버 handleSave가 **레거시 `_handleSaveV2Compat`** 경로 사용. V2Compat는 `_routeItem`으로 항목별 성별시트 결정.
- **시트 기록 규칙=완료+이슈만(2026-06-15 GM 최종)**: `_shouldRow(dept,c)`=**완료(checked) 또는 이슈/노하우/측정 있는 항목만** 행 생성.
- **2026-06-15 버그**: `_routeItem`이 `itemId.indexOf('_f')`/`'_m'` **부분문자열** 매칭 → custom id의 랜덤 접미사가 `_f…`면 남자 탭 점검이 여성 시트로 유실. 수정: custom_/cx_ 추가항목은 id 성별판정 제외→genderTab(현재 탭) 기준.
- **신규 도구**: `?action=delete_item_row&dept=&date=&zone=male|female|common&itemId=` = (zone×날짜×itemId) **1행 정밀삭제**.

## 라이브 GAS=지원팀 일일점검.js (apps_script_v3.js는 미끼)

라이브 GAS = scriptId `1FLQAzjq6IME2A41QZlfZZSzzAeaFFDAr58M6T-JzDtzzbC4gEKuQFNp6`(`.deploy-check/지원팀 일일점검.js`). 4부서 공용.

⚠️ **레포의 `coo/check/apps_script_v3.js`(약 920줄)는 구버전 레포 복사본 — 라이브 아님.** 거래업체 점검 시 이 파일만 보고 "vendor_list/vendor_save 핸들러 없음 → 서버 저장 안 됨"으로 **오진한 적 있음(2026-06-16)**. 실제 라이브엔 `vendor_list`·`vendor_save`·`_vendorSheet()` 시트 자동생성이 **이미 구현·작동** 중이었다.

**교훈:** 점검·수정할 땐 반드시 HTML의 `API_URL` → scriptId로 **라이브 소스를 먼저 확정**한 뒤 작업한다.

## 항목ID 정규화 완료 (2026-06-13)

지원부 점검 항목ID 전체 정규화 = **2026-06-13 완료**(커밋 `0b0198a1`, 라이브검증 PASS).

**아키텍처 핵심(앞으로 유지):** base 항목 = **HTML `const WEEKDAY`/`const WEEKEND` 두 배열**(같은 base id 공유 — **둘 다 동시 수정 필수**). custom 항목 = 지원_매뉴얼 시트(`action=items` 반환). **shadow는 폐기함 → base 정본 = 코드 단일출처.**

**최종 카탈로그:** A 사우나 a1~a3 · B 락커룸 b1~b7 · C 내부 c1~c10 · D 업장 d1~d5 · E 외부 e1~e2 · 오픈 c1a~c1c · 마감 cls1~cls3. 시트 custom = 11개. 야간 n_*·요일별집중 df_* = id 불변.

**충돌 처리(앞으로 동일 작업 시 필수):** base id rename에 출발지=도착지 겹침 → **2단계 임시토큰**(old→§final→final) 필수. 단일 find-replace 금지.

⚠️ **ID rename 동반수정 필수:** base id를 바꾸면 **ROUND_MAP**(HTML ~line 1669 `const ROUND_MAP={}`)의 키도 같이 바꿔야 한다. 안 바꾸면 itemRounds가 roundOfSlot 단일라운드로 폴백 → 해당 항목이 오후조·마감조에서 사라지고 완료율 거짓100%.

## 4부서 공용 GAS — 기능은 지원부 한정

점검 백엔드 GAS는 **support·facility·ops·parking 4개 부서 공용**(`_deptTabs(dept)`로 탭 분기).

**부서별 기능 격차:**
- **지원부(support)만** 보유: 5조 클릭형(ROUND_MAP·itemRounds), 점검일지 스냅샷(snapshot_append/appendRoundSnapshot), 조별 타이머, 완료 체크 원장.
- 시설·운영·주차: 스냅샷 미보유 → 항목별 시트 col5가 완료율 유일 출처.

**그래서 '이상치만 기록' 필터는 support 한정**(`_anomalyOnlyDept(dept)`). 타 부서에 적용하면 정상완료가 빠져 **완료율 회귀**.

**How to apply:** 점검 GAS의 부서-의존 로직 변경 시 "이 기능이 4부서 전부에 있나? 스냅샷 의존인가?" 먼저 확인. 타 부서 점검을 5조·스냅샷으로 올리기 전엔 이상치필터·스냅샷집계 확장 금지.
