---
name: project_gm_aide_autonomy
description: GM 보좌 자율화 체계(배237) — 웰리가 GM 성향·습관 학습해 놓친 것·다음 할 것 선제 포착·실행
metadata: 
  node_type: memory
  type: project
  originSessionId: 8e6a94c1-0701-48f1-af38-3bbdc0d05c2b
---

웰리가 GM 성향·습관을 학습해 GM이 놓친 것·다음 할 것을 스스로 챙기는 체계. 자율화 다음 지평([[project_northstar_g1_orchestration_erp]]·[[project_bridge_mechanized]] 위). deep-interview로 모호성 4.5% 확정(2026-07-02).

**3층:** ①관찰·학습(GM 지시·결정·추천 승인/보류·루틴 로그 → 수치+LLM 서술 `gm_profile.md`) ②포착(확정신호+GM 지시함의, 예측형 제외) ③선제 실행(적극 자율=금지5종만 게이트·가역=자율/비가역=제안).

**핵심 규칙:** 실행 주체=웰리 위임→담당 C-Level 실행→웰리 검증(직접실행 금지 유지). 전 C-Level=공유 원장 append→웰리 단일두뇌 통합. 보고=G1 통합(자율=입항기록/제안=대기배+KPI→북극성 경로). 루프=하이브리드(GM지시 이벤트 즉시+06:30 일일스캔). 성공기준=GM개입감소+포착적중률+사후보고신뢰.

**구현:** phase1 라이브(2026-07-02) — `scripts/gm_profile_builder.py`·`scripts/gm_aide_scan.py`(06:30 예약 `Wellperion-GM-Aide-Scan-0630`)·`status/gm_observation_ledger.jsonl`·제안배 `[GM보좌 제안]`. **phase2 라이브** = 가역 자율실행. 스위치 `GM_AIDE_AUTO_EXEC`(gm_aide_scan.bat set=1)·멱등·역롤백=플래그 OFF.
- 2026-07-02: next_augment(표류 배 next 자동보강) 1종만 → 완료 훅이 표류를 없애 **auto_applied 0건 굶주림**(정직 상태).
- **2026-07-04 GM go: 자율 정비 액션 5종 추가**(`plan_maintenance_actions`) — 미러동기·현황재발행(죽은 예약작업 소거)·KPI갱신·죽은워크트리정리(clean만·[[reference_prune_dead_subagent_worktrees]])·일요일컨텍스트정비(`context_budget_report.py`). 전부 **조건부(실제 문제 있을때만·없으면 그날 0=정직·억지발동 금지)·가역·멱등·사후 auto_exec 로그**. 오늘 라이브 1회로 3건 실행(0→3) 실증. subprocess는 utf-8·errors=replace 필수(cp949 크래시 방지). '자율이 오늘 한 일' 카운트=자율현황.html buildFeed DONE_SIG={auto_exec,activation}.
- 비가역·도메인 실무는 여전히 제안/C-Level 세션 몫(자율실행 금지). 스펙 정본=`.omc/specs/deep-interview-gm-aide-autonomy.md`.

**How to apply:** GM 놓친 것 포착·제안은 이 체계 경유. 가역만 자율·비가역은 제안. 관련 [[project_daily_northstar_recommender]](추천기)와 물림.
