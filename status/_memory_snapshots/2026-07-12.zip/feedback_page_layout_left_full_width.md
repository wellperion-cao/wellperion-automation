---
name: feedback_page_layout_left_full_width
description: 모든 가이드 페이지 레이아웃 표준=좌측 정렬+폭 최대(중앙정렬·max-width 캡 제거)+모바일 반응형
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 8e6a94c1-0701-48f1-af38-3bbdc0d05c2b
---

**가이드 페이지 레이아웃 표준(전 페이지 상시):** 컨테이너를 **좌측 정렬 + 폭 최대**로 한다 — 중앙정렬(margin:0 auto) 제거·`max-width` 캡 제거(또는 100%)·`margin:0`으로 화면 폭을 최대한 활용. **모바일은 반응형으로 항상 맞춘다.**

**Why:** 2026-07-02 GM — "좌측 정렬로 폭을 최대로 해줘, 다른 것들도 항상 이렇게 해줘, 당연히 모바일은 또 맞춰줘." 넓은 화면에서 가운데 좁게 몰리는 것보다 폭 최대가 정보 밀도·가독에 유리.

**How to apply:** 새 페이지·기존 페이지 컨테이너(`.wrap` 등)에서 `max-width` 캡·`margin:auto` 중앙정렬을 빼고 좌측 정렬·풀폭. 가독용 좌우 padding은 유지. 데스크톱=풀폭 좌측정렬, 모바일=기존 @media 반응형 보존. 새 페이지 만들 때 기본값으로 적용([[feedback_gm_reports_short_scannable]] 결과중심과 별개, 이건 레이아웃).

**+ 파비콘 표준(2026-07-02 GM):** 각 가이드 페이지의 **브라우저 파비콘 = 그 페이지 제목(h1) 앞 이모지**(예: 월간운영계획 📅·자율현황 🤖·헌법 🏛️). 방법=인라인 SVG data-URI(`<link rel="icon" href="data:image/svg+xml,...<text>이모지</text>...">`)로 공용 favicon.ico 교체. **이모지는 파비콘에만 — 화면 제목(h1)엔 선행 이모지 넣지 않음(중복 제거, 2026-07-02 GM).** 새 페이지도 기본값.
