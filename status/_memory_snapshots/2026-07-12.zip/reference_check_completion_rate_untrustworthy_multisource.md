---
name: reference_check_completion_rate_untrustworthy_multisource
description: "점검 완료율(%)은 소스별 분모가 달라 신뢰불가 — 화면·대시보드에 실측처럼 표시 금지, 잠정 표기"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 46770c63-3022-422d-b677-ad41a31f15b6
---

점검 완료율(%)을 어떤 화면·대시보드에도 **'실측'처럼 확정 숫자로 표시하지 말 것**. 라이브 GAS 실측(2026-07-04) 결과 소스별 분모가 제각각이라 같은 날 값이 갈린다:

- **today_live vs monthly_report 같은 날 불일치**: 7/4(토)를 `today_live&dept=support`=25/105(24%), `monthly_report&dept=support`=25/25(100%)로 냄. 분모가 스케줄 총량(105) vs 스냅샷 기록량(25)으로 다름 → 완료율 완전 상반.
- **주말 오후조 phantom**: today_live가 주말(토)인데 오후조(pm) 슬롯 포함(byGender pmTotal). 주말 정상 분모=오전+마감만(105→76). = [[project_g1_done_today_past_search]] 무관, 주말 회차버그(배173).
- **avgPct/issueCount top-level 불안정**: 응답에서 null 관측될 수 있음 → 완료율·이슈는 `dailySeries[]`에서 합산해야 신뢰(이슈=per-day issueCount 합).

**적용:** 완료율(%)은 백엔드 정합(today_live 주말 pm 제외·today_live↔monthly_report 분모 단일화·avgPct 안정화 = 배14/173/239) 확정 **후에만** 표시. 그 전엔 '잠정·분모 정합 확정 전' 명시 + 신뢰 카운트(이슈 건수·세션·활성일)만 실수치로. 이 세션에서 자율현황 시우섹션이 이 함정에 걸려 정직 대체함(baf82a76). 관련: [[reference_check_gas_korean_cell_and_pct_clamp]] · [[project_support_check_single_source_page]] · [[feedback_gm_decides_by_seeing_kpi_path]].
