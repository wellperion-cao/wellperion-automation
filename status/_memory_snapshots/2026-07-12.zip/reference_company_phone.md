---
name: reference_company_phone
description: "웰페리온 대표 전화번호(공식값) = 02-6261-1200 · 규모 3,000평 종합 스포츠클럽"
metadata: 
  node_type: memory
  type: reference
  originSessionId: e4974790-ef30-4c7a-8bab-a27369911016
---

웰페리온 **대표 전화번호 = `02-6261-1200`** (멤버십 문의, 회사 대표회선 — 개인 010 아님). GM 확인 2026-06-06.

전 채널(네이버 플레이스·구글 비즈니스 프로필·블로그·CS 스크립트 등) 공식 노출용. 개인 010 번호 노출 금지 원칙은 유지하되, 이 대표회선은 노출 가능.

규모·시설(공식값, GM 확인): **3,000평 종합 스포츠클럽** — PT·필라테스·스쿼시·골프·체조·G.X·수영·사우나·스파. 주소=서울 용산구 서빙고로 413(한남동). 운영시간은 [[project_operating_hours]] 참조. 채널 등록 콘텐츠 = status/briefs/CMO-2026-06-06-CHANNEL-REGISTRATION-PACK.md
