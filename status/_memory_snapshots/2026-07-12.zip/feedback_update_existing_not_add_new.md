---
name: feedback_update_existing_not_add_new
description: 무엇이든 기존에 있던 것을 업데이트로 해결 — 새 파일·페이지·스크립트 계속 추가하면 양만 방대하고 내실 없음
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 644d85ba-fbd1-4fc9-8170-ce95d1fcc47a
---

GM 확정(2026-06-08). 작업 해결 방식의 기본값 = **기존 자산을 업데이트**. 새 파일·새 페이지·새 스크립트·새 탭을 계속 추가만 하는 방식 금지.

**Why:** 새로 추가만 하면 양(파일·페이지·코드)만 방대해지고 내실은 하나도 안 쌓인다. GM이 이 세션에서만 같은 패턴을 반복 지적: (1) 바레 슬라이드를 기존 덱 수정 대신 전부 새로 렌더, (2) 체계 페이지 안에 넣을 대시보드를 standalone 새 페이지로 생성("아예 페이지를 새로 만들어버렸네?"). 둘 다 결국 기존 것 수정으로 되돌렸다. 단일 SSOT·중복삭제 원칙([[project_ssot_dedup_2026_06_06]] · [[project_principles_s2_single_source]])의 실행 버전.

**How to apply:**
- 어떤 요청이든 먼저 "이 기능/내용이 들어갈 기존 파일·페이지·스크립트가 있는가?"부터 찾는다. 있으면 그걸 수정한다.
- 신규 생성은 해당 기능이 기존에 **아예 없을 때만**. 그 경우에도 사실과 이유를 먼저 명시하고, 가능하면 기존 파일에 통합.
- C-Level 위임 프롬프트에 이 원칙을 명시("새 파일 만들지 말고 기존 X를 수정")한다.
- 신규 추가 충동이 들면 = 중복·드리프트 신호. 멈추고 기존 정본을 찾는다.

연관: [[feedback_guidehub_design_principles]] (중복삭제·읽을거리최소화) · [[project_ssot_dedup_2026_06_06]] · [[feedback_single_image_set_all_channels]].
