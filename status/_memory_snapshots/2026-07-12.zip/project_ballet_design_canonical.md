---
name: project_ballet_design_canonical
description: 발레 슬라이드 = 사진형 디자인 정본 확정 기준 (2026-06-05 GM·웰리 직접 셋팅) + 다음 미완 3건
metadata: 
  node_type: memory
  type: project
  originSessionId: 97ac62ee-369b-4aa7-ada7-edd6433c0841
---

발레 런칭 슬라이드(`instagram/260520_발레_런칭/output(인스타그램)/ig_01~07`)가 **사진형 슬라이드 디자인의 정본 기준**으로 확정됐다. 2026-06-05 GM이 시모 반복 미세수정에 지쳐 웰리(CEO)에게 직접 맡겨 셋팅.

**확정 디자인 (사진형 정본 = `scripts/compose_barre.py` 엔진, `compose_ballet`이 import 재사용):**
- **캔바 폐기·코드 정본**: 바레 정본이 캔바 제작본이라 코드가 영구 모방→픽셀 불일치였음. GM 결정으로 캔바 추격 종료, compose_barre 코드가 유일 SSOT. "캔바와 다르다"는 더 이상 결함 아님. [[project_slide_engine_canva_independence]]
- **표지**: 듀오톤 `to_duotone(normalize=True)` — 밝은 배경 표지도 톤 일관(autocontrast).
- **본문 4줄 교차 패턴**: 1·3줄(메타·서브)=베이지+medium / 2·4줄(헤드라인·풋터)=흰색+bold.
- **메타라인**: "BALLET · 2026.05 OPEN" (2026.05 중복 제거).
- **CTA**: "문의 :  wellperion.com/ko/inquiry".
- 색·로고·폰트 상수 = `scripts/brand_constants.py` 단일 SSOT.

**다음 (미완 — 끊김 방지 기록):**
1. **compose_barre 정본도 동일 본문 패턴 통일** — 현재 발레(compose_ballet 자체 compose_story)에만 교차패턴 적용됨. 바레 정본 코드도 맞춰 바레·발레 코드 레벨 완전 일치(기존 발행 바레는 소급 안 함).
2. **M5 디자인 표준 마스터 정립** — 이 확정 디자인(엔진 2종·계정별 비율·색·글꼴 패턴·CTA)을 M5(cmo-publish)에 명문화. ground truth=코드 정본. ([[feedback_visual_reuse_reference_generator]] 정신)
3. **발레 검수큐 등록·발행** — review_queue 등록 → GM 승인 → 4채널 임시저장([[project_4channel_dispatcher]]).
