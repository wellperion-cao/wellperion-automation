---
name: project_cpo_autonomy_brain_action_hub
description: 시포(CPO) 자율화 두뇌 현황 — 자동보고=module_registry 경유(별도발신 금지)·상담사 액션허브=문의회원.html·미해결 데이터갭
metadata: 
  node_type: memory
  type: project
  originSessionId: 646f1cbb-5df0-4b8d-b7b7-f1973de912f9
---

시포(CPO) 자율화 두뇌 마일스톤 (2026-07-09 착수·배 시포 754 · deep-interview 스펙 `.omc/specs/deep-interview-cpo-autonomy-brain.md`). GM 4기둥(①백엔드 AI없이 ②모듈화 ③UX단순화 ④일/주/월 텔레그램 자동보고). 역할분리=상담사 입력·처리 / GM 현황·결정.

**④ 자동보고 = 웰리 단일 등록부 경유(★별도 발신 금지=혼선방지).** `status/module_registry.json`에 `cpo-inquiry-daily-actions`(daily·실무진 문의방)·`cpo-member-rollup`(weekly/monthly·GM채널) 2모듈 등록, **`bot_id:null`=발효 OFF**. 발신은 `scripts/module_reporter.py`(단일 소비자)가 함 — 각 C레벨이 daily_scheduler에 자기 CronTrigger 심어 따로 쏘면 안 됨(그 방식은 철거했음). 수집기=`scripts/collectors/cpo_*.py`가 `scripts/cpo_report.py` 로직 재사용. 통합 발신 ON=웰리 전C레벨 롤아웃 대기.

**①②③ 상담사 액션 허브 = `cpo/member/문의회원.html`.** '오늘 할 일' 패널(type-chip-bar 형제 위치=전 탭 상시노출, 멤버십+강습 switchFamily 분기, 4분류=오늘신규·미컨택·오늘상담예약·이탈위험, 화면 숫자=cpo_report 로직 이식이라 텔레그램과 일치, 클릭→CONTACT 연락이력 모달/예약은 예약모달). + 이탈방지 액션 모듈(회원현황 탭·멤버십 갱신임박≤30일·저이용). 신규 GAS 액션 0(기존 member_active_list·lesson gviz·dbRows 재사용).

**미해결 데이터 갭(GM 인풋 필요 — 임의설계 금지):**
- **강습 이탈방지 미적용**: 강습 명단=수강 인원수만, 만료·갱신 개념 없음(클래스 수강 구조). "강습에서 이탈=무엇"(예 수강종료 후 N일 미재등록) 정의부터 필요.
- **저이용 정확도 한계**: 시트에 방문일·방문빈도 원본 없음 → 저이용=등록일 대비 이용일수 근사(추정 배지). 실측=출입/방문 로그 연동 필요(시토 협업).

**Why:** GM 지시 "Fable로 결과물 아닌 뼈대(자율화 두뇌) — 시포것을 exemplar로." 각 C레벨이 따라 짓는 첫 레퍼런스([[project_clevel_autonomy_brain_productization]]).
**How to apply:** CPO 보고 신규=module_registry에 cpo-* 등록(별도 텔레그램 발신 코드 금지). 화면 액션=문의회원.html 재사용. 추정 지표는 정직 배지. [[project_cpo_owns_post_inquiry_funnel]] [[reference_member_calendar_status_visual_and_carryover]]
