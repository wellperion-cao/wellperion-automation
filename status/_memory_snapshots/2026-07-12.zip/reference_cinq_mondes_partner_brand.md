---
name: reference_cinq_mondes_partner_brand
description: 생크몽드(Cinq Mondes) 외부 파트너 스파 브랜드 — 정체성·시그니처·페디큐어 오인정정·로고출처
metadata: 
  node_type: memory
  type: reference
  originSessionId: ac184aeb-8f8a-4322-9c7e-89090526b314
---

생크몽드 = **Cinq Mondes**, 웰페리온 **외부 파트너 스파 시설**(웰페리온 자체시설 아님). 정확표기 = Cinq Mondes(한글 병기 "생크몽드"). 전부 대문자 CINQ MONDES는 공간 사이니지/로고에서만.

- **정체성:** 2001 파리 창립(Jean-Louis Poiroux 부부). 5대륙(인도·중국·일본·발리·모로코) 전통 뷰티 리추얼을 프랑스 에스테틱으로 재해석한 럭셔리 스파·스킨케어. 브랜드명 = '다섯 개의 세계'.
- **철학:** "Worldly Beauty Rituals®" — 즉각 변화보다 시간이 지날수록 건강해지는 피부, 정직한 고농축 식물성 포뮬러(석유화학·실리콘·미네랄오일 배제), 피부·감각·마음 전체론적 회복.
- **시그니처(핵심 제공):** 페이셜·바디·시그니처 마사지(인도 아유르베다·동양 전통·일본 코비도 페이스리프팅·DERMAPUNCTURE 니들프리). 한국 한남점 추가: 키즈·임산부·산후케어·요가/명상.
- ⚠️ **페디큐어는 핵심 아님(오인 정정):** 어느 사이트 메뉴에도 풋케어가 시그니처로 없음. '풋배스+골드수전' 컷은 페디큐어룸이 아니라 트리트먼트 직전 **웰컴 발씻기 의식(welcome foot ritual)**. 콘텐츠에서 단독 주제로 쓰지 말 것 — '리추얼의 시작' 장면으로만 재맥락화.
- **공식:** https://cinqmondeskr.com (한국 한남점). 로고 로컬 assets 없음 → imweb CDN PNG(`cdn.imweb.me/thumbnail/20260324/cb997b9dbd4b0.png` 등 2종), 투명배경/해상도 부족 시 본사 SVG 원본 요청 후 `_assets/logo/`에 파트너 로고로 박제.
- **웰페리온 서사:** 운동(웰페리온 스포츠클럽) + 힐링·회복(생크몽드 파트너) = '한 곳에서' → 이런 파트너십으로 브랜드 확장하는 그림. (GM 2026-06-11 방향)

관련: [[feedback_brand_voice_positioning]] · [[project_logo_assets_ssot]] · [[project_asset_locations]]
