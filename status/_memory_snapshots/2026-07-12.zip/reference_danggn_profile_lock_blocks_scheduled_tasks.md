---
name: reference_danggn_profile_lock_blocks_scheduled_tasks
description: profiles/danggn 크롬 창을 열어두면 9:30 매출보고 무인 생성·당근 발행이 프로필 잠김으로 실패
metadata: 
  node_type: memory
  type: reference
  originSessionId: 6160b796-c8c8-42e9-a1cd-890323eae1a1
---

`profiles/danggn` = cao 구글세션 저장 퍼시스턴트 프로필. **매출보고 자동생성**(scripts/generate_sales_report_image.py)과 **당근 자동발행**(scripts/danggn_upload_playwright.py)이 이 프로필을 **공유**한다.

**함정:** 이 프로필로 크롬 창을 하나라도 **열어두면** 프로필이 잠겨, 같은 프로필을 쓰는 예약작업(9:30 매출보고 등)이 `launch_persistent_context: Target page, context or browser has been closed` (exitCode=21)로 실패한다. 2026-07-08 실사례: cao 세션 만료 복구용 로그인 창을 열어둔 채 9:30 예약작업이 돌아 충돌·실패(OWNER 경보 발화).

**규칙:**
- cao 세션 만료 시 이 프로필로 로그인 창을 열어 재로그인하되, **로그인 직후 창을 반드시 닫는다** — 특히 9:30 예약작업 전.
- 세션 유효 확인 = generate_sales_report_image.py 재실행 시 시트가 로그인 리다이렉트 없이 열리면 OK(그 자리서 당일 PNG도 생성됨).
- 9:30 무인 실패는 자동 재시도 없음 → 프로필 잠금 풀고 수동 재생성하면 복구. 카톡 3방은 GM이 「📤 카톡 3방 전송」 버튼으로 대체 가능.

관련: [[reference_kakao_report_sender]] · 시토 신뢰성 소유 배102([[reference_telegram_alert_healthcheck_and_gas_diag]]).
