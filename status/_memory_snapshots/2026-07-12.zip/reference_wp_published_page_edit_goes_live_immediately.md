---
name: reference_wp_published_page_edit_goes_live_immediately
description: 이미 발행된 WP 문의페이지(post 8394)는 draft-inquiry 재주입도 즉시 공개 라이브 반영 — 초안 격리 없음
metadata: 
  node_type: memory
  type: reference
  originSessionId: dff9eebd-7c03-47c3-81fd-f1121f8caf53
---

워드프레스 문의 페이지(post ID 8394)가 이미 '발행(published)' 상태면, `scripts/wordpress_admin_playwright.py --mode draft-inquiry` 재주입도 WP "업데이트(#publish)" 버튼을 눌러 **즉시 공개 라이브(http://wellperion.com/ko/inquiry/)에 반영**된다. `publish-inquiry` 모드를 안 돌려도 마찬가지 — 발행된 글엔 별도 초안 격리 상태가 없다. preview URL(`?page_id=8394&preview=true`)도 라이브로 301 리다이렉트한다.

**재발방지(발행 전 GM 검수가 필요할 때):** 편집 전에 post status를 먼저 확인하고, 이미 발행된 페이지면 (a) 임시로 draft로 내린 뒤 검수 → 반영하거나 (b) 스테이징/미리보기 환경에서 검수 후 반영한다. "미리보기까지만"이 발행된 페이지엔 성립하지 않음을 인지. 라이브 반영이 곧 발행이므로, 콘텐츠·화질을 편집 착수 전에 확정할 것.

관련: [[reference_wp_inquiry_inject_self]] · [[reference_wordpress_site_structure]] (2026-07-09 딜라이브 소개영상 유튜브 임베드 시 발견 — post 8394 발행상태라 임베드가 즉시 라이브 공개됨, GM 확인 후 유지)
