---
name: project_clevel_autonomy_brain_productization
description: "C-Level 자율화 두뇌 = 타 비즈니스 업체용 제품화 레퍼런스(북극성 'ERP 상품화'). CMO가 첫 레퍼런스"
metadata: 
  node_type: memory
  type: project
  originSessionId: 71ccfd64-00a2-45eb-a9b4-d8130da18e83
---

2026-07-09 GM Fable세션 지시: 각 C-Level 자율화 두뇌를 만들되 **결과물이 아니라 뼈대(자율화 두뇌·프롬프트·가드레일·아키텍처)**를 남긴다("두뇌 찍으면 복리"). GM이 전 C-Level에 동일 지침 직접 전달 완료 → 각자 본인 소유 백엔드·프론트(ERP 모듈) 기준으로 셋업.

**핵심 방향(deep-interview 6R 확정, 시모 seat):**
- "AI 없이 실무진이 쓰게"의 대상 = **다른 비즈니스 업체**. 즉 자율화 두뇌 = 웰페리온 내부용을 넘어 **제품화 레퍼런스**(북극성 '스포츠클럽 ERP 상품화' 직결).
- **단일테넌트 now + 제품화 가능 아키텍처**: 하드코딩 배제·설정 외부화(봇 ID·채널 계정·모듈=웹등록). 실 멀티테넌트 판매는 자체서버(≈2026-09·[[project_self_hosted_server_setup]] 배101) 후속.
- 5기둥: ①백엔드 AI없이 사용 ②UI/UX 프로세스 단축 ③프론트 모듈화 가독 ④모듈별 텔레그램 일/주/월 자동보고(봇 등록 레지스트리) ⑤채널 자격증명 ERP 웹등록+자동로그인.
- **채널 인증 = 세션 우선 + PW 암호화 폴백**(원안 'PW 저장 자동로그인' 교정 — persistent-profile은 PW 없이 동작, IG·네이버 2FA/캡차로 PW 자동로그인 취약). 2FA=사람 1회.
- 보안 라이브 발효 = GM go + 즉시 역롤백([[feedback_security_live_activation_needs_gm_go]]).

**Why:** 이 프레이밍이 없으면 웰페리온 하드코딩으로 지어 제품화 불가. GM 비전=ERP를 타 업체에 파는 것.

**How to apply:** CMO 두뇌부터 레퍼런스로 셋업(MVP=M3→M1 병합+텔레그램 자동보고, 보안무관 먼저). 검증 후 헌장 박제→타 C-Level 복제. 스펙=`.omc/specs/deep-interview-cmo-autonomy-brain.md`(로컬)·`docs/superpowers/specs/2026-07-09-clevel-autonomy-shared-platform-design.md`(repo). CMO 배747·시모 소유. 모든 설계 결정=버튼 카드/deep-interview([[feedback_offer_numbered_options]]).
