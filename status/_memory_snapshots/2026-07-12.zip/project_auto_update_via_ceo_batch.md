---
name: project_auto_update_via_ceo_batch
description: Claude 본체·OMC 자동 업데이트는 웰리(CEO) Start 배치 1곳에만 — 본체·OMC가 PC 공용이라 전 C-Level 커버
metadata: 
  node_type: memory
  type: project
  originSessionId: 4fd0f3b8-c77d-4cb6-9038-34919b52ad43
---

Claude Code 본체와 OMC 플러그인은 PC에 **글로벌 1개(공용)**다. C-Level별 Start 배치(`Start-AI CEO.bat` + 6개 C-Level)가 같은 본체·OMC를 공유한다.

**자동 업데이트 설계 (2026-06-02 구축):**
- `Start-AI CEO.bat`(웰리) 맨 앞에만 업데이트 3종 삽입: `claude update` / `claude plugin marketplace update omc` / `claude plugin update oh-my-claudecode@omc`. 나머지 6개 C-Level 배치엔 **중복 삽입 불필요** — 웰리가 한 번 최신화하면 이후 뜨는 모든 세션이 최신 사용.

**핵심 명령 차이:** `claude plugin install`은 "already installed" 스킵 → 업그레이드 안 됨. **`claude plugin update`가 정답**(4.14.1→4.14.4 실증). 강제는 uninstall+install.

**부팅 순서 조건:**
- **웰리(CEO)를 가장 먼저** 띄워야 본체(claude.exe) 교체 성공 — 다른 Claude 창이 떠 있으면 "claude.exe in use"로 실패(무해, 다음 기회).
- OMC(플러그인)는 창 떠 있어도 업데이트됨(파일 기반, exe 잠금 무관) → 순서 무관.

[[reference_windows_batch_ascii_only]] [[feedback_daemon_autostart_check]]
