---
name: project_cpo_product_planning_page
description: 상품 기획 페이지 위치·저장 백엔드·데이터 소스 (시포 도메인)
metadata: 
  node_type: memory
  type: project
  originSessionId: 7b36ac1f-8952-4eba-a29b-f3e0676b09e4
---

AI CPO '상품 기획' 페이지 = `3. 웰페리온 가이드/cpo/product/상품기획.html`. AI CPO 메뉴 '통합 회원 관리' 위 '🏷️ 상품 기획'. 구조=탭 4개(멤버십·강습·요금정책·기획작업대): 상단=현행 상품·요금·정책 정리(읽기), 하단 기획 작업대=시포 신규 제안(A 등급간소화·B 멤버십×강습 번들·C 시간대상품·D 전환프로모션·E 이탈방지) 편집·저장.

**저장 백엔드(비자명):** 기존 요금 시트엔 write 금지. 페이지 편집은 **공유 TODO GAS**(scriptId `1VUMgK-vJvxCUO_mjQPpTFLjtv3NWWt8ESkCHH-l3QyCYrpBw2RXsYFFg`, 소스 `.deploy-todo/업무&결재 현황.js`)의 `product_plan_list`(GET)·`product_plan_save`/`product_plan_delete`(POST no-cors)로 **'상품기획저장' 전용 탭**에 영속. POST 본문은 핸들러에서 `e.postData.contents` JSON 파싱 필수(notice_ 패턴). clasp 재배포해야 발효.

**데이터 소스:** 멤버십 요금 CSV(gid=280736331)·강습요금 CSV(gid=39485626)는 첫 스프레드시트. 멤버십 요금 정책 탭 = 별 스프레드시트(2PACX-1vRZyrIV0…, gid=1632372317). 성인강습·유소년강습·멤버십 상세탭 URL은 GM이 추후 제공 예정. CSV 라이브연동 아님(정적 정리). 라이브 URL=가이드 접두사 없는 루트 배포([[reference_pages_url_no_guide_prefix]]).
