---
name: feedback-remote-control-always-on
description: Claude Code 시작 시 --remote-control 옵션 항상 포함. 모바일 연결 끊김 방지.
metadata: 
  node_type: memory
  type: feedback
  originSessionId: e5ddfbd0-7073-4b6d-8a75-e2e140267a52
---

Claude Code 세션 시작 시 `--remote-control "Wellperion GM"` 옵션을 항상 포함한다.

**Why:** 2026-05-27 PC 리부팅 후 --remote-control 옵션 누락으로 모바일 연결 끊김 발생. GM님이 모바일에서 세션 접근 불가 경험.

**How to apply:** PC 부팅 스크립트·bat 파일·자동 시작 설정에 `--remote-control "Wellperion GM"` 포함 의무. 수동 시작 시에도 동일.
