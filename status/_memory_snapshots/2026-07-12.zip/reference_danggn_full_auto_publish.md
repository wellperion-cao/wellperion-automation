---
name: reference_danggn_full_auto_publish
description: 당근 채널은 완전 자동 발행 — 스크립트가 본문+사진+게시까지 전부 자동. 세션 만료 시 구글 SSO(cao) 로그인 1회만
metadata: 
  node_type: memory
  type: reference
  originSessionId: b12a8a37-ef8a-4438-a05b-a7d81d3d27b5
---

당근 채널 = **완전 자동 발행**(2026-06-29 확인). 발행 스크립트(`--mode publish`)가 `danggn_copy.md` 본문 + 이미지(post_*.jpg, 8장) **자동 첨부 + 게시까지 전부 자동** 수행. 증거 `danggn_publish_done.png`.

**세션:** cao@wellperion.com **구글 SSO**. 쿠키 만료 시 → 헤드풀 당근 로그인 화면에서 **'구글 로그인' → cao@wellperion.com 클릭 1회**로 세션 갱신, 이후 발행은 자동. (자동화가 구글 계정 선택 클릭을 못 하면 그 클릭만 사람.)

**URL:** 발행 직후 `page.url`에서 `daangn.com/kr/business-posts/{fullPostId}` 패턴 자동 캡처. 리다이렉트 불일치 시 bizprofile posts list 페이지에서 `a[href*="daangn.com/kr/business-posts/"]` 링크 추출 → 자동구성. **수동 회수 불필요** (2026-06-29 보강).

**※ 구 '반자동·사진 수동첨부' 기록은 폐기됨** — 이제 사진까지 완전 자동. 4채널 실행법 정본 = [[reference_4channel_publish_execution]].
