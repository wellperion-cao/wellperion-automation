---
name: project_cmo_designer_and_image_originals
description: 시디(디자이너 에이전트) 폐기 → 비주얼 제작 도구는 시모(CMO) 산하. 이미지→Image/영상→Movie
metadata: 
  node_type: memory
  type: project
  originSessionId: 5841da60-6926-442c-aff6-54482211cb13
---

GM 결정(2026-06-04 정정): **"시디(별도 디자이너 AI)" 역할 폐기.** 이유 — 브랜드 정체성·로고·핵심 비주얼 "창작"은 AI 영역 아님(사람 전문 디자이너 외주). AI는 정해진 톤·템플릿으로 콘텐츠 **양산**만 하므로 별도 에이전트 페르소나 불필요(가짜 조직 늘리기 회피). `cmo-designer.md` 삭제됨.

**도구는 살려서 시모(CMO) 산하로 흡수** (`ai-cmo.md` §5-1):
- `scripts/slide_compositor.py`·`build_slides.py` — 슬라이드·이미지 (Pillow, 무료)
- `scripts/make_reel.py` — 슬라이드→MP4 릴스 (MoviePy, 무료, Ken Burns·자막·음악)
- `scripts/bing_image_gen.py` — Bing 무료 AI 그림 생성 (GM MS 로그인 1회: `--mode setup`, 이후 `--mode gen`)
- **저장 규칙(절대): 이미지 원본→`instagram/Image/` · 영상→`instagram/Movie/`.** 콘텐츠별 가공은 `instagram/{YYMMDD_콘텐츠}/output(...)`([[project_content_folder_naming]]).
- 제작 기준: `2. 브랜드_공식문서/웰페리온_비주얼_스타일_가이드.md`.

**핵심 교훈:** 양산=AI(무료 충분), 정체성·핵심디자인=사람 외주(유료 AI도 하이엔드 브랜드 "얼굴"엔 부족). 웰리 공식 심볼=왕관+보석(가이드허브 favicon 적용)은 AICODE 실험 산출물(`instagram/Image/welly_concept/`). 슬라이드 합성 → [[project_slide_compositor_workflow]].
