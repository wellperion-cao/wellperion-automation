---
name: feedback_live_verify_always_then_taper_with_trust
description: 외부 발송·발행은 라이브 검증까지 무조건 완료 · 초반 신뢰 쌓은 뒤 검증 점감
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ad3d48ad-6510-4c51-82ae-0dc076e3ba8d
---

발행 링크·외부 알림은 **라이브 검증(실제 렌더로 콘텐츠 실재 확인)까지 반드시 마무리**하고 내보낸다. HTTP 200·큐 기록 같은 간접 신호로 "됐다" 판단 금지.

**Why:** 2026-07-09 F2 링크정리에서 카페 363539가 200이라 라이브로 넘겼으나 실제로는 삭제글 → GM이 먼저 발견("확인 안하고 막 알림 넘길거야?"). GM 핵심 철학: **"초반에 신뢰가 정말 중요하다."** 검증을 예컨대 10번쯤 반복해 완벽함이 증명되면 **그때부터 검증을 줄여나가라** — 신뢰를 먼저 쌓고, 쌓인 뒤에 효율화한다. 순서를 뒤집지 말 것.

**How to apply:** ①발행 링크는 Playwright 렌더로 제목·본문·CTA(utm_campaign) 실재 확인 후에만 공유(카페=[[reference_naver_cafe_deleted_post_returns_200]], 블로그=m.blog og:title/RSS). ②실수 시 원본은 editMessageText로 조용히 정정하되, GM이 지시하면 알림방에 별도 사과+정정 알림도 보낸다. ③같은 검증이 반복해 무결이 입증되기 전까지는 스텝을 건너뛰지 않는다. [[feedback_welly_publish_verify_artifacts]] · [[project_publish_verify_before_done]] · [[feedback_exhaust_automation_before_asking_gm]]
