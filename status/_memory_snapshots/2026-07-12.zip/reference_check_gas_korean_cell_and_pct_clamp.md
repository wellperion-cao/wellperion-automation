---
name: reference_check_gas_korean_cell_and_pct_clamp
description: 점검 GAS(지원팀 일일점검.js) 집계 함정 — 시트칸 한글 변환 필수 + 완료율 100% 안전장치 뒤집힘
metadata: 
  node_type: memory
  type: reference
  originSessionId: 54ecf5dd-3949-4d59-b2e5-993e4e2fafc2
---

`.deploy-check/지원팀 일일점검.js`(라이브 점검 GAS) today_live 집계 두 함정 (2026-07-03 수리·clasp v137).

**① 시트칸은 한글 저장 — 읽을 땐 반드시 변환.** saveItems가 성별을 `_genderToKorean`('공통·남·여'), 회차를 한글('오전조' 등)로 저장. 읽는 함수는 `getItems`처럼 `_genderToEnglish(row[4])`·`_roundsToEnglish`로 영문(m/f/all·am/pm/close) 변환해야 함. `_buildTodayMaster`가 성별칸을 raw로 읽어(`String(row[4]||'all')`) glist=['공통'] 등 → 다운스트림 totalByG/doneByG(m/f/all 키)와 매칭 실패 → **전 항목이 조용히 집계 탈락 → today_live total=0/done=0 전날짜 도배**. 수리=`_genderToEnglish(row[4])` 한 줄. 새 집계함수 추가 시 이 변환 빠뜨리면 재발.

**② 완료율 100% 도배 = 안전장치가 분모를 분자로 끌어올림.** `if (totalByG[g][b] < doneByG[g][b]) totalByG[g][b] = doneByG[g][b]`처럼 예정수를 완료수에 맞춰 **올리면** 무조건 100%. 100% 상한은 **완료수를 예정수로 내리는(cap-down)** 방향으로만. 성별 안 맞는 완료기록은 `info.glist.indexOf(g)<0` 게이트로 제외(cross-gender leak가 done>total 유발 → 클램프 트리거).

**소재 구분:** 텔레그램 "오늘의 점검현황" 숫자 = 점검 GAS today_live(서버). 점검 페이지 화면 대시보드(`collectDashboardData`)는 **별개 하드코딩 엔진**(localStorage) — 서버 정합은 [[project_support_check_single_source_page]] ship14 4단계(시우) 미완. 배포=clasp push -f + deploy 동일 deploymentId(AKfycbyXw4Za…), 역롤백=`-V <이전버전>`. [[reference_two_check_pages_mapping]]
