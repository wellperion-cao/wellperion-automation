---
name: project_home_kpi_wiring
description: home 대시보드 KPI 자동집계 연동 전체(매출 월/연간·지출·이슈VOC·보안) — 매출 정본=AV열 단일통합(8.33억 중복합산 버그 수정 후), 지출=시트구조 집계불가
metadata: 
  node_type: memory
  type: project
  originSessionId: 644d85ba-fbd1-4fc9-8170-ce95d1fcc47a
---

home 대시보드 KPI(매출·지출·이슈VOC) 자동집계 연동. 2026-06-08 deep-interview로 요구사항 확정 후 구축. 명세: `.omc/specs/deep-interview-home-financial-voc-wiring.md`.

**엔드포인트:** 기존 todo GAS(.deploy-todo) 확장 — `{TODO_API_URL}?action=home_kpi` → JSON {sales,expense,voc,asOf}. base 검증본·라이브 deploymentId=`AKfycbxDwFkrxK1YIaEoSNcuw2MiHiZQ-7o5N6311ytksSyeEd86ZFOhLknOWqQgNArQvZ-7`(/exec 고정). home JS가 fetch해 ID 채움(heroSales*·heroExp*·kpiIssue*). 운영 현황 상세 상단에 매출·지출, 4카드(업무·결재·문의·이슈 현황) 2×2. clasp 재배포 필요(push≠deploy). MCP 시트 직독 차단→GAS openById만, 검증=home_kpi 라이브 curl.

**✅ 매출 (2026-07-02 GM 지시로 AV열 단일 정본 통합):**
- **정본 = "26년 매출 분석" 시트 AV열 단일** (`KPI_SALES_ANALYSIS_SHEET_ID = 1gCQNny8TDls5SjrtMkINu4HCltvFkoXmkTeXO_c3q58`, 탭 "26년 매출 분석" gid 195790960). **AV3=1월 … AV8=6월 … AV14=12월**(월별 마감값). GM이 매달 이 AV열만 채우면 됨.
- **연간 매출** = `_kpiSales()`가 `openById`로 **AV3:AV14(getRange(3,48,12,1))** 읽어 **값>0인 달만 합산** → 달 채워질수록 자동 누적. 실패 시 null("집계 보완 중").
- **월(당월) 매출** = **현재월 AV 셀** = 행(현재월+2). 예 7월→AV9. 값 없으면 null·hasCurMonth=false("이번달 미마감" 표기, 스테일 이전달 금지).
- **연 목표(yearTarget)=72억**, 라이브 실측 2026-07-02: 연간=35억 700만(1~7월 누적)·당월 7월=2,434만·달성률 48.7%. (breakdown 주차만 parking_revenue.json 별도 유지.)
- **(폐기 이력)** "보고" 탭(`KPI_SALES_SHEET_ID 1oG63rj17-RMk2cdiVbwp4TOp-yN73uc04jDV7RfN9BI`)은 매출 KPI 산출에서 폐기(2026-07-02). 과거 분산 SSOT(보고탭 6월~ + AV 1~5월)가 6월 스테일·연간 급락 폭탄·8.33억 중복합산 버그(옛 보고탭 로직)·AV3:AV7 5월한정 범위 원인 → AV 단일화로 근본 제거. (구 보고탭 6/7 검증값: 오늘 755,000·이번달 150,317,501·연간 591,000,000·달성률 25.43%.)

**이슈 VOC (시트 1akZLs7…gid=1576318230):** 오늘신규=타임스탬프 today, 처리완료='진행 상황'에 '완료' 포함, 미처리=나머지, 처리율=완료/전체. 미처리 261은 과거 누적분 포함 — GM "사실 자료 그대로" 유지 결정. [[reference_voc_issue_intake]]

**⚠️ 지출 (시트 1umSF9rf3K0TuAvR5l0F_gvXHxcOLVKKvkSUfTtbRhdc) — 자동집계 불가, "집계 보완 중"으로 내림(2026-06-08 GM):**
- 거래 1행=1건 로그(가격·구매진행상황). 집계규칙=승인건 가격합(오늘/당월/연간), 예산 대비 집행률(월예산=GAS 상수, 미설정).
- **근본 문제: 시트 행마다 칸이 어긋남**(병합·열 밀림 — '구매진행상황' 칸에 날짜가 섞여 들어온 행 수십개). 자동집계가 들쭉날쭉. GAS=6월 309,400/연간 104.7M, 웰리 독립집계=6월 0/연간 95.8M(1월13.6M·2월1.5M·3월71.8M·4월8.9M, 5·6월 승인표기 없거나 열밀림으로 0). **둘 다 못 믿음.**
- 코드 버그 아님 = **원천 데이터(시트) 구조 문제.** 해결하려면 시트 입력 정리(승인 표기·열 정렬 일관화) 또는 시트 실태 맞춤 집계 재설계 후 재연결 필요(후속).

**보안 과제(미해결):** home_kpi·todo API 모두 무인증 개방. home=GitHub Pages(공개 추정)에 매출·회원 노출. 재무 노출 위험 — 별도 보안 과제 [[project_todo_api_open_security_gap]]. 웰리 솔직평가(2026-06-08)에서 ERP 최우선 약점으로 지목.

**배포**: `.deploy-todo/업무&결재 현황.js` clasp.

연관: [[project_guidehub_identifier_ssot]] · [[feedback_report_final_value_decision_support]] · [[project_coo_issue_sheet_name]] · [[reference_parking_revenue_integration]] · [[reference_clasp_webapp_redeploy]]
