---
name: feedback_content_git_commit_immediately
description: 콘텐츠 폴더(instagram/)는 생성 즉시 git 커밋 — untracked는 동시세션 rebase에 유실됨. 원본 보관소·드라이브 백업 위치
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2370e909-23da-4dbd-a077-61e32e4bb950
---

**콘텐츠 폴더는 만들자마자 git add+commit 해서 추적 상태로 둘 것.** (2026-06-04 사고)

**Why:** 발레·WJO 콘텐츠의 가공본·일부 원본이 **git 미추적(untracked)** 상태로 방치됐다가, 동시 세션들의 `git pull --rebase --autostash` 반복 중 유실됨. untracked 파일은 rebase/clean에 보호되지 않는다. [[feedback_git_commit_atomic_vs_watcher_reset]]의 위험이 실제로 터진 사례.

**How to apply:**
- 새 콘텐츠 폴더(`instagram/{YYMMDD_콘텐츠명}/`) 생성 직후 `git add` + commit. untracked로 절대 방치 금지.
- **원본 사진 보관소 = `instagram/Image/{콘텐츠명}(원본 이미지)/`** (예: `WJO_스쿼시 대회(원본 이미지)`, `발레_런칭(원본 이미지)`, `바레_런칭(원본 이미지)`). 콘텐츠 폴더의 가공 이미지와 별개.
- **백업·복구처 = cao@wellperion.com 구글드라이브**: 발레/바레 = "루프메소드(발레,바레,카이로키네시스)(완)" 폴더, WJO = "26.5.6 WJO 스쿼시 대회/images" 폴더. **MCP `download_file_content`(base64→python 디코드)로 자동 복구 가능**(실증됨).
- 2026-06-04 복구·보호 커밋: 발레 da63223 · instagram전체보호 8985826 · WJO원본 c9df4cd.
연관 [[project_content_folder_naming]] [[project_asset_locations]] [[project_slide_compositor_workflow]].
