---
name: feedback_dept_system_link_parity
description: 부서 체계 페이지 신설·연동 시 링크 짝(home 운영카드+운영통합체계) 전수 맞추기
metadata: 
  node_type: memory
  type: feedback
  originSessionId: aa7d3533-5567-4cf5-a618-caa6aa6b6b04
---

새 부서 체계 페이지(예: 시설부 체계.html)를 만들거나 연동할 때, **지원부 체계가 링크된 모든 버튼 지점에 같은 부서 짝 링크를 빠짐없이** 넣는다. GM이 일일이 짚지 않아도 웰리가 교차 누락을 선제적으로 챙겨야 한다("웰리가 이런거 잘 챙겨줘", 2026-06-06).

**Why:** GM은 한 곳(운영통합체계)만 말해도, 실제로는 여러 진입점에 같은 링크가 흩어져 있어 한 곳만 고치면 나머지가 누락됨.

**How to apply:** 부서 체계 추가 시 `grep "지원부 체계"`로 전수 조사 → **링크 버튼**인 곳만 시설부 짝 추가. 현재 버튼 2곳 = ① ERP 칵핏 home '운영' 카드 알약(`wellperion_guide(main).html` ~526행) ② 운영통합체계(gcoo-check) 부서별 체계(~4273행). 설명문·시드데이터·이력문서의 '지원부 체계' 언급은 링크 대상 아님. 시설부 URL 인코딩 = `coo/check/%EC%8B%9C%EC%84%A4%EB%B6%80%20%EC%B2%B4%EA%B3%84.html`. 작업은 시우(COO) 라인 위임. 관련 [[project_g1_vs_업무현황_분리]] [[feedback_guidehub_commit_must_push_and_live_verify]]
