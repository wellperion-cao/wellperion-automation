---
name: CMO 자동 업로드 표준 — IG 1 + 네이버 2 = 3채널 (페북 폐기)
description: 페북 자동 업로드 폐기 후 IG namuk.wellperion · 네이버 블로그 · 네이버 카페(동부이촌동) 3채널 운영. 당근은 별건 보류 (2026-05-03 축소)
type: project
originSessionId: 37b7c49f-03b9-4c84-a313-635fa646e5da
---
CMO 자동 업로드 표준 채널: **IG 1 + 네이버 2 = 3채널** (2026-05-03 페북 폐기로 축소)

## 채널 의존 분기 (2026-05-20 GM님 룰)

- **IG(가공) 큐 있음** → 그 IG의 **디자인·카피·시각 자산을 참고해서 기획**하여 카페·블로그 임시저장 (IG 큐가 별도 비동기로 진행되더라도 디자인·콘텐츠 일관성 의무)
- **IG(가공) 큐 없음** → 카페·블로그는 **단독 텍스트 기획·임시저장** (강제 슬라이드 합성 불필요)

핵심: IG 슬라이드는 **디자인 SSOT 역할**. IG가 진행되는 주제는 카페·블로그 콘텐츠도 동일 디자인 결을 따라야 한다. 별개 콘텐츠로 분리되어 톤·디자인 일관성을 잃으면 위반.

세부 슬라이드 합성 규칙은 [[project_slide_compositor_workflow]] 참조.

## 표준 3채널

| # | 채널 | 동의어 | 도메인 | 게이트 | 파이프라인 |
|---|---|---|---|---|---|
| 1 | 네이버 블로그 | — | 브라우저 자동화 (Playwright) | `NAVER_BLOG_ENABLED` | `naver_upload_pipeline.py` |
| 2 | 네이버 카페 | **동부이촌동 커뮤니티** | 브라우저 자동화 (Playwright) | `NAVER_CAFE_ENABLED` | `naver_upload_pipeline.py` |
| 3 | 인스타그램 `namuk.wellperion` | — | **반자동 즉시 게시 + CEO 검수** (Meta Graph API) | `INSTAGRAM_ENABLED` (R&D 후 활성) | CMO Meta API 호출 (`feedback_ig_auto_publish_with_review`) |

## 폐기·보류 채널
- **페이스북 페이지**: ❌ **영구 삭제** (2026-05-03 GM님 지시 격상 — "보류 아니라 삭제") — `FACEBOOK_ENABLED=OFF` 영구 고정·재합류 트리거 없음
- **당근**: 보류 (별건, 인지 노출만)
- **wellperion 비즈니스 계정 전환**: 보류 (GM님 명시 지시 트리거 필요)

## Why
- 4.29-Meta 토큰 v1.x 단계 페이스북·비즈니스 통합 연동 실패 반복
- "계정이 제한되었습니다" 차단 + 페어 연결 매번 재시도 부담
- IG 단일이라도 자동 업로드 안정 가동 우선

## How to apply
- CMO 작업 SSOT(CMO-001/CMO-005) patch 시 채널 구성 위 3개로 통일
- 페북 관련 SOP·템플릿·자동화 코드 신규 추가 금지
- 기존 페북 운영 항목은 C-Level 자체 전수 정리 (브랜드 용어 정정 절차 동일)
- 채널별 CTA 원칙(`feedback_channel_cta_rules`) 유지 — 페북 항목만 제외 처리
- 페북 합류 트리거: **없음** (영구 삭제). wellperion 비즈니스 계정 전환만 별건 보류
