---
name: project_ig_personal_publish_0730_m5
description: IG 개인발행 0730·3대 함정 통합 — 제작→M5/[승인]→즉시발행(무폴링)·큐레이션필수·headful·URL실측
metadata: 
  node_type: memory
  type: project
  originSessionId: 5841da60-6926-442c-aff6-54482211cb13
---

GM 확정(2026-06-04, 정정본): IG 개인계정(namuk.wellperion) AI 시리즈 파이프라인 =
1. **매일 07:30** — 시모가 로드맵 다음 편 **초안 자동 제작 → M5 검수대기 등록 + 텔레그램 [승인]카드 발송**. (발행 아님)
2. **GM 검토** — 슬라이드는 M5에서 시각 검수.
3. **GM 텔레그램 카드 [✅승인] 탭 → 즉시 발행**. 상주 봇의 pub: 콜백(이벤트 기반)이 발행기 호출 — **review_queue 폴링 없음**(폐기한 IG 폴링 감시기 부활 안 함).

핵심 제약·결정:
- M5 웹 [승인] 버튼만으로는 발행 불가(클라우드→PC 못 띄움). 무폴링 발행 트리거는 **텔레그램 카드 탭이 유일** → 승인은 텔레그램에서. 검토는 M5에서.
- 발행 게이트 유지: GM 탭 없으면 발행 0.
- **예약작업 재구성 = GM 관리자 1회 실행 대기(2026-06-04)**: `register_ig_series_produce_0730.bat` 우클릭→관리자 실행 = ① 구 3개 삭제(`IG-Series-Produce-2100`·`IG-Publish-0730`·`IG-Publish-Watcher`) ② 신 `IG-Series-Produce-0730`(DAILY 07:30 /IT) 등록. schtasks 생성·삭제는 관리자 권한 필수.
- 소진 가드: 로드맵 편 전부 제작되면 생성 중단. 생산 후 로드맵 행 '제작완료' 자동 표시 필요(미구현 시 중복생성).

## IG 개인계정 발행 파이프라인 3대 함정

발행기 = `scripts/instagram_upload_playwright.py`, 디스패처 = `scripts/ig_review_publish_watcher.py --once`(status∈{승인,승인발행대기,approved}만 처리).

1. **큐레이션_추천.md 필수 입력.** `parse_curation_md`가 폴더 안 `큐레이션_추천.md`를 읽음(`## post A` → `### 캡션`/`### 해시태그`/`### Collaborator`/`### 종목`). 파일 없으면 FileNotFoundError 즉사. 캡션엔 해시태그 빼고 본문만(merged_caption이 합성).

2. **headful 브라우저 = 인터랙티브 데스크톱 세션 필수.** 발행기는 headless=False. 백그라운드 상주 봇(텔레그램 pub: 콜백)이 subprocess로 띄우면 데스크톱 없어 즉사(스샷 0개). CLI 인터랙티브 세션에서만 발행 성공.

3. **게시 URL 자동회수 false-negative.** 공유하기 후 "게시 완료 토스트"는 떠도 신규 shortcode 그리드 스크랩 실패 시 status='확인필요'(실제론 게시됨, 재시도 안 함=중복발행 가드). 확정은 `scripts/instagram_grid_recheck.py`로 그리드 최상단 표지 텍스트 실측.

세션 쿠키는 `profiles/instagram/namuk.wellperion/`에 영속, 만료 길음(2027까지). 재로그인은 `--mode setup-auto`.
