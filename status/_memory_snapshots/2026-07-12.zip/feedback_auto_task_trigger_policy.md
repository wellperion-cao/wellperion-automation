---
name: v2
description: "정기 C-Level 루틴은 추가 승인 없이 자동 실행. 트리거=Windows Task Scheduler 등록 작업, 사전알림=pre_task_notifier(status/schedule.json SSOT). 노션 업무자동화DB·auto_task_watcher는 2026-06-01 폐지."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 53b64db4-aecb-45f0-8341-87c1406eeb0d
---

정기 C-Level 루틴은 **추가 승인·지시 없이 자동 실행**된다(GM·CEO 재결재 불요). 단, 실행 메커니즘이 2026-06-01 노션 폐기로 전면 교체됐다.

**현행 구조 (2026-06-01~):**
- 실행 트리거 = **Windows Task Scheduler 등록 작업** (예: `Wellperion-CEO-Morning-Brief-0800-Live`, `Wellperion-Education-Archive-Weekly` 등). 노션 폴링 아님.
- 실행시간 SSOT = 레포 `status/schedule.json` (스키마: sid·name·exec_time·clevel). 노션 의존 0.
- H-15분 사전 알림 = `telegram_bot/pre_task_notifier.py` (5분 주기, schedule.json 읽음). @namuki_report_bot 발송.

**폐지된 것 (호출·복원 금지):**
- 노션 `업무자동화DB`(`aac275a4-…`) → 2026-06-01 `[폐기]` 표기. 라이브 reader 0건.
- `auto_task_watcher.py`(노션 상태=진행중+실행시간 폴링→Claude CLI 자동기동) → 2026-06-01 GM 결재로 공식 폐지. 소스 소실(git 미추적), daily_scheduler import 블록도 제거.
- 따라서 "노션 레코드 상태를 진행중으로 바꾸면 자동 실행"이라는 구(舊) 트리거는 더 이상 작동하지 않는다.

**How to apply:**
- 새 정기 루틴을 자동 실행시키려면 ① `status/schedule.json`에 등록(알림용) + ② 실제 실행은 Windows Task Scheduler 작업으로 등록(관리자 권한 필요 → GM 1회 실행건일 수 있음). schedule.json에만 있고 Task Scheduler 미등록이면 **사전 알림만 가고 자동 실행은 안 됨** — 루틴별 매핑 검증 의무.
- 자동화 가동 검증 = Task Scheduler State=Ready + LastTaskResult=0 실측(`Get-ScheduledTaskInfo`). 스크립트는 `python -m py_compile`로 사전 문법 검증.
- 상태 보류↔진행중 자율 patch 금지는 [[feedback_no_auto_restore_from_planned]] 유지. SSOT 단일화 원칙은 [[feedback_dual_ssot_only]].
