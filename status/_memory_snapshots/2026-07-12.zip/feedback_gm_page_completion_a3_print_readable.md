---
name: feedback_gm_page_completion_a3_print_readable
description: "GM 조망 페이지 '완성 95%' 기준 = A3 인쇄 시 직관 가독성. 헌법=역할 카드 그리드 주인공"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ac72b438-1642-4dbf-ace0-7a583b563e64
---

GM이 가이드 페이지 "최종본 95%"를 말할 때의 **완성 기준 = A3 한 장에 인쇄했을 때 직관적으로 눈에 잘 읽히는가.** 화면 배선이 라이브여도 A3 인쇄가 과밀·중복·군더더기면 미완으로 본다.

**Why:** GM은 페이지를 실제 A3로 뽑아 본다(Ctrl+P → A3). 스캔성이 판정 기준.

**How to apply:**
- 완성 작업 = 4렌즈(디자인·정직 프레이밍·내용 채움·군더더기 제거) + @media print A3 최적화(break-inside:avoid·잘림 방지·위계 크게).
- 전사 운영 헌법(헌법한장.html): GM 확정 A3 주인공 = **8역할 카드 그리드**(요약 중심). 각 카드=아이콘·이름·북극성 한줄·정직 상태 배지(✅측정개통/🔖제안본/🔧측정개통전)+상단 집계 범례. 3칸 매트릭스는 화면 상세용·인쇄 2페이지. 2026-07-04 라이브(커밋 e0637de8).
- 정직 원칙: 미측정 KPI를 %로 억지 금지, 배지로 정직 표기(약속 L05). 실측 개통은 coo 점검·cto 인프라 2/7뿐.
- 검증=로컬 헤드리스 렌더(python playwright) 콘솔0+무회귀 확인 후 1회 배포. [[feedback_gm_verify_via_incognito_chrome]] [[feedback_page_layout_left_full_width]] [[feedback_wysiwyg_print_unit_parity]]
- 자율현황.html: 북극성 추천 top3는 페이지 미표시 — 웰리 06:30 추천은 **GM 텔레그램 승인라인 전용**(2026-07-04 GM). [[project_daily_northstar_recommender]]
