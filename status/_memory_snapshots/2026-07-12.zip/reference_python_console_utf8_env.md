---
name: reference_python_console_utf8_env
description: Windows 파이썬 콘솔 한글 깨짐 영구해결 — PYTHONIOENCODING=utf-8 사용자 환경변수
metadata: 
  node_type: memory
  type: reference
  originSessionId: 4a73ca95-87e1-4d1a-b638-1ba07330562e
---

Windows 콘솔 기본 코드페이지=CP949라 파이썬이 `—`(em대시) 등 일부 문자를 출력할 때 `UnicodeEncodeError: 'cp949'`로 멈춤(데이터는 UTF-8 정상, **출력 통로만** 막힘). 2026-06-19 GM 지시로 근본 해결: `setx PYTHONIOENCODING utf-8`로 사용자 환경변수 영구 박음(레지스트리 확인 완료). 새 세션/재부팅부터 모든 파이썬 출력 자동 정상 → 명령마다 `PYTHONIOENCODING=utf-8` 접두 불필요.

만약 다시 한글 출력이 깨지면 이 환경변수가 사라졌는지부터 확인(`[Environment]::GetEnvironmentVariable("PYTHONIOENCODING","User")`). 파일 쓰기 계열 한글 깨짐은 별개 — [[reference_appsscript_korean_write]] / [[reference_windows_batch_ascii_only]] 참조.
