---
name: project_self_hosted_inquiry_db_goal
description: "향후 목표 — 구글시트 의존 탈피, 자체 문의 DB 구축 + CPO 회원관리 권한메뉴에서 체험·예약 직접 기록"
metadata: 
  node_type: memory
  type: project
  originSessionId: cd89c981-4d1e-4a92-a07d-86bc499b75d9
---

GM 향후 목표(2026-06-16): 문의·예약 데이터를 **구글시트(26년 신규문의 등) 의존에서 벗어나 자체 문의 DB로 구축·셋팅**한다.

**현재(v1):** 멤버십 체험·상담·투어 예약은 26년 신규문의 시트(12AWcAlg gid 1902010032)에 기록 → ERP가 읽음. 체험·예약 달력은 **CPO(회원·CS, 시포) 권한 메뉴 = AI CPO 회원관리**에 둔다(공개 대시보드 아님 — 이름·전화 PII 때문). 입력은 당분간 리셉션이 시트에.

**최종 목표:** ERP-AI CPO 회원관리 메뉴에서 체험·예약을 **직접 입력→자동 기록**(시트 우회). 더 나아가 문의 전체를 **자체 DB**로 셋팅(구글폼/시트 분산 → 단일 자체 저장소).

**Why:** 시트 분산·PII 노출·수기 의존이 한계. 자체 DB면 권한·정합·자동화 일원화.
**How to apply:** 체험·예약 달력은 CPO 권한메뉴에 구현. 마케팅 대시보드(공개)엔 집계만, PII는 권한메뉴에만. 관련 [[project_member_db_sheet]] · [[project_conversion_funnel_leak_diagnosis]] · 설계=cmo/funnel/회원_체험예약_달력_설계.md.
