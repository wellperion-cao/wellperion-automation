---
name: reference_two_check_pages_mapping
description: 점검 페이지 2종 구분 — 지원부 체계(점검 남/여) vs 시설부 체계(시설점검 fcheck). 작업 전 어느 페이지인지 확정
metadata: 
  node_type: memory
  type: reference
  originSessionId: 1ee3fbb7-111e-48ac-8810-b11970a6664d
---

점검 관련 페이지가 둘이라 헷갈리기 쉽다. GM이 "시설점검"이라 하면 **시설부 체계**다(지원부 아님). 한 번 잘못 짚어 엉뚱한 페이지를 고친 적 있음 — 작업 전 반드시 어느 페이지인지 확정할 것.

| 페이지 | 탭/내용 | 시각·타이머 방식 |
|---|---|---|
| `coo/check/지원부 체계.html` | 점검(남)/점검(여) — 회차(조: am1/pm1/close1) 항목 체크 | 06-20 B안: **첫 항목 체크=시작 자동 캡처**(수동 시작버튼 의존 제거). `STATE`+`led.timers`+서버 `_roundDurationMin` |
| `coo/check/시설부 체계.html` | **시설점검(fcheck)** 탭 — 날짜별 측정 작업일지(온도·수질·설비) | `fcStore` blob. `roundTimes`=저장순간 시각 자동(06-23 B안) + `roundDur`=자동 소요분(06-24). 회차=권장시간대 라벨(오픈/오전/오전2…) |

공통: 둘 다 "수동 시작/종료 버튼 없이 자동" 설계가 GM 선택(2026-06-24). 시설점검은 프론트 fcStore blob 영속이라 GAS 무변경. 관련 [[project_support_check_single_source_page]] · [[reference_facility_check_live_gas]].
