---
name: project_dept_a3_guideline_print
description: "4부서 체계 A3 운영 가이드라인 인쇄 = 핵심 1장 압축본 방식(A3_GUIDELINE 상수), 상세는 카드 보존"
metadata: 
  node_type: memory
  type: project
  originSessionId: b08134eb-3a71-4280-b75b-18f11a8a3c5c
---

4부서 체계 페이지(운영부·시설부·지원부·주차관리부 `coo/check/*체계.html`)의 '운영 가이드라인 A3 인쇄' 결정·구조 (2026-06-23 GM deep-interview→team 실행, 시우03/시우64 연계).

- **A3 인쇄 = '핵심 1장 압축본'** — A3 세로·좌우 2단(좌=규정 핵심 / 우=가이드 핵심). 규정+가이드 탭만 대상(점검·매뉴얼·접수·약품·비품 제외).
- **구조**: 편집 가능한 상수 `A3_GUIDELINE = { title, policy:[{h,lines[]}], guide:[{h,lines[]}] }` + 공용 `renderA3Section(items)` → `.a3-card/.a3-card-title/.a3-card-line`. `printA3Guideline()`이 이 상수를 렌더(카드 전체 덤프 아님). 밀도 표준: 제목11px/본문9.5px/lh1.3/column-gap6mm. @page는 JS 동적 `<style id=a3-page-style>` 주입(A3 portrait) — CSS 내 `body.a3-print-mode @page` 중첩은 무효 데드코드라 쓰지 말 것.
- **GM 결정**: A3는 핵심만 1장(전체 덤프하면 부서별 4~5장 됨), **상세 원본 규정·가이드 카드는 화면에 그대로 보존**. 압축본 내용은 시우가 기존 실제 내용에서 발췌(지어내기 금지 L05).
- **가이드 탭 카드화(2026-06-23)**: 원래 가이드 탭은 4부서 모두 고정HTML(편집불가)이었음 → 규정과 동일한 카드 시스템(`*_GUIDE_BOARD` localStorage + GAS saveBoard, DOM접두사 `gd`/`sg` 등, requireEditAuth 1234)으로 전환. 기존 내용은 SEED 카드로 무손실 이관. 운영/시설/지원부 완료.
- **주차관리부 전체 카드화(2026-06-23)**: 더 이상 고정HTML 아님 — 규정·가이드·매뉴얼 3보드(`PARK_POLICY_BOARD`/`PARK_GUIDE_BOARD`/`PARK_MANUAL_BOARD`, 매뉴얼=구역별 카드) 카드 편집형. 내용 확정: 주차장 운영시간=웰페리온 운영시간([[project_operating_hours]]), 근무조=오전조(평일08:30~17:30·주말09:00~16:00)+오후조(평일10:00~19:00·주말09:00~16:00)·야간조 없음. **발렛 시스템=직영 운영체계 확정(2026-06-23 GM 결정)**: ⓐ유료 5,000원(회원 포함 전원) ⓑ직영(외주X, 시우 셋업 주관) ⓒ차량 배상 보험 가입 완료 ⓓ운영체계 셋업 후 발렛 전담 채용→정식 운영. 규정 6카드(개요·운영방식·대상시간·요금정산·키관리·책임배상)+가이드 응대+매뉴얼 입출차 절차(5천원 정산)+A3 정합. '초안/기획중' 표기 전부 제거. 주차관리인이 주차장 청결관리도 담당. 정기회의=주간만(월간 폐지). 오전조=양상규 고문. ★잔여: 오후조 담당 충원 / 발렛 물리 셋업(정산수단·키보관함·발렛데스크·채용)은 운영 도입 단계. (주의: 운영시간 값을 주차 카드에 직접 기재 → incident-guard 캐논복사 경고. 추후 [[project_operating_hours]] 단일출처 연동 여지.)
- **매뉴얼 A3(2026-06-23 추가)**: 별도 '🖨️ A3 매뉴얼(주간)' 버튼 → `printA3Manual()` → A3 **가로(landscape)** 1장. 운영/시설/지원부=요일(월~일)×분류 주간표(`*_MANUAL_BOARD` 보드), 주차관리부=구역별 절차(고정 내용 적응). 네임스페이스 `a3m-`(`#a3-manual-print`·`body.a3-manual-mode`·`a3-manual-page-style`)로 가이드라인 A3(`a3-`)와 완전 분리. ★주의: `printA3Manual()`은 window.print() 후 스스로 클래스·@page를 원복함 → Playwright 검증 시 함수를 끝까지 돌리면 A4로 잡힘. window.print를 throw로 막아 원복 전 상태에서 pdf 떠야 정확.
- 인쇄 실검증 = Playwright(file://→`printA3Guideline()`→emulate print→`page.pdf(prefer_css_page_size)`→fitz 페이지수)로 1장 확인. 관련: [[feedback_wysiwyg_print_unit_parity]] [[feedback_coo_owns_ops_4dept_interior]] [[reference_guidehub_concurrent_commit_corruption]]
