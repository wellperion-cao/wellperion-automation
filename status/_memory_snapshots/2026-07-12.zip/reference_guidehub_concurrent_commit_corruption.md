---
name: reference_guidehub_concurrent_commit_corruption
description: 메인 가이드허브 파일 손상(사이드메뉴 먹통) = 동시 커밋 race + changelog 훅. 진단·복구·예방
metadata: 
  node_type: memory
  type: reference
  originSessionId: 5841da60-6926-442c-aff6-54482211cb13
---

메인 가이드 `3. 웰페리온 가이드/wellperion_guide(main).html`는 changelog 훅이 **매 커밋마다 home 카드를 재작성·재스테이징**한다. 여러 백그라운드 에이전트가 같은 레포에 **동시 커밋**하면 쓰기 race로 파일이 **truncate**됨(끝부분 잘림 → 마지막 사이드메뉴 nav `<script>` 미닫힘 → nav JS 사망 = "사이드메뉴 선택 자체가 안 됨". 페이지는 HTTP 200이라 안 죽은 듯 보임).

**진단:** `<script>`/`</script>` 개수 불균형(예 5/4)이면 손상 + 파일이 `</html>`로 안 끝나고 JS 문장 중간에서 잘림.

**복구:** 최근 커밋별로 `git show <c>:파일`의 끝·스크립트 균형 스캔 → 마지막 정상본(균형 5/5·`</html>` 종료) 찾아 `git checkout <good> -- "<파일>"` 복원 → 커밋(훅이 재손상시킬 수 있으니 **push 전 HEAD 재검증**) → push → 원격 재검증. 잘린 건 자동생성 home 카드뿐이라 실제 내용 손실 0(다음 커밋에 재생성).

**예방:** 같은 레포에 **커밋하는 백그라운드 에이전트 동시 실행 금지(직렬화)** — 하나 끝나고 다음. 동시 watcher 리셋 대응 → [[feedback_git_commit_atomic_vs_watcher_reset]]. 2026-06-04 발생·복구(정상본 복원).
