---
name: project_daily_northstar_recommender
description: "일일 북극성 추천기 v1 — 자율화 첫 실전 배. 브릿지=과정, 최상급 4박자, 제안까지+기존게이트, 웰리로직/시토엔진"
metadata: 
  node_type: memory
  type: project
  originSessionId: bf777cf9-c815-44c7-90db-2c229f28f6da
---

「일일 북극성 추천기」 = AI 자율화 북극성의 **첫 실전 배**(2026-06-29 GM GO·deep-interview 확정). 매일 06:30 텔레그램으로 각 C-Level 북극성 대비 '오늘의 다음 한 수' 3후보 제안→GM [승인1/2/3]·[보류]→승인건 _queue 배 등록→기존 실행 파이프라인.

**GM 정의 '브릿지' = 화면이 아니라 과정** — 북극성=목표 / 브릿지=목표로 나아가는 과정(KPI·파이프라인) / 핵심=좋은 과정이 최상위 결과를 낳는다.

**'최상급 과정' 4박자(전부 필수):** ①경로지도(지금 어디→다음 한 수) ②품질완주(대충완료 차단 — ※추천기는 제안까지, 승인 후 기존 완료4요건·웰리검수 게이트가 보증·새 실행권 없음) ③지표환류(KPI·파이프라인 진척 추적·매 사이클 개선) ④근거투명(왜 이게 북극성에 최선인지 명시).

**경계:** 자율=제안까지만(실행=GM 승인·5종 게이트). 측정 정직(과장 금지·정성 허용). **대상=처음부터 전 C-Level(7역할 ceo·cmo·coo·cto·cpo·cfo·chro, gm제외) — 웰리가 전사 top3 선정·역할 태그**(G3 변경 2026-06-29, 웰리 단독 파일럿 폐기). 개인 북극성 v1 제외. **두뇌=웰리(추천 로직)/손=시토(엔진)**. 입력 정본=헌법 한 장(bootsetup_matrix.json 북극성·KPI·소유 owns·확장아이디어 ideas) — 이 매트릭스가 추천기의 토대(그래서 정비함).

**GM 잠금 결정(2026-06-29):** G1=상태파일 `status/northstar_pending.json`(git 추적). G2=미승인 추천은 다음날 06:30 새 추천 생성 시 자동 보류(만료)·당일 자정 만료 아님. G3=전 C-Level(위 경계 참조).

**1단계 빌드 완료(2026-06-29):** `scripts/northstar_recommender.py` 드라이런 엔진 — 입력 수집(bootsetup_matrix 7 C-Level행 + _queue active/next + kpi_values) → 두뇌(claude CLI·model_router 폴백, 실패시 규칙기반 폴백) → 전사 top3 후보(역할 태그·경로지도·근거·난이도 배) → `status/northstar_pending.json` 기록. **라이브 부작용 0**(텔레그램 전송·스케줄러 등록 없음). 2단계(06:30 Task Scheduler·텔레그램 카드·봇 승인콜백→_queue 등록·폐루프)=GM 1단계 확인 후.

정본: `.omc/specs/deep-interview-daily-northstar-recommender.md` · 배=_queue CTO-2026-06-29-NORTHSTAR-RECOMMENDER(ship 213) · 설계서=status/briefs/CTO-2026-06-29-NORTHSTAR-RECOMMENDER-DESIGN.md. [[project_autonomy_next_after_automation]] [[project_ai_self_learning_pipeline]]
