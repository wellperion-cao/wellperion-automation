---
name: feedback_wysiwyg_print_unit_parity
description: 미리보기≠인쇄/PDF 불일치의 근본은 표면마다 글씨 크기 단위가 다른 것 — 같은 공식으로 통일해야 WYSIWYG
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 029ac1fc-343f-44e9-a8fc-23f8d6533501
---

공지 서식 등 "미리보기 + 인쇄/PDF/PNG 출력" 도구에서 글씨 크기가 화면과 출력이 다르게 나오면, 거의 항상 **렌더 표면마다 폰트 크기를 다른 단위·기준으로 산출**하는 게 원인이다.

**실제 사례(공지서식 notice_template.html, 2026-06-04):**
- 미리보기 본문 기본크기 = CSS `clamp(px)` 고정
- 인쇄 빌더 본문 기본크기 = `px입력칸 값 × 0.17 vmin`
- → px입력칸을 한 줄만 키우려 건드려도 인쇄 본문 **전체**가 폭발(34→76px), 미리보기는 불변 → "전혀 다르게" 보임

**Why:** px(화면 절대) vs vmin(종이 비례)은 서로 다른 기준이라 절대 일치 불가. 또한 "선택 줄 전용" 컨트롤(px입력칸) 값이 본문 base 산출에 새어들어가면 의도치 않게 전체 스케일이 바뀐다.

**How to apply:**
1. 미리보기와 출력 빌더가 **동일 공식**으로 base를 산출하게 통일 (예: 둘 다 `18 × 0.17 × 페이지최소변`. 미리보기는 프레임 px, 인쇄는 vmin — 같은 비율).
2. 줄별 크기 조정은 **px 절대값이 아니라 base 대비 `em` 상대값**으로 (px면 vmin base에서 역전됨 — 크게가 인쇄에서 작아짐).
3. "선택 줄 전용" 컨트롤 값은 본문 base 계산에 절대 사용 금지.
4. 검증은 코드 신뢰 말고 Playwright로 px입력칸 조작 후 미리보기 base 불변 + 출력 PNG 캡처 시각 일치까지 실측.

관련: [[feedback_input_no_rerender_ime]] (입력 표면 안정), [[feedback_welly_publish_verify_artifacts]] (실측 검수 의무).
