---
name: feedback_minimize_gm_participation_batch_auth
description: GM은 계속 붙어있을 필요 없어야. 되돌릴 일은 안 여쭙고 바로·인증게이트 배포는 모아서 다음 인증창에 자동완결
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 663e250e-1772-41e9-9f5d-04ab45f5ba80
---

GM "내가 계속 참여해야해?"(2026-07-04) = 참여 요구가 과하다는 신호. 되돌릴 수 있는 일에 선택 카드(AskUserQuestion)로 착수 여부·방향을 묻는 건 [[feedback_autonomy_standing_mandate]] 위반. 그냥 진행하고 결과만 보고.

**GM이 진짜 필요한 지점은 셋뿐:** ①금지5종 결재(결제·보안·금지·전략·공식값) ②대화형 재인증(`clasp login` 등 브라우저 OAuth — 헤드리스 불가) ③물리·오프라인.

**How to apply:**
- 되돌릴 수 있는 작업 = 착수·방향 안 물어보고 바로 실행, 결과만 L18 보고.
- 인증게이트(clasp invalid_rapt 등)로 라이브 배포가 막히면 → GM께 지금 로그인 강요하지 말 것. 코드는 커밋해 안전히 두고, **다음에 clasp 인증이 열리는 아무 때나(다른 펀넬 작업 시) 모아서 자동 배포·스모크·완결**. "지금 아무것도 안 하셔도 됩니다"가 기본.
- 급할 때만 GM에게 원클릭 재인증 옵션 제시(강요 아님).

관련: [[feedback_offer_numbered_options]](카드는 GM이 먼저 결정 요청할 때만) · [[feedback_exhaust_automation_before_asking_gm]] · [[project_cpo_inquiry_system_unification]](배417 렌트·비즈 패널이 이 교훈 촉발).
