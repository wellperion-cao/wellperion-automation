---
name: project_approval_final_approver_per_ssot
description: 최종 결재권자 = 운영현황·결재현황 모두 GM 종착(2026-06-16~). 대표 단계는 시스템 제외·페이퍼
metadata: 
  node_type: memory
  type: project
  originSessionId: a1350697-833f-408f-9c47-e41a2da99da0
---

**GM 변경(2026-06-16): 결재현황도 GM 종착으로 통일.** 이전엔 두 SSOT가 분기였으나(운영현황=GM / 결재현황=대표), GM 지시로 **전응준 대표 결재 단계를 시스템에서 완전 제거**하고 GM을 양쪽 최종 결재권자로 일원화. 대표 보고·승인은 시스템 밖 **오프라인 페이퍼**로 처리. 약속 [[L09]]/ssot 약속.json 동시 갱신.

- **업무 현황 SSOT(운영현황)** = 최종 결재권자 **김남욱GM**. route = `부서장?→GM` GM 종착(불변).
- **결재 현황 SSOT** = **GM 종착**(2026-06-16~). route = `부서장?→GM`. 대표님 단계 제거 — 커밋 393f300c(`결재 현황 SSOT.html` `buildEffectiveRoute` + `.deploy-todo/업무&결재 현황.js` `_buildApprovalRoute`·`_nextApprover`·PIN map·G1미러에서 '대표님' 전부 제거). '대표싸인' 시트 컬럼은 데이터 호환 위해 보존(로직 미참조). ⚠️라이브 반영=clasp push + webapp 새버전 배포 GM 게이트.

부서장 단계는 [[project_ai_clevel_to_practitioner_mapping]] 기준 owner 우선(담당자의 부서장이 1단계, 본인이라도 승인부터 — 카테고리 짐작 배정 금지). GM 직속(담당자=GM) 업무는 부서장 생략·GM 단독.

**Why:** GM이 결재 종착을 본인으로 단일화하고 대표 결재를 오프라인 종이로 분리하기로 결정. 두 SSOT route가 이제 동일(`부서장?→GM`)하지만, 그래도 SSOT별 코드는 각자 유지(한 모델로 강제 병합 금지 — 표시·필터·인쇄 등 뷰 차이 존재).
**How to apply:** 결재선 로직에 '대표님' 단계 다시 넣지 말 것. 대표 escalation이 필요한 사안은 시스템이 아니라 페이퍼로 안내. 회장(차의주)·이사(주영희)도 결재 라인 대상 아님([[project_executive_decision_authority]]).

**정책 명문 출처(2026-06-06):** 결재선·부서장 매핑·종착 분기 = **S2 AI COO 탭 '결재 요청·승인 체계' 표**가 단일 원본. S3(업무·결재 현황) 페이지엔 중복 기재 금지 — S3는 실시간 대시보드+두 SSOT 링크만(개요·보고체계 콜아웃은 GM 결정으로 제거). 관련 [[feedback_ssot_page_report_vs_ceo_brief]].
