---
name: project_member_db_sheet
description: "회원부 회원 DB = 구글시트 \"1-1) 멤버십 문의 관리(26년도)\" 유효회원 탭, 전화번호 키=휴대폰 번호"
metadata: 
  node_type: memory
  type: project
  originSessionId: c06aac3f-ecc6-413f-8616-9d748f9e52cd
---

웰페리온 회원부(회원 DB) SSOT = 구글 스프레드시트 **"1-1) 멤버십 문의 관리(26년도)"**.
- ID: `12AWcAlgmmYKr2nUbWmVpa71_z3zi0BaU4ZdnOwrI_7U`
- 회원 탭: `유효회원` (약 79명)
- 전화번호(매칭 키) 컬럼: **`휴대폰 번호`**
- 등록일 컬럼: `등록 일자` (문의→가입 전환 소요기간 계산용)
- 컬럼 30개(회원명·휴대폰 번호·회원 구분·종목·등록분류·등록 일자·시작/종료일·락커·종목별 담당자/Contact 등)

용도: 시모-02 마케팅 대시보드 "문의→가입 전환" 매칭. apps_script_survey.js의 `funnel_conversion` 액션이 문의접수 시트 `연락처`를 정규화해 이 시트 `휴대폰 번호`와 대조, 유입채널별 전환율 집계(집계수치만 노출·개인정보 비노출).

라이브 조건: GM Apps Script '동일 배포→새 버전' 재배포 + 실행계정(cao@wellperion.com)이 이 시트 뷰어 이상 권한 OAuth 승인. 개인정보이므로 헤더·집계만 다루고 전체 명단 덤프 금지.
