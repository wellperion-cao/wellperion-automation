---
name: slide-engine-canva-independence
description: 슬라이드 디자인 SSOT = 코드 단일 엔진(compose_barre 함수). 캔바 의존 폐기 방향(2026-06-05 GM).
metadata: 
  node_type: memory
  type: project
  originSessionId: 30f9a123-d094-47b6-b3c8-34d95f096505
---

GM 결정(2026-06-05): **슬라이드 디자인을 캔바에 의존하지 말고 코드 단일 엔진을 SSOT로.**

## 왜 (근본원인)
- 바레 정본(`260520_바레_런칭/output(인스타그램)/ig_02~05`)은 **캔바 제작본**(코드 헤더 "Canva 완성본 픽셀 실측 기반"). 발행 후 한 번 더 교체됨(커밋 7e1883f).
- 코드(compose_barre/ballet)는 캔바를 **눈대중 모방** → 칩 크기(코드 240 vs 정본 180)·분리선 유무·글자 미세 불일치 영구 발생. GM "왜 바레 복사를 못하냐"의 진짜 원인.
- M5(cmo-publish)에는 디자인 표준이 **없음**(검수·업로드 단계일 뿐, cmo/review=preview+큐). 그래서 디자인 SSOT가 어디에도 없던 게 문제.

## 해결 (단일 엔진)
- `scripts/compose_barre.py` = 스타일 함수 SSOT(draw_chip·draw_counter·paste_logo·apply_bottom_gradient·to_duotone·load_font·center_crop_fill·compose_guide_card·상수 BEIGE/BLACK_BG/W/H 등).
- `scripts/compose_ballet.py` = compose_barre를 **import**해서 그 함수 그대로 호출. 발레 고유는 사진경로·텍스트·top_crop_fill(표지 인물보정)·full_dark 분기뿐. **스타일 독자정의 금지 = 추측 0**.
- 앞으로 모든 콘텐츠 슬라이드 스크립트는 compose_barre 함수를 import → 전 콘텐츠 디자인 100% 일관(형평성).

## 발레 현황(2026-06-05)
- GM 새 사진 6장(`output(인스타그램)/_src_gm/ig_01~06`)으로 7장 생성(표지+본문5+가이드).
- **카운트 제거**(GM 지시), 분리선 없음(바레 함수 동일), CTA 1줄 "문의 wellperion.com/ko/inquiry"(GM 지시).
- 표지(ig_01): 발레복 전신 → top_crop_fill x_bias 0.6·zoom 1.28로 인물 중앙·확대.
- 커밋 12abd8e. build_slides.py(구 scrim 엔진)는 폐기 방향(compose_ballet이 정본).

## 미해결/다음
- 게시된 바레(캔바본)와 코드본은 미세차이 존재 — 바레를 코드본으로 재정렬할지는 GM 미결.
- 발레 내용 승인 → 블로그·카페 등 채널 임시저장([[project_4channel_dispatcher]]).
- 캔바 MCP 검색('바레/발레/wellperion') 빈 결과 = 현 연결계정에 원본 없음.

## 브랜드 프리셋·해상도 (구 slide_compositor.py 유산, 참조용)
- 해상도: 인스타 1080×1350 / 카페 1080×1080 / 블로그 1200×900
- 폰트 SSOT: `brand/font/Pretendard-{Bold,SemiBold,Medium}.otf`
- 브랜드 가이드: `brand/241030_웰페리온 브랜드 가이드(최종).pdf`
- 프리셋 선택 기준: 주니어·스포츠·대회=sports_club(Blue&Navy) / 종목별=squash·pt·golf·swimming·pilates·gymnastic / 전사=main(Beige&Black)
- EXIF 회전 보정 필수: `ImageOps.exif_transpose`

연계: [[project_main_slide_template]] · [[project_cmo_designer_and_image_originals]] · [[project_ballet_design_canonical]]
