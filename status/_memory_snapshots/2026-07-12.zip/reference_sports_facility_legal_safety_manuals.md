---
name: reference_sports_facility_legal_safety_manuals
description: 체육시설 안전점검·응급대응 법정 공식 매뉴얼 실검증 링크(시설부 페이지 연결용)
metadata: 
  node_type: memory
  type: reference
  originSessionId: e104ce56-2d78-47aa-92cf-94f2b9116ce5
---

체육시설(스포츠클럽) 안전점검·사고응급 **법정 공식 근거** — 2026-07-07 웹 실접속 검증(지어낸 링크 아님). 시설부 체계.html 매뉴얼 탭 「🚨 사고·응급상황 & 법정 안전 근거」 섹션에 연결됨.

- **체육시설 안전관리 표준매뉴얼(문체부·2024)**: mcst.go.kr/kor/s_policy/dept/deptView.jsp?pSeq=1925&pDataCD=0417000000 — 정부 공식 최신 표준(PDF 33MB)
- **체육시설법 시행규칙 별표6 안전·위생기준**: law.go.kr/LSW/lsInfoP.do?urlMode=lsInfoP&lsId=008468 — 수영장 안전요원·수질(유리잔류염소0.4~1.0)·응급장비 법정 기준. 해설=easylaw csmSeq=1453
- **응급의료법 §47조의2 AED 의무**: m.easylaw.go.kr csmSeq=906 — 설치·월1회 점검·과태료300만. ⚠️의무설치 대상(전문체육시설·종합운동장 등)에 민간종합체육시설 포함 여부는 규모·분류 따라 불확실 — 정직 표기 필수
- **기본응급처치·CPR·AED(E-GEN)**: e-gen.or.kr/egen/first_aid_basics.do — 중앙응급의료센터 표준 절차
- **체육시설 안전점검 지침(문체부 고시)**: mcst.go.kr/site/s_data/ordinance/instruction/instructionView.jsp?pSeq=2744

함정: law.go.kr 본문=JS 렌더라 WebFetch 시 골격만 보임(브라우저는 정상). 사우나=공중위생관리법 소관(체육시설법 아님). 국민체육진흥공단 등급판정매뉴얼=내부배포·공개URL 불확실.
