---
name: reference_gm_personal_tracking_sheet
description: GM이 직접 정리하는 개인 추적 시트 — 웰리도 참고할 것. MCP 자동열람은 차단
metadata: 
  node_type: memory
  type: reference
  originSessionId: 80eced37-a236-4f9f-8efe-cedfd8eadd11
---

GM이 요즘 헷갈려서 따로 정리해두는 개인 추적/정리 구글시트(2026-06-19 공유, 웰리도 참고하라 지시).

- URL: https://docs.google.com/spreadsheets/d/1gCQNny8TDls5SjrtMkINu4HCltvFkoXmkTeXO_c3q58/edit?gid=1702494225
- fileId: `1gCQNny8TDls5SjrtMkINu4HCltvFkoXmkTeXO_c3q58` · gid 1702494225

**★ 읽는 법 (해결됨 2026-06-19):** GM이 '웹에 게시→CSV'로 발급한 **공개 CSV 링크**로 읽는다(MCP는 차단됨 — 아래 참고). 파이썬 urllib로 바로 읽힘:
`https://docs.google.com/spreadsheets/d/e/2PACX-1vQ98GImmOf_J7gcKzIgtMmpH6-hH6hPTNhgXRM3Iwl9XkJXI5dk3Jc2P8KTMBE2P756aoOQ3PxaKy0C/pub?gid=1702494225&single=true&output=csv`
시트 구조: A열=엔티티(1김남욱·2웰리·3시토·4시모·5시우·6시포·7시뽀·8시로), 각 엔티티 8행 템플릿(🌟북극성·🔧파이프라인·📚부트셋업SSOT·📊KPI·🛡️재발방지·🔐권한·🚧소유경계·🤝협업). E열=내용.

**MCP 차단(참고):** claude.ai Google Drive MCP `read_file_content`는 "ineligible to be used in generative AI contexts" 오류로 불가 — 뷰어 공유해도 안 풀림(파일/워크스페이스 'AI 접근 차단' 설정, 권한과 별개 토글). 그래서 위 CSV 링크가 정답.

**How to apply:** 작업·할일 관련 GM 의도가 모호할 때 이 시트가 GM의 실제 정리본이므로 참고 대상. 단 자동 못 읽으니, 필요 시 GM께 해당 탭 내용을 요청. G1(_queue) 항로와 이 시트가 어긋나면 GM 의도(시트) 우선 확인. 관련 [[project_g1_sources_no_queue_unification]] [[feedback_log_adhoc_work_to_g1]].
