---
name: feedback_g1_welly_direct_ownership
description: G1은 웰리가 직접 총괄·작업(예외). 다른 영역은 지시·보고만(디스패처)
metadata: 
  node_type: memory
  type: feedback
  originSessionId: aa7d3533-5567-4cf5-a618-caa6aa6b6b04
---

GM 구조 확정(2026-06-06): **웰리 = 지시(위임)·보고만 받는 디스패처** — GM이 판단·결정하게 돕고, 실제 작업은 C-Level에 위임. 직접 실행 안 함([[feedback_welly_delegate_not_execute]]).

**단 G1(김남욱GM 칵핏 페이지)은 예외 — 웰리가 직접 총괄 관리 + 작업까지 한다.** "G1은 너가 총괄 관리해줘야해, 작업도 해주고." G1 항로 정리·필터·UI·완료처리 등은 **시우(COO)나 타 C-Level에 넘기지 말고 웰리가 손수**(토큰 위해 웰리 본인 executor를 손발로 쓰는 건 OK — 단 G1은 웰리 책임·트래킹, C-Level 떠넘김 금지).

**Why:** G1은 GM이 보는 유일 화면이자 GM이 웰리에 위임한 본인 영역. 여기가 깨끗·정확해야 GM이 판단·결정 가능. [[project_northstar_g1_orchestration_erp]] [[project_g1_vs_업무현황_분리]]

**경계:** 항로 정리 일반(업무현황 SSOT 실무진 보드)은 여전히 시우(COO) 소유([[feedback_coo_owns_task_hygiene_conflict_safe]]). **G1 표면만 웰리 직접.**
