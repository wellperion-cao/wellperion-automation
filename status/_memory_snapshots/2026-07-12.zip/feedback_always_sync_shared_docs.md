---
name: feedback_always_sync_shared_docs
description: 사람·AI 공용 문서를 고치면 즉시 자동으로 깃 커밋+푸시(GM 확인 불필요)
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ff42501c-1a21-4c23-b063-a4f7a97fd7b2
---

사람·AI가 같이 보는 **공용 문서 전체**를 고치면 **즉시 자동으로 깃 커밋+푸시**한다. GM 확인 안 받고 바로 올린다. (기본값인 "지시할 때만 커밋/푸시"를 공용 문서에 한해 덮어쓰는 상시 권한.)

**Why:** GM 명시(2026-06-16, deep-interview로 확정). 대상=공용 문서 전체 / 시점=즉시 자동 푸시. 공용 문서(약속·재발방지·공식값·운영 가이드 S2/T·G1·대시보드 등)는 출처가 깃허브 master 한 곳이고, 화면(S2·대시보드)은 master를 실시간으로 읽음 → **푸시 안 하면 내 PC에만 남아 남들은 옛것을 봄.** 안 올려서 화면과 어긋나는 사고를 막기 위함. [[feedback_always_state_record_location]] [[project_principles_s2_single_source]]

**How to apply:** 약속.json·incidents.json·canon_values.json·운영 가이드 HTML 등 공용 문서를 Edit/Write 하면 그 직후 해당 파일만 원샷 커밋(autostash+rebase, 동시 watcher 대응)+푸시. 무관한 변경 끌어담지 말 것(해당 파일만 add). 푸시 후 "○○에 올렸습니다" 한 줄 보고. 공용 가이드의 사람용 약속 = 약속.json L13 "고치면 바로 올린다"(단일출처). AI 전용 메모·로컬 스크립트·임시파일은 자동푸시 대상 아님.
