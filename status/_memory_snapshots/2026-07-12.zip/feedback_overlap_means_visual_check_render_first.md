---
name: feedback_overlap_means_visual_check_render_first
description: "GM이 \"겹친다/안 보인다/막혀있다\" 하면 내용 중복이 아니라 화면 레이아웃 겹침(CSS)일 수 있다 — 라이브 렌더 먼저 보고 판단"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ed1390fd-79c6-4e24-8cd4-0a01ea24fd9e
---

GM이 페이지를 보고 "겹친다 / 안 보인다 / 반칸을 막는다 / 앞장 뒷장" 이라고 하면, **내용(텍스트) 중복이 아니라 화면에서 요소가 물리적으로 포개진 레이아웃 버그(z-index·풀블리드·flex 오버플로)** 일 수 있다.

**Why:** 시설부 직원 가이드 "겹친다"를 내용 중복으로 단정해 R/R 트리밍·카드 병합·1단화까지 4~5차례 헛짚어 GM이 크게 답답해했다. 실제 원인은 CSS 한 줄: 우측 보드에 `.board-fullwidth`(width:100vw; margin-left:calc(50% - 50vw) 풀블리드)가 걸려 2단 flex에서 좌측 카드 위로 튀어나와 덮은 것. 지원부가 "잘 됐던" 이유=애초에 2단이 아니라 세로 적층이라 풀블리드가 아무것도 안 덮음.

**How to apply:** GM의 "겹친다" 류 지적은 **먼저 실제 라이브 렌더를 눈으로 확인**(시크릿 크롬 열기·헤드리스 스크린샷)한 뒤 진단한다. 내용 중복으로 가정하고 편집 시작 금지. 레이아웃 의심 신호=풀블리드(100vw breakout)가 flex 형제 옆에 있음 / position absolute / 음수 margin. 해결=풀블리드 제거하거나 세로 적층으로. 참고 [[reference_dept_board_gas_is_ssot_not_seed]] · [[feedback_gm_verify_via_incognito_chrome]].
