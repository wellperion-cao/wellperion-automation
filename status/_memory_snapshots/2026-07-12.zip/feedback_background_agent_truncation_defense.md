---
name: feedback_background_agent_truncation_defense
description: background executor는 런타임이 tool_use 루프를 중간에 잘라 status=completed로 오라벨할 수 있다 — 종결 센티넬+커밋해시로 탐지·재위임
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 97ac62ee-369b-4aa7-ada7-edd6433c0841
---

`run_in_background:true` executor 에이전트는 **런타임이 tool_use 루프를 중간에 잘라(silent truncation)** `status=completed`로 잘못 표시할 수 있다. 에이전트/프롬프트 잘못이 아니다.

**식별 신호:** 끊긴 transcript의 마지막 assistant 메시지 `stop_reason=tool_use`(end_turn 아님) + 마지막 기록이 성공한 tool_result인데 다음 assistant 턴이 없음. surfaced result가 미완성 narration 문장("…확인합니다", "…수집한다"). 정상 완주 에이전트는 마지막이 `end_turn`+text.

**Why:** 2026-06-05 오늘 2회 재발(시우 빈칸 버그·시토 3단계 — 둘 다 편집/작업 중 커밋 직전 잘림, completed 오라벨). tracer 증거진단으로 확정. 토큰·길이 한계 반증(끊긴 게 오히려 가장 짧은 run, 168k 긴 run은 완주). 정확한 방아쇠(스케줄러 슬라이스/스트림 끊김/harvest race)는 subagent JSONL에 없어 미핀포인트 — 런타임 로그 필요.

**How to apply (방어 4 — 이미 [[feedback_welly_publish_verify_artifacts]] 실측검증 + 완료=증거 4요건 게이트가 백스톱):**
1. **종결 센티넬 의무**: 모든 executor 위임 프롬프트에 "작업 끝에 반드시 `DONE: <commit-hash>` 또는 `BLOCKED: <reason>`로 끝내라" 요구. narration은 이걸 못 만족 → 끊김 결정적 탐지.
2. **완료 불신**: background 완료 통지가 와도 result에 센티넬/커밋해시 없으면 **truncated로 간주, status=completed 신뢰 금지 → 재위임 + 웰리 독립검증(git log)**.
3. **commit-first**: 되돌릴 수 없는 커밋을 가능한 일찍, 재검증은 나중 → 잘림 창 축소.
4. **commit-critical은 foreground 또는 model=opus** 선호(완화책, 인과 확정은 아님). 끊긴 건 전부 background+sonnet 짧은 run이었고 opus background는 완주.

[[feedback_welly_delegate_not_execute]]: 끊겨도 직접 떠안지 말고 재위임이 원칙.
