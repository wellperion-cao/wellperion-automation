---
name: feedback_offer_numbered_options
description: GM에게 선택지 제시=deep-interview식 선택가능 카드(AskUserQuestion) 선호. 못 쓸 때만 번호 텍스트
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 8e6a94c1-0701-48f1-af38-3bbdc0d05c2b
---

GM이 선택을 요구할 때는 **deep-interview식 선택가능 UI**(AskUserQuestion 클릭 카드)로 제시한다. GM이 카드에서 바로 고를 수 있는 형태를 선호(2026-07-02 '이런건 /deep-interview 식으로 선택하게 해주는게 좋겠다').

**상시 규칙 재확인(2026-07-09):** '항상 내가 결정할 수 있게 추천 제안식 or /deep-interview 방식으로 버튼만 클릭할 수 있게 해.' → 설계·spec·방향 등 **모든 결정 요청**은 예외 없이 클릭 카드(AskUserQuestion, 추천안 first) 또는 deep-interview 버튼 흐름으로. 열린 질문·안 선택되는 표로 GM에게 떠넘기지 말 것.

**Why:** 안 선택되는 markdown 표를 주면 GM이 답하기 번거로움('번호를 주던가'). 클릭 선택 카드가 마찰 최소.

**How to apply:** 결정 요청 시 `AskUserQuestion`으로 선택지 카드 제시(추천안엔 label에 '(추천)'). 카드를 못 쓰는 맥락에서만 **번호 텍스트**(0/1/2, 숫자로 답)로 폴백. 안 선택되는 표만 던지지 말 것. GM 보고 본문은 여전히 짧게([[feedback_gm_reports_short_scannable]]).
