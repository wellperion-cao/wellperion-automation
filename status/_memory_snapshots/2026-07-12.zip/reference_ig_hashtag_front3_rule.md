---
name: reference_ig_hashtag_front3_rule
description: IG 해시태그 앞 3개 규칙 — 개인=고정2(#AI자동화 #스포츠클럽자동화)+주제1, 공식=주제3 고인기. 코드박제+기획 리서치
metadata:
  node_type: memory
  type: reference
  originSessionId: 55d6c635-7b89-4ee9-8df5-4da3bce4ad45
---

GM 지시(2026-07-08): 인스타 해시태그 **앞 3개를 인기(고도달) 태그로 셋업** — 기존 앞자리가 도달 약한 태그(스포츠센터·센터운영 등)였음. 개인·공식 둘 다.

**규칙 (계정별):**
- **개인 @namuk.wellperion:** 앞 **2개 고정 = `#AI자동화 #스포츠클럽자동화`**, **3번째는 그 콘텐츠 주제 맞춤** 인기태그(기획 단계 리서치).
- **공식 @wellperion:** 앞 **3개 전부 그 콘텐츠 주제별 상위 인기태그**(고정값 없음). **지역+주제 복합 태그 우선** (GM 2026-07-08 방향: `#한남동스파 #한남동힐링 #한남동피부관리`처럼 한남동+주제). 이유=순수 메가태그는 묻히지만 지역+주제는 경쟁 낮고 **로컬 검색 의도(핫리드)**를 정확히 잡음(로컬 프리미엄 업장 전환 유리). 별도 `#한남동`은 중간에 유지(넓은 지역 도달), 브랜드(#웰페리온)는 꼬리.
- 구조: **[계정 고정 선두] + [주제 맞춤 인기태그(기획)] + … + [브랜드 꼬리 #종합스포츠클럽 #웰페리온 #WELLPERION]**.

**코드 박제 (행동=코드):** `scripts/cta_utm.py` → `HEAD_TAGS_FIXED`(계정→고정선두 리스트) + `apply_head_tags(tags, account)`(중복제거·순서유지). `scripts/instagram_upload_playwright.py` `_publish_single_post`가 `merged_caption` 직전 `spec.hashtags = apply_head_tags(spec.hashtags, account)` 호출 → 개인은 발행 시 항상 앞 2개 고정 박제, 공식은 무변경(기획 태그 유지). 꼬리 브랜드=`_TAIL_TAGS`.

**주제 맞춤 태그 = 기획 단계 리서치:** 콘텐츠 주제에 맞는 고인기 태그를 매 콘텐츠 기획 시 선정(개인 3번째·공식 3개). ⚠️ **키워드마스터 직접 로그인 접근 없음**(유료 툴) → 웹 리서치 + 도메인 데이터로 인기도 근거잡아 선정(키워드마스터 대용, 출처 표기). GM이 키워드마스터 상위 목록 붙여주면 그중 선택 가능. 정직 원칙: 인기도 수치 날조 금지([[feedback_welly_verification_standard]]).

**적용 예 (공식 시설 시리즈, 2026-07-08 · 지역복합):** F2 편의시설=`#한남동스파 #한남동힐링 #한남동피부관리`…, F3 회복=`#한남동사우나 #한남동힐링 #한남동회복`… (F1은 발행 후라 둠). 2026 리서치: IG 해시태그 노출 영향력↓ · '대형 앵커+지역/틈새 혼합'이 정석 → 앞3=도달앵커, 중간=지역·프리미엄 틈새.

관련: [[project_namuk_operator_case_series]] · [[feedback_cta_standard_bilingual]] · [[project_ig_content_folder_standard]] · [[project_personal_account_signature_color_emerald]].
