---
name: feedback_security_live_activation_needs_gm_go
description: "보안·접근통제 조치는 코드·설계·검증까지 C-Level 자율, 그러나 라이브 발효(실제 차단·잠금)는 GM 명시 go + 즉시 역롤백 보장 필수. 2026-06-18 PII 게이트 사고 교훈"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ad2dcef5-26a1-4455-936d-35f0ca9d722a
---

보안·접근통제(개인정보 게이트·권한 잠금·토큰 enforce 등) 조치는 **코드·설계·검증까지는 자율**이되, **라이브 발효(실제로 사용자/직원/페이지를 차단·잠그는 단계)는 GM 명시 go가 있어야 하고, 즉시 무중단 역롤백이 보장돼야** 한다.

**Why:** 2026-06-18 PII 접근 게이트(CTO-2026-06-17-GAS-PII-ACCESS-GATE)가 큐엔 "GM 활성화 대기"로 적혀 있었는데 실제로는 서버 `TOKEN_ENFORCE='1'`로 **라이브 발효**돼 개인정보 화면이 잠겼다. GM이 당황 → "더 큰 틀로 재설계, 일단 삭제" 지시. 발효 시점이 GM 통제 밖이었던 게 사고의 본질.

**How to apply:** ① 보안 기능은 기본 OFF(불변식: enforce 플래그 꺼지면 전 액션 통과)로 배포 ② 실제 차단을 켜는 건 GM이 직접 또는 GM go 후에만 ③ 켜기 전 역롤백 한 줄(속성 삭제 등)을 미리 확보·문서화 ④ 큐/보고의 상태값과 실제 라이브 상태가 어긋나지 않게(켜졌으면 "발효 중"으로 정직 기재). 정본 = S2 cto탭 [[시토 운영 헌장]] 축6(권한·게이트 경계). PII 보호 재설계는 [[project_pii_gate_aggregates_public_no_key_ux]] · [[project_self_hosted_inquiry_db_goal]]와 묶어 큰 틀에서.
