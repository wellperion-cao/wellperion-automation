---
name: gm-record-style
description: "GM 본인의 일·이력은 건바이건 X, 핵심 요약본 + 히스토리 순번 누적 정리"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 80777498-c2ef-4d1a-bdc6-40d7cfcb2d61
---

GM 본인의 일·이력 기록은 건바이건이 아닌 **핵심 요약본 + 히스토리 순번 누적**으로 정리한다.

**Why:** 2026-05-28 GM 피드백 — "건바이건으로 기록되면 너무 힘들고, 핵심요약본으로 정리되어서 히스토리를 순번대로 정리가 되어있었으면 좋겠어". 50+ 커밋·세부 항목 나열은 GM 부담. 큰 그림 우선.

**How to apply:**
- **일일 단위**: 오늘 핵심 3-5건만 표면에. 세세한 디테일은 토글·아카이브로 숨김.
- **순번 부여**: 과거 기록은 `#001 / #002 / #003 ...` 누적 순번. 클릭하면 상세.
- **주간·월간 자동 요약**: 일 → 주 → 월 단위 자동 합산. 큰 카테고리(매출·인사·시설·운영 등)별 그룹.
- **김남욱GM 페이지의 일일 정리**: 오늘 한 일·내일 할 일 영역 모두 요약 우선 표시.
- **결재 SSOT 보고용 출력**: 41건 카드 줄줄이 X → 카테고리·결재자별 요약.
- **CEO 보고**: 표·요약 3요소 압축은 [[feedback_ceo_essence_oversight_and_brief]]와 일관.

**관련:** [[feedback_ceo_essence_oversight_and_brief]] · [[feedback_report_style]] · [[feedback_no_lookback_tomorrow_only]] · [[project_gm_unified_tasks]]
