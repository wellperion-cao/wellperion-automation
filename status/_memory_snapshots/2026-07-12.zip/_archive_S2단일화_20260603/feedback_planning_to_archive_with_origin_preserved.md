---
name: db
description: Start 기획DB 「초안 완료」 트리거로 결과물DB 페이지 생성 시 본문 끝에 「📜 원 기획서」 토글 + Start 기획 원본 페이지 mention-page 자동 보존.
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 63d35c3d-04dd-4095-be62-d069a93c7814
---

기획 초안완료 → 결과물DB 이관 시 **원 기획서를 결과물 페이지 안에 mention으로 보존** 의무. (2026-05-20 GM님 신지시)

**Why:** 이관(Move) 흐름에서 원본 추적이 끊기면 컨텍스트 손실. 결과물 페이지가 PSP 정렬·인쇄용으로 가공되지만, 원 기획서의 6섹션 답변·DI 5차원 등 작성자 의도는 별도 보존 필요. 메모리 [[feedback_no_copy_paste]] 정신상 본문 복사 금지 + mention-page로 양방향 추적 가능.

**구조:**
```
결과물 페이지 본문
├── 📄 최종 산출물 Callout (최상단)
├── # Product · System · Philosophy (PSP 정렬)
└── # 📜 원 기획서 (이관 보존)
    └── 📌 callout
        - **원 기획서:** mention-page → Start 기획DB SP-N 페이지
        - **이관 정책:** 본문 복사 금지, mention 보존만
```

**How to apply:**
- CTO 자동 이관 코드 가동 시 위 토글 자동 삽입 의무 (현재 코드 미가동 — CEO 수동 ingest 시에도 적용).
- 원 Start 기획 페이지는 stub archive 권장 ([[feedback_post_move_stub_delete]]).
- mention-page는 Notion이 자동 추적 — 원본 제목·상태 변경 시 결과물 페이지에서도 갱신.
- 결과물 페이지 본문에 Start 기획 6섹션 본문을 텍스트로 복사하는 행위 금지 ([[feedback_no_copy_paste]]).

**연동 메모리:** [[feedback_no_copy_paste]] · [[feedback_post_move_stub_delete]] · [[feedback_pipeline_policy_unified]] · [[feedback_start_planning_telegram_briefing]]
