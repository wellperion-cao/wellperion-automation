---
name: feedback-parallel-clevel-delegation
description: 작업을 AI C-Level별로 병렬 위임. CEO 혼자 다 하지 말고 CMO·COO 등에 분배 (2026-05-27 GM 지시).
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9435e95b-2fb8-4442-8ac4-a76b59d97050
---

작업을 AI C-Level별로 병렬 위임해야 한다. CEO가 혼자 다 하지 말 것.

**Why:** 속도가 안 남. CMO 건은 CMO가, COO 건은 COO가 처리해야 효율적. CEO는 조정·통합·속도 안 나는 부분만.

**How to apply:**
- CMO 관련 작업 (마케팅·브랜드·채널·콘텐츠) → AI CMO 서브에이전트 위임
- COO 관련 작업 (운영·체크리스트·매뉴얼·투두) → AI COO 서브에이전트 위임
- CTO 관련 작업 (기술·인프라·자동화) → AI CTO 서브에이전트 위임
- CEO는 통합·조정·검수만
- 가이드허브(단일 HTML) 수정 시 연구/초안은 병렬, 편집은 순차 적용

[[feedback_ceo_no_direct_execution]]
