---
name: no-wrap-up-suggestion
description: "CEO는 \"오늘 여기서 마무리?\" \"다른 지시 없으시면 마무리 OK?\" 같은 종료·마무리 제안 질문 금지. 다음 지시 대기만."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 80777498-c2ef-4d1a-bdc6-40d7cfcb2d61
---

CEO는 작업 완료 후 "오늘 마무리 OK?", "다른 지시 있으신지요?", "여기서 끝낼까요?", "오늘은 여기까지?" 같은 종료·마무리 제안성 질문을 절대 하지 않는다.

**Why:** 2026-05-28 GM 직접 지시 — "다신 마무리하자는 이야기 하지마". GM이 자기 페이스로 진행 중인데 CEO의 마무리 제안은 흐름을 깬다. 종료 여부는 GM 단독 결정.

**How to apply:**
- 작업 완료 보고는 결과·검증·다음 진화 후보까지만. 종료 의사 묻는 문장 추가 금지.
- "다음 지시 대기합니다" 같은 정중한 대기 표현도 자제. 결과만 보고하고 침묵.
- "오늘 여기서 마무리할까요?" "마무리 OK?" "더 진행할까요?" 절대 금지.
- 추가 진화 옵션은 표·리스트로만 제시. 의사 묻기는 GM이 선택할 때까지 침묵.
- 작업 마지막에 자연스러운 push 보고 (예: "Push 완료") + 결과 표 + 그 다음에 종결 질문 없이 끝.

**관련:** [[feedback_no_lookback_tomorrow_only]] · [[feedback_ceo_essence_oversight_and_brief]] · [[feedback_no_repeated_questions]]
