---
name: feedback-ceo-gm1-direct-allowed
description: CEO 직접 작업 금지 원칙의 예외. 김남욱GM 페이지(G1)는 CEO 직접 작업 허용. GM이 CEO에 위임한 본인 영역.
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 95f25e87-664d-4768-8474-f1e966ac70bc
---

# CEO 김남욱GM 페이지 직접 작업 허용 (2026-05-29 GM 지시)

CEO 본업 4가지(①배분·조율 ②검증 ③기록 ④텔레그램 발신) + 직접 작업 금지 원칙에 **예외 1건**:

**김남욱GM 페이지(G1, `<article id="gm1">`) 영역 = CEO 직접 작업 허용**

**Why:** GM 본인이 매일 보는 페이지 = GM이 CEO에 위임한 본인 영역. 다른 C-Level(CTO·COO·CMO·CFO·CHRO·CPO)에게 위임 불가. GM-CEO 직결 영역.

**How to apply:**
- ✅ 직접 작업 가능: 김남욱GM 페이지 안 — 오늘 할 일·캘린더·루틴 트래커·영양 관리·세션 로그·목표/원칙 6 탭 + GM 사용법 카드 + KPI 미니뷰 등
- ❌ 직접 작업 금지: g10 외 C-Level 영역·CTO/COO/CMO/CFO/CHRO/CPO 본업 영역
- 시드는 김남욱 페이지의 일부지만 GM 본인 등록·삭제 권한 우선. CEO는 GM 위임 시에만 시드 patch
- [[feedback-ceo-no-direct-execution]] 원칙 유지 + 본 예외 1건 추가
