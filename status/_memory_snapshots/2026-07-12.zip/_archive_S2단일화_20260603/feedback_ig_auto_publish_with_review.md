---
name: Instagram namuk.wellperion 자동 게시 — Playwright 방식 + CEO 검수 게이트
description: IG 자동 게시 = Playwright Persistent Context (Creator 계정) + CEO 검수. Meta Graph API B' 옵션은 페북 영구 삭제 정책 충돌로 폐기 (2026-05-08 GM님 결재 A 채택)
type: feedback
originSessionId: 37b7c49f-03b9-4c84-a313-635fa646e5da
---
Instagram `namuk.wellperion` 게시 흐름: **CMO 가공완료 → CEO 검수 → CMO Playwright 자동 게시 (Creator 계정 + Persistent Context)** (2026-05-08 GM님 결재 A 옵션 = Playwright 방식 채택. Meta Graph API B' 옵션 폐기)

**Why (2026-05-08 정책 전환):**
- Meta Graph API B' (2026-05-03 채택) → **폐기**. 사유: 페북 매개 영구 삭제로 Instagram Login API + 호스팅 인프라 R&D 부담 + Meta App Review 가능성
- Playwright Creator 계정 방식 = CMO-001 v1.20 「P-1 인스타 Playwright 전환」 정합 + 반나절 작성 가능 (CTO 평가) + 검수 게이트 동일 보존
- ToS 위반 잔존 위험 — Creator 계정은 개인 계정보다 감지 임계 높음 (CTO 평가) + headful + 고정 UA로 감지 최소화

**How to apply (운영 흐름):**
1. CMO: 채널별 업로드 캘린더 DB 가공중 → 가공완료 전환 + 게시 패키지(캡션·이미지·해시태그) 본문 정리
2. CEO: 가공완료 → CEO 검수 게이트 (`feedback_cmo_content_gate` 단독 게이트)
3. CEO 검수 통과 → CMO 호출 → CMO가 `scripts/instagram_upload_playwright.py` 실행 (Persistent Context `C:\Users\jjky0\.welperion-instagram-profile`)
4. 게시 완료 → 캘린더 DB 상태=`업로드 완료` patch + 산출물 IG URL 입력 + 텔레그램 보고

**선결 별건 (GM님 결재 후 CTO 단독 R&D):**
- `scripts/instagram_upload_playwright.py` v0.1 작성 (`--mode setup` + `--mode dryrun`) — CTO 본업, 반나절 공수
- setup 모드 = GM님 수동 1회 로그인(OTP 직접 입력) → 세션 쿠키 영속
- namuk.wellperion **Creator 계정 전환** 확인 (이미 Creator면 OK / 개인 계정이면 Creator 전환 — GM님 수동)
- `--mode publish` 구현은 setup/dryrun 통과 후 별건 결재 (CEO 경유 GM님)

**금지:**
- ❌ CEO 검수 미통과 상태 자동 게시 금지 (`feedback_cmo_content_gate`)
- ❌ 페이스북 매개 시도·Meta Graph API 복원 시도 금지 (영구 폐기)
- ❌ setup·dryrun 통과 전 publish 모드 강행 금지
- ❌ CMO 자체 검수·자체 게시 금지 (CEO 게이트 단독)
- ❌ headless 모드 인스타 자동화 금지 (감지 트리거)

**대체 정책:** `feedback_ig_manual_publish`(옵션 A 수동) 폐기 → `Meta Graph API B'`(2026-05-03) 폐기 → **Playwright Creator(2026-05-08 A) 단독**.
