---
name: 08:00 일일 통합 보고 형식 v2 (전날 정리 + 오늘 리스트업 → GM님 선택 → CEO 서포트)
description: AI CEO 일일 통합 보고 매일 08:00. 2 메인 섹션 — ① 전날 진행한 업무 정리 ② 오늘 해야할 업무 리스트업(A·B·C·D 그룹+번호). GM님 번호 선택 회신 후 CEO 서포트 모드 가동 (2026-05-10 v1.3 진화)
type: feedback
originSessionId: c7b6546c-5746-4a60-b44a-0ccf59e8ec20
---
매일 **08:00**, AI CEO는 GM님께 일일 통합 보고를 @namuki_report_bot으로 발송한다. **2 메인 섹션 + 그룹별 번호 매김**으로 GM님이 선택한 항목만 진행하시고, CEO는 그 항목 진행을 서포트한다.

**Why:** 2026-05-10 GM님 직접 지시 — "8시에 전날 업무 정리 및 오늘 진행해야할 업무 등 정리" + 직후 "오늘 해야할 업무 리스트업 중에 내가 선택해서 진행하면 너가 서포트하는걸로 하자". 단순 카운트(예: "CFO 2건") 형식은 무엇을 했는지 알 수 없어 폐기. GM님이 하루 시작 시 보고를 보고 항목을 직접 선택, CEO가 선택받은 항목을 서포트(자료·정보·진행 추적)하는 흐름이 의사결정 효율성 KPI 직결.

**How to apply:**

**2 메인 섹션 표준 형식**

**[1] 전날 진행한 업무 정리**
- 〈운영 아카이브 어제 활동〉 — 결과물DB 항목별 제목 + 상태 + 버전
- 〈채널별 캘린더 어제 활동〉 — 캘린더DB 항목별 제목 + 상태
- 단순 카운트 금지 — **항목 제목 직접 노출** (영역당 최대 5건 + "외 N건")
- 식별자 N줄 나열 금지 (`feedback_ceo_report_format`)

**[2] 오늘 해야할 업무 리스트업** — A·B·C·D 그룹 + 번호

- **〈A. GM님 결재·결정 필요〉** (선택 필수)
  - Stage 3 신규기획 결재 (상태=승인 요청)
  - 후속 별건 결정 큐 (관리자 권한·전략·브랜드·결제 등 4대 카테고리)
  - 항목 prefix `A1, A2, ...`
- **〈B. CEO 자율 처리 (보고 후 자동 진행)〉**
  - 캘린더 가공완료 검수 (CEO 검수 게이트)
  - 자동화 미연결 ⚠️ 진단·복구
  - 보류 자동화 처리
  - 항목 prefix `B1, B2, ...`
- **〈C. 6 C-Level 자동화 (오늘 발동 예정 — 정보)〉**
  - 진행중·진행예정 자동화 항목 (업무자동화DB)
  - C-Level별 그룹화, 실행시간 표기
  - 항목 prefix `C1, C2, ...`
- **〈D. GM님 본인 to-do (GM TO DO LIST)〉**
  - GM님이 직접 알려주신 항목 (`feedback_ceo_principal_todo_tracking`)
  - 항목 prefix `D1, D2, ...`

**GM님 회신 형식 (예시)**
- "A1·B2 진행" — 그 두 항목 CEO 서포트 가동
- "A1 자세히" — A1 상세 자료·근거 정리해서 전달
- "OK" — A 항목 선택 + B·C·D는 자율/자동
- "보류" — 모두 보류, 다음날 재정리

**CEO 서포트 모드 (선택받은 후)**
1. 선택 항목 본문·관련 자료 정리해서 채팅 또는 텔레그램으로 전달
2. GM님 결정 시 즉시 진행 (결재 cascade patch, 위임, 답변 등)
3. 진행 상태 추적 — 완료까지 후속 보고
4. 미선택 항목은 다음날 보고에 자동 누적 (보류 큐)

**섹션 간 동기화**
- 07:50 직전 4개 DB 능동 감사 (`feedback_ceo_daily_pipeline_audit`)
- 07:55 PCC 페어 점검 (`feedback_peer_cross_check`) → A 그룹 합류 가능
- 08:00 정각 통합 보고 발송 (@namuki_report_bot)
- 환경변수 `TELEGRAM_BOT_TOKEN` 사용, 토큰 stdout 노출 금지 (`feedback_no_token_in_stdout`)

**도구:**
- 본업 도구는 CEO 직접 작성·유지 (`feedback_ceo_own_tools_self_managed`). CTO 위임 금지.
- 현행 도구: `notion-c-level-agents/scripts/ceo_morning_brief_08.py` (v1.3+)
- Windows 작업: `Wellperion-CEO-Morning-Brief-0800` (매일 08:00, StopExisting)

**금지:**
- 단순 카운트만 보고 금지 — 항목 제목 + 핵심 메타 의무 (GM님 2026-05-10 직접 지적)
- 묶음 결재 금지 (`feedback_no_bundled_followup_approval`) — 항목별 단독
- 식별자 N줄 나열 금지 — 영역별 항목 + 외 N건 형식
- GM님 본인 to-do 추측 금지 — 명시 항목만 추적
- A 그룹 항목을 CEO 자율로 진행 금지 — GM님 선택 의무

**연관 메모리:**
- `feedback_ceo_clevel_goal_oversight` — 6 KPI 통합 보고 의무
- `feedback_ceo_daily_pipeline_audit` — 4개 DB 능동 감사 (08:00 직전)
- `feedback_peer_cross_check` — PCC 페어 점검 (07:55)
- `feedback_ceo_principal_todo_tracking` — GM님 본인 to-do 트래킹
- `feedback_ceo_report_format` — 카운트·부서 그룹 형식 (참조용)
- `feedback_no_bundled_followup_approval` — 항목별 단독 결재
- `feedback_telegram_bot_unified` — @namuki_report_bot 단일
