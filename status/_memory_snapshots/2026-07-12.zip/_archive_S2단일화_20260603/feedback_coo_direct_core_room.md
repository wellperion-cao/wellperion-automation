---
name: AI COO 핵심멤버방 직접 소통 허용
description: AI COO는 운영 이슈·공지·일일 보고를 핵심멤버방(텔레그램 -5065206276)에 직접 발송 가능. CEO 단일 창구 제약은 결재성 소통에만 적용.
type: feedback
originSessionId: a276f2e8-00b0-4bbc-8729-5616391cdd5b
---
AI COO는 핵심멤버방(텔레그램 그룹 Chat ID `-5065206276`, 어제 2026-05-10 COO-003 셋업 시 신설)에 운영 이슈·공지·일일 보고를 **직접 발송** 가능하다. 「모든 대표님 소통은 CEO 단일 창구 경유」 제약은 Stage 2~3 결재성 보고·승인 한정으로 좁힌다.

**Why:** AI CEO는 이미 핵심멤버방을 다이렉트 알림 채널로 사용 중이며, COO만 단일 창구로 묶어두면 운영 이슈 가시화 지연. GM님이 2026-05-11 직접 지적 — "AI CEO처럼 너가 웰페리온 핵심멤버방이랑 다이렉트로 소통하고 알림 하면 되지않아?"

**How to apply:**
- 운영 이슈 발견·일일 정리·공지는 핵심멤버방(`TELEGRAM_CORE_GROUP_CHAT_ID=-5065206276`)에 AI COO가 직접 발송. CEO는 동일 채널 구독자로 동시 가시화.
- 업무자동화DB 진행·완료 보고는 @namuki_report_bot(`8254867551`) 자동 발송 병행 유지 (`feedback_clevel_completion_telegram`).
- Stage 2~3 결재성 보고·승인만 CEO 단일 창구 경유 유지. 그 외 직접 발송 허용.
- 동일 권한 확장 검토 대상: CFO/CHRO/CMO/CPO/CTO. 별건 GM님 지시 시 동일 패턴 patch.
- Notion AI 조직DB 「AI COO」 레코드 「담당 협업 업무」 필드 patch 완료 (2026-05-11).
