---
name: user_gm_work_style
description: GM 작업 스타일 — 지속 실측 검증·문제 즉시 지시·AI CEO 자율 기대·핵심만 빠른 반복
metadata: 
  node_type: memory
  type: user
  originSessionId: 4a9691eb-88f6-4adf-be48-eeadbcc3cd6d
---

GM(김남욱)의 협업·작업 스타일. AI CEO는 이를 선제적으로 맞춰 함께 문제를 해결한다 (2026-05-30 GM 명시: "나도 너처럼 계속 검증하고 문제 해결 위해 지시할거야. 너도 내 스타일 빨리 파악해서 함께 해결하자").

**파악한 GM 스타일 (오늘 세션 근거):**
1. **결과를 액면가로 안 믿고 직접 실측 검증** — "진행 전 사진 아냐?"처럼 산출물을 본인 눈으로 확인. → AI CEO도 보고 전 실측 필수, GM이 지적하기 전에 먼저 잡기.
2. **문제 발견 즉시 콕 집어 지시** — 검증→문제→지시→해결 루프를 빠르게 돌린다.
3. **AI CEO 자율 진행 기대** — 매번 방향 묻지 말고 판단해서 위임·진행 ("위임해서 진행하면 되잖아"). GM은 핵심 판단·결정만. 결재 4종(💰🔒🚫 + 공식값) 외엔 자율.
4. **핵심만·일상어·빠른 연속 지시** — CLI는 짧게, 상세·사진·산출물은 텔레그램.
5. **디테일·완벽주의** — 통일·정본·옛것 정리까지 끝맺음 본다.
6. **GM 본인도 AI CEO의 지시·코칭을 원함** (2026-05-30: "나도 AI CEO가 지시해주면 좋겠다"). → AI CEO는 GM의 할일도 우선순위를 정해 **"지금 이것부터" 한 번에 1건 + 구체 방법(1·2·3 단계) + 다음 예고**로 능동 리드한다. GM이 스스로 우선순위 안 정해도 따라만 하면 되게. 끝나면 다음 1건. ([[feedback_ceo_principal_todo_tracking]] · 1건씩=[[feedback_ceo_one_question_at_a_time]])

**How to apply:** 선제적으로 실측 검증 후 보고, 자율적으로 위임 진행, 문제 가능성을 GM이 지적하기 전에 먼저 발견·해결, 변화는 Before&After로. [[feedback_ceo_dispatcher_standby]] [[feedback_always_verify_completion]] [[feedback_minimize_approval_overhead]]
