---
name: C-Level 업무자동화 루틴 셋업 포맷 & 상태 전환 권한
description: C-Level은 각 자동화 루틴을 "제목·주기·실행시간·산출물" 4항목으로 정리한다. 상태 전환(진행예정 → 진행중)은 GM님 수동 전환 전용. C-Level·CTO 임의 전환 금지. (2026-04-23 GM님 확정)
type: feedback
originSessionId: 7dbf3cc3-aa27-4486-899a-7b2bd93b607b
---
C-Level은 본인 담당 업무자동화 루틴을 아래 **4항목 포맷**으로 정리한다. 상태 필드 전환("진행예정 → 진행중")은 **GM님이 1건씩 수동 전환** 하는 영역이다. C-Level·CTO가 임의 전환 금지.

## 루틴 정리 포맷 (C-Level 책임)
| 항목 | 설명 |
|---|---|
| 제목 | 네이밍 표준 `M.D-프로젝트명` (메모리 `feedback_naming_standard`) |
| 주기 | 매일 / 매주 {요일} / 매월 1일 / 매월 말일 / 기타 |
| 실행시간 | `HH:MM / N분` 형식 |
| 산출물 | 결과물 형태·기록 위치 (예: 텔레그램 @namuki_report_bot 1건 / Notion 페이지 / DB 필드 업데이트) |

## 상태 전환 규칙
- "진행예정" → "진행중": **GM님 수동 전환 전용**
- C-Level·CTO 임의 patch 금지 (2026-04-23 42건 사고 재발 방지)
- GM님은 각 루틴의 4항목을 확인 후 1건씩 수동 전환

**Why:** 2026-04-23 GM님 확정 — "CMO가 제목, 주기, 실행시간, 산출물 정리 → 상태는 내가 수동으로 할게. 이건 CTO한테도 전달해서 CTO가 전 C레벨들에게 위 내용으로 셋업해줘". 42건 강제 전환 사고 재발 방지 + GM님이 실제 가동 시점을 최종 컨트롤. 데이터 소스·집계 로직 완벽 정의보다 "무엇을 언제 만들어 내는가"를 선명히 하는 것이 GM님 본질 관심사.

**How to apply:**
- CTO는 전 C-Level(CFO·CHRO·COO·CPO·CMO)에 본 포맷 전파·셋업 주관.
- 각 C-Level은 본인 루틴 전수를 4항목 포맷으로 정리 → 업무자동화DB 레코드 필드에 반영.
- 정리 완료 후 CEO에 보고 → CEO가 GM님께 1건씩 질문 + 추천 (메모리 `feedback_ceo_one_question_at_a_time`) → GM님 수동 전환.
- CTO는 본인 R/R 내 기술 지원만. 타 C-Level R/R 영역 레코드 직접 수정 금지 (메모리 `feedback_accountability_rules_by_role`).
- 메모리 `feedback_no_ambiguous_automation` 병행 — 4항목 정리 시 모호함 발견되면 질문 리스트 작성.
