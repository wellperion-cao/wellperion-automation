---
name: feedback-guidehub-over-notion
description: 가이드허브(Netlify)가 전체 SSOT. Notion은 필요 부분만 동기화. 가이드허브 기준으로 정상이면 Notion도 반영 (2026-05-26 GM 지시).
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 88d13af2-5d51-4abb-9ca4-a3a6b3714259
---

가이드허브(Netlify 웹앱)가 백그라운드에서 모든 것의 기준(SSOT). Notion은 필요한 부분만 제안·동기화.

**Why:** Notion 점차 축소·폐기 예정. 가이드허브에서 정상 확인되면 Notion 상태도 맞춰야 함 (예: PC ON/OFF 실제 가동 → Notion도 진행중).

**How to apply:**
- 상태 판단 기준 = 가이드허브 업무자동화 캘린더
- Notion 상태 불일치 발견 시 가이드허브 기준으로 Notion 동기화 (GM님 이미 포괄 승인)
- Notion 신규 등록은 최소화, 필요 시 제안 후 진행
- 관련: [[project-gm-todo]] [[project-guidehub-ssot]]
