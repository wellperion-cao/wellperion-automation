---
name: feedback-self-verify-before-user-test
description: UI/JS/스크립트 변경 후 사용자(GM)에게 사용·검증 요청하기 전에 반드시 자체 실측 검증(Playwright/curl/스크립트)으로 동작 확인 의무. 코드 정합 grep만으로 OK 보고 금지.
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 3d0dba27-391b-4519-984a-5d62568d2a34
---

코드 변경 후 GM에게 "사용해보세요/Ctrl+F5 후 피드백 부탁드립니다" 같은 요청 직전에 반드시 자체 검증으로 실제 동작 확인 의무.

**Why:** 2026-05-28 공지 서식 px input 동작 fix 시 4회 commit·push 반복했는데 검증 없이 보냈더니 다 안 됐음. GM이 "이게 몇번째야" 짜증. v2.54·v2.55·v2.56 세 번 push 후 직접 Playwright 검증으로 진짜 동작 확인했고 결국 selectionchange 이벤트가 정답. 처음부터 검증했으면 1번에 해결됐을 일.

**How to apply:**
- UI 변경(버튼·input·이벤트): Playwright 시나리오 스크립트로 사용자 입력 시뮬레이션 + innerHTML/computed style 검사
- CSS·시각 변경: Edge headless 또는 Playwright screenshot 캡처 + Read로 시각 확인
- API 호출·자동화: 실제 호출 결과 print + 핵심 필드 검증
- grep으로 "코드에 들어감"만 확인하는 건 검증 아님 — 실행 결과까지 확인
- "코드 정합 OK"만으로 GM 요청 보고 금지. 시각·동작 증거 같이 첨부
- 검증 실패 시 즉시 재수정 → 통과까지 반복. 사용자 검증 부담 떠넘기지 X

`feedback_screenshot_visual_verify`와 같은 맥락 — 자동화 결과 보고 전 시각/실측 검증 의무. 본 메모리는 코드 동작(JS·UI)까지 확장.
