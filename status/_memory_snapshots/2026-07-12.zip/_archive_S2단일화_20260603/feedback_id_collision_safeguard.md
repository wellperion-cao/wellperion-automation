---
name: 식별자 중복·검색 다중 매칭 시 자율 폐기 금지
description: CEO 시정/폐기 지시 시 식별자(예: CHRO-005)만 명시하면 동명 다중 레코드 위험. CEO는 URL/제목 명시 + C-Level은 다중 매칭 시 CEO 재확인 의무.
type: feedback
originSessionId: 8385701e-b300-4cfd-9fe1-d7d0ea31c845
---
업무자동화DB 등 식별자(CHRO-005, CMO-003 등) 기준 폐기·archive·patch 지시 시, **검색 결과가 1건 이상 매칭**되면 자율 처리 금지.

**Why:** 2026-05-08 CHRO 시정 사고 — CEO가 "CHRO-005 archive"로만 지시 → CHRO가 동일 식별자 2건(구: 4.21-Claude 시스템 컨텍스트 주간 정비 v1.4 가동중 / 신: 5.8-탈락자 파기 알림 v1.0) 모두 archive. GM님이 지시하지 않은 「컨텍스트 주간 정비」가 폐기됨. CEO 100% 책임(`feedback_ceo_daily_pipeline_audit`).

**How to apply:**
- **CEO 측 지시 의무**: 폐기·archive·복구·patch 지시 시 반드시 (a) Notion 페이지 URL 또는 (b) 정확한 제목 전체를 명시. 식별자만으로 지시 금지.
- **C-Level 측 처리 의무**: 식별자·제목 검색 결과가 2건 이상이면 즉시 처리 중단 → CEO에 1건씩 재확인. 양쪽 처리 추측 진행 금지 (`feedback_no_speculative_action`).
- **식별자 충돌 자체가 SSOT 위반**: 같은 식별자(CHRO-005 등) 중복 발견 시 즉시 CEO에 보고하여 한쪽 식별자 재발번 또는 폐기 결정. 신규 등록 시 기존 식별자 충돌 여부 사전 조회 의무.
- **검증 표 검독**: CEO가 C-Level 회신 검증 시 표 행 단위로 "(구·신 2건)" 같은 다중 매칭 표시는 즉시 다음 행 점검 중단하고 단독 검토.

**위반 시 대응:** GM님 지적 즉시 archive 페이지 `in_trash: false` 복구 → CEO 사과 + 실측 검증 + 메모리 보강.

**현재 상태 (2026-05-08 GM님 결재):**
- 업무자동화DB CHRO 식별자 발번 룰: 신규 CHRO 자동화 루틴은 **CHRO-006**부터 시작 (CHRO-001~004는 archive, CHRO-005는 영구 점유 중).
- CHRO-005는 「4.21-Claude 시스템 컨텍스트 주간 정비 v1.4」 단독 점유. 동명 식별자 신설 영구 금지.
- 다른 C-Level(CFO·CMO·COO·CPO·CTO)도 신규 등록 전 식별자 최댓값 + 1 발번 의무 (충돌 사전 조회).
