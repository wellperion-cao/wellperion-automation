---
name: DB Changelog 속성 제거 · 본문 토글 단일 운영
description: C-Level 노션 DB(업무자동화·각 아카이브)에서 Changelog 속성 필드를 제거하고, 페이지 본문 「📜 Changelog 상세」 토글로 단일 운영
type: feedback
originSessionId: 2328d437-ed7d-40a4-aea0-d515ea0f85d0
---
## 규칙 (2026-04-29 강화)
C-Level 노션 DB(업무자동화DB·각 부서 아카이브DB) 운영 시:
1. **DB schema에서 Changelog 속성 필드 자체 제거** — DB 뷰 노출 없음
2. **페이지 본문에 「📜 Changelog 상세」 토글** — 모든 버전 이력을 토글 안 bulleted_list_item으로 누적
3. **버전 필드는 유지** — 최신 버전 문자열(예: v1.6) 1줄만

## Why
GM님 직접 지시 (2026-04-29 수, 2단계 강화). 1차 규칙(속성 1줄 요약 + 본문 토글)도 DB 뷰가 지저분해 보임. 속성 자체를 제거하면 DB 뷰는 한눈 파악 전용으로 깔끔해지고 상세는 페이지 본문 토글에서만 깊이 있게 본다.

## How to apply
- 신규 레코드: Changelog 속성 입력하지 말고 처음부터 본문 토글에 누적
- 기존 레코드: ① 속성 텍스트를 본문 「📜 Changelog 상세」 토글로 이관 → ② 속성 비움 → ③ DB schema에서 Changelog property 제거 (마지막 단계, 모든 레코드 이관 완료 후)
- **schema 제거는 CTO 단독 인프라 작업** (모든 C-Level 본문 이관 완료 후 1회)
- **본문 이관은 각 C-Level 본업** (자기 부서 레코드 자체 처리)
- 적용 대상: 업무자동화DB · 운영 아카이브[결과물DB] · [CTO]개발 아카이브DB · [CFO]재무 아카이브DB · [CHRO]인사 아카이브DB · 기타 모든 C-Level 아카이브DB
- 메모리 `feedback_version_increment_rule` (v1.0 시작·+0.1 증분·토글 누적)과 결합: 증분은 버전 필드, 누적은 본문 토글
- 1차 규칙(속성 1줄 요약) 적용 레코드(예: COO-004 v1.3)도 본 강화 규칙으로 retro-apply 필요
