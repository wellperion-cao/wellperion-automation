---
name: feedback_ig_publish_verify_grid_existence
description: IG 발행은 스크립트 성공출력·회수 URL을 믿지 말고 프로필 그리드 실등장(오늘 날짜 신규 shortcode)으로 검증
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 10213ccd-502a-4feb-beb8-15fb894bdf5d
---

인스타그램 발행 후 완료 판정은 `instagram_upload_playwright.py`의 stdout("발행 성공")·회수 URL만으로 단정 금지. 반드시 **프로필 그리드에 오늘 날짜의 신규 게시물(이전에 없던 shortcode)이 실제 등장**했는지 독립 확인할 것.

**Why:** 2026-06-01 바레 발행에서 스크립트가 "공유 중" 상태에서 프로필 이동·context.close()로 업로드를 중단시켜 실제 게시 실패했는데도, 완료 신호 오탐(공유 버튼 사라짐=share_still==0)으로 "발행 성공"을 출력하고 **고정(핀)된 2022년 옛 게시물 URL(CmqDpTjJHdp)을 회수**해 review_queue를 거짓 발행완료로 기록했다. C접두 shortcode = 시간상 옛 게시물 신호.

**How to apply:** ① 발행 후 wellperion 프로필 그리드 상위 게시물의 `time[datetime]`을 읽어 오늘 날짜·신규 shortcode 확인(상위 3개는 핀 게시물일 수 있으니 datetime으로 판별). ② 견고 발행은 공유 클릭 후 별도 탭으로 그리드를 폴링해 신규 shortcode 등장까지 대기(메인 탭 종료 금지). ③ 발행기 자체 버그(조기 완료판정+핀 URL 회수)는 CTO 하드닝 대상. [[feedback_always_verify_completion]] [[feedback_screenshot_visual_verify]] [[feedback_irreversible_publish_final_visual_gate]]

**발행 검증 = 3종 동시 확인(2026-06-03 #4 사고 보강):** 그리드 실등장 하나만 보고 "완료" 선언 금지. ① **그리드 실등장**(위) ② **M5 배포본 노출** — review_queue.json 갱신을 **반드시 git push**해야 배포본 M5(가이드허브)가 읽는다. 커밋만 하고 push 안 하면 GM 화면엔 안 뜸(=발행 안 한 것과 동일). ③ **텔레그램 실수신** — `telegram_report`는 `TELEGRAM_BOT_TOKEN` 미설정 시 **조용히 생략**한다. "보고 생략" 경고를 놓치면 알림 0건. 토큰은 `telegram_bot/.env` 로드. 표준 종료 절차(M5 cmo-publish 콜아웃) = 제작완료 시 텔레그램+검수대기 자동등록인데, 이게 빌드에 **미배선**이라 매번 수동 누락 위험 → CTO 자동화 대상.
