---
name: feedback_seed_completion_autocheck
description: "C레벨 [DONE] 완료를 G1 오늘할일 시드에 반영할 때 task_id 자동 대조 의무 — 수동 반영은 누락 반복"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: bc9b5aa3-d1e2-4b66-852d-741695f3c021
---

C레벨이 작업 완료([DONE][역할][task_id] 커밋 + status DONE)했을 때 G1(김남욱GM 페이지) 오늘할일 시드를 완료로 반영하는데, **수동으로 하면 누락이 반복**된다. 2026-05-29 하루에만 seed#09·#10·#12 등 완료 반영을 GM이 여러 번 지적("처리됐는데 완료 안 됨", "완료가 2건?").

**Why:** ① 수동 반영은 빠뜨리기 쉬움 ② seed#10 SSOT 자동합류가 제목 매칭 + SSOT 우선 병합이라 G1 완료를 진행중으로 역행 덮음(hotfix=완료 우선) ③ 시드 memo의 task_id가 실제 [DONE] task_id와 표기가 다르면 자동 대조도 실패.

**How to apply:**
1. 시드 등록 시 memo에 담당 C레벨의 **실제 [DONE] task_id를 정확히** 기입(예: `CTO-2026-05-29-GM-SSOT-AUTOSYNC`). 약칭·다른 ID 금지 — 자동 대조가 깨진다.
2. 작업 마칠 때마다 `git log [DONE] task_id` ↔ `CEO_SEEDS 시드 memo` **자동 대조 스크립트**로 "DONE인데 진행중인 시드" 0건 확인 후 완료 보고. 정규식 1줄로 검증 가능(누락 자동 탐지).
3. 근본: C레벨 [DONE] → 매핑 시드 자동 완료(task_id 기반)를 CEO 검증 watcher / seed#10 자동합류에 통합. 관련 [[feedback_always_verify_completion]] · [[project_ceo_verify_watcher]].
