---
name: Telegram bot 단일화 원칙 = @namuki_report_bot
description: 웰페리온 텔레그램 통신은 단일 bot(@namuki_report_bot · 8297784147)에서 알림·답장·역방향 제어 모두 처리. 다중 bot 분리 금지.
type: feedback
originSessionId: 472a3e16-de52-46a5-8ee9-b0c91b970284
---
웰페리온 텔레그램 통신은 **@namuki_report_bot (bot ID 8297784147) 단일 채널**로 운영한다.

**Why:** 2026-04-18 GM님 "핑" 답장이 반응 없던 사건. 원인은 **bot 2개 분리 운영**(알림 전용 @namuki_report_bot vs 역방향 제어 전용 @wellperion_ceo_bot)으로 GM님이 알림 bot에 답장 → polling 없는 곳이라 영원히 무응답. @wellperion_ceo_bot은 GM님이 @BotFather에서 삭제 완료.

**How to apply:**
- `telegram_bot/.env`의 `TELEGRAM_TOKEN` = `notion-c-level-agents/.env`의 `TELEGRAM_BOT_TOKEN` (동일 토큰)
- 알림 발송(CEO→GM님)과 수신 polling(GM님→Claude CLI) 모두 이 bot 하나로
- 새 bot 추가 금지. 만약 추가 필요 시 반드시 GM님 승인 후 메모리 업데이트
- watchdog.py는 bot.py crash 시 자동 재시작. 수동 kill → watchdog가 재시작. 중복 인스턴스 방지 위해 kill 시 watchdog도 같이 일시정지 권장
- Conflict 에러(409) 발생 시: 다른 프로세스가 동일 토큰 polling 중. 전체 python 프로세스 cmdline 스캔 (`Get-CimInstance Win32_Process`)
- Chat ID 8254867551 (GM님) · state.json의 `owner_id` 필드로 관리
