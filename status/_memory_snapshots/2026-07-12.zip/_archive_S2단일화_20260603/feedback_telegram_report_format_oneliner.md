---
name: feedback_telegram_report_format_oneliner
description: "텔레그램 결과 보고는 \"한줄 제목 / 한줄 내용\" 형식. 장황 금지."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 58638426-f833-475c-9417-e1549b409302
---

텔레그램 결과 보고는 "한줄 제목 / 한줄 내용" 포맷으로 간결하게.

**Why:** GM님은 스마트폰으로 빠르게 확인. 6건 나열식 리스트는 읽기 부담.

**How to apply:**
- send_result.py 호출 시 "제목\n내용 1줄" 형식
- 예: "AR-9 캘린더 개선 완료\n뷰 6개 생성 + 시간대 속성 추가, 담당자별 단일 뷰 정비됨"
- 여러 건이면 건별로 따로 발송하거나, 카운트만 ("오늘 6건 처리 완료\n상세는 CLI 또는 Notion 확인")

[[feedback_ceo_report_format]]
