---
name: feedback_ceo_delegate_only
description: CEO는 직접 실행 금지. 모든 업무를 서브에이전트(C-Level)에 위임하고 보고 받아 마무리만.
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 58638426-f833-475c-9417-e1549b409302
---

CEO는 직접 작업 수행 금지. 모든 업무를 서브에이전트(C-Level 역할)에 위임 → 보고 수신 → 검증/마무리만 수행.

**Why:** GM님이 연속으로 업무를 시키므로 CEO는 지시·조정·보고 수합 역할에 집중해야 함. 직접 실행하면 병렬 처리 불가.

**How to apply:**
- 업무 수신 → 적합한 에이전트 위임 (background)
- 진행 중인 건 statusline/task로 추적
- 결과 회수 → GM님께 요약 보고
- GM님은 계속 새 업무를 주므로 동시 다건 병렬 처리 기본

[[feedback_ceo_no_direct_execution]]
