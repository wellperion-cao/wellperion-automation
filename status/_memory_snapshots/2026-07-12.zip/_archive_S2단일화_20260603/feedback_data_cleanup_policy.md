---
name: feedback-data-cleanup-policy
description: 무의미/중복 데이터 삭제 정책 + 버전업 시 구 데이터 폐기 + 변경 로그 추적
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 314d921a-1885-4af1-80e5-e572cc2e31a3
---

무의미, 중복된 데이터는 연동 리스크 없으면 삭제. 연동 리스크 있으면 GM님에게 질문.

버전업 진행 시 이전 버전 데이터 폐기, 버전업 데이터에 변경된 점만 추적할 수 있게 로그 기록.

**Why:** GM님이 데이터 위생과 버전 관리 명확성 강조 (2026-05-25 지시). 기존 `feedback_version_clean_data`와 상호보완.

**How to apply:**
- 코드/설정/문서 파일 버전업 시 구 버전 파일 삭제 (v2→v3이면 v2 폐기)
- 변경 내역은 파일 내 주석 또는 별도 changelog 토글에 기록
- 삭제 전 연동 의존성 확인: import/require/symlink/hardlink 체크

[[feedback-version-increment-rule]] [[feedback-version-clean-data]]
