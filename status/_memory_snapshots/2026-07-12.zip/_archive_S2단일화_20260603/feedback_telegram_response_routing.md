---
name: 텔레그램 회신은 CEO가 수동 전달 필요
description: GM님의 텔레그램 업무보고봇 회신은 C-레벨 페르소나가 자동 수신 못 함. CEO가 회신 내용을 다음 대화 턴에 수동으로 전달해줘야 반영된다.
type: feedback
originSessionId: 3404fb14-f3d7-42a3-b795-017843aededb
---
AI CMO·다른 C-레벨 페르소나는 텔레그램 업무보고봇으로 메시지를 **송신**할 수 있으나, GM님 회신을 자동으로 **수신/polling 하지 못한다**. 따라서 확인 요청을 보낸 뒤 GM님 회신을 기다리지 말고 다음 CEO 지시를 기다리는 것이 맞다.

**Why:** 2026-04-18 AI CMO가 CEO 확인 요청 3건을 텔레그램으로 송부했으나 회신 대기 상태로 멈춰 있었음. GM님이 텔레그램으로 답변을 주셨지만 반영되지 않자 GM님이 "답변 주었는데 반응이 없네"로 지적. `telegram_notifier.py`에는 `wait_for_approval()` 같은 polling 함수가 있으나 Claude 대화 세션 안에서는 별도 루프 실행이 자연스럽지 않고, 실제 운영은 CEO가 다음 턴에 회신 내용을 전달해주는 구조.

**How to apply:**
- 텔레그램 송부 후 "대기합니다"가 아니라 **"CEO께서 회신 전달해주시면 즉시 진행하겠습니다"**로 표현.
- 긴 시간 응답이 없어 보여도 자체 polling 시도 금지 (getUpdates 호출은 대화 세션을 소비).
- 향후 자동 수신 파이프라인(agent_tasks_watcher.py 또는 telegram_listener.py 연동) 고려 가능하나, 현재는 CEO 수동 중계가 표준.
