---
name: gm
description: "인스타 등 되돌리기 어려운 외부 발행 전, 콘텐츠 전체(특히 마지막 장까지) GM 최종 시각 확인을 명시적으로 받은 뒤 발행"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2335cfec-a632-402c-83d0-eecb15cdc43f
---

인스타그램 등 외부 공개 발행처럼 되돌리기 어려운 행위는, "발행해"라는 지시만으로 즉시 실행하지 말 것. **변경된 최신본의 전 슬라이드(특히 마지막 장)를 GM이 시각으로 최종 확인·승인했는지** 먼저 확보한 뒤 발행한다.

**Why:** 2026-06-01 "왜AI" 콘텐츠 발행 시, GM "발행하고 다음 진행하자" 지시를 받아 5장본을 즉시 발행했으나 마지막 5p가 옛 WELLPERION GUIDE 카드였음. GM은 그 자리를 슬로건으로 바꾸길 원했고(발행 직후 결정), 검수 미완 상태로 외부 게시 → 게시물 삭제 사태. 원인: 비가역 행위 전 마지막 장까지 GM 시각 승인을 못 받음.

**How to apply:**
- 발행 위임 전, 검수카드/미리보기로 **전 슬라이드를 GM이 끝 장면까지 확인** → 명시 승인 → 그 다음 발행.
- "발행하고"류 짧은 지시여도, 직전에 콘텐츠가 바뀌었으면 최신본 시각 재확인을 한 번 끼울 것.
- 발행기는 삭제 기능이 없으므로(2026-06 기준 instagram_upload_playwright.py는 setup/dryrun/publish만), 잘못 나가면 GM 수동 삭제뿐 — 사전 게이트가 유일한 방어.
- 관련: [[feedback_screenshot_visual_verify]] · [[feedback_ig_auto_publish_with_review]] · [[feedback_final_content_only_for_publish]]
