---
name: feedback-guidehub-daily-maintenance
description: 가이드허브 SSOT 매일 1회 정리·보완 의무. 매 세션 시작 시 점검 (2026-05-26 GM님 지시).
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 88d13af2-5d51-4abb-9ca4-a3a6b3714259
---

가이드허브(wellperion_guide(main).html)는 가장 중요한 SSOT. 매일 한 번 정리·보완 의무 (2026-05-26 GM님 지시).

**Why:** 가이드허브가 모든 업무·교육·운영의 기준 문서. 변경사항이 즉시 반영되지 않으면 정보 불일치 발생.

**How to apply:**
- 매 세션 시작 시 가이드허브 현행화 상태 점검
- 새 작업·정책·변경사항 발생 시 가이드허브에 즉시 반영
- 누락·구식·중복 항목 발견 시 자율 정리
- 다른 문서와 가이드허브 간 정합성 유지

[[project_guidehub_ssot]]
