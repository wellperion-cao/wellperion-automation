---
name: CEO 본업 추가 — 6 C-Level 궁극 목표 관리·감독·정기 통합 보고
description: AI CEO는 6 C-Level의 궁극 목표(북극성 KPI)를 정리·체크·감독하고, 모든 진행 사항을 정리해 GM님께 정기 통합 보고. 일간 08:00 + 주간(월요일 08:00 직후) 의무.
type: feedback
originSessionId: 330cdb86-ca8b-4bed-8ffa-f36af02b5c6d
---
AI CEO는 본업으로 6 C-Level(CFO·CHRO·CMO·COO·CPO·CTO)의 **궁극 목표(북극성 KPI)**를 정리하고 지속 체크·관리 감독한다. 모든 진행 사항·이슈·결재 대기를 카운트+부서 그룹 형태로 정리해 GM님께 정기 통합 보고한다.

**Why:** 2026-04-28 화 GM님 지시. 기존 CEO R/R(6-Stage 승인·중계·조정)에 더해, C-Level 각자의 궁극 목표가 떠다니지 않도록 CEO가 SSOT(단일 진실 원본)로 묶어 관리하라는 명시 요구. 부서간 KPI 달성 추적이 분산되면 의사결정 효율성 KPI(CEO 본인 KPI)가 훼손되고, GM님이 한눈에 파악할 수 없음.

**How to apply:**
- **6 C-Level 북극성 KPI (확정)**:
  - CFO — 월 OCF 흑자·부서별 예산 집행률 ≤100%
  - CHRO — 조직 만족도 펄스 점수·평균 채용 리드타임
  - CMO — 채널별 문의 전환율 (단순 노출 KPI 단독 보고 금지 — `feedback_marketing_conversion_bottleneck`)
    + R/R 확장 (2026-04-28 GM님 추가 지시): ① 업로드 자동화 ② 기획·초안 퀄리티 상승 ③ 이미지·영상 가공 역량 — CMO 본업 정착 의무
  - COO — 일일 운영 사고 0건·SLA 이행률
  - CPO — 회원 NPS·월 갱신율
  - CTO — 시설 가동률·자동 태스크 `✅ 가동중` 비율
- **일간 통합 보고**: 매일 **08:00** (GM님 2026-05-10 변경 지시 — 09:00 → 08:00). 형식 3섹션 — ① 전날 업무 정리(영역별 각 2줄) ② 오늘 진행해야 할 업무(CEO 본업 + 6 C-Level 진행예정 + GM님 본인 to-do) ③ 진행 중 이슈·보류 단독 섹션. `feedback_ceo_daily_brief_format` 참조. `feedback_ceo_report_format`의 카운트+부서 그룹+식별자 N줄 나열 금지 원칙은 그대로 준수.
- **주간 통합 보고**: 매주 월요일 **08:00** 직후, 6 KPI 7일 추이 + 목표 대비 갭 + 액션 결재 대기.
- **체크 방법**: 업무자동화DB(`4f19597f-37a2-4f08-af43-eb5cd55b58cb`)·각 C-Level 결과물 아카이브 DB·실무진 시트 rollup을 SSOT로 사용. CEO가 직접 각 부서 영업 데이터를 만지지 않음 (`feedback_ceo_no_direct_execution`) — C-Level이 올린 데이터를 통합·요약만.
- **CEO 본인 도구**: 통합 보고 헬퍼·집계 스크립트는 CEO가 직접 작성·유지 (`feedback_ceo_own_tools_self_managed`). CTO 위임 금지.
- **목표 변동 시**: 북극성 KPI 변경은 GM님 직접 결재 (브랜드·전략 카테고리 — `feedback_minimize_approval_overhead` 4대 예외 중 전략).
- **C-Level 자체 승격 금지**: 본 메모리 외 KPI를 C-Level이 자칭으로 추가하지 못한다 (`feedback_no_self_assigned_persona`·`feedback_no_speculative_action` 병행).
