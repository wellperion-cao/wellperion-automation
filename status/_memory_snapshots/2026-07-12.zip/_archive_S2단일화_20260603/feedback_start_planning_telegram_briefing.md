---
name: start-gm
description: "Start 기획DB에서 실무진(최종 책임자)이 상태=`초안 완료` 전환 시 GM @namuki_report_bot으로 간단 브리핑 자동 발송."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 63d35c3d-04dd-4095-be62-d069a93c7814
---

Start 기획DB에서 **실무진(최종 책임자)가 상태=`초안 완료` 전환하는 순간** GM @namuki_report_bot으로 간단 브리핑 자동 발송. (2026-05-20 GM님 신지시)

**Why:** GM님이 신규 기획 적시 보고를 받아 정책·전략 영역 점검 시간 단축. 직접 DB 확인 부담 제거.

**메시지 포맷 (1건 1메시지):**
```
🆕 새 기획 등록 [SP-N]
📋 프로젝트명
👤 책임자: 실무진(최종 책임자)
🤝 서포트: 담당 C레벨
🎯 KPI: 목표 KPI
💡 한 줄: 본문 ① 핵심 요약의 한 줄 요약
🔗 페이지 URL
```

**구현:**
- 업무자동화DB CEO-002 (`5.20-Start 기획 초안완료 → GM 텔레그램 브리핑`)
- 코드: `scripts/start_planning_briefing.py`
- 트리거: Notion API 폴링 + baseline cache 비교, 신규 `초안 완료` 1건 감지
- 발송: telegram_notifier.py → @namuki_report_bot (Chat ID 8254867551)
- baseline: `.cache/start_planning_baseline.json`
- 로그: `logs/start_planning_briefing.log`
- 환경 변수: NOTION_API_KEY · TELEGRAM_BOT_TOKEN (메모리 [[feedback_telegram_token_env_key]] 정합)

**How to apply:**
- 실무진은 본 자동화 알고 있을 필요 없음 — 상태=`초안 완료` 클릭만 하면 GM님께 자동 도달
- 메시지 누락 시 baseline cache 무결성·텔레그램 토큰 환경변수 점검
- 메시지 포맷 변경 시 본 메모리 + CEO-002 페이지 본문 동기 patch ([[feedback_ceo_continuous_update_sop]])
- 토큰·자격증명 stdout 노출 금지 ([[feedback_no_token_in_stdout]])

**연동 메모리:** [[feedback_role_inversion_main_support]] · [[feedback_ceo_own_tools_self_managed]] · [[feedback_telegram_bot_unified]]
