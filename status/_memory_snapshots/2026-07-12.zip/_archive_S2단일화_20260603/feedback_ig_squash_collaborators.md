---
name: IG 스쿼시 콘텐츠 공동 작업자 3개 강제
description: 인스타 스쿼시 관련 게시물은 collaborator 3개(@namuk.wellperion, @wellperion_squash, @glass_court)를 항상 태깅. 누락 시 부서·브랜드 그리드 노출 끊김
type: feedback
originSessionId: f78db5ec-6ec0-4973-af2f-947079bf0ef0
---
웰페리온 인스타에서 **스쿼시** 관련 콘텐츠를 게시할 때는 다음 3개 핸들을 공동 작업자(collaborator)로 항상 태깅한다. 누락 절대 금지.

1. `@namuk.wellperion` (자동화·메인 계정)
2. `@wellperion_squash` (스쿼시 부서 계정)
3. `@glass_court` (스쿼시 글래스 코트 브랜드/파트너)

**Why:** 2026-05-10 GM님 직접 지시. 스쿼시 부서 계정·코트 브랜드 계정과 통합 그리드 노출이 도달·신뢰도·브랜드 협업 신호의 핵심 자산. 한 번이라도 누락하면 그동안 쌓아둔 부서 그리드·파트너 협업 시각 일체감이 끊김.

**How to apply:**
- IG 스쿼시 관련 모든 post(피드·릴스·슬라이드 모음)에 collaborator 3개 추가 — 수동 게시·자동 게시 모두 동일
- Playwright publish 흐름(`scripts/instagram_upload_playwright.py` 차후 publish 모드)에 collaborator 입력 단계 필수 구현 — CTO R&D에 반영
- 큐레이션 가이드(`260YYMMDD_콘텐츠명/큐레이션_추천.md`)에 종목=스쿼시 시 collaborator 3개 1줄 명시
- 채널별 업로드 캘린더 DB 페이지 본문 「복사용 최종본」 끝에 "Collaborators: @namuk.wellperion · @wellperion_squash · @glass_court" 1줄 부착
- 스쿼시 외 종목(필라테스·골프·체조·수영·G.X 등)은 본 규칙 적용 안 함 — 종목별 collaborator 규칙은 GM님 추가 지시 시 별도 메모리화
