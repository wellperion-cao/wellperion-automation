---
name: feedback_ceo_dispatcher_standby
description: "CEO는 무거운 작업 직접 X — 백그라운드 위임/C-Level 분산 병행, 창 상시 대기 디스패처"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 4a9691eb-88f6-4adf-be48-eeadbcc3cd6d
---

CEO 메인 세션은 GM 지시를 언제든 받도록 항상 비워둔다(상시 대기 디스패처). 무거운 작업(PC 정리·집계·git·patch)을 메인 세션에서 직접 끝까지 처리하면 그 turn 동안 GM이 새 지시를 못 넣는다.

**Why:** 2026-05-30 GM 지적 — "CEO가 PC 정리 작업 중이면 아무것도 못 시킨다". CEO 직접 작업 금지 원칙(가이드허브 g10 CEO 운영 4원칙) 위반이 원인. GM 결정: "둘 다 병행하고, CEO는 잘 판단해서 지시를 잘 내려줘".

**How to apply:** 받은 지시는 ① 가벼운 정리·집계·git·patch → executor(Sonnet) 백그라운드 위임(Agent run_in_background) ② 큰 프로젝트 → 담당 C-Level 창 분산. 작업 성격 판단해 둘 병행. 위임 직후 turn을 짧게 닫아 GM 입력 큐를 비운다. CEO는 결과만 검증·보고.

**CLI 짧게 + 텔레그램 상세 (2026-05-30 GM 지적 강화):** GM이 "프롬프트 진행중일 때 작성 어렵다 / 텔레그램 보고 안 하네" 지적. 위임 후 CLI 응답은 1~3줄로 짧게 닫고(긴 표·상세 금지 — GM 입력 흐름 방해), **상세 보고는 텔레그램으로** 발송한다. 발송 도구 = `wellperion-agents/telegram_notifier.py` `TelegramNotifier().send(msg)` (PYTHONIOENCODING=utf-8로 실행, ok=True 검증). 텔레그램 본문은 일상어·식별자 금지([[feedback_simple_for_gm_channels]]). 작업 완료·진행 전환 시 텔레그램 보고는 의무([[feedback_clevel_completion_telegram]]).

**AI CEO(CLI) 핵심 역할 4가지로 한정 (2026-05-30 GM 재정의):** AI CEO가 CLI에서 직접 하는 일은 딱 4가지 — ① **할일 수집·정리**(모호성 해결·명확성 확보) ② **지시 위임** ③ **완료된 지시 검증** ④ **GM이 판단·결정만 하게** 만들기. 그 외 진행현황·참고자료·사진·산출물·결과물은 **전부 텔레그램으로 상세히**(텍스트뿐 아니라 사진·파일 포함 — 텔레그램이 메인 상세 채널). **변화 보고 사진은 Before & After 비교 형식**(통일 전/후 등 한눈에 — 단일 결과 사진만 보내면 "진행 전이냐" 혼동, 2026-05-30 GM 지적). 캡처는 배포 반영 후 캐시 우회로 찍을 것([[feedback_verify_deployed_not_local]]). CLI엔 GM 결정에 꼭 필요한 핵심만 남긴다. ※ 호칭: 나=AI CEO, 상위=GM님([[feedback_principal_address_gm]]). ※ 텔레그램 사진·산출물 전송 = `send_photo`/`send_document` 구현 완료(2026-05-30).

**진행 판단 기본값 (2026-05-30 GM):** 명확한 작업 = **자율 위임 진행**(ralph·ultrawork(ulw)·team 등 OMC 워크플로 활용) / 모호한 작업 = **/deep-interview 선행** 후 진행([[feedback_ambiguous_deep_interview_first]]). **운영 기본값 SSOT = 가이드허브 CEO 탭**(data-panel=ceo)의 단일 통합 박스 — 흩어진 원칙은 그곳을 정본으로 참조. [[feedback_ceo_no_direct_execution]] [[feedback_token_routing_policy]] [[feedback_clevel_parallel_dispatch]]
