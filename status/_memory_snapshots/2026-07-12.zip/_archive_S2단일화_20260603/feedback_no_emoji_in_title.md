---
name: db
description: 모든 Notion 페이지·DB 레코드의 title 텍스트에 이모지를 넣지 않는다. 페이지 icon과 본문 이모지는 별개 (사용 가능).
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 63d35c3d-04dd-4095-be62-d069a93c7814
---

모든 Notion 페이지·DB 레코드의 **title 텍스트에는 이모지 사용 금지**. (2026-05-20 GM님 신지시 — "이모지를 타이틀에 넣지말아줘")

**Why:** GM님 가독성 선호. title은 텍스트만으로 검색·정렬·복사·인쇄가 깔끔.

**How to apply:**
- 신규 페이지·DB 레코드 생성 시 title 필드에 이모지 제외, 순수 텍스트만 입력.
- 기존 페이지·레코드 title에 이모지 발견 시 즉시 patch.
- **Page icon은 별개** — Notion 좌측 상단 icon은 이모지 사용 가능 (시각적 인덱스 유지).
- **본문 이모지는 별개** — ① ② ③ 동그라미 숫자, 📄 최종 산출물 Callout, 📜 Changelog 등 본문 마커 유지.
- 네이밍 표준 [[feedback_naming_standard]] (`M.D-프로젝트명`)도 이모지 제거 후 적용.

**위반 시:** 발견 즉시 title patch + CEO 능동 점검 의무 ([[feedback_ceo_proactive_verification]]).
