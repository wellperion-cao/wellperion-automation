---
name: gm
description: 업무자동화DB의 상태 보류 → 진행중 전환은 GM님 수동 권한 단독. CEO·C-Level이 가동 정합성·자동 태스크 ID 등록 여부만으로 임의 진행중 patch 절대 금지. (2026-05-22 진행예정 옵션 폐기, 보류로 통합)
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 63d35c3d-04dd-4095-be62-d069a93c7814
---

업무자동화DB 자동 태스크의 **상태 보류 → 진행중 전환은 GM님 수동 권한 단독**. CEO·C-Level의 자율 일괄 patch 절대 금지. (2026-05-20 CEO 16건 월권 사고 + 2026-05-22 진행예정 옵션 폐기·보류 단일화)

**Why:** 2026-05-20 CEO가 "자동 태스크 ID가 등록되어 있고 정기 가동인데 휴면 상태"라는 추정으로 16건을 일괄 진행중으로 patch했다가 GM님이 직접 정정. **GM님이 직접 진행중으로 설정하지 않은 자동 태스크는 보류 상태가 정합** — GM님 의도적 보류·검토중·미가동 결정일 수 있음. CEO 자율 판단 = 월권.

**원칙 (2026-05-22 갱신):**
- 보류 = 휴면 / 가동 보류 / 검토중 (GM님 의도적 상태, 진행예정 옵션 폐기 후 단일 휴면 상태)
- 진행중 = GM님이 수동 클릭으로 진행중 전환한 것만 가동 정합
- 자동 태스크 ID 등록 ≠ 자동 진행중 = 코드 등록과 가동 결정은 별개

**위반 사례 (2026-05-20):**
- 15건 일괄 진행중 patch (CEO-001 · CFO-003·004 · CHRO-002·005 · CMO-002·003 · COO-001·003·004 · CPO-002·004 · CTO-006)
- GM님 정정 즉시 휴면 상태로 복귀

**How to apply:**
- CEO·C-Level은 보류 → 진행중 patch 시도 자체 금지
- 가동 정합성 검토 시 "GM님 결정 필요" 보고만 가능, 자체 patch 안 됨
- 진행중 → 완료 → 보류 사이클은 `auto_task_watcher.py` 자동 처리 (2026-05-22부터 완료 후 보류로 리셋, 기존 진행예정에서 변경됨)
- 메모리 [[feedback_clevel_routine_setup_format]] "상태 전환은 GM님 수동 전용" 정합 강화
- 메모리 [[feedback_no_speculative_action]] 정합 강화 — 자동 태스크 ID 등록 여부만으로 진행중 추정 진행 금지

**연동 메모리:** [[feedback_clevel_routine_setup_format]] · [[feedback_no_speculative_action]] · [[feedback_status_progression_via_ceo]] · [[feedback_auto_task_trigger_policy]] · [[feedback_no_auto_restore_from_planned]] · [[feedback_no_status_regression_on_body_patch]] · [[feedback_mistake_process_sop]]
