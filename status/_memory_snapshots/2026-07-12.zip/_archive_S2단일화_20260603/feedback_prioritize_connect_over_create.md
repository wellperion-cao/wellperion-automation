---
name: prioritize-connect-over-create
description: 신규 페이지 신설보다 기존 자산을 연결·고도화하는 방향 우선
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 80777498-c2ef-4d1a-bdc6-40d7cfcb2d61
---

신규 페이지·기능을 마구 만들기보다, 이미 존재하는 자산을 서로 연결하고 깊이를 더하는 방향이 우선이다.

**Why:** 2026-05-28 GM님 명시 — "추가로 막 만드는건 좋은데, 기존 것을 연결&고도화할 수 있도록 집중해줘". 직전에 4 C-Level에게 신규 페이지(매출현황·회원관리·전환Funnel) 만들라고 시킨 직후. 가이드허브가 비어 있는 게 아니라 자산이 단절되어 있는 게 문제.

**How to apply:**
- **신규 페이지 신설 전에 먼저 점검**: "기존 OO 페이지를 확장하면 같은 목적 달성 가능?" 자문
- **연결·고도화 패턴 우선 적용**:
  - 데이터 연동 강화 (지출현황 ↔ 매출현황 ↔ 예산집행 같은 라인 통합)
  - 양방향 링크 추가 (관련 페이지 상호 참조)
  - 자동화 합류 (수동 → 워크플로·스크립트)
  - 중복 제거 (유사 콘텐츠 통합)
- **신규 신설은 다음 조건일 때만**:
  - 기존 자산으로 절대 흡수 불가능
  - 명확한 단독 R/R 영역
  - GM님 직접 승인
- 관련: [[feedback_improvement_not_rebuild]] · [[feedback_minimize_task_count]]
