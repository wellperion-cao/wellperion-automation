---
name: ig-inquiry-only
description: "인스타그램 콘텐츠 CTA·문의 표기는 \"문의: litt.ly/wellperion\" 단일. 개인 연락처(010-…) 노출 금지."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f39f6807-2207-4271-821b-7bbede864929
---

인스타그램 발행 콘텐츠의 CTA·문의 안내는 **"문의: litt.ly/wellperion"** 단일 표기로 고정한다 (2026-05-20 GM님 신지시).

**Why:** 개인 휴대전화 번호(010-5320-5514 등)가 IG 슬라이드에 노출되면 스팸·무차별 전화 위험, 그리고 공식 멤버십 콘텐츠 톤과 어긋남. Litt.ly 통합 링크는 추적·전환 측정 가능 + 사전 예약 정책(`feedback_reservation_mandatory`)에 부합. 발레/바레 런칭 슬라이드 모음 CTA에 010 번호 직접 노출 사고로 룰 확정.

**How to apply:**
- IG 슬라이드 카피·캡션·해시태그·DM 자동응답 어느 자리에서도 010-XXXX-XXXX 형식 노출 금지
- CTA 자리에는 한 줄 = **"문의: litt.ly/wellperion"** 만 사용 (또는 단순 `litt.ly/wellperion`)
- 무료체험·예약·문의 모두 Litt.ly 단일 진입점 — 거기서 사전 예약 또는 매니저 라우팅
- 네이버 블로그·카페·당근 등 다른 채널은 별도 룰(채널별 CTA — `feedback_channel_cta_rules`) 적용; 본 룰은 **IG 한정**
- compose_*.py 등 합성 스크립트의 CTA 카피 매핑 시 자동 적용
