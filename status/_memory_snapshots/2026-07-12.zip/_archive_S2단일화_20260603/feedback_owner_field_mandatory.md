---
name: 담당자 필드 필수 입력 — DB 레코드 생성 시 누락 금지
description: C-레벨 에이전트가 Start 기획·운영 아카이브·(주)웰페리온 하위 DB에 레코드 생성할 때 "담당자" relation 필드를 본인 AI 역할로 반드시 채워넣어야 한다.
type: feedback
originSessionId: 1bb3b40d-edd1-4c3d-9bd9-b8513c1041e9
---
웰페리온 Notion DB에 새 레코드(기획안·결과물·정립 페이지 등) 생성 시 **"담당자" relation 필드는 반드시 본인 AI 역할로 연결**해야 한다. 공란 생성 금지.

**Why:** GM님이 직접 지시 (2026-04-17, "[CPO-001] 담당자 누락 있네 확인해주고, 이런 실수 반복하지 않도록 해"). 담당자 누락 시 Watcher 자동화의 `OWNER_PSP_MAP` 매핑이 실패 → PSP 정립 자동 이관 불가 → 파이프라인 끊김. 또한 조직 R/R 추적 불가.

**[2026-05-20 의미 재해석 — 전사 R/R 대전환 반영]**
본 메모리의 "담당자 relation = 본인 AI 역할" 원칙은 유효하되, 의미가 **"행정 서포트 라우팅 키"**로 재해석됨. 최종 책임자 오너십은 별도 신설된 `실무진(최종 책임자)` select 필드로 분리되어 실무직원이 보유. 두 필드 분리 의무:
- `실무진(최종 책임자)` = 실무직원 6옵션 select (메모리 [[project_main_owner_field_options]])
- `담당자` = AI C-Level relation (이 메모리 원칙 유지, 단 의미는 행정 서포트)
- 자세한 R/R 대전환은 메모리 [[feedback_role_inversion_main_support]] 참조.

**담당자 relation 대상 AI 조직 DB page_id** (조직 DB: `33f0407d-a948-80d2-ad27-000b132ef146`)
- AI CEO: `33f0407d-a948-8083-a829-fcf4468a7845`
- AI CFO: `33f0407d-a948-8131-b5b7-f461a3847774`
- AI CHRO: `33f0407d-a948-81ba-a202-f93ce049f41d`
- AI COO: (조직 DB 에서 확인 후 OWNER_PSP_MAP 에 합께 기입)
- AI CPO: `33f0407d-a948-81c6-b91e-ebdf9402b471`
- AI CMO: `33f0407d-a948-81f2-a45a-daebd2907286`
- AI CTO: `33f0407d-a948-81d3-a817-dc514967835c`

**How to apply:**
- 각 C-레벨 에이전트 자체에 하드코딩된 본인 relation ID 를 써서 create-pages 호출 시 `"담당자": "<본인 page_id>"` 포함.
- CEO 가 C-레벨 위임 프롬프트 작성할 때도 "담당자 필드 본인 AI 역할로 필수 연결" 명시.
- 레코드 생성 후 즉시 `retrieve-a-page` 로 담당자 relation 비어있지 않은지 검증하는 "self-check" 단계 추가 권장.
- Watcher (archive_result_watcher / planning_to_archive_watcher) 는 담당자 비어있는 레코드 감지 시 이관 중단 + 텔레그램 경고 발송하도록 확장 권장.

**위반 시:** 발견 즉시 담당자 채우고 CEO 보고. 재발 방지를 위해 원인 분석 메모리에 추가.
