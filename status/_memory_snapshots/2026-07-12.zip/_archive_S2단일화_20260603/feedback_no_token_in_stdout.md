---
name: 토큰·자격증명 stdout 노출 금지 — 명령 실행 시 redirect 의무
description: Bash로 텔레그램·Meta·Notion 등 자격증명 사용 명령 실행 시, 실패 트레이스가 토큰을 stdout에 노출. requests 호출 등은 stderr를 /dev/null로 redirect하거나 try/except로 감싸 토큰을 trace에 노출 금지.
type: feedback
originSessionId: f1c097c3-c852-4bd4-956e-5a76cdd3416f
---
CEO·C-Level이 Bash로 자격증명(Bot Token, Meta Token, API Key 등) 사용 외부 API 호출 시, 실패 시 urllib3·requests 트레이스가 URL에 포함된 토큰을 stdout/stderr 그대로 노출함. 노출 시 즉시 회전 검토 필요.

**Why:** 2026-04-30 CEO가 텔레그램 API getWebhookInfo 시도 중 ConnectTimeout 발생, requests 트레이스에 `bot8297784147:AAFxi1HGVYfqn4EuVtO3pgpaqbNdiVGiUh4` 형식 텔레그램 BOT_TOKEN 평문 노출. 사고 트리거: 일시 네트워크 차단 + try/except 부재. 향후 동일 사고 발생 가능성 존재.

**How to apply:**
- Bash로 토큰 사용 외부 API 호출 시 반드시 try/except로 감싸고, except에서는 `type(e).__name__`과 메시지 80자만 출력. 풀 트레이스 stdout 금지
- 또는 `2>/dev/null` 또는 `2>&1 | head -3`로 stderr 출력 제한
- requests URL 패턴: f-string에 토큰 포함 시 트레이스 노출 100% — 가능하면 `requests.Session()` + headers Authorization 또는 query param 분리
- 토큰 노출 발생 시: ① 메모리에 사고 기록 ② GM님께 즉시 1줄 보고 ③ 토큰 회전 결재 요청
- 자격증명 입력은 항상 `getpass` 사용, 명령줄 인자·`echo`·`-c "...token..."` 패턴 금지 (cmd history 평문 잔존)
- 텔레그램 BOT_TOKEN은 이미 `.env` 평문 저장 상태이므로 .env 자체를 keyring 이관하는 별건 검토 필요 (`feedback_credentials_policy` 정신 동일)
- **검색 단계도 동일 통로 (2026-05-10 CTO 자체 발견)**: 자격증명을 담은 파일을 grep/Select-String 등으로 조회할 때 `output_mode: "content"` 또는 매칭 라인 출력은 토큰 값을 transcript에 노출시킴. 토큰 검색은 (a) `output_mode: "files_with_matches"`로 파일 위치만 확보, (b) Get-Content + regex 캡처를 변수에 저장 후 `-replace` 마스킹, (c) `findstr /N` + 라인번호만 출력 중 1택. content 출력 직접 금지.
