---
name: feedback_daemon_autostart_check
description: 상시 프로세스(텔레그램 봇·스케줄러)는 부팅 자동기동(ONLOGON 예약작업) 등록 여부 점검 의무
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2e762195-0239-44fb-bcb7-ab9a4f1556ce
---

상시 가동돼야 할 프로세스(`telegram_bot/bot.py`, `telegram_bot/daily_scheduler.py`)가 **부팅 자동기동에 등록돼 있지 않은 채 수동 기동 상태**로 떠 있던 것을 발견(2026-06-01). 예약작업·레지스트리 Run 어디에도 없었음 → **PC 재부팅 시 보고봇·알림·정기보고 전체가 안 살아나는** 잠재 사고.

**Why:** 봇/스케줄러는 한 번 떠 있으면 정상 동작해 보이지만, 자동기동 미등록이면 재부팅 한 번에 전 보고 라인이 침묵한다. 코드가 멀쩡해도 "어떻게 다시 뜨는가"가 보장돼 있지 않으면 인프라가 아니다.

**How to apply:**
1. 상시 프로세스 점검 시 가동 여부(`Get-Process`)뿐 아니라 **재기동 경로**까지 확인: `Get-ScheduledTask` ONLOGON 등록 + 실제 task 존재 여부.
2. 등록 스크립트: `telegram_bot/register_task_scheduler.bat`(WellperionDailyScheduler + WellperionTelegramBot, `/SC ONLOGON`, `C:\Python314\python.exe`). schtasks 생성은 **관리자 권한 필수** → 현 CLI 세션은 비관리자라 GM 직접 실행.
3. 코드 교체(예: pre_task_notifier) 후 실제 적용도 같은 재기동에 의존 — daily_scheduler가 import한 모듈은 메모리 로드라 파일만 바꿔선 적용 안 됨.

관련: [[feedback_critical_scripts_git_tracked]] [[reference_powershell_scheduledtasks_limitation]] [[project_ceo_verify_watcher]]
