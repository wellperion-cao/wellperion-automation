---
name: feedback-dual-ssot-only
description: "SSOT 2개만 기억. 백엔드 = GitHub (repo state), 프론트 = 가이드허브 (시드·UI). 그 외 모든 캐시·백로그·archive는 SSOT 아님."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 95f25e87-664d-4768-8474-f1e966ac70bc
---

# SSOT 2개만 기억 (2026-05-29 GM 명시)

웰페리온 자동화 운영의 SSOT는 다음 2개로 한정한다.

| 계층 | SSOT | 역할 |
|---|---|---|
| 백엔드 | **GitHub repo** (`wellperion-cao/wellperion-automation`) | 코드·자산·git log·PR·Actions 등 상태 진실 |
| 프론트 | **가이드허브** (`3. 웰페리온 가이드/wellperion_guide(main).html` → GitHub Pages) | 시드·할일·KPI·UI 사용자 가시 진실 |

**Why:** SSOT 분산이 사고 유발. 오늘(2026-05-29) 폐기된 `ceo_inbox.jsonl`에서 회수 항목 2건(Apps Script 재배포·COO 캘린더뷰)을 끌어와 우선순위에 등록 → GM 지적. [[feedback-no-lookback-tomorrow-only]] 위반. SSOT가 1개도 아니고 N개도 아닌 정확히 2개여야 일관성 유지 가능.

**How to apply:**
- 오늘 할일·우선순위·진행 상태 = **가이드허브 시드 SSOT 단일 참조** (다른 inbox·archive 끌어오기 금지)
- 코드·자산·git 상태 = **GitHub repo 직접 조회** (캐시·로컬 백로그·메모리 추정 금지)
- archive·DEPRECATED·폐기된 자산 = 회수 대상 아님. "지나간 건 내려놓고 내일 것만"
- Notion DB·텔레그램 백로그·jsonl·메모리는 보조 컨텍스트일 뿐 SSOT 아님. 충돌 시 GitHub/가이드허브 우선
- CEO·6 C-Level 모두 작업 시작 시 2개 SSOT만 fetch 후 진행

[[feedback-no-lookback-tomorrow-only]] · [[project-master-framework-page]] · [[project-guidehub-ssot]] 결합.
