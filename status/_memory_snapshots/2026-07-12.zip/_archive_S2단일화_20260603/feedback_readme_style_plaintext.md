---
name: feedback-readme-style-plaintext
description: _README·INDEX 같은 설명 문서는 마크다운 마크업 최소화 (대시·아포스트로피·굵게 줄임). 평문·번호 위주로 작성.
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 11519ba0-2bd5-41d2-a662-f8cd0e047d8e
---

# _README / INDEX 표기 스타일

설명용 문서(_README.md, INDEX.md, 가이드 문서)는 마크다운 마크업이 많으면 GM님이 읽기 불편함. 다음 규칙으로 작성한다.

## 줄임 대상
1. `-` 불릿 → `1.` `2.` 번호 또는 빈 줄 위주의 평문 단락
2. `**굵게**` → 평문. 정말 강조 필요하면 대괄호 [중요] 같은 한글 prefix
3. ``` `code` ``` (인라인 코드 백틱) → 가능하면 평문. 단 파일 경로·명령어는 그대로
4. `>` 인용 블록 → 가능하면 평문

## 유지해도 되는 것
1. 헤더 `#` `##` (구조 잡기)
2. 표 (한눈 비교용)
3. 파일 경로·명령어 표기 (실제 실행해야 하므로)

## Why
GM님 2026-05-23 피드백 "_README.md 너무 좋은데 -·'·** 이런게 보기 불편". 마크업 자체가 노이즈로 작용.

## How to apply
1. 신규 _README·INDEX 작성 시 처음부터 평문 위주
2. CEO 답변 메시지 표·마크업은 별개 (GM 한눈 파악용은 OK)
3. 기존 마크업 많은 문서 → 새로 patch할 때 함께 정리

[[project-asset-locations]]
