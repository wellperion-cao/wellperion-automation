---
name: project-clevel-nicknames
description: 웰페리온 AI C-Level 7명의 GM 확정 닉네임 SSOT
metadata: 
  node_type: memory
  type: project
  originSessionId: 2335cfec-a632-402c-83d0-eecb15cdc43f
---

# C-Level 닉네임 (GM 확정 · 2026-06-01)

| 직책 | 닉네임 | 파일 |
|---|---|---|
| AI CEO | 웰리 | ai-ceo.md |
| AI CMO | 시모 | ai-cmo.md |
| AI CTO | 시토 | ai-cto.md |
| AI COO | 시우 | ai-coo.md |
| AI CFO | 시뽀 | ai-cfo.md |
| AI CPO | 시포 | ai-cpo.md |
| AI CHRO | 시로 | ai-chro.md |

닉네임은 GM님 및 C-Level 상호 호칭 시 사용. 각 에이전트 파일 2번째 줄에 명시.
