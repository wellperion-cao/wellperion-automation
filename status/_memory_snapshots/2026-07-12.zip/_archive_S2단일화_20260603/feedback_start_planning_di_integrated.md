---
name: Start 기획 = 신규 기획 v2.0 (DI 통합) 단일 템플릿
description: Start 기획 DB 템플릿은 신규 기획 v2.0 (Deep Interview 통합) 단일 운영. 자동 승인 트리거는 옵션 A(작성 후 사용자 상태=승인 요청 수동 전환).
type: feedback
originSessionId: 0fab724c-bbbc-46ff-8c0a-9b220d60d3c9
---
Start 기획 DB 템플릿은 「신규 기획 템플릿 v2.0」(Deep Interview 통합, 6섹션) 단일 운영. 별도 Deep Interview 템플릿은 archive 처리됨. 작성 후 자동 승인 요청 트리거는 옵션 A(사용자가 상태=승인 요청 수동 전환) 채택.

**Why:** 2026-05-07 GM님이 "Start기획에 Deep Interview 템플릿이랑 신규기획 템플릿 합병하고, 글 쓰면 승인 요청 들어가는건가?" 직접 질의. CEO 답변 후 "A" 결정. 6섹션 통합 본문 = ① 핵심 요약 ② DI 모호성 검증 5차원(가정·범위·결과 정의·실패 시나리오·검증 기준) ③ 실행 5단계 ④ 위험·대응 ⑤ 승인·진행 ⑥ 작성 가이드. CEO가 결정만 하고 실제 patch 누락하여 GM님 재질책. CTO 합병 patch로 이행 완료.

**How to apply:** Start 기획 DB에 신규 레코드 등록 시 본 v2.0 템플릿 본문 구조 따를 것. Deep Interview 템플릿 별도 신설·복원 금지. 작성 완료 → 사용자가 직접 상태='승인 요청' 변경 시에만 bot.py가 폴링·텔레그램 알림 발송. 새 페이지 생성 시 자동 승인 요청 default 금지(옵션 B 폐기). 본문 마지막 표식으로 자동 상태 patch(옵션 C)는 별건 R&D.

**관련 page_id:**
- 신규 기획 템플릿 v2.0: `3440407d-a948-8151-9df1-c86246f62ec7` (담당자 = AI CEO)
- Deep Interview 템플릿: `3560407d-a948-81c6-a8b9-d5d7472d801e` (in_trash=true)
- Start 기획 DB: `3430407d-a948-8156-afde-e663227cb7a1`
