---
name: 파이프라인 = 2단계 단일 흐름 (2026-05-10 신지시)
description: Start 기획DB → 운영 아카이브[결과물DB] 2단계 단일 흐름. 6-Stage 폐기. 「초안 완료」 클릭 시 기획서 본문이 PSP 원칙으로 재정렬된 1장 인쇄용 산출물 자동 생성. PSP는 정렬 기준이지 추출 대상이 아님.
type: feedback
originSessionId: 7c32475d-5da1-4db0-a3bc-172d761a47b6
---
웰페리온 운영 파이프라인은 2단계 단일 흐름이다. 옛 6-Stage(T-2+T-3 양립) 정책은 **2026-05-10 GM님 신지시로 전면 폐기**되었다.

**Why:** 6-Stage 구조는 결재 게이트·종착지·운영 아카이브·Changelog 단일 진실 원본 등 규칙이 누적되며 C-Level 혼선 + 다중 DB patch 사고를 유발. GM님이 본질 단순화 결단 — "기획 작성 → 인쇄 가능 산출물 자동 생성" 단 2단계로 압축. **PSP(Product/System/Philosophy, 제품·시스템·철학)는 기획서 본문을 1장 인쇄용으로 재정렬·구조화하는 편집 원칙**이며, PSP 부분만 추출하는 것이 아니라 기획서 본체(핵심 요약·DI 5차원·실행 5단계·위험·대응·승인·진행 등)를 PSP 프레임에 맞춰 압축·정렬한 결과가 산출물이다.

**How to apply:**

## 1. 단계 1 — Start 기획[신규기획DB]
- DB ID: `3430407d-a948-8156-afde-e663227cb7a1`
- 작성자: 실무진·C-Level 모두
- 본문 표준: **신규기획 v2.0 6섹션**
  - ① 핵심 요약
  - ② Deep Interview(딥 인터뷰) 5차원
  - ③ 실행 5단계
  - ④ 위험·대응
  - ⑤ 승인·진행
  - ⑥ 작성 가이드
- 자체 검수 후 상태 = 「**초안 완료**」 1회 클릭 → 단계 2 자동 진입

## 2. 단계 2 — 운영 아카이브[결과물DB]
- DB ID: `3430407d-a948-819d-8769-f739221cf4c8`
- 트리거: 단계 1의 「초안 완료」 클릭 (CTO 자동화 코드 5/12 구현 예정)
- 자동 생성 내용:
  - **기획서 본문을 PSP 원칙으로 재정렬·구조화한 1장 인쇄용 산출물 페이지**
    - **P**roduct: 무엇을 만드는가 — 산출물·실행안 (핵심 요약·실행 5단계 압축)
    - **S**ystem: 어떻게 작동하는가 — 실행 단계·R/R·트리거·위험 대응
    - **P**hilosophy: 왜 하는가 — 목적·원칙·KPI·DI(딥 인터뷰) 핵심
  - PSP는 **정렬 기준**이지 추출 대상이 아님 — 기획서 본체가 산출물 본체
  - 본문 최상단 📄 **최종 산출물 Callout** 자동 삽입
  - **프린트할 수 있는 최종 산출물 페이지(핵심 요약 본) 자동 추가** (2026-05-20 GM 지시) — Callout 바로 아래에 인쇄용 최종 1장 페이지 생성, Cmd/Ctrl+P 시 통일된 한 장 출력
  - 상태 = 「**인쇄 가능**」으로 진입
- 종착점: 작성자가 **Cmd/Ctrl+P**로 통일된 1장 인쇄 → 실제 업무·공유에 활용 가능한 기획 산출물
- **결과물DB 속성 (6개·최소화 2026-05-11 GM 지시 확정)**: 프로젝트명(title)·담당자(relation→AI 조직 DB)·목표 KPI(multi_select)·버전(text)·상태(select: 인쇄 가능)·최종 수정(시스템). **Start 기획 relation·식별자 rollup·작성자(실무진) 텍스트는 모두 DROP**. 원본 추적은 본문 Callout의 프로젝트명·버전·작성자 본문 표기로 충분.
- **Start 기획DB ↔ 결과물DB 양방향 relation 폐기** (2026-05-11). 단계 2는 독립 산출물 페이지. 본문 안에 원 기획서 복사 금지(`feedback_no_copy_paste`).

## 3. 분리된 DB — [COO] 운영 관리 아카이브 DB
- DB ID: `fbeac76b-e9c8-4698-ad95-f37dac99a715`
- 역할: COO 관할 프로젝트(SOP·매뉴얼·주차·운영·안전)의 **최종 완료본** 보관
- 단일 흐름과 **별도** — 결과물DB와 혼동 금지

## 4. R/R SSOT 페이지
- 자세한 흐름·R/R 정의: 「웰페리온 AI 운영 프레임워크」 페이지 **섹션 5.5**
- 분산·중복 금지 (`project_master_framework_page`)

## 5. 폐기·무효 항목
- 6-Stage 구조 (Stage 1~6)
- T-2(종착지 직접 + 운영 아카이브 슬림화) / T-3(GM님 의제 큐) 양립 정책
- 종착지(사이드바) 산출물 직접 운영 + Changelog 단일 진실 원본 정책
- 운영 아카이브DB 좁은 역할(결과 보고·KPI 분석·회고) 분리
- **Start 기획DB ↔ 결과물DB 양방향 relation** (2026-05-11 GM 지시 DROP)
- **결과물DB 식별자(SP-N) rollup** (양방향 relation 제거에 따라 DROP)
- **결과물DB 「작성자(실무진)」 텍스트 속성** (담당자 relation과 중복으로 DROP)
- **결과물 페이지 본문 「📜 원 기획서 (토글)」** — 원본 4섹션·Advisor 회신 복사 금지

## 6. 유지 항목 (단일 흐름과 호환)
- 사전 아카이브 선행 조회 의무 (`feedback_clevel_planning_flow`)
- 신규기획 v2.0 6섹션 = DI 통합 단일 템플릿 (`feedback_start_planning_di_integrated`)
- 담당자 relation 필수 (`feedback_owner_field_mandatory`)
- 네이밍 표준 `M.D-프로젝트명` (`feedback_naming_standard`)
- 버전 관리 +0.1 increment (`feedback_version_increment_rule`)
