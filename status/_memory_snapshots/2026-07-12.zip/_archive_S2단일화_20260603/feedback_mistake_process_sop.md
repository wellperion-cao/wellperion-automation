---
name: 실수·버그 재발 방지 5단계 SOP
description: 모든 버그/실수 발생 시 ①발견 ②원인진단 ③즉시수정 ④메모리+Notion DB 등록 ⑤재발방지 규칙까지 완주. 수정으로 끝나면 재발, ④⑤가 영구 방어선.
type: feedback
originSessionId: 472a3e16-de52-46a5-8ee9-b0c91b970284
---
버그·실수·오판 발생 시 **반드시 5단계를 완주**한다. 중간에 멈추면 동일 실수 반복.

**Why:** 2026-04-18~20 반복 실수(토큰 교체 후 scheduler 미재시작, .env DB ID 누락 등). GM님 2026-04-20 09:15 지시 — "실수 발생 시 확실하게 기억할 수 있는 프로세스".

**How to apply:**

### 5단계 SOP
1. **① 발견 (Discovery)** — 증상 기록: 시각·재현 조건·영향 범위
2. **② 원인 진단 (Root Cause)** — 표면 증상 금지. 진짜 원인까지 파고듦. 예: "401 에러" 아니라 "토큰 교체 후 기존 프로세스 미재시작으로 캐시된 구 토큰 사용"
3. **③ 즉시 수정 (Fix)** — 임시 조치 + 영구 수정 구분 기록
4. **④ 이중 기록 (Record)**
   - 메모리 파일: `feedback_mistake_<slug>.md` 신규 생성
   - Notion「실수 레지스터 DB」레코드 등록 (data_source_id는 MEMORY.md 참조)
   - MEMORY.md 인덱스에 1줄 추가
5. **⑤ 재발 방지 규칙 (Prevention)** — 체크리스트 or 자동화 추가. 예:
   - "토큰 교체 시 관련 프로세스 모두 나열 · 전원 재시작 확인"
   - ".env 수정 시 의존 스크립트의 `os.getenv` 호출 전수 검증"
   - 자동화 가능하면 watcher·lint·pre-commit hook 추가

### 적용 범위
- CEO·모든 C-Level 에이전트 전원 준수
- 검증되지 않은 "수정 완료" 보고 금지 → 반드시 ④⑤ 완주 후 보고

### 점검
- 매주 월요일 CEO가 실수 레지스터 DB 전수 조회 → 미완주 건 재진행 지시
- 유사 실수 3회 이상 발생 → 전사 SOP 업데이트 또는 자동화 투자

### 2026-04-20 즉시 소급 기록 2건
- 토큰 교체 후 scheduler 미재시작 (bot_unified.md 관련)
- daily_scheduler.py .env NOTION_PLANNING/ARCHIVE_DB_ID 누락
