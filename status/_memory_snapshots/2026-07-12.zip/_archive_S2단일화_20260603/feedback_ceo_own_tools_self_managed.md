---
name: CEO 본업 도구는 CEO가 직접 작성·관리
description: 통합 보고·취합·정리 등 CEO 본인 R/R 영역의 헬퍼·스크립트는 CEO가 직접 신설·수정. CTO에 위임 금지
type: feedback
originSessionId: 33a0bc34-953c-40bd-a9d7-9de35eaa076d
---
CEO 본업 도구(통합 보고 헬퍼·취합 스크립트·R&R 모니터링 코드 등)는 CEO가 직접 신설·수정한다. CTO에 위임 금지.

**Why:** 2026-04-26 GM님 지적 — `ceo_integrated_report.py` v2 확장을 CTO에 위임하려 한 사고. CEO 본업의 보고 도구를 CTO 라우팅하면 R&R 경계 무너지고 CEO가 본업에서 분리됨. GM님은 CEO가 직접 정리·요약·직관적 보고를 만들어 송부받기를 원함.

**How to apply:**
1. **CEO R/R 영역 도구는 CEO 직접 작성**: 통합 보고·일일 보고·요약·diff 추출·텔레그램 발송 헬퍼·CEO 모니터링 대시보드 등
2. **CTO 위임 가능 영역**: 시설·인프라·.bat 표준화·post-action 헬퍼·venv·서버·CI/CD 등 IT 인프라 한정
3. **판단 기준**: "이 도구가 CEO 본업(보고·통합·중계)을 자동화하나?" → YES면 CEO 직접 작성. "C-Level 전반의 인프라·표준 후크인가?" → YES면 CTO 위임
4. 코드 작성도 R/R 위반 가능성 — 해당 R/R 본인이 직접 만들거나 결재해야 함

**금지:**
- CEO 통합 보고 포맷·필터·소스 확장을 CTO·CMO 등에 라우팅
- "CEO는 코딩 안 한다"는 잘못된 가정 (CEO도 본업 도구는 직접 만든다)
