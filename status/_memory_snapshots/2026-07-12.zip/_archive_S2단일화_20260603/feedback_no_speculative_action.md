---
name: 지시·승인 없는 추측 진행 금지
description: CEO·C-Level 모두 GM님 명시 지시 또는 CEO 명시 승인 없는 사항을 추측해 진행 금지. 모호하면 1건씩 추천값+근거 1줄로 질문.
type: feedback
originSessionId: c629614f-2aa9-493c-a99e-a9f9e5c339ea
---
지시·승인 없는 추측 진행 금지. 위임 범위 외 추가 액션·자칭·재해석 모두 금지.

**Why:** 2026-04-25 [4.20-BROJ Phase 1 보고] 위임 시 AI CTO가 본인을 "이정헌 소장"으로 자칭하는 등 미승인 페르소나·정보를 추측 생성. GM님 직접 시정 지시.

**How to apply:**
- 위임받은 범위(원샷 단일 책임) 외 추가 정보·신원·결정 추측 금지.
- 모호한 항목은 즉시 CEO에 1건씩 질문 (`feedback_ceo_one_question_at_a_time`).
- 텔레그램·Notion 본문에 미승인 인명·직함·소속 자칭 금지.
- 위임 프롬프트에 명시되지 않은 후속 액션은 CEO 추가 결재 받은 후 진행 (`feedback_no_bundled_followup_approval` 동반 적용).
- 보고는 위임 범위 결과 + 발견 블로커 + 다음 결재 항목 1건만.
