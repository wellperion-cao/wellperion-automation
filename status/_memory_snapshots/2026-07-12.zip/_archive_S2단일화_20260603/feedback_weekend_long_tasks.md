---
name: feedback_weekend_long_tasks
description: 주말에는 오래 걸리는(긴 호흡) 작업을 CEO가 능동적으로 찾아 진행
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d94ea138-ce81-40c1-9df9-f62b7b2f25dc
---

주말에는 평일에 못 하는 "오래 걸리는 작업"을 AI CEO가 능동적으로 찾아서 진행한다 (2026-05-31 GM 지시, 토요일).

**Why:** 주말은 GM 실시간 지시·중단이 적어 긴 호흡의 대형 작업(전사 QA 스윕·리뉴얼·재설계·완성도 감사 등)에 적합. 평일엔 짧은 응답성 업무, 주말엔 누적 백로그·고도화를 소화하는 리듬.

**주말 운영방식 (2026-05-31 GM 정립): 전체 검증 → 문제점 보완 → 고도화 하나씩.** 단순 신규 빌드만이 아니라, 먼저 전사 실측 검증으로 문제를 찾아 보완하고, 고도화 항목을 하나씩 끝까지 처리(각각 독립 검증)한다.

**How to apply:** 주말 세션에서 CEO는 ① 백로그(큐·미실행 스펙·미완 파이프라인·메모리상 대형 과제) + 전사 실측 검증으로 문제점 수집 → ② 게이트 0(💰결제·🔒보안·외부발행 무관)인 자율 안전 작업 선별 → ③ 한눈 표 + 추천 1순위로 GM 결정(또는 자율 착수) → ④ 충돌 없게 파일 소유권 분리해 서브에이전트 병렬/직렬 위임 + CEO 배포본 실측 검증(에이전트 "검증 생략" 불허, CEO가 직접 재실측). **결재·권한 필요건(🔒보안·외부 GAS 재배포·관리자 권한 등)은 즉시 처리 말고 G1(김남욱GM) 내일 할일로 기록**해 GM이 회사 PC/권한 환경에서 처리하게 한다. [[feedback_minimize_approval_overhead]] · [[feedback_clevel_weekly_context_maintenance_scope]] · [[feedback_gm_slogan]]
