---
name: feedback_ssot_hardcoded_list_sync
description: 업무 현황 SSOT 카테고리·예산항목 추가 시 흩어진 하드코딩 목록 전수 동기화 필수
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d3de3966-d733-4b0d-a746-313d92b9381c
---

`coo/todo/업무 현황 SSOT.html`에 카테고리나 예산 항목을 추가/변경할 때, 한 곳만 고치면 회귀 발생. 추가 시 아래 전부를 함께 점검·동기화:
- 카테고리: `<select id=fCategory>` 옵션 · `CATEGORIES` · `CAT_COLORS` · `CATEGORY_TEMPLATES` · 정렬 `catOrder`(CATEGORIES.concat 사용 권장) · 대시보드 색상
- 예산: `<select id=fBudgetCategory>` 옵션(9개) · `BUDGET_CATEGORIES` · `routeApproval` switch case

**Why:** [8] 회의 추가 시 catOrder 하드코딩 1곳을 빠뜨려 회의 업무가 잘못 정렬되는 회귀가 났음(2026-06-02). 예산 ⑨ 시설물 리뉴얼은 routeApproval case 누락으로 결재 게이트가 우회되던 기존 버그도 동일 패턴.
**How to apply:** 가능하면 하드코딩 배열 대신 SSOT 상수(CATEGORIES 등)를 파생해 쓰고, 추가 시 grep으로 옛 목록 전수 확인. 관련: [[feedback_mistake_process_sop]], [[project_ops_meeting_cadence]]
