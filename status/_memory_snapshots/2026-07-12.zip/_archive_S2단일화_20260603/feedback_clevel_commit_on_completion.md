---
name: clevel-commit-on-completion
description: 모든 C-Level은 작업 완료 직후 즉시 git commit + push 의무
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 80777498-c2ef-4d1a-bdc6-40d7cfcb2d61
---

모든 C-Level(CEO 포함)은 작업 완료 직후 git commit + push 필수.

**Why:** 다른 C-Level 세션이나 CEO가 git log로 작업 내역을 파악해야 협업이 가능. 커밋하지 않으면 변경사항이 보이지 않아 [[clevel-parallel-dispatch]] 병렬 작업도 불가능. GM님이 직접 지시 (2026-05-28).

**How to apply:**
- 작업 단위별로 즉시 커밋 (한 작업 = 한 커밋)
- 커밋 메시지는 짧고 명확하게
- 커밋 직후 즉시 push (다른 세션이 볼 수 있도록)
- 묶음 커밋 X, 미커밋 상태 방치 X
- 가이드허브 g10 공통 탭에도 명시
