---
name: feedback_worktask_sheet_status_sync
description: "C레벨 작업 완료 시 status/{role}.json뿐 아니라 업무현황 시트(todo_done)도 완료 전환해야 G1 오늘할일에서 빠짐"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 4fd0f3b8-c77d-4cb6-9038-34919b52ad43
---

GM이 업무현황 SSOT 시트(Apps Script, `action=todo_*`)에 `[닉네임-NN]` 형식으로 등록한 작업(예: `[시토-01] 발행기 하드닝`)은, C레벨이 완료해도 `status/{role}.json`만 DONE 처리하면 **시트에는 "진행중"으로 잔존**한다. G1 오늘할일은 `gm1FetchSsot`가 이 시트에서 owner=C레벨·상태=진행중 행을 자동 합류(가이드허브 line ~6515)하므로, 시트가 진행중인 한 G1에 계속 떠서 GM이 "이미 끝난 일이 왜 있지?"로 혼란.

**Why:** 2026-06-02 GM이 G1의 "시토-01"을 질의 → 발행기 하드닝은 6/1 완료(status DONE)인데 시트 진행중 잔존이 원인이었음.

**How to apply:**
- C레벨 작업 완료 시 **두 SSOT 동기화**: ① `status/{role}.json` DONE ② 업무현황 시트 `action=todo_done&id=<TODO-...>` 호출(또는 GM이 카드에서 완료 클릭).
- 시트 id는 `action=todo_list`로 조회해 업무명 매칭으로 확보.
- 완료/보류는 G1에서 제외되고, 진행중·오늘시작만 합류됨.

**API:** `https://script.google.com/macros/s/AKfycbx...QvZ-7/exec` (SSOT_API_URL=TODO_API_URL 동일). GET + URLSearchParams, redirect follow, 응답 `{ok:true}`.

[[feedback_seed_completion_autocheck]] [[project_gm_unified_tasks]] [[feedback_clevel_commit_on_completion]]
