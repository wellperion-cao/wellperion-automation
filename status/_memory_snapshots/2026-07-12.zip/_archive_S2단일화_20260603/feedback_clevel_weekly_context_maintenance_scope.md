---
name: c-level
description: 6 C-Level 매주 월 09:00 컨텍스트 정비는 본인 영역 방대 누적 자료를 스스로 확인·정리정돈·고도화하는 핵심 본업. GM 지시 이상 자율 진화.
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 63d35c3d-04dd-4095-be62-d069a93c7814
---

6 C-Level의 매주 월 09:00 「Claude 시스템 컨텍스트 주간 정비」(CPO-002·COO-001·CMO-002·CHRO-005·CFO-004·CTO-003)는 **단순 컨텍스트 정비가 아닌 핵심 본업**. (2026-05-20 GM님 본업 정의 SSOT)

**Why:** 매주 방대하게 누적된 본인 영역 내용을 C레벨 스스로가 검토·정리정돈해 업무처리가 더 명확해지고, **GM 지시 이상으로 자율 진화·고도화**되도록 만드는 게 본업. GM님이 정말 중요한 업무로 명시.

**본업 범위:**
- 본인 영역 마스터페이지·하위 페이지·SOP·정책 누적 검토
- 중복·구식·과잉 항목 정리
- 업무처리 흐름 명확화 (모호한 단계·기준 정의)
- **GM 지시 이상 자율 진화** — 새로 발견한 개선점·고도화 안 자체 제안·반영
- 6 C-Level 모두 동일 의무 (각자 본인 R/R 범위)

**반자동 실행 모델 v2 (2026-06-02 GM 확정 · SSOT=가이드허브):**
- 자동 무인 실행 아님. ① 매주 월 09:00 텔레그램 알림(`pre_task_notifier`+`status/schedule.json`)=리마인더 → ② 그 주 월요일 세션 열리면 **CEO(웰리)가 6 C-Level에 "주간 정비 시작" 일괄 위임** → ③ 각자 본인 범위(가이드허브 범위표) 정비 → ④ **CEO가 6건 취합해 GM께 1회 통합 보고**(취합 경로가 핵심).
- 세션 안 열리면 다음 가능일 수행, 소급 추적 X.
- 정비 엔진 `.py` 없음(과거 `scripts/context_maintenance.py` 안내는 죽은 참조였음 — 제거). 가이드허브 핵심 프롬프트 STEP 1~5를 세션에서 수동 실행.
- 죽은 자동화 정리됨: 작업스케줄러 `Weekly-Context-Maintenance-Arm`(일 23:00 실패) 폐기, 등록배치 `register_arm_scheduler.bat` 삭제.
- 식별자 SSOT=가이드허브 범위표(CMO-002·CPO-002·COO-001·CHRO-005·CFO-004·CTO-003). schedule.json sid·작업스케줄러명은 SSOT 아님.

**상태 정합:**
- 매주 정기 가동되는 본업이므로 **항상 진행중** 상태 정합 (가동 사이 완료 사이클은 OK)
- 진행예정으로 되돌리면 매주 가동 끊김 = 사고

**관할 6 자동 태스크:**
| 식별자 | 담당 |
|---|---|
| CPO-002 | AI CPO |
| COO-001 | AI COO |
| CMO-002 | AI CMO |
| CHRO-005 | AI CHRO |
| CFO-004 | AI CFO |
| CTO-003 | AI CTO (전사 인프라) |

**How to apply:**
- 매주 월 09:00 가동 후 본인 페이지·SOP·정책 검토 → 정리정돈·고도화 산출물 누적
- 산출물 = Before/After 측정 표 + 정비 항목 prepend (페이지 본문)
- GM 추가 지시 없어도 자율 발견·개선 안 제안 의무
- SP-28 5단계 단순화 정비 항목 추가 (`feedback_role_inversion_main_support` 정합) — 마스터페이지 색인 DB의 본인 영역 페이지 `단순화 상태` patch

**연동 메모리:** [[feedback_status_change_gm_exclusive]] · [[feedback_role_inversion_main_support]] · [[feedback_minimize_task_count]] · [[feedback_ceo_continuous_update_sop]] · [[feedback_no_status_regression_on_body_patch]]
