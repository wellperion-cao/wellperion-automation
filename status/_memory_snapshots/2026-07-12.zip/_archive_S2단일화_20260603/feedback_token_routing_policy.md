---
name: feedback-token-routing-policy
description: 토큰 라우팅 매트릭스 (Haiku/Sonnet/Opus 3계층). 메인 = Opus 유지. 반복 작업은 Sonnet/Haiku 서브에이전트 위임 의무. 메인 모델로 반복 처리 시 사고.
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 95f25e87-664d-4768-8474-f1e966ac70bc
---

# 토큰 라우팅 매트릭스 (2026-05-29 GM 옵션 B 결재)

메인 CEO·6 C-Level 에이전트는 Opus 4.7 유지(판단·결재 본업). 반복 작업(가동·집계·patch·git·송부·콘텐츠 가공·로그 정리)은 무조건 Sonnet/Haiku 서브에이전트(`executor` 등)로 위임. 메인 모델로 반복 작업 처리하면 토큰 사고 — 위임 누락 자체가 위반.

## 매트릭스

| 모델 | 가격 비율 | 담당 |
|---|---|---|
| Haiku 4.5 | 0.2x | 단순 Notion read · 1줄 보고 · 텔레그램 송부 · lookup |
| Sonnet 4.6 | 1x | 자동화 가동 · 집계 · patch · git · 콘텐츠 가공 · 일일 보고 빌드 · 로그 정리 |
| Opus 4.7 | 5x | 판단 · 결정 · 진행 · 검토 · 결재 · 정책 정립 · 이슈 진단 · R&D 방향 · Peer Cross-Check |

**Why:** GM 토큰 절감 + Opus 5x 가격 부담. 메인 에이전트가 반복 작업까지 직접 처리하면 Opus 토큰을 Sonnet 가격 5배로 태우는 셈. 판단·결재는 양보 못 함(Opus 유지) → 반복만 분리.

**How to apply:**
- 가동·집계·patch·git·송부 → 즉시 `executor`(Sonnet) 또는 Haiku 위임. 메인이 직접 Bash·Edit 다중 수행 금지
- 판단·결재·진단·정책 정립·중계 → 메인(Opus) 직접 처리
- 헷갈리면 1건씩 분류 → 위임 vs 직접 결정 후 진행
- 옵션 A(.bat 분리)·옵션 C(자동 키워드 라우팅)는 보류

OMC `<delegation_rules>` + `<model_routing>` 정합. [[feedback-ceo-no-direct-execution]] 본업 외 영역 직접 실행 금지 원칙과 결합.
