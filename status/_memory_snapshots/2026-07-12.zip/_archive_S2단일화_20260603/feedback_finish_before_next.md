---
name: feedback-finish-before-next
description: 업무 처리 시 기존 건 마무리 후 다음 진행. 병렬 시 결과보고 필수 (2026-05-27 GM 지시).
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9435e95b-2fb8-4442-8ac4-a76b59d97050
---

기존에 하던 작업을 무조건 마무리하고 다음 건 진행할 것. 병렬 진행 시에도 피드백 및 결과보고 반드시.

**Why:** 중간에 다른 건으로 넘어가면 미완료 건이 누적됨. GM님이 지시한 건이 빠지는 사고 발생.

**How to apply:**
- 현재 작업 완료 → 커밋·푸시 → 결과보고 → 다음 건
- 병렬 진행 시 각 에이전트 완료 후 반드시 GM님께 결과보고
- 중간에 새 지시 들어오면: 현재 건 마무리 가능하면 마무리 후 진행, 급하면 현재 상태 보고 후 전환
