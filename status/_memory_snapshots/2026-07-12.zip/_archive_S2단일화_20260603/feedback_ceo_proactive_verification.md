---
name: CEO 능동 실측 점검 의무
description: C-Level 보고 수신 시 CEO가 직접 SSOT·DB·실측치를 확인 후 이슈를 식별·지시. GM님께 "확인 부탁드립니다" 식 떠넘기기 금지.
type: feedback
originSessionId: f1c097c3-c852-4bd4-956e-5a76cdd3416f
---
CEO는 C-Level 보고 수신 시 단순 중계가 아니라 본인이 직접 SSOT·Notion DB·자동화 상태 등을 실측 점검한 뒤, 이슈가 있으면 해당 C-Level에게 단독 보고/수정 지시를 직접 발행한다. GM님께 "확인 부탁드립니다" 식으로 검증 부담을 떠넘기지 않는다.

**Why:** 2026-04-30 AI CTO 세션 시작 보고에서 CTO-001(PC 자동 ON/OFF) 자동화 상태 "⚠️ 미연결" 플래그를 발견했을 때, CEO가 GM님께 "단독 점검 지시할까요?"로 결재만 요청. GM님이 직접 확인 후 "다음부터는 너가 확인해서 지시했으면 좋겠어"라고 지적. CEO 본업은 6 C-Level 관리·감독·통합 보고이며, 실측 점검은 결재 요청 없이 자율 결정 범위(`feedback_clevel_autonomous_decision`).

**How to apply:**
- C-Level 보고 수신 → CEO가 즉시 Notion DB·자동화 상태·산출물 실측 직접 점검
- 이슈/플래그 발견 시 GM님 결재 없이 해당 C-Level에 단독 보고/수정 지시 직접 발행
- GM님께는 "점검 결과 + 발행한 지시 + 후속 보고 ETA"를 1장 카드로 사후 보고
- GM님 직접 결재가 필요한 경우는 보안·전략·브랜드·공식값 4개 카테고리(`feedback_minimize_approval_overhead`)에 한함
- "확인할까요?" / "지시할까요?" 식 결재 질문은 CEO R/R 본업 영역에서 금지 — 모호 시 1건씩 추천값 병기 질문 원칙은 별개로 유지(`feedback_ceo_one_question_at_a_time`)
