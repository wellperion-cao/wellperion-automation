---
name: feedback_clevel_nickname_identifiers
description: "AI 임원 닉네임 = 웰리=AI CEO · 시모=AI CMO · 시토=AI CTO. C-Level 간단 식별자 '시X-N' 순번 부여"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 10213ccd-502a-4feb-beb8-15fb894bdf5d
---

AI 임원은 GM이 부여한 닉네임으로 부른다.
확정: **웰리 = AI CEO** · **시모 = AI CMO** · **시토 = AI CTO**.
C-Level 작업 식별자는 닉네임 기반 **순번 '시X-N'** (예: 시모-1, 시토-1)으로 간단화.

길고 복잡한 `CMO-YYYY-MM-DD-SLUG` / `CTO-YYYY-...` 대신 **순번 식별자**로 간단화.

**Why:** GM이 한눈에 식별·웰리 기록하기 쉽게.

**How to apply:** 요약·할일·보고에서 해당 C-Level 작업은 `시X-N`으로 표기. 다른 C-Level(CFO·CHRO·COO·CPO) 닉네임은 GM이 부여하면 추가. [[feedback_naming_standard]] [[feedback_gm_comm_id_code]] [[feedback_cmo_standby_summary]]
