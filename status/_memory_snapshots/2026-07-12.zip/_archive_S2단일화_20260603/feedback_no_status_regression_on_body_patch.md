---
name: no-status-regression-on-body-patch
description: "업무자동화DB 본문 patch 시(정비 토글 append 등) '상태' 필드 동시 patch 금지. 진행중 → 보류 회귀 = auto_task_watcher 침묵 사고. status_regression_guard 폐기 (2026-05-22)."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 93a84c2a-e50c-474c-b762-4be73565075e
---

업무자동화DB 레코드 본문 patch(예: "[완료] 5.X 정비 결과 (WkXX)" 토글 append) 시 `properties.상태` 필드를 절대 동시 patch하지 않는다. 본문 변경과 상태 변경은 분리된 작업으로 처리.

**Why:** 3회 재발 사고(2026-04-26 CMO-005 · 2026-05-10 CMO-001/005 · 2026-05-13 CMO-001/005) — Claude 세션이 본문 toggle append 시 페이로드 default로 상태 reset이 함께 들어가 진행중 → 휴면 회귀 발생. `auto_task_watcher` 트리거 조건(상태=진행중 + 실행시간 ±10분)이 불충족되어 매일 10:00/10:30 KST 자동 가동 침묵.

**How to apply:**
- 본문 patch만 필요할 땐 `properties.상태` 필드를 페이로드에 포함하지 말 것 (Notion API는 미포함 필드를 변경하지 않음).
- 상태 전환이 필요할 땐 별도 patch 호출로 분리 (본문 patch 1회 + 상태 patch 1회 = 2회).
- 모든 C-Level 에이전트 정비·세션 시작 토글 append 코드는 본 규칙 준수.

**가드 폐기 (2026-05-22 GM 지시):**
- `status_regression_guard.py` 폐기 — 자동 복원은 GM 의도까지 덮어쓰는 무의미 사이클이었음.
- 동시에 업무자동화DB select 옵션 "진행예정" 폐기 → 휴면 상태는 "보류" 단일화. 보류 → 진행중 전환은 GM 수동 권한 단독([[feedback_status_change_gm_exclusive]]).
- 본문 patch 코드의 상태 동시 patch 금지는 여전히 유효. 위반 시 즉시 자동 가동 침묵 사고 발생 가능 — 호출자 코드 측 차단이 유일한 방어선.

**관련 메모리:** [[feedback-auto-task-trigger-policy]], [[feedback-auto-task-id-visibility-only]], [[feedback-clevel-completion-telegram]], [[feedback_status_change_gm_exclusive]].
