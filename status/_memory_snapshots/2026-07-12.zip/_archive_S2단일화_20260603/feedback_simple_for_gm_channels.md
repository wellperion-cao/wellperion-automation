---
name: feedback-simple-for-gm-channels
description: GM 발신 채널(텔레그램·가이드허브)은 일상어 의무. 기술 용어·내부 식별자 금지. GM이 쉽게 이해할 수 있게.
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 95f25e87-664d-4768-8474-f1e966ac70bc
---

# GM 발신 채널 일상어 의무 (2026-05-29 GM 지시)

GM에게 직접 보이는 2 채널(텔레그램·가이드허브)은 **일상어**로만 작성한다. 기술 용어·내부 식별자·코드 경로 금지.

**Why:** 오늘 보낸 텔레그램 [CEO 검증 통과] COO 64f2c83 → 작업·1층 기계 검증·status/coo.json·_ceo_log.jsonl 등 기술 용어 가득. GM이 한눈에 의미 파악 어려움. 가이드허브 메타 시드 description도 in_trash·callout·migration 등 내부 용어 다수. [[feedback-explain-simply]] · [[feedback-ceo-essence-oversight-and-brief]] 위반.

**How to apply (GM 발신 채널 한정):**

| 금지 | 대체 |
|---|---|
| status/coo.json · _ceo_log.jsonl · _queue.json | "기록 완료" / "내부 메모" |
| VERIFIED · ASSIGNED · IDLE · PENDING_DEPENDENCY | "통과" · "맡김" · "쉬는 중" · "대기" |
| 1층 기계 검증 · 2층 AI 검증 | "기본 점검" · "내용 점검" |
| FIFO 큐 · 상태 머신 · watcher · polling | "할 일 줄" · "상태 표시" · "자동 감시" · "확인" |
| 커밋 sha (64f2c83 등) | "어제 업데이트" 또는 생략 |
| in_trash · callout · IIFE · migration | 모두 생략 또는 "정리·표시·이동" |

**구조:**
- 텔레그램 1건 = 3줄 이내 (무엇·결과·다음)
- 가이드허브 시드 description = 한 문단 일상어 (내부 메모는 memo 필드 X — 다른 곳에 별도)
- CEO 본업 ④ 텔레그램 발신 시 보낼 메시지를 작성한 뒤 "GM이 1초만에 의미 파악되는가?" 자기점검 의무

**예시 정정:**

| 원본 (기술 용어) | 정정 (일상어) |
|---|---|
| `[CEO 검증 통과] COO 64f2c83\n1층 기계 검증 OK (수동 트리거)\nstatus/coo.json status:VERIFIED + _ceo_log.jsonl 갱신 완료` | `COO 어제 작업 점검 완료 ✓\n업무 현황 시트 0건 사고 원인 차단됨` |
| `[AI CEO → AI CTO] 4단계 선행 위임 task — CTO-2026-05-29-NOTION-DEPRECATE` | `CTO 할 일: 노션에 남은 자료 가이드허브로 옮기고 노션 원본은 [폐기] 표시` |

[[feedback-explain-simply]] · [[feedback-ceo-essence-oversight-and-brief]] 결합 강화.
