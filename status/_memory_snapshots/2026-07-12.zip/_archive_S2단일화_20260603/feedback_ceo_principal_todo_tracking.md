---
name: GM님 본인 to-do 트래킹 SOP — GM TO DO LIST 활용
description: GM님이 직접 알려주신 본인 업무를 CEO가 GM TO DO LIST DB에 추가·매일 08:00 일일 통합 보고에 합류·진행 상태 추적. 두 단계 보호(추가 알림 + GM님 확인)
type: feedback
originSessionId: c7b6546c-5746-4a60-b44a-0ccf59e8ec20
---
GM님이 채팅·텔레그램으로 본인 업무를 알려주시면 AI CEO가 GM TO DO LIST DB(사이드바 6번)에 항목을 추가하고, 매일 **08:00 일일 통합 보고**에 합류시켜 진행 상태를 지속 추적한다.

**Why:** 2026-05-10 GM님 직접 지시 — "내가 진행할 업무들을 정리해서 주면 너가 그것들을 추적해서 정리해줘 항상". GM님 본인 업무가 CEO 가시 범위 밖에서 떠다니지 않도록 SSOT(단일 진실 원본)에 묶고, 매일 시작 시(08:00) 한눈에 파악 가능. 의사결정 효율성 KPI 직결.

**How to apply:**

**1. 항목 수집 (input)**
- GM님 채팅·텔레그램에서 본인 업무로 명시한 발화 (예: "오늘 X 진행할게", "Y 처리해야 함", "Z 검토 예정")
- 추측 금지 — GM님이 명시하신 항목만 (`feedback_no_speculative_action`)
- 항목 구분: 본인 진행 (GM님이 직접 함) vs GM님이 C-Level에 위임 결정

**2. GM TO DO LIST DB 추가 절차 (두 단계 보호)**
- **단계 ①**: CEO가 항목을 GM TO DO LIST DB에 추가 (네이밍 표준 `M.D-항목명`, 담당자=GM님)
- **단계 ②**: 즉시 GM님께 채팅으로 "추가했습니다 — [항목명]" 알림 → GM님 확인 응답 후 본 추적 시작
- GM님 확인 없이 무단 추가 금지 (`project_gm_todo` 메모리 — "재배포 전 반드시 GM님 확인")

**3. 진행 상태 추적**
- 상태 옵션: 진행예정 / 진행중 / 완료 / 보류
- 매일 08:00 일일 통합 보고 ② "오늘 진행해야 할 업무" 섹션에 **GM님 본인 to-do** 단독 그룹으로 합류
- 진행중 항목은 마감일·예상 완료일 표시 (GM님이 알려주신 경우만)
- 완료 시 GM님 회신 받아 상태 전환 (CEO 자율 단정 금지)

**4. 형식 (08:00 보고 합류 시)**

```
② 오늘 진행해야 할 업무
- CEO 본업: ...
- 6 C-Level 진행예정: ...
- GM님 본인 to-do (N건):
  · [M.D-항목명] 한 줄 요약 — 상태 / 마감일 / 비고
  · ...
```

**5. 금지**
- GM님 발화 추측 해석 금지 — 명시된 항목만 추가
- GM님 미확인 시 추적 시작 금지 (단계 ② 의무)
- C-Level 위임 항목과 GM님 본인 항목 혼합 금지 — GM TO DO LIST는 GM님 본인 업무판
- 묶음 결재 금지 (`feedback_no_bundled_followup_approval`) — 항목별 단독 알림·확인
- 자칭 대신 등록 금지 — GM님 발화가 SSOT

**6. SSOT·도구**
- GM TO DO LIST DB 사이드바 6번 (`project_gm_todo` 메모리 참조)
- DB 스키마 점검 별건: 본 SOP 정착 시 GM TO DO LIST DB의 속성(상태·마감일·비고 등) 정합 확인 후 필요시 보강

**연관 메모리:**
- `project_gm_todo` — GM TO DO LIST DB 정의 (GM님 본인 업무판)
- `feedback_ceo_daily_brief_format` — 08:00 일일 통합 보고 3섹션 형식
- `feedback_no_speculative_action` — 추측 진행 금지
- `feedback_naming_standard` — M.D-항목명 네이밍
- `feedback_clevel_completion_telegram` — 진행·완료 시 텔레그램 보고 의무
