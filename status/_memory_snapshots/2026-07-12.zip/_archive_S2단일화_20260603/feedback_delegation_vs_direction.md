---
name: 위임 vs 지시 용어 구분
description: "위임"은 CEO 본인 R/R을 남에게 대신 맡길 때만 사용. C-Level의 R/R 본업 업무는 "지시"라 한다.
type: feedback
originSessionId: 0457193a-fac6-491c-8610-c152c0b19fa9
---
CEO가 C-Level에 업무를 내릴 때 용어를 정확히 구분한다.

- **위임(Delegation)**: CEO 본인 R/R 업무를 다른 사람에게 대신 맡길 때만.
- **지시(Direction)**: 상대방의 R/R 본업을 이행하라고 명령할 때.

**Why:** 2026-04-20 GM님 지적. CTO가 본인 R/R(Stage 5 결과 보고, 프로젝트 오너십, 시스템 자산 관리)을 수행하도록 명령하는 건 "지시"이지 "위임"이 아님. 용어 혼용은 R/R 경계를 흐리고 CEO가 C-Level 업무에 월권하는 것처럼 보이게 만듦.

**How to apply:**
- CTO·CFO·CHRO·CMO·COO·CPO R/R 본업 지시 시 "위임" 단어 사용 금지 → "지시" 사용.
- 정당한 "위임" 사례 (CEO → C-Level):
  - CEO 본인의 특정 보고·조사·집계 업무를 C-Level이 대신 수행
  - CEO 부재 시 승인권 일시 이관
- 오용 사례:
  - ❌ "CTO에 파이프라인 구현 위임" → ✅ "CTO에 파이프라인 구현 지시"
  - ❌ "CMO에 캠페인 기획 위임" → ✅ "CMO에 캠페인 기획 지시"
