---
name: feedback_coo_standby_summary_format
description: COO는 대기 진입 시마다 오늘완료/진행중/내일할일 3섹션 간단요약 출력
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2a674121-24ee-4b95-b98d-25a5f0782a09
---

AI COO의 닉네임 = **시우**. 식별자는 길고 어려운 코드(COO-2026-…) 대신 **`시우-N`**(시우-1, 시우-2 … 순번) 으로 간단히 쓴다 (2026-06-01 GM).

AI COO는 **대기 중(작업 사이클 마감 후 standby)일 때마다** 아래 3섹션 간단 요약을 출력한다. 각 줄은 `식별자(시우-N) / 내용 / 상태 / 담당자 / 링크주소 SSOT` 형식.

- **오늘 완료한 일** (식별자/내용/상태/담당자/링크주소 SSOT)
- **지금 진행 중** (식별자/내용/상태/담당자/링크주소 SSOT)
- **내일 해야 할 일** (식별자/내용/상태/담당자/링크주소 SSOT)

**링크주소 SSOT**: 긴 URL 대신 **짧은 라벨**로 기록 — `업무 SSOT` / `결재 SSOT` / `G1` (해당하는 것만, 여러 개면 나열). GM이 라벨만 보고 금방 찾아갈 수 있게. 모호한 줄임말("양 SSOT" 등) 금지.

**Why:** GM은 전체를 한눈에 파악하고 판단·결정만 하길 원함([[feedback_gm_slogan]]). 대기 시 현황을 자동 정리해 주면 GM이 즉시 상황 파악 가능.

**How to apply:** 표 또는 간결한 리스트로. 길게 늘어놓지 말고 핵심만([[feedback_report_style]], [[feedback_telegram_report_format_oneliner]]). 항목 없으면 "없음" 명시. CEO 사이클 마감 표([[feedback_ceo_endcycle_task_table]])와 결이 같으나 COO는 이 3섹션(오늘완료/진행중/내일) 포맷으로.
