---
name: Peer Cross-Check (PCC) 메커니즘 v1.0 — C-Level 상호 문제점 노출
description: C-Level 6명을 고정 페어 3쌍(CMO↔CPO · CFO↔COO · CHRO↔CTO)으로 묶어 매일 07:55 (08:00 CEO 일일 통합 보고 직전) 카운터파트 산출물을 무작위 표본 점검·문제점 노출. 오너십 이양 없음, 발견 사항은 CEO 조정·중계 (2026-05-10 08:55→07:55 변경)
type: feedback
originSessionId: 330cdb86-ca8b-4bed-8ffa-f36af02b5c6d
---
C-Level 6명은 매일 **07:55** (08:00 CEO 일일 통합 보고 직전) 고정 페어 3쌍 구조로 카운터파트의 직전 24시간 산출물 1건을 무작위 표본 점검하고 발견된 문제점 0~N건을 CEO에게 노출한다. 본 메커니즘 명칭은 PCC(Peer Cross-Check, 동료 교차 검토). 오너십은 본인 C-Level에 그대로 귀속, 검토자는 Advisor로만 참여.

**Why:** 2026-04-28 화 GM님 직접 지시 — "C-Level이 서로 문제점을 노출시켜 바로잡을 수 있게 만들 수 없나, 토큰 여유도 있어 보임". 단방향(C-Level → CEO → 대표) 위계만으로는 사각지대 누적·자체 검수 한계 존재. 측면 견제선 추가 시 문제 조기 노출·KPI 달성 가속·CEO 의사결정 효율성 KPI 향상. 토큰 여유 = Claude API 분석·검토 깊이 강화 가능.

**How to apply:**
- **고정 페어 v1.0 (도메인 인접성 기준)**:
  - CMO ↔ CPO (모집·전환 ↔ 회원·리텐션 — 깔때기 양 끝)
  - CFO ↔ COO (예산·집행 ↔ 현장 운영 — 비용·매출 양 끝)
  - CHRO ↔ CTO (인사·교육 ↔ 시설·기술 — 인프라 양 끝)
- **운영 시각**: 매일 **07:55** 단계 (08:00 CEO 일일 통합 보고 직전, 운영 프레임워크 일일 운영 사이클 표). 2026-05-10 08:55→07:55 변경 — `feedback_ceo_clevel_goal_oversight` 일간 통합 보고 09:00→08:00 동기화. 토큰 여유분 활용해 라운드별 1건 무작위 표본 점검.
- **체크리스트 8종 (공통 점검 항목)**:
  1. 산출물 본문이 가공완료 최종본인가? (`feedback_final_content_only_for_publish`)
  2. 담당자 relation 채워져 있나? (`feedback_owner_field_mandatory`)
  3. 네이밍 표준 준수? (`feedback_naming_standard`)
  4. 영어 약어 한글 병기? (`feedback_english_terms_korean_gloss`)
  5. 브랜드 용어 "스포츠클럽"으로 통일? "피트니스" 사용 시 위반 (`feedback_brand_terminology`)
  6. 버전·Changelog 누적 토글? (`feedback_version_increment_rule`)
  7. 본인 KPI(북극성) 직결성?
  8. 자율 결정 범위 vs CEO 결재 필요 분류 적정?
- **결과 노출 형식**: "[페어 검토 — 검토자→피검토자] 발견 N건 / 항목 1줄씩 / CEO 조정 요청 1건". CEO 일간 통합 보고에 「Peer 검토 발견 사항」 단독 섹션으로 합류.
- **금지**:
  - 검토자가 피검토자 산출물 직접 수정 금지 (오너십 이양 금지 — `feedback_no_speculative_action`)
  - 인신·평가 금지, 사실·체크리스트 기반 1줄 노출만
  - 페어 간 자체 종결 금지 — 모든 발견 사항 CEO 경유
  - 자칭 평가권·직책 부여 금지 (`feedback_no_self_assigned_persona`)
  - 묶음 결재 금지 — 발견 항목별 단독 결재 (`feedback_no_bundled_followup_approval`)
- **단계적 강화 로드맵**: v1.0 고정 페어 → v2.0 라운드 로빈(셔플) 도입 → v3.0 1:N 전체 노출 (토큰·시간 비용 따라 단계 승격, GM님 직접 결재).
- **중단 조건**: 페어 간 갈등·과도한 노이즈 발생 시 CEO가 즉시 일시 중단·재설계 (GM님 보고 필수).
