---
name: feedback-version-clean-data
description: 버전업 진행 시 이전 버전 데이터(로그·임시파일·캐시 등)는 항상 폐기. 구 데이터 보존 금지.
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b8c8c565-9105-4858-8b62-425942f1e9a0
---

버전업(코드 수정·배포·재시작) 진행 시 이전 버전 데이터는 항상 폐기한다.

**Why:** 구 데이터가 남으면 혼동·디스크 낭비·디버깅 오염 유발. 깨끗한 상태에서 시작해야 문제 추적이 명확함.

**How to apply:** 봇 재시작·스크립트 업데이트·인프라 변경 시 관련 로그·임시파일·캐시를 삭제 후 가동. 아카이브 보존이 필요한 경우에만 예외.

관련: [[feedback-version-increment-rule]]
