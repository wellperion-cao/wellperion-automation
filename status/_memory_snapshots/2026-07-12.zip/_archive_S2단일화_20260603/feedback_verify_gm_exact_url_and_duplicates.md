---
name: feedback_verify_gm_exact_url_and_duplicates
description: "GM이 \"안됨\" 보고 시 GM의 정확한 URL부터 받아 그 파일을 검증 — 중복·옛 파일 함정"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: dfc75a26-b057-4e5c-8d79-b115525d2e0f
---

GM이 배포 페이지가 "그래도 안됨"이라고 반복 보고하면, 내가 고친 파일이 **GM이 실제로 보는 파일과 다를 수 있다**. 추측 말고 GM의 정확한 URL을 받아 **그 URL이 서빙하는 파일**을 검증·수정하라.

**Why:** 2026-05-29 결재 SSOT 사고. `결재 SSOT.html`(GM URL, 옛 내용)과 `결재 현황 SSOT.html`(내가 고친 파일) 2개가 git HEAD에 동시 추적됨. 옛 파일은 로컬 삭제(D)됐으나 커밋 안 돼 GitHub Pages가 계속 서빙. 나는 grep으로 찾은 파일만 고치고 "라이브 검증 완료"라 보고했지만, GM URL엔 수정이 전혀 없어 비밀번호 게이트·헤더 통일·진척로그 수정 셋 다 "안됨". GM이 URL을 직접 줘서야 발견.

**How to apply:**
1. "안됨" 보고 → **GM에게 정확한 URL 요청**(또는 이미 줬으면 그 URL). 내가 검증한 URL과 일치하는지 대조.
2. `git -c core.quotepath=false ls-files <dir>` 로 **동명·유사명 중복 파일** 점검. (quotepath 켜지면 한글이 octal로 떠 grep 누락)
3. Playwright는 GM의 **정확한 URL**로 goto해 끝(리다이렉트 포함)까지 도달한 페이지를 검증.
4. 중복 발견 시 옛 파일은 정식본으로 **리다이렉트**(meta refresh + JS location.replace, search/hash 보존)해 북마크 보존 + SSOT 단일화.
5. 캐시 미반영 방지: 페이지에 `window.__PV` 버전 + 서버 비교 자동갱신 스크립트(루프 가드). [[feedback_verify_deployed_not_local]]
