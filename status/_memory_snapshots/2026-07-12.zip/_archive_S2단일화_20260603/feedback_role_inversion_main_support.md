---
name: r-r-ai-c-level
description: "모든 프로젝트의 최종 책임자는 실무직원, AI C-Level 6명은 행정·자동화·DB·보고·집계·문서화·검증의 후방 서포트 라인 한정."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 63d35c3d-04dd-4095-be62-d069a93c7814
---

전사 R/R 구조 대전환 SSOT (2026-05-20 GM님 신지시).

**핵심 규칙:**
- **최종 책임자 = 실무직원** (강습부·운영부·시설부·관리부·경영지원부 매니저 등). DB 필드 `실무진(최종 책임자)` select 6옵션으로 기록.
- **행정 서포트 라인 = AI C-Level 6명**. DB 필드 `담당자` relation으로 라우팅 키 역할. 자동화·DB·집계·문서화·검증·보고 후방 지원에 한정.
- **자율 결정 권한**: 메인 의사결정은 실무직원. AI C-Level은 서포트 산출물·자동화·집계 한정 자율.
- **GM 직접 트리거 3종 SSOT 유지**: 💰결제·🔒보안·🚫금지 (메모리 [[feedback_gm_direct_trigger]]).

**Why:** 2026-05-20 SP-27 진행 정체 진단 중 GM님 신지시. "AI C레벨들은 이제 서포트 라인으로 설정하고 메인은 우리 실무직원들이 하는걸로". 실무진 결정·진행 속도 확보 + AI C-Level의 R/R 침범 위험 차단.

**How to apply:**
- Start 기획DB·결과물DB의 모든 신규 레코드: `실무진(최종 책임자)` 필드 = 실무직원 6옵션 중 1명 / `담당자` 필드 = 해당 영역 AI C-Level relation.
- 두 필드 분리 의무. 최종 책임자에 AI C-Level 입력 금지. 담당자에 실무진 입력 금지.
- 신규 파트너팀 관리·런칭 R/R: Phase 1 행정서포트 = AI CHRO · Phase 2 = AI CPO · Phase 3 = AI COO. 최종 책임자는 풀 사이클 실무진 단일.
- 파트너팀 인사·평가·재계약은 AI CHRO 영구 잔존.
- 기존 메모리 [[feedback_owner_field_mandatory]]의 "담당자 = 본인 AI 역할 relation" 원칙은 유효하되, **의미가 "행정서포트 라우팅 키"로 재해석됨**. 최종 책임자십은 별도 `실무진(최종 책임자)` 필드로 분리.
- 운영 프레임워크 페이지([[project_master_framework_page]])에 「전사 R/R 대전환」 섹션 신설 의무.
- C-Level 텔레그램 보고는 서포트 산출물(자동화·집계 완료) 시만. 프로젝트 메인 진척 보고는 실무직원 책임.

**위반 시:** 발견 즉시 필드 patch + 운영 프레임워크 업데이트 + 메모리 보강. CEO 능동 점검 의무 ([[feedback_ceo_proactive_verification]]).
