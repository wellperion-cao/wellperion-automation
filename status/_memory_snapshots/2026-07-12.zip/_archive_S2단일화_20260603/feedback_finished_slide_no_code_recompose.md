---
name: ""
description: Canva 등으로 제작된 완성 슬라이드를 slide_compositor 코드로 재합성·인페인트하면 품질 저하·배경박스. 완성본은 그대로 두고 코드는 발행(업로드)만 담당
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2335cfec-a632-402c-83d0-eecb15cdc43f
---

WJO·발레·바레처럼 **Canva(디자인툴)로 제작된 완성 슬라이드**는 절대 코드(slide_compositor)로 재합성·인페인트하지 말 것. 완성본 디자인은 그대로 쓰고, **코드는 발행(업로드)만** 담당한다.

**Why:** 2026-06-01 바레(CMO-2026-05-20-BARRE) 사고. 발행 자동화하려고 완성본을 코드로 건드리기 시작하면서 전부 틀어짐 — ① 카운터 숫자를 코드 인페인트로 고치니 회색 배경박스 발생 ② 원본 사진으로 재합성하니 Canva 커스텀 디자인(로고·표지 65/35·폰트)을 100% 재현 못 해 "수준이 떨어진다" "다 틀어졌다"는 GM 지적 반복 ③ 편집 소스(원본 사진·카피 데이터·Canva 원본 파일)가 없는 채로 완성본을 수정하려니 더 망가짐. 결국 GM이 "망했다, 컴팩트하고 다시" 판단.

**How to apply:**
- 완성본(Canva 등)이 이미 있으면 **디자인은 그대로 둔다.** 코드로 재현/수정 금지.
- 발행 파이프라인의 코드 역할 = **이미지/영상 업로드·캡션·위치·발행만.** 디자인 영역 비침범.
- 슬라이드 수정이 필요하면 **Canva 원본에서** (GM/디자이너), 코드 아님.
- 발행기 형식(`output/`·`post_A_N`·`큐레이션_추천.md ## post A`)과 완성본 폴더 구조(`output(인스타그램)/`·`ig_NN`)가 다르면, **완성본을 발행기 형식으로 맞추되 디자인은 건드리지 않는다**(파일 복사·이름 정렬까지만).
- **합성 착수 전 소스 판별 의무(2026-06-03 WJO 재발 후 신설):** slide_compositor로 합성하기 **전에 반드시 소스 1장을 직접 시각 확인**한다. 다음 중 하나라도 burned-in 되어 있으면 = **이미 완성본 → 합성 금지, 발행만.** ① 페이지 카운터(02/07 등) ② 사업부 칩(SPORTS CLUB 등) ③ 캡션/풋터 텍스트 ④ 로고가 이미 박힌 상태 ⑤ 1080×1080 정사각(완성 IG 슬라이드 비율). 폴더에 `output(인스타그램)/`이 이미 차 있거나 `_blog_body`·`_reels.mp4`가 있으면 완성 단계 신호.
- **CEO 위임 시 브리프에 "원본 사진"이라 단정 금지** — "소스가 원본인지 완성본인지 먼저 판별 후 분기"를 지시한다. (2026-06-03: CEO가 "원본 사진" 단정해 위임→완성본 위 재합성 사고. CEO 시각 게이트에서 발견·발행 차단·정리, 미발행.)
- 관련: [[feedback_irreversible_publish_final_visual_gate]] · [[project_slide_compositor_workflow]] · [[feedback_improvement_not_rebuild]] · [[feedback_screenshot_visual_verify]] · [[feedback_just_do_it_source_yourself]]
