---
name: gm-personal-slogan
description: "GM 개인 슬로건 — \"전체를 한눈에 파악할 수 있게, 나는 판단과 결정만 할 수 있도록\""
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 80777498-c2ef-4d1a-bdc6-40d7cfcb2d61
---

GM 김남욱의 개인 슬로건. 모든 시스템·페이지·보고·자동화의 최상위 원칙.

> **전체를 한눈에 파악할 수 있게**
> **나는 판단과 결정만 할 수 있도록**

**Why:** 2026-05-28 GM 직접 명시. CEO·시스템 설계의 단일 북극성.

**How to apply:**
- **한눈 파악 원칙**: 카드·리스트 N건 줄줄이 X → 표·요약·통계·funnel·그래프로 압축.
- **판단·결정만 원칙**:
  - GM이 클릭·승인·선택만 하면 모든 후속 액션 자동
  - 데이터 입력·분류·라우팅·이관·기록은 시스템 자동
  - CEO가 항목별 결재 N개 던지지 X — 묶음 표 + 추천값 1개로 압축
  - 결재요청 시 1건씩 + 추천값 병기 ([[feedback_ceo_one_question_at_a_time]])
- **건바이건 X**: 핵심 요약 + #순번 누적 ([[feedback_gm_record_style]])
- **CEO 본업**: 감독·정리보고·실무 구상. GM은 결정 ([[feedback_ceo_essence_oversight_and_brief]])
- **결재 최소화**: GM 직결재는 4 카테고리만 (보안·전략·브랜드·공식값) ([[feedback_minimize_approval_overhead]])
- **마무리 제안 금지**: 종료 묻기 X ([[feedback_no_wrap_up_suggestion]])

**적용 우선순위:** 시스템 설계·페이지 신설·보고 작성 시 이 슬로건이 충돌하는 옵션은 폐기.

**관련:** [[feedback_ceo_essence_oversight_and_brief]] · [[feedback_minimize_approval_overhead]] · [[feedback_ceo_one_question_at_a_time]] · [[feedback_gm_record_style]] · [[feedback_no_wrap_up_suggestion]] · [[feedback_report_style]]
