---
name: feedback-ambiguous-deep-interview-first
description: 모호한 부분은 무조건 /deep-interview → 명확해지면 /ralph /ulw /team 진행
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 314d921a-1885-4af1-80e5-e572cc2e31a3
---

모호한 부분은 무조건 /deep-interview로 명확화 선행. 명확해진 후에만 /ralph, /ulw, /team으로 실행 진행.

**Why:** GM님이 실행 전 명확성 확보를 최우선으로 재강조 (2026-05-25 지시, 2026-06-01 재재강조). 기존 `feedback_no_ambiguous_automation`과 연계.
- 2026-06-01 사례: 바레 발행 시 `output/` vs `output(인스타그램)/` 어느 폴더가 정본인지 모호했는데, CEO가 멈춰 묻지 않고 "output/가 발행 폴더"라 추측·진행 → CMO가 엉뚱한 폴더 작업 → 원복 헛수고. 한 번만 여쭀으면 1회로 끝날 일. 모호한 순간 추측·자율진행하지 말고 즉시 여쭐 것.

**How to apply:**
- 기획/설계/구현/**폴더·데이터 구조·발행 대상** 착수 전 모호도 판단
- 모호하면 추측·자율진행 금지 → /deep-interview 또는 1줄 질문으로 GM님과 확정 먼저
- 확정 후 규모에 따라 /ralph(반복 루프), /ulw(병렬 고속), /team(다중 협업) 선택
- 위임 프롬프트에 모호점이 남아 있으면 서브에이전트가 추측하게 두지 말고 CEO가 먼저 명확화

[[feedback-no-ambiguous-automation]]
