---
name: no-auto-restore-from-planned
description: 업무자동화DB 상태 자율 patch 금지 (보류↔진행중 양방향). GM 페이지별 명시 지시만. 진행예정 옵션 자체 폐기 (2026-05-22).
metadata: 
  node_type: memory
  type: feedback
  originSessionId: c8e01373-6646-4a8c-a34f-00862db0d067
---

업무자동화DB 상태 전환 (보류 ↔ 진행중) **CEO·C-Level 자율 patch 절대 금지** — 페이지 정체성(가동 중 데몬인지 미가동인지) 판단은 GM 단독.

**Why:** 2026-05-21 같은 세션 내 양방향 사고:
1. (1차) 회귀 5건 (CFO-003·CPO-004·CTO-006·COO-003·COO-004) → CEO 자율 진행중 복원 → GM 지적 → 보류 정정
2. (2차) CMO-001 자율 진행중 복원 → GM 지적 → 보류 정정 → GM 재정정 "왜 또 보류야 진행중이지" → 진행중 재복원
3. (2차 부산물) CMO-003 보류 → GM 정정 → 진행중 재복원

CEO·C-Level이 페이지의 가동 의도(진행중이 맞는지 / 보류가 맞는지)를 자율 판단할 수 없다.

**How to apply:**
- 휴면 상태(보류) 페이지 발견 시 → 자율 진행중 patch 절대 금지. GM께 1건 보고만.
- 진행중 페이지를 보류로 격하하는 것도 GM 명시 지시 필요.
- 보고 형식: "X 페이지 보류 상태. (a) 진행중 전환 (b) 보류 유지 중 결정 부탁드립니다."
- 일괄 변환도 명시 지시 받은 페이지 범위 한정.

**2026-05-22 진행예정 옵션 폐기:**
- GM 지시로 select 옵션 "진행예정" 자체를 데이터소스에서 제거. 휴면 상태는 "보류" 단일.
- 기존 진행예정 레코드는 보류로 일괄 흡수.
- status_regression_guard.py 동시 폐기 — 자동 복원은 GM 의도 덮어쓰기 위험이라는 본 정책과 정면 충돌이었음.

**관련:** [[feedback_status_change_gm_exclusive]] · [[feedback_no_speculative_action]] · [[feedback_no_status_regression_on_body_patch]]
