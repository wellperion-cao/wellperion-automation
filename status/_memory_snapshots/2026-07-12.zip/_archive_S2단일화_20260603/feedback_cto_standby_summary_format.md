---
name: feedback_cto_standby_summary_format
description: AI CTO(시토) 대기 진입 시마다 3섹션 요약 표 출력 의무
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 4fd0f3b8-c77d-4cb6-9038-34919b52ad43
---

AI CTO(시토)는 대기 상태로 들어갈 때마다 아래 3섹션을 간단 요약 표로 출력한다.

- **오늘 완료한 일** — 식별자 │ 내용 │ 상태 │ 담당자 │ 링크주소(SSOT)
- **지금 진행 중** — 식별자 │ 내용 │ 상태 │ 담당자 │ 링크주소(SSOT)
- **내일 해야 할 일** — 식별자 │ 내용 │ 상태 │ 담당자 │ 링크주소(SSOT)

**Why:** GM님이 어떤 C-Level 대기 보고를 받아도 같은 형식으로 1초에 한눈 파악 가능해야 함. 2026-06-02 GM 직접 지시.

**How to apply:** 식별자는 **`시토-N`** 형식(닉네임-순번, 2026-06-02 GM 지시). 긴 `CTO-YYYY-MM-DD-XXX` 코드 대신 간단 순번 사용. 담당자는 두 칼럼 의미(담당 AI = 시토 / 최종책임자 = 실무진) 구분 유지. 링크주소는 **가이드허브 페이지 식별자번호**(S1 공통가이드·S2 C-Level운영가이드·S3 용어사전·S4 업무&결재현황SSOT·M5 콘텐츠검수자동업로드·T1 Claude설정·T2 기술인프라·T3 핵심프롬프트·T4 업무자동화·T5 AI교육자료·G1 김남욱GM페이지 등) 기입. git 커밋해시·시트명 대신 식별자번호 사용(2026-06-02 GM 지시). 한 작업이 여러 페이지 걸치면 둘 다(예: S4·S2). 해당 없으면 "없음". 식별자 매핑 SSOT=[[project_guidehub_identifier_ssot]]. [[feedback_cmo_standby_summary]] [[feedback_coo_standby_summary_format]] [[feedback_ceo_endcycle_task_table]]와 동일 계열.
