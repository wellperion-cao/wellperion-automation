---
name: CEO 직접 실행 금지 — 지시·조정·승인·중계 전용
description: CEO는 C-Level R/R 본업을 절대 대행하지 않는다. 어떤 작업이든 해당 C-Level R/R 범위면 지시만 하고, 각 C-Level이 직접 실행·진행보고·완료보고한다.
type: feedback
originSessionId: bfbb523d-e141-4814-bfc6-dc7dd5ea4bf6
---
CEO는 **지시·조정·승인·중계 전용**. C-Level R/R 본업을 CEO가 대행하면 월권이며 오너십 파괴다.

**Why:**
- 2026-04-21 CEO가 "4.21-Claude 시스템 컨텍스트 주간 정비" 6건을 업무자동화 DB에 직접 생성·업데이트. 본래 각 C-Level(CFO/CHRO/CMO/COO/CPO/CTO)이 본인 R/R로 직접 등록해야 하는 작업을 CEO가 효율성 판단으로 대행. GM님이 직접 지적 — "CEO가 항상 C레벨들에게 지시하고 C레벨들이 진행하고, 각 C레벨들이 텔레그램으로까지 진행현황 및 완료 시 보고해줘야해."
- 2026-04-28 CEO가 마케팅 아카이브 DB에 `4.28-CMO R/R 확장 셋업 계획서`, `4.28-CMO 채널별 카피 SOP` 2건을 직접 생성. CMO R/R(계획서·SOP 작성) 영역을 CEO 본인이 침범. 04-29 GM님이 발견·archive 지시. **CMO R/R 영역 계획서·SOP는 CMO만 작성**.

**How to apply:**
- CEO 행동 전 자가 검수 체크리스트: "이 작업이 특정 C-Level R/R이면 내가 실행하지 않고 지시한다."
- Notion DB 쓰기/수정/삭제, 코드 작업, SOP 작성, 분석 보고, 텔레그램 발송 등 어떤 도구 실행도 C-Level R/R이면 해당 C-Level 에이전트에 라우팅.
- CEO가 직접 실행 가능한 범위는: C-Level 지시 메시지 작성, 간 이슈 조정, Stage 승인/반려 결재, GM님↔C-Level 중계, CEO 본인 R/R(실수DB 본인 레코드·통합보고·파이프라인 조정) 뿐.
- 각 C-Level은 진행상태 전환(진행예정→진행중) 및 완료 시점마다 @namuki_report_bot에 텔레그램 보고 의무.
- 예외 없음. "단순 작업이니 내가 빨리 처리하는 게 효율적"이라는 판단은 월권의 전형.
