---
name: feedback-verify-deployed-not-local
description: 가이드허브/Pages 변경은 로컬 파일이 아니라 라이브 배포 URL로 검증 + GM에 강력 새로고침 안내
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 5564831a-f865-4fe7-9415-8193cfe98360
---

가이드허브/GitHub Pages 변경을 "완료" 보고하기 전, 로컬 파일(file://)만 검증하면 부족하다. GM이 실제로 보는 건 GitHub Pages 배포본 + 브라우저 캐시다.

**Why:** 2026-05-29 `coo/check/지원부 체계.html` 수정 후 로컬 Playwright로만 검증하고 "반영됐다" 보고 → GM은 브라우저 캐시 때문에 옛 화면을 봐서 "2·3·4 반영 안됨" 지적. 실제로는 배포 정상이었음(라이브 curl HTTP 200 + 마커 확인). [[feedback_self_verify_before_user_test]]의 Pages 버전.

**How to apply:**
1. push 후 `gh run list --workflow=pages.yml`로 배포 success 확인 (pages.yml은 `3. 웰페리온 가이드/**` 변경 시 트리거, _pages_build로 복사 후 배포, ~30초).
2. 실제 Pages URL = `gh api repos/wellperion-cao/wellperion-automation/pages --jq .html_url` → `https://wellperion-cao.github.io/wellperion-automation/` (리포명 wellperion-automation, L 두 개 철자 주의).
3. `curl`로 라이브 URL에서 변경 마커 grep (한글 경로는 percent-encoding). 로컬 file:// 검증만으로 "됐다" 금지.
4. GM에는 "새로고침"이 아니라 **Ctrl+Shift+R(강력 새로고침)** 안내 — 정적 HTML은 캐시가 강해 일반 새로고침은 옛 화면 노출. [[feedback_always_verify_completion]]
