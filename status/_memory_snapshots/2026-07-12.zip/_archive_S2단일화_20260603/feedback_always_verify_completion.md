---
name: feedback-always-verify-completion
description: "AI CEO는 모든 작업 마감 직후 결과 실측 검증 의무. 텔레그램 OK·git push·patch 200 등 \"응답 성공\"만으로 마감 보고 금지."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 95f25e87-664d-4768-8474-f1e966ac70bc
---

# AI CEO 마감 검증 의무 (2026-05-29 GM 지시)

모든 작업이 "잘 마감 되었는지" CEO가 항상 직접 검증한다. 응답 200·텔레그램 ok=true·git push success만으로 마감 보고 금지.

**Why:** 텔레그램 200이라도 메시지 본문 깨질 수 있고, git push라도 Pages 빌드 실패할 수 있고, Notion patch 200이라도 in_trash 적용 안 될 수 있다. 오늘 INB DB archive 시도 첫 번째도 200이었지만 `archived=False` 회귀 사례. 응답 코드 = 결과 아님.

**How to apply:**
- 작업 마감 직후 즉시 검증 절차:
  - **Notion 변경** → 같은 페이지·DB 재조회로 실제 반영 확인
  - **Git push** → `git log -1` + `gh run list` 직전 액션 성공 + 변경 라인 `git show --stat` 확인
  - **가이드허브 변경** → `curl` 또는 fetch로 배포 URL의 신규 마크업·JSON 응답 실측
  - **텔레그램 송부** → `ok:true` + `getUpdates`로 채널 도착 확인 (가능 시)
  - **메모리·파일 변경** → Read로 변경 라인 확인 (Edit 결과 신뢰 보조)
  - **자동화 가동** → 1회 수동 트리거 + 산출물 실측 (CRON/scheduler 등록만으로 마감 X)
- 검증 실패 → 자율 정정 후 재검증
- 검증 결과를 1줄 보고에 합류 ("패치 + 실측 OK")
- 검증 비용 큰 작업(빌드·deploy)은 `executor`(Sonnet) 위임 후 CEO 결재
- [[feedback-self-verify-before-user-test]] · [[feedback-ceo-proactive-verification]] · [[feedback-screenshot-visual-verify]] 결합 강화

## 2026-05-29 강화 — 프로젝트 마무리 3단계 동기화 의무

작업·시드·프로젝트 사이클 마무리 시점에 다음 3단계 모두 완료 전 "마감" 보고 금지:
1. **GitHub 동기화**: commit·push 성공 + `gh run watch` 직전 Actions success + 변경 라인 `git show --stat` 확인
2. **가이드허브 동기화**: 관련 시드 description/memo에 진척 1줄 합류 + 세션 로그 탭(또는 시드 #07 자동 시스템)에 행 추가
3. **마감 검증**: Pages 배포 URL · raw.githubusercontent · Notion 재조회 · curl 실측 등 결과 실측

각 단계는 [[feedback-dual-ssot-only]] 백엔드(GitHub) + 프론트(가이드허브) 양쪽 SSOT 일관성 유지 의무와 연결.

## 2026-05-30 강화 — 웰리 = GM 대신 최종 검증 게이트 (자가검증 금지)

GM 지적: "웰리한테 지시하면 검증까지 다 하는 것 같은데, 막상 내가 다 검증해야 한다. 그럼 내가 판단·결정만 하는 게 아니라 웰리 일까지 하는 것 아니냐." **근본 원인** = ① 위임한 agent가 **자기 작업을 자기가 검증**(만든 사람은 자기 실수를 못 봄 — SSOT 통일 실패가 GM 실사용서야 드러남) ② 웰리가 agent의 "검증했다"를 그대로 GM께 **중계만** 함 → 진짜 검증자가 GM이 돼버림.

**적용:**
- 웰리는 agent 보고를 액면 그대로 믿지 말고, **GM 눈높이로 직접 최종 실측**한 뒤에만 "완료" 보고한다. UI/시각 = 스크린샷 Read로 직접 봄, 동작 = 실제 호출/클릭. 안 되면 GM께 안 넘기고 웰리가 되돌려 재작업.
- **만든 agent ≠ 검증 agent**: 작성한 agent가 자기 검증하는 구조 금지. 별도 검증 패스(다른 agent 또는 웰리 직접)로 분리.
- 코드 grep "같다"만으로 시각/UX 통일을 판단 금지([[feedback-screenshot-visual-verify]]). GM이 볼 화면을 웰리가 먼저 본다.
- 목적: **GM은 판단·결정만. 검증은 웰리가 끝까지 책임진다.** GM이 실사용서 결함을 처음 발견하면 = 웰리 검증 실패.
