---
name: feedback_cmo_standby_summary
description: "시모(CMO)는 대기 진입 시 항상 '오늘 완료 / 지금 진행중 / 내일 할일' 3구획 요약(식별자·내용·상태·담당자·링크주소 SSOT) 출력"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 10213ccd-502a-4feb-beb8-15fb894bdf5d
---

시모(AI CMO)는 대기 상태로 들어갈 때마다 **항상** 아래 요약을 출력한다:
① 오늘 완료한 일 · ② 지금 진행중 · ③ 내일 해야할 일 + **🔁 Before & After**(완료건 전→후 핵심 1줄, 2026-06-02 GM 추가).
각 항목 공통 필드 = **식별자 · 내용 · 상태 · 담당자 · 링크주소 SSOT** (표 형식 권장).
링크는 가이드허브 페이지 식별자(M1·M2·M4·M5·G1 등, 홈 사용법 표 기준) 또는 친숙한 SSOT 이름으로 표기(2026-06-02 GM 확정). [[project_guidehub_identifier_ssot]]
Before & After = 오늘 완료건만, "변경 전 → 후" 1줄로. 가이드허브 g10 공통 보고 포맷의 ②블록과 동일.

**Why:** GM이 대기 시점마다 전체를 한눈에 파악하고, 다음 판단·웰리 기록에 바로 쓰기 위함.

**How to apply:** 작업 사이클을 마치고 대기로 전환하기 직전 이 3구획 요약을 자동 출력. 담당자 = 시모(서포트) / 김남욱 GM(최종책임). 진행중 없으면 "없음(대기)".

**링크주소 SSOT = 3대 허브 매핑** (깊은 개별 링크 대신 각 항목이 기록된 허브로): ① **업무 SSOT** = `coo/todo/업무 현황 SSOT.html` ② **결재 SSOT** = `coo/todo/결재 현황 SSOT.html` ③ **G1**(김남욱 GM 오늘 할일) = `wellperion_guide(main).html#gm1`. 배포 베이스: https://wellperion-cao.github.io/wellperion-automation/ . 일반 시모·시토 작업=업무 SSOT, GM 결재 필요건=결재 SSOT, GM 개인 to-do=G1. [[feedback_ceo_endcycle_task_table]] [[feedback_gm_slogan]] [[feedback_clevel_routine_setup_format]]
