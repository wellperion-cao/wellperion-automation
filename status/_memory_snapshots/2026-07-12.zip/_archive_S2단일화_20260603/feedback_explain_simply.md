---
name: feedback-explain-simply
description: "기술 설명도 일상 비유로 쉽게. 전문 용어 나열 금지, GM님이 바로 이해할 수 있는 수준으로."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b8c8c565-9105-4858-8b62-425942f1e9a0
---

기술적 내용 설명 시 전문 용어 나열 금지. 일상 비유·일반 용어로 풀어서 설명.

**Why:** GM님이 기술 배경 없이도 즉시 판단할 수 있어야 함. 이해 못하면 의사결정이 지연됨.

**How to apply:** 구조·흐름 설명 시 "비서가 메모장에 정리" 같은 비유 우선. 기술 용어가 불가피하면 괄호 안에 쉬운 설명 병기. 코드·API·DB 등 구현 상세는 GM님이 묻지 않으면 생략.

관련: [[feedback-english-terms-korean-gloss]], [[feedback-report-style]]
