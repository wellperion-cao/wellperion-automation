---
name: feedback_gm_comm_id_code
description: "GM 소통 시 작업·제안·질문마다 [#NN] 식별코드 부여 — GM이 코드로 콕 집어 답·이어가기"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 4a9691eb-88f6-4adf-be48-eeadbcc3cd6d
---

GM과 소통할 때 동시에 여러 업무·제안이 오가므로, 웰리가 보내는 각 제안·작업·질문·진행 항목에 **[#NN] 식별코드**를 앞에 붙인다. GM은 그 코드로 콕 집어 답한다("#04 응", "#01은 이렇게"). 이어가는 내용·후속 보고도 **같은 코드를 유지**해 추적 가능하게.

**Why:** 2026-05-30 GM 지시 — "여러 업무를 동시 진행하니, 각 제안에 답하거나 이어갈 때 작업마다 식별코드를 넣어 답할 수 있게 해줘." 동시 다발 작업에서 어느 건에 답하는지 구분 필요.

**How to apply:**
- 제안·할일·질문·진행현황 표의 각 행에 `[#NN]` prefix(오늘/세션 기준 순번).
- GM이 코드로 답하면 그 작업만 정확히 처리. 같은 작업의 이어가기·후속 보고도 동일 코드.
- 작업 끝나면 해당 코드 상태 갱신(🔄 진행 / ✅ 완료 / ⏸️ 대기 / ❓ GM대기).
- [[feedback_ceo_endcycle_task_table]](모든 항목 식별자 prefix 의무)·[[feedback_gm_comm_id_code]] 결합 — 식별자를 [#NN] 코드로 통일.
