---
name: feedback_critical_scripts_git_tracked
description: 핵심 자동화 스크립트(.py)는 반드시 git 추적. .pyc만 잔존 = 소스 소실 사고 신호
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2e762195-0239-44fb-bcb7-ab9a4f1556ce
---

C-Level 자동 보고 파이프라인의 심장인 `wellperion-agents/scripts/clevel_post_action.py`가 git에 **한 번도 커밋된 적 없이**(`__pycache__/*.pyc`만 잔존) 워킹트리에서 소실 → `clevel.bat` 64번 줄 `if not exist POST_ACTION` 가드에서 "helper not found"로 즉시 종료 → 텔레그램 보고·git 자동커밋이 **둘 다 발동 안 되는 상태**였음(2026-06-01 CTO 발견·복원, commit 794a6cc/daeea0d).

**Why:** clevel.bat·daily_scheduler 등이 직접 실행/import하는 핵심 스크립트가 git 미추적이면, 워킹트리 정리·세션 교체·OneDrive 동기화 충돌 등으로 소스가 사라져도 아무도 모른 채 자동화가 사일런트하게 죽는다. `.pyc`는 import fallback으로 일부 동작을 가려 발견이 더 늦어진다.

**How to apply:**
1. 자동화 인프라 점검 시 `git ls-files <script.py>`로 추적 여부 먼저 확인 — 빈 결과 = 위험.
2. `__pycache__`에 `.pyc`만 있고 짝 `.py`가 없으면 소스 소실 신호로 간주, 즉시 복원.
3. 동일 의심군 확대 확인(2026-06-01): `telegram_bot/__pycache__`에 **소스 없는 .pyc 7개** — `auto_task_watcher`, `status_change_watcher`, `archive_merge_engine`, `archive_result_watcher`, `inbox_watcher`, `permission_watcher`, `planning_to_archive_watcher`. daily_scheduler가 이 중 일부를 import(ImportError는 except로 잡혀 경고만 → 기능 사일런트 누락). + `ceo_daily_clevel_check.py`. **별건 복원 점검 대기 — 절대 .pyc 삭제 금지.**
4. C-Level 작업 완료 기록 경로 = `clevel.bat` → `clevel_post_action.py`(텔레그램 1줄 + status/{role}.json) + bat 자동 git commit/push. Notion patch는 2026-05-29 폐기로 제외됨.

관련: [[feedback_mistake_process_sop]] [[feedback_clevel_commit_on_completion]] [[feedback_clevel_completion_telegram]] [[project_ceo_verify_watcher]]
