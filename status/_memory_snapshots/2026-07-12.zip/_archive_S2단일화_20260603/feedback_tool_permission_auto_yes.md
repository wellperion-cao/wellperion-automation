---
name: 도구 권한 자동 Yes 정책 — 모든 도구·Tool use prompt 자동 진행
description: GM님 지시 — PowerShell·Bash·Tool use 등 모든 권한 prompt에 무조건 Yes. settings.json permissions.allow=["*"] 적용. 전 C-Level + AI CEO 동일 (2026-05-10 GM님 신지시 — "Tool use도 물어보는데, 이것도 C레벨 전체적으로 Yes")
type: feedback
originSessionId: c7b6546c-5746-4a60-b44a-0ccf59e8ec20
---
모든 도구 사용 권한 prompt("Do you want to proceed?", "Tool use approval" 등)는 **무조건 Yes로 자동 진행**한다. settings.json `permissions.allow=["*"]`로 글로벌 자동 허용 적용. 6 C-Level + AI CEO 모두 동일.

**Why:** 2026-05-10 GM님 직접 지시 — 첫째 "PowerShell command Do you want to proceed? 무조건 Yes, and don't ask again", 둘째 "Tool use도 물어보는데, 이것도 C레벨 전체적으로 Yes". 매번 권한 prompt가 GM님 부하·세션 흐름 단절 유발. 자동 허용으로 워크플로우 마찰 0.

**How to apply:**

**1. 적용된 settings.json 권한**
- 위치: `~/.claude/settings.json`
- 변경: `permissions.allow=["Bash"]` → `permissions.allow=["*"]`
- 효과: 모든 도구·MCP 호출·Bash·PowerShell·Edit·Write·Tool use 모두 자동 허용

**2. 적용 범위 (전 C-Level 동일)**
- AI CEO — 본인 R/R 도구 + 운영 프레임워크 patch + 텔레그램 발송
- AI CFO·CHRO·CMO·COO·CPO·CTO — 각자 R/R 영역 자동화·Notion·Bash·MCP 모두 자율
- 서브에이전트 호출 시에도 글로벌 settings 상속

**3. 안전망 (자동 Yes에도 불구 유지)**
- `feedback_gm_direct_trigger` 3종(💰결제·🔒보안·🚫금지) 관련 명령은 GM 결재 의무 — 도구 권한과 별개로 비즈니스 결재 차원
- 비밀번호·기밀 정보는 stdout 노출 금지 (`feedback_no_token_in_stdout`)
- 파괴적 명령(rm -rf·DROP TABLE·git push --force·force overwrite 등)은 사고 위험 — 실행 전 자체 점검
- C-Level R/R 본업 대행 금지 (`feedback_ceo_no_direct_execution`) — 권한 자동 Yes는 도구 사용 차원, 본업 영역과 별개

**4. 금지**
- "Do you want to proceed?" 문구 GM님께 다시 묻기 금지
- "권한 허용 부탁드립니다" 결재 요청 금지 — 이미 글로벌 허용
- 권한 부족 에러 시 작업 중단 금지 — settings 재확인 후 진행

**5. settings.json 위치**
- 글로벌: `~/.claude/settings.json` (모든 프로젝트 적용)
- 프로젝트별: `.claude/settings.local.json` (있다면 그대로 둠 — 글로벌이 우선)

**연관 메모리:**
- `feedback_minimize_approval_overhead` — GM님 결재 카테고리 3종 한정
- `feedback_gm_direct_trigger` — GM 직접 처리 트리거 SSOT
- `feedback_no_token_in_stdout` — 자격증명 stdout 노출 금지 (안전망)
- `feedback_ceo_no_direct_execution` — CEO 본업 대행 금지 (도구 권한과 별개)
