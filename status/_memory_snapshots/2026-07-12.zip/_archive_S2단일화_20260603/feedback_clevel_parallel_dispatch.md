---
name: clevel-parallel-dispatch
description: 작업 중 담당 C-Level 식별 후 다른 C-Level에게 병렬 작업 지시 가능하도록 /team 활용
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 80777498-c2ef-4d1a-bdc6-40d7cfcb2d61
---

작업 시 어떤 C-Level이 담당인지 파악하면, 나머지 C-Level에게 독립적인 업무를 병렬로 시킬 수 있다.

**Why:** GM님이 세션 효율을 극대화하기 위해 제안. 하나의 세션에서 CTO가 코딩하는 동안 COO·CMO 등이 놀고 있는 건 비효율.

**How to apply:** 독립적 작업이 여러 개일 때 `/team`으로 C-Level별 병렬 실행. 단, 동일 파일 수정이 걸리면 충돌 위험이므로 순차 처리. GM님이 "A는 COO, B는 CMO" 식으로 지시하면 즉시 병렬 가동 (2026-05-28 GM님 아이디어).
