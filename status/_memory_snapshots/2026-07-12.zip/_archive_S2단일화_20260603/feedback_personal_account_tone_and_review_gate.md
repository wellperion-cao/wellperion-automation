---
name: feedback_personal_account_tone_and_review_gate
description: GM 개인 계정(namuk.wellperion)엔 회사 가이드 카드·멤버십 마케팅 톤 금지 + 인스타 발행 전 검수 게이트 필수
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 713d60b8-b992-4f64-9f62-d9c437c55021
---

GM 개인 계정(namuk.wellperion) 콘텐츠는 개인 인사이트·생각 리더십 톤만. 회사 WELLPERION GUIDE 카드(회원·시설 이용수칙·예약·운영시간·litt.ly 문의)는 **회사 브랜드 계정 전용** — 개인 계정 게시물 마지막에 자동 첨부 금지. 시드 #09에서 개인 AI-철학 글에 회사 가이드 카드를 붙였다가 GM이 "전혀 관련없다"고 지적.

또한 인스타 발행 전 **검수 게이트 필수**: CMO 가공완료 → 5장 미리보기(montage)로 GM 검수 → 승인 후에만 발행. 검수 없이 바로 발행하면 톤 충돌·구성 오류가 그대로 노출됨(시드 #09 1차 발행 사고).

**Why:** 2026-05-29 GM 지적 2건. (1) 개인 계정에 회사 마케팅 자산 혼입 = 톤 정체성 훼손. 기획서가 "회사 멤버십 마케팅 톤 아님"이라 명시했는데도 [[project_ig_guideline_card]] 자동첨부 규칙을 기계적으로 적용한 판단 착오. (2) [[feedback_ig_auto_publish_with_review]]의 CEO 검수 게이트를 건너뛰고 바로 발행 → 사고가 라이브로 나감.

**How to apply:**
- 개인 계정 콘텐츠 마지막 장 = 개인 톤 마무리 슬라이드(예: 1장 영문 헤드라인과 짝). 회사 가이드 카드 X
- [[project_ig_guideline_card]] 가이드 카드 자동첨부 = 회사 브랜드 계정(wellperion) 한정
- 모든 인스타 발행 전 montage 미리보기 제시 → GM 승인 게이트 통과 후 발행 (비가역이므로 필수)
- 발행 후 캐러셀 사진 교체 불가 → 수정은 게시물 삭제 후 재발행(새 URL)
