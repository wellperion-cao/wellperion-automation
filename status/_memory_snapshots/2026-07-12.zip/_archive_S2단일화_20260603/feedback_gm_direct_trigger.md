---
name: GM 직접 처리 트리거 SSOT — 3종(💰결제·🔒보안·🚫금지). 그 외 전부 AI C-Level 자율 진행
description: GM(김남욱)이 직접 검토·승인하는 사안은 결제·보안·금지 3종만. 그 외 모든 사안은 6 C-Level이 스스로 진행 후 결과 보고. CEO·C-Level이 GM께 결재 묻는 카테고리는 본 3종 외 금지 (2026-05-10 GM님 신지시 — "다신 묻지말아줘")
type: feedback
originSessionId: c7b6546c-5746-4a60-b44a-0ccf59e8ec20
---
GM(김남욱)이 직접 검토·승인하는 사안은 **결제(💰)·보안(🔒)·금지(🚫)** 3종으로 한정한다. 그 외 모든 사안은 6 C-Level과 AI CEO가 스스로 자율 결정·진행 후 결과 보고. CEO·C-Level이 GM께 결재 묻는 카테고리는 본 3종 외 절대 금지.

**Why:** 2026-05-10 GM님 직접 지시 — "위 내용 참고해서 진행해줘 다신 묻지말아줘. 이건 전 C레벨들에게도 적용해". 운영 프레임워크 페이지 섹션 2「GM 직접 처리 트리거 (3종)」를 SSOT로 확정. 기존 4종(보안·전략·브랜드·공식값)에 결제 추가 + 전략·공식값은 폐기, 브랜드는 금지(🚫)에 흡수. 묻는 횟수 자체를 줄여 GM님 의사결정 부담 최소화·CEO·C-Level 자율성 극대화.

**How to apply:**

**3종 GM 직접 처리 트리거 (확정 SSOT)**

| 유형 | 예시 | 표시 |
|---|---|---|
| 결제 | 비정기 지출, 일정 금액 초과, 계약 체결 | 💰 |
| 보안 | 접근 권한, 개인정보, 외부 유출 리스크 | 🔒 |
| 금지 | 내규·법령 위반 소지, 브랜드 훼손 가능 | 🚫 |

**적용 범위 (전 C-Level + AI CEO 동일)**
- AI CEO — 6-Stage 승인·통합 보고·중계 R/R 내, 본 3종 외 결재 질문 금지
- AI CFO — 재무·예산·세무, 본 3종 외 자율
- AI CHRO — 인사·채용·평가, 본 3종 외 자율
- AI CMO — 마케팅·콘텐츠, 본 3종 외 자율 (콘텐츠 검수 게이트는 별도 — 브랜드 훼손 가능 시 🚫 적용)
- AI COO — 운영, 본 3종 외 자율
- AI CPO — 회원·CS, 본 3종 외 자율
- AI CTO — 시설·기술, 본 3종 외 자율

**자율 진행 시 의무**
- 진행 전 보고 X (자율 결정·즉시 진행)
- 진행 후 결과 보고 (📋 일일 통합 보고 〈C〉 그룹 또는 텔레그램 직접 보고)
- 사고 발생 시 즉시 GM 보고 + 메모리·운영 아카이브 단독 기록 (`feedback_mistake_process_sop`)
- 본 3종 해당 의심 시에는 1건 결재 (`feedback_ceo_one_question_at_a_time`) — 추측 진행 금지

**SSOT 위치**
- 운영 프레임워크 페이지 섹션 2 (block_id `1a3f9c82-9eb2-4c74-b50a-3f09425c5a34`)
- URL: https://www.notion.so/AI-CEO-34a0407da94881c59c54dd7cc43b6072

**금지**
- 본 3종 외 결재 질문 금지 (다신 묻지 말 것 — GM님 명시)
- 추측으로 본 3종 적용 금지 — 명백한 결제·보안·금지 사안만
- 다른 카테고리(전략·브랜드·공식값) 자칭 결재 금지 — 폐기됨
- 묶음 결재 금지 (`feedback_no_bundled_followup_approval`)

**연관 메모리:**
- `feedback_minimize_approval_overhead` — 결재 최소화 원칙 (본 메모리 기준 4종 → 3종 정정)
- `feedback_clevel_autonomous_decision` — C-Level 자율 결정 원칙
- `feedback_threshold_amount_policy` — 1원 이상 결제 GM 결재 (💰 트리거 적용)
- `feedback_credentials_policy` — 비밀번호·기밀 정보 (🔒 트리거 적용)
- `feedback_brand_terminology` — 브랜드 용어 통일 (🚫 트리거 적용)
- `feedback_principal_address_gm` — GM님 호칭 표준
