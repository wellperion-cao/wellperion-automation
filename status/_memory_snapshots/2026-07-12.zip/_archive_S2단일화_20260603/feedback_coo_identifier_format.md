---
name: feedback_coo_identifier_format
description: "COO 작업 식별자는 \"시우-숫자\"(시우-1, 시우-2 …) 형식으로 통일"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d3de3966-d733-4b0d-a746-313d92b9381c
---

AI COO(시우)의 모든 작업·할일·진행 항목 식별자는 `시우-N`(시우-1, 시우-2 …) 형식으로 표기한다. COO-2026-... 같은 긴 코드 대신 닉네임+순번 단순 표기.

**Why:** GM님이 한눈에 어느 임원 건인지 즉시 식별 가능하게.
**How to apply:** 대기 요약 3섹션 표·보고·큐 등록 시 식별자 칼럼에 시우-N 사용. 관련: [[feedback_clevel_nickname_identifiers]], [[feedback_coo_standby_summary_format]]
