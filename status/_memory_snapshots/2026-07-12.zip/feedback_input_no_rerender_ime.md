---
name: feedback_input_no_rerender_ime
description: 입력 중 input DOM을 재생성하면 한글 IME 조합이 깨짐 — 검색/입력칸은 1회 생성·재사용
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d3de3966-d733-4b0d-a746-313d92b9381c
---

검색칸 등 사용자 입력 요소를 매 keystroke마다 `innerHTML`로 다시 그리면, 한글 IME 조합 중 DOM이 교체되어 '김남욱'이 'ㄱㅣㅁㄴㅏㅁㅇㅜㄱ'처럼 자모가 분리된다. 조합 중 `.value`를 코드로 set하거나 `setSelectionRange`를 호출해도 조합이 깨진다.

**규칙:** 입력 요소는 최초 1회만 생성하고 재렌더 시 재생성·value변경·캐럿조작 금지. 주변 UI(초기화 버튼·카운트 등)만 별도 토글. 값 동기화가 필요하면 사용자 액션(버튼) 경로에서만.

**Why:** 업무 SSOT 검색칸이 입력마다 input을 innerHTML 재생성 → 한글 조합 깨짐(2026-06-02). 1차로 포커스만 복원했으나 부족했고, DOM 영속화가 근본 해결. 가이드허브 내 다른 검색·입력 UI에도 동일 적용.
**How to apply:** `if(!el){ create once }` 패턴, oninput 핸들러는 상태만 갱신하고 input 요소는 건드리지 않기. 관련: [[feedback_ssot_hardcoded_list_sync]], [[feedback_mistake_process_sop]]
