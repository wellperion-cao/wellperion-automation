---
name: project-education-archive-policy
description: AI 교육자료 자동 정리 정책. 매주 일(2026-06-15 월→일 이동) 09:00 Desktop·Downloads → Desktop\_정리완료\03_교육\YYYY-MM\ 자동 이관.
metadata: 
  node_type: memory
  type: project
  originSessionId: 11519ba0-2bd5-41d2-a662-f8cd0e047d8e
---

# AI 교육자료 자동 정리 정책

## 적용 시작
2026-05-23 GM님 신지시. "AI 관련 교육자료 등은 매주 한번씩 정리해서 정리완료 폴더로 정리하는걸로".

## 정리 위치
Desktop\_정리완료\03_교육\YYYY-MM\

월별 sub-folder 자동 생성. 2026-05 부터 시작.

## 자동화 도구
파일: scripts\education_archive_weekly.py
Task Scheduler: Wellperion-Education-Archive-Weekly (**매주 일 09:00**) + Wellperion-AI-Education-Weekly (일 09:30, ai_education_auto_learner.py).

> **2026-06-15 GM 지시: 주간 정비 월→일 전면 이동.** 사유: 월요일=일 시작, 일요일=쉬는 날에 정비 끝내고 월요일은 가벼운 컨텍스트로 시작. 바뀐 곳(전수): ① 자동작업 2개(Education-Archive·AI-Education) Set-ScheduledTask Days 2→1(다음 06-21 일 검증) ② **주간 컨텍스트 정비** 정본 = 가이드 S2 통합원칙·T1 정의/SOP/일정표·**T2 범위표(단일출처, 6 C-Level 식별자 CMO-002·CPO-002·COO-001·CHRO-005·CFO-004·CTO-003)** 의 "매주 월 09:00"→"매주 일 09:00" 일괄 ③ `status/schedule.json` 6건 "매주 월요일"→"매주 일요일". 컨텍스트 정비≠교육자료정리(별개지만 같은 날). 5711 폐기이력은 보존. (구 docs/weekly_context_maintenance_sop.md는 T2/T1 중복이라 폐기 — SSOT는 가이드 T2.)

## 정리 대상
1. 위치: Desktop top-level + Downloads top-level (재귀 X — 작업 폴더 침범 차단)
2. 확장자: .pdf .docx .md .txt .html .epub
3. 키워드 매칭: claude, gpt, llm, anthropic, gemini, prompt-engineering, token-tips, ai-learning, ai-framework, 에이전트, 튜토리얼, 컨퍼런스, prompt
4. 7일+ 미수정 (편집 중 파일 보호)

## 결과 보고
텔레그램 @namuki_report_bot 1줄 (이관 N건 + 상위 5개 파일명).

## Why
GM님 의도 = Desktop 분산 학습 자료가 매주 쌓이는데 수동 정리 부담. 매주 자동 모음 → CEO 능동 감사 + GM 한눈 파악.

## How to apply
1. 신규 AI 학습 자료 다운로드 시 Desktop·Downloads top-level에 두면 다음 월 09:00 자동 이관
2. 7일 내 자료는 보호 (작업 중)
3. 키워드 매칭 안 되면 수동 이동 필요 — 키워드 추가는 본 메모리 + 코드 동시 patch
4. 충돌 시 자동 suffix (_1, _2)

[[project-asset-locations]] 자산 위치 SSOT의 Desktop 정리 정책에 합류.
