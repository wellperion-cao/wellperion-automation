---
name: feedback_formal_titles_for_upward_reports
description: "회장·상위·외부 보고=공식 직함(AI CMO 등), 내부·항로=닉네임(시모 등)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 8e6a94c1-0701-48f1-af38-3bbdc0d05c2b
---

**상위·외부 보고(회장·대표·투자자·대외)에는 공식 직함**을 쓴다: AI CEO·AI CMO·AI COO·AI CTO·AI CPO·AI CFO·AI CHRO. **내부(GM·C레벨 간·G1 항로·텔레그램 일상 보고)는 닉네임**(웰리·시모·시우·시토·시포·시뽀·시로) 유지.

**Why:** 2026-07-02 GM — 회장 보고용은 닉네임보다 공식 직함이 격에 맞음.

**How to apply:** 문서 대상이 상위·대외면 직함으로 렌더. 내부 운영 보고는 닉네임 그대로([[feedback_gm_reports_short_scannable]]). 대표(GM)는 상위 보고에서 '대표' 또는 'GM'.
