---
name: feedback_no_100pct_overclaim_report_actual_progress
description: "\"100%·완료\" 남발 금지 — 실제 진행된 만큼만 정직하게 표기(페이지·보고 공통)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: afb8b79d-e6d8-4718-9546-37f77c6c95a2
---

GM 지시(2026-07-07): **"100% 너무 남발하지 마. 정확하게 진행하고 있는 상황을 기준으로 해."** 완료·100% 라벨을 헐겁게 붙이지 말고, 실제로 정확히 된 만큼을 기준으로 상태를 적는다.

**Why:** 자동화·기능이 "핵심은 마무리됐으나 100%는 아님"인 경우가 많다. 이걸 100%/완료로 표기하면 결재 서류·경영진 보고·페이지가 실제보다 부풀려져 신뢰가 깨진다. L05(안 한 건 지어내지 않기)·정직 표기의 실천.

**How to apply:**
- 페이지/보고에 "100%·완료·완결" 대신 실제 상태로: "핵심 마무리·고도화 진행 중", "주요 배선 완료·잔여 X", "라이브·미측정 정직 표기" 등.
- 진짜 완료(실증거 재현)만 🏁/완료 도장 — [[feedback_welly_verification_standard]].
- 예시 사실(2026-07-07): **CMO 마케팅 자동화 = 마무리됐으나 100% 아님. 다음 단계 = 영상 제작 및 고도화 진행 중.** 전사회의·월간운영계획·자율현황의 CMO 문구는 이 정직 프레이밍으로.
- 관련: [[project_cmo_marketing_pipeline_loop]] · [[feedback_gm_reports_short_scannable]] · [[feedback_report_pages_minimal_helper_text]]
