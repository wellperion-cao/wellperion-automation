---
name: feedback_coo_owns_ops_4dept_interior
description: 운영 4부서 체계 내부 = 시우(COO) 책임이나 '지시형'(구체 빈칸·지시 시에만). 상시 자율 보강 폐지(2026-06-24 GM)
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f4d15087-26db-48d5-a6f7-3cf3f29256b1
---

운영 4개 부서 체계(운영부·시설부·지원부·주차관리부) 페이지의 **틀(레이아웃·탭·링크)은 완성**됐다. 내부 운영 콘텐츠(보드·매뉴얼·항목·SOP)는 시우(COO) 책임이나, **방식 = '지시형'**: 구체적 빈칸·GM/웰리 지시가 있을 때만 착수. **상시 자율 '보강·꾸미기' 소유는 폐지**(2026-06-24 GM — 상시로 두면 '시키는대로 채우는' 저가치 busywork가 됨). 큐 배 64 = 지시형·PENDING(대기).

**Why:** 틀과 내부 운영 콘텐츠는 책임이 다르고 내부는 운영을 아는 COO가 채워야 살아있다. 단, 끝없는 '꾸미기'를 상시 자율로 돌리면 가치 없는 일을 만들어낸다 → 실제 필요(빈칸·지시)에 묶는다.

**How to apply:** 4부서 내부 작업은 **구체적 빈칸·GM/웰리 지시가 있을 때만** 시우가 착수(상시 자율 발의 아님). 페이지↔시트 동기·정렬 등 기본 정합은 시우 기본 책임 유지. 관련: [[feedback_coo_owns_task_hygiene_conflict_safe]] · [[project_facility_dept_roles]] · [[project_parking_dept_standalone]] · [[feedback_page_sheet_sync_default]] · [[project_3line_org_structure]]
