---
name: feedback-session-name-wellperion-gm
description: "Claude Code 세션명은 항상 \"Wellperion GM\" 사용. \"Wellperion CEO\" 금지."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: e5ddfbd0-7073-4b6d-8a75-e2e140267a52
---

Claude Code 세션(--remote-control, --name 등)의 표시 이름은 항상 "Wellperion GM"으로 설정한다.

**Why:** GM님이 직접 지시. "Wellperion CEO"는 GM님 본인 명칭이 아님.

**How to apply:** --remote-control, --name 등 세션명을 지정하는 모든 곳에서 "Wellperion GM" 고정. 부팅 스크립트·bat 파일에도 동일 적용.
