---
name: PowerShell 5.1 ScheduledTasks 모듈 한계 + schtasks.exe 폴백 SOP
description: Windows 자동화 통합 — PS5.1 ScheduledTasks 우회법·.bat 영문전용·예약작업 검은창=VBS 숨김런처
type: reference
originSessionId: c7b6546c-5746-4a60-b44a-0ccf59e8ec20
---
Windows PowerShell 5.1 (powershell.exe)의 `Set-ScheduledTask` / `New-ScheduledTaskSettingsSet` cmdlet은 `MultipleInstancesEnum`에 대해 **Parallel · Queue · IgnoreNew** 세 값만 지원하며, `StopExisting`은 enum 미지원으로 적용 불가.

**Why (2026-05-10 발견):** StopExisting 적용 시도 중, v2 스크립트가 `Set-ScheduledTask`로 시도 → "Cannot convert null... due to enumeration values that are not valid. The possible enumeration values are Parallel,Queue,IgnoreNew". 4개 작업 모두 실패. v3 schtasks.exe + XML namespace 패치로 우회해 5/5 적용 성공.

**How to apply:**

**1. MultipleInstancesPolicy 적용 시**
- ❌ `Set-ScheduledTask -InputObject $task` 후 `.Settings.MultipleInstances = 'StopExisting'` — enum 한계로 실패
- ✅ **schtasks.exe + namespace-aware XML 패치** + `/Create /XML <file> /TN <name> /F`
- ✅ XML 파일은 **BOM 없는 UTF-8**로 저장 (`[System.Text.UTF8Encoding]::new($false)`)

**2. XML namespace-aware 패치 패턴**
```powershell
[xml]$xmlObj = $xmlString
$nsMgr = New-Object System.Xml.XmlNamespaceManager($xmlObj.NameTable)
$nsMgr.AddNamespace('t', 'http://schemas.microsoft.com/windows/2004/02/mit/task')
$settingsNode = $xmlObj.SelectSingleNode('//t:Settings', $nsMgr)
$multiNode = $settingsNode.SelectSingleNode('t:MultipleInstancesPolicy', $nsMgr)
if ($multiNode) { $multiNode.InnerText = 'StopExisting' }
```

**3. 실행경로(.bat) 재지정 시 Set-ScheduledTask 사용**
- ❌ `schtasks /Change /TN <name> /TR <new path>` — 암호 프롬프트 → 무한대기
- ✅ **관리자 권한 + PowerShell `Set-ScheduledTask -TaskName <name> -Action $a`** — 트리거·principal 전부 보존, 암호 프롬프트 없음

**4. 다중 인스턴스 정책 enum 매핑**
| 정책 이름 | PowerShell 5.1 |
|---|---|
| Parallel | ✅ |
| Queue | ✅ |
| IgnoreNew (기본값) | ✅ |
| **StopExisting** | ❌ enum 미지원(XML로만) |

**5. LastResult 0x80070420** = `ERROR_SERVICE_ALREADY_RUNNING` — 정상 보호 코드(오류 아님).

## .bat 파일 영문 전용

Windows `.bat` 배치 파일에 한글(주석 REM·echo 포함)을 넣으면, 한국어 Windows cmd.exe가 기본 CP949로 읽으면서 UTF-8 한글이 깨지고, 깨진 문자열이 명령으로 잘못 해석돼 "내부 또는 외부 명령이 아닙니다" 오류가 줄줄이 발생한다(`chcp 65001`을 넣어도 그 줄 이전·REM 라인은 이미 깨짐).

**Why:** 2026-06-02 `_unregister_arm_scheduler.bat`에서 한글 주석·echo가 전부 깨져 GM 실행 실패.

**How to apply:** GM이 더블클릭/실행하는 배치(.bat)는 **영문(ASCII) 전용**으로 작성. 안내 문구가 한글이어야 하면 배치 대신 PowerShell(`.ps1`, UTF-8 BOM) 또는 텔레그램/대화로 전달.

## 예약작업 검은창 숨김=VBS 숨김런처

부팅/로그인마다 검은 cmd·python 창이 뜨는 근본 원인: 예약작업이 `LogonType=Interactive` + 콘솔판 `python.exe`/`.bat`(cmd.exe)로 등록돼 **GM 화면 세션에 창을 노출**.

**해결책 SSOT**: `launchers/*.vbs` 숨김 런처(`WScript.Shell.Run cmd, 0, False` = window style 0) + `fix_task_windows.bat`(GM 1회 관리자 실행 → `scripts/fix_task_windows.ps1`이 각 작업 Action을 `wscript.exe <vbs>`로 재지정). 보고라인·IG발행 유지, 창만 제거.

**주의**: 예약작업은 RunLevel=Highest라 수정에 관리자 권한 필수. 신규 .bat 런처 작성 시 숨기려면 반드시 VBS 숨김 래퍼 경유.

**Claude 자동 업데이트**: 실행 중 `claude.exe`는 Windows가 잠가 교체 불가. 정답 설계 = **부팅 시 `Start-AI CEO.bat` [0/4]가 단일 업데이터**(claude.exe 0개일 때만 update+검증). 실제 업데이트는 **모든 Claude 창 닫고 재부팅** 때만 적용. 나머지 6개 Start-AI *.bat은 업데이트 단계 없음(git pull+실행만).
