---
name: feedback_brand_voice_positioning
description: "웰페리온 외부 채널 포지셔닝 = '프리미엄 라이프스타일 클럽'. 금지어·가족 표현 규칙"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: e4974790-ef30-4c7a-8bab-a27369911016
---

외부 채널(네이버 플레이스·구글·블로그·소개문 등) 웰페리온 포지셔닝 = **"프리미엄 라이프스타일 클럽"** (스포츠·스파·웰니스가 한 공간에 통합 · "하루의 품질을 설계하는 곳"). deep-interview로 GM 확정(2026-06-06).

**금지 표현(GM 거부):** "하이엔드 프라이빗 스포츠클럽" · "사교" · "생활형 커뮤니티". 또한 브랜드 규칙상 "피트니스/헬스장" 금지 → "스포츠".

**가족·세대 면:** "온 가족이 함께하는" 으로 자연스럽게 표현(사교·커뮤니티 단어 회피).

**Why:** GM이 포지셔닝 문구를 3회 거부(하이엔드프라이빗→사교→생활형커뮤니티) — 브랜드 보이스가 미확정이라 반복 수정 발생. deep-interview로 못 박음.
**How to apply:** 모든 채널 업체 소개·캡션·CS 문구에 이 결을 일관 적용. 톤 출처=회사소개서 v2.19. 규모 3,000평·대표 02-6261-1200은 [[reference_company_phone]]. 확정 카피 원본=status/briefs/CMO-2026-06-06-CHANNEL-REGISTRATION-PACK.md
