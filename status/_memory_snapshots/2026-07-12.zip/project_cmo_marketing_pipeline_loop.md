---
name: project_cmo_marketing_pipeline_loop
description: 시모(CMO) 마케팅 폐루프 5단계 정본 — 콘텐츠→문의→등록→대시보드→평가환류
metadata: 
  node_type: memory
  type: project
  originSessionId: ce65ab07-aa07-4709-b674-d44aa113df4a
---

시모(CMO) 운영 북극성 = **마케팅 폐루프(닫힌 고리) 5단계** (GM 박제 2026-06-23). 정본=S2 cmo탭.

1. **콘텐츠**: 기획 → 자동 업로드 (M5→텔레그램 승인→5채널 발행). ✅완성. [[reference_4channel_publish_execution]] [[project_ig_upload_ssot]]
2. **문의 접수**: CTA → 문의페이지(wellperion.com/ko/inquiry) → 자동 집계·시트 기록 + 문의 DB 페이지(+체험·투어&상담 캘린더). 🟡부분(시트의존, 자체DB 미구축). [[reference_inquiry_funnel_map]] [[project_self_hosted_inquiry_db_goal]] [[project_funnel_stage_pages]]
3. **등록 반영**: 회원 관리프로그램 신규 등록 명단 체크 → 문의 DB 페이지 통해 등록 체크·등록 현황 반영. ❌가장 약함(등록매칭=전화 수기·등록일 미사용→추정). [[project_member_db_sheet]] [[project_member_inquiry_page_wiring]]
4. **마케팅 대시보드**: 현황. 🟡부분(전환·등록=추정, 채널귀속 구조불가). [[project_dashboard_conversion_data_honest_limits]]
5. **분석→평가→환류**: 대시보드 분석 → 콘텐츠 평가 → 1)로 되먹임. ❌약함(정성뿐, 구조화 루프 없음). [[feedback_marketing_conversion_bottleneck]] [[project_conversion_funnel_leak_diagnosis]]

**진단:** 1번(공급)은 강하나 **고리 닫는 3·5번이 끊김** → 콘텐츠가 문의·등록을 만들었나를 못 닫아 평가→재기획 환류 불가. **우선순위=3번 등록매칭부터**(닫혀야 4·5 숫자가 진실해짐). GM 지시 2026-06-23.
