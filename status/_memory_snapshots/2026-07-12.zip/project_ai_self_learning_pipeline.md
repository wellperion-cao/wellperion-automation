---
name: project_ai_self_learning_pipeline
description: "AI 자기학습 파이프라인 완성(시토 ship_no 102, 2026-06-23). 수집·요약·박제 + 신설 ③제안→승인→반영. 두뇌=claude CLI 재사용(API크레딧 0). 잔여=주간 schtasks 등록(namuk 계정). claude CLI를 python subprocess로 부르는 교훈 포함."
metadata: 
  node_type: memory
  type: project
  originSessionId: e72855a2-e6a4-4538-b270-8bb89a925afa
---

시토 ship_no 102. 끊긴 **③ 적용(반영)** 고리를 '제안→승인→반영' 안전구조로 메워 완성(2026-06-23 GM go).

**파이프라인 구조**
- ① 수집·요약: `scripts/ai_education_auto_learner.py`. Task Scheduler 작업 `Wellperion-AI-Education-Weekly`가 **이미 등록**(namuk 계정)돼 가동 중. `status/schedule.json`엔 사전알림용 등재.
- ② 제안 생성기: `scripts/ai_learning_proposer.py` (신설). `latest_summary.json` → 개선제안 카드 → `status/learning_proposals.json` + 텔레그램. **두뇌=claude CLI(`claude -p`) 재사용** (GM 결정 2026-06-23: 별도 Anthropic API 크레딧 미사용). 규칙폴백 2순위.
- ③ 승인→반영: 같은 스크립트 `--list/--approve/--reject/--mark-applied` 로 상태전이만. **실제 반영(메모리/프롬프트 수정)은 승인 후 웰리가 수동** — 스크립트엔 자기수정 코드 0(수위=GM 결정 '제안만→승인 후 반영', [[feedback_security_live_activation_needs_gm_go]] 정렬).
- ④ 효과 공책(2026-06-23): 반영된 제안의 **실제 효과를 사람이 회고 기록**(자동측정 불가). `--record-effect <id> --effect 효과있음|효과없음|미확인 --note`(status=반영 카드만). **T1(기술&AI학습) ▸ 자기학습 탭 ▸ 📓 반영·효과 로그** 섹션에 표시. 역할분리=**G1=제안 검토·승인 / T1=반영·효과 회고**. 목적=자랑 아니라 **몇 달 후 GM이 '유지냐 폐기냐' 판단할 근거**(빈 공책=접기). GM 합의 '만들고 지켜보자'.

**★ claude CLI를 python subprocess로 호출하는 법 (실증 4회로 확정)**
1. `shutil.which("claude")` 로 `claude.CMD` 풀패스 해결 — `["claude", ...]` 직접은 Windows에서 `.cmd` 못 찾아 FileNotFoundError.
2. 긴 한글 프롬프트는 명령줄 인자(`-p "..."`) 대신 **stdin**(`input=prompt`)으로 — 인자 길이/인코딩 한계로 빈 응답('char 0' JSON 파싱 실패) 발생. `subprocess.run([bin,"-p"], input=prompt, ...)`.
3. Task Scheduler는 **namuk 계정**으로 등록(전 웰페리온 작업 동일). `/ru SYSTEM`이면 사용자 npm의 claude·사용자 환경변수(PYTHONIOENCODING 등)를 못 찾아 폴백.

**주간 자동화·요일(2026-06-23 교정)**: 자기학습 계열은 전부 **일요일** — 컨텍스트정비 일 09:00 / AI교육 수집·요약(Wellperion-AI-Education-Weekly) 일 09:30 / 제안생성(Wellperion-AI-Learning-Proposer-Weekly) 일 09:45(수집 직후). ★최초 제안Task를 월요일로 잘못 등록 → GM이 `schtasks /delete`+`/create ... /d SUN /st 09:45 /it`로 일요일 재등록(요일 변경은 삭제 후 재생성). 등록은 **`/it`**(로그온 시·비번 불필요 — `/ru namuk /rp *`는 MS계정이라 실패). `schtasks /run` 실증서 ClaudeCLI 제안 3건 적재 확인.

설계서 = `.omc/specs/ai-self-learning-pipeline.md` (.gitignore라 로컬만). 연계 = [[project_education_archive_policy]].
