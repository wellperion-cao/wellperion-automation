---
name: feedback_coo_owns_task_hygiene_conflict_safe
description: 시우(COO)가 할일 정리 상시 소유 + 웰리와 충돌 안 나는 쓰기 규칙
metadata: 
  node_type: memory
  type: feedback
  originSessionId: bfbdcf2d-b7f2-4f95-9adf-bcaf04512e15
---

GM 지시(2026-06-05): 웰리(CEO 오케스트레이션)가 아직 덜 여물어 할일 정리가 안 됨 → **시우(COO)가 할일 정리를 상시 맡는다.** 단 웰리가 동시에 손댄 것과 **충돌(서로 덮어쓰기) 금지.**

**왜:** 같은 저장소를 웰리·시우·watcher·changelog 훅이 동시에 만진다. 2026-06-05 실사고 — 시우 부팅 때 읽은 _queue.json은 PENDING이었는데, 웰리가 그 사이 같은 2건(SUPPORT-ISSUE-SAVE·TODO-UPDATE-EMPTY-OVERWRITE)을 완료·커밋(749bd19·b29681c)해 DONE으로 바꿔둠. 시우가 옛 스냅샷으로 진행했으면 같은 일 2번 + 웰리 완료분 덮어쓸 뻔. [[feedback_git_commit_atomic_vs_watcher_reset]] [[reference_guidehub_concurrent_commit_corruption]]

**How to apply (충돌-세이프 4규칙):**
1. **권한 분리:** 웰리 = 배정(assign) + 검증 후 완료 도장(status→DONE). 시우 = 정리·가시화(중복 제거·끝난 일 걷어내기·급한 순 정렬·GM께 살아있는 일만 표시). 서로 다른 칸을 만진다. 시우는 status를 임의로 DONE 전환 안 함(웰리 검증 권한).
2. **쓰기 직전 재읽기:** _queue.json 수정 직전 항상 최신본 다시 읽고 내가 바꾸는 줄만 최소 수정. 부팅 스냅샷으로 통째 덮어쓰기 절대 금지(오늘 사고 직접 원인).
3. **원샷 커밋 + autostash, 직렬화:** 묶어서 한 번에 커밋. changelog 훅/watcher와 안 부딪히게, 커밋 전 최신 합류(pull/rebase 정신).
4. **단일 출처:** _queue.json = 기계 원장(자동등록). GM께 보여주는 "살아있는 일" 표는 그걸 읽어 만든 뷰일 뿐, 따로 두 번째 목록 만들지 않음([[project_principles_s2_single_source]] 중복 금지).
