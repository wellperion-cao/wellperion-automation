---
name: feedback_welly_publish_verify_artifacts
description: 웰리는 발행 전 status·미리보기뿐 아니라 발행기 필수 입력 산출물 실재까지 검수
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 5841da60-6926-442c-aff6-54482211cb13
---

발행/완료 검증 시 status·미리보기 경로만 확인하면 부족하다. **발행기가 실제로 요구하는 입력 산출물이 폴더에 실재하는지**까지 검수해야 한다.

**Why:** 2026-06-04 AI5(개인계정 인스타) 발행이 3번 실패. 웰리가 review_queue status='검수대기'·preview 경로만 검증하고, IG 발행기 필수 입력 `큐레이션_추천.md`가 누락된 걸 못 잡음. GM 직접 지적: "다음엔 문제 안 되게 확실하게 검수해서 보완하라."

**How to apply:** 콘텐츠 발행 전 체크 = ① review_queue status ② preview 경로 200 ③ **발행기 필수 입력 파일 실재**(IG=큐레이션_추천.md, 블로그/카페=body_file·image_dir) ④ output 슬라이드 N장 실재. 하나라도 없으면 "검수 통과" 선언 금지. 관련 함정 정본 → [[reference_ig_personal_publish_pipeline]].
