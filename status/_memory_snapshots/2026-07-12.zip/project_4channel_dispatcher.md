---
name: 4channel-dispatcher
description: IG 외 4채널(블로그·카페·카카오·당근)은 M5 검수큐 경유가 정본. register_channel_review→텔레그램승인→watcher 임시저장.
metadata: 
  node_type: memory
  type: project
  originSessionId: 30f9a123-d094-47b6-b3c8-34d95f096505
---

GM 방향: 발레·바레 등 신규 클래스 콘텐츠를 IG 공식발행 외 **4채널(네이버 블로그·카페(동부이촌동)·카카오 채널·당근)에 자동 임시저장**. 발레가 첫 시범.

## 정본 파이프라인 (2026-06-05 GM "검수요청 단계가 빠졌다" 지적 후 복원)
`output/슬라이드+본문 → M5 검수큐 등록(검수대기) → 텔레그램 [승인]카드 → 승인 시 watcher가 임시저장`
- **register_channel_review.py** (신규, 커밋 2de9e46) = IG용 `register_publish.py`의 **채널판**. 콘텐츠폴더+채널설정 → `review_queue.json` id기준 upsert(검수대기) + 슬라이드 montage 미리보기를 `cmo/review/`로 복사 + 채널폴더에 슬라이드(ig_*.jpg) 채움. **발행·카드발송 안 함**(공개부작용 분리). 발행완료 강등가드·미삭제.
- **send_review_card.py --id <id>** = 텔레그램 검수카드(미리보기+[✅승인][❌반려]). `--all-pending`도 가능.
- **ig_review_publish_watcher.py** = 승인(bot 콜백 status='승인')→채널분기. 블로그/카페=**`--mode draft`(임시저장, 스티커0개, GM 정책: 최종 게시는 GM 수동)**, **당근=`danggn_upload_playwright.py --mode draft`(글 자동입력+임시저장, 이미지는 GM 수동첨부; 당일 QR세션 없으면 exit5→수동알림 폴백)**, 카카오=자동입력 스크립트 미구현→수동알림(status='수동발행대기'). 중복알림 가드: 카드 보낸 id(.review_card_msgids.json)는 텍스트 알림 생략.
- 큐 엔트리(채널, WJO·발레가 본보기): id·title·channel·account·folder·**body_file·image_dir·image_glob(ig_*.jpg로 stale 대표이미지 회피)**·menuid(카페=659)·body(M5표시)·preview·status.

## ⚠️ 우회 금지 (내 과거 실수)
- 처음 만든 `publish_4channel_dispatcher.py`는 **검수 단계를 건너뛰고 업로드기를 직접 호출**한 잘못된 구조. M5에도 안 뜨고 텔레그램 승인도 못 함. 채널 폴더에 본문만 손으로 넣는 것도 금지. **반드시 register_channel_review → M5 → 승인 경유.** [[feedback_visual_match_one_pass_not_iterate]](구조 먼저 보고)
- M5(cmo-publish)는 검수·업로드 단계 SSOT([[project_ig_upload_ssot]]). 검수카드는 **텔레그램+M5 둘 다** 남겨야(GM 명시).

## 발레 현황(2026-06-05) — 검수대기 등록 완료
- 4채널 `검수대기` 등록(CMO-2026-05-20-BALLET-{BLOG/CAFE/KAKAO/DANGGN}), 텔레그램 카드 4장 발송, push 완료. 커밋 429f6df.
- GM 내용 확정: 수강료 제거 / 클럽설명 **"3,000평 멤버십 스포츠클럽"** 통일(하이엔드 프라이빗 멤버십 커뮤니티 폐기) / "웰페리온 이용 안내" / CTA 한줄 **"문의 : wellperion.com/ko/inquiry"**(이 콘텐츠는 한/영 2줄 아님). 오픈일=슬라이드 기준 2026.05.
- 다음: GM 승인 → 블로그/카페 임시저장 실작동 확인(브라우저 로그인 세션 필요).

연계: [[project_ig_content_folder_standard]] · [[project_ig_upload_ssot]] · [[feedback_cta_standard_bilingual]] · [[project_danggn_manual_b_confirmed]] · [[project_kakao_bot_rd_closed]]
