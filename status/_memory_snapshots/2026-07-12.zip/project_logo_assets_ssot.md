---
name: project-logo-assets-ssot
description: 웰페리온 공식 로고는 1. AI학습자료_아카이브/08_로고&워터마크/_assets/logo/ 단일 SSOT 참조 의무. base64 인라인 금지.
metadata: 
  node_type: memory
  type: project
  originSessionId: 8e87fd02-d8ad-40f1-b03e-3553ee18a17f
---

웰페리온 공식 로고 자산 단일 SSOT 정책 (2026-05-28 신설, 2026-05-28 이전)

위치: `1. AI학습자료_아카이브/08_로고&워터마크/_assets/logo/`
※ 옛 위치 `3. 웰페리온 가이드/_assets/logo/`는 v2.21에서 학습자료 아카이브로 통합 이전.

자산 (총 22개):
- wellperion_wordmark.png — 베이지 가로 wordmark
- wellperion_wordmark_white.png — 흰색
- wellperion_wordmark_black.png — 검정
- w_mark.png — W 한 글자 (현재 코드 미참조, CSS 텍스트로 대체됨)
- sportsclub_wordmark.png — SPORTS CLUB(유소년) 전용 방패+월계관+텍스트 (브랜드 가이드 PDF 페이지 12 자동 crop)
- watermarks/ 하위 18개 사업부별 워터마크 (corner 9 + mark 9)
  - 파일명 형식: `{코드}_LOGO-{logo_hex}_BG-{bg_hex}_{타입}.png`
  - 예: PT_LOGO-B54840_BG-512B32_corner.png
  - 코드 9개: MAIN/PT/PILATES/SWIMMING/SQUASH/GOLF/GYMNASTIC/SPORTS/BRAD
  - 타입 2개: corner (가로 락업 30%), mark (W 한 글자 12%)
- _README.md — 사용 가이드 (각 폴더에 1개씩)

규칙:
1. 새 HTML 페이지에서 로고 base64 인라인 금지. 항상 _assets/logo/ PNG 상대경로 참조.
2. 페이지 깊이별 상대경로 (가이드허브 폴더 기준):
   - 가이드허브 wellperion_guide(main).html → `../1. AI학습자료_아카이브/08_로고&워터마크/_assets/logo/...`
   - 가이드허브 1단계 하위 (cmo/, coo/) → `../../1. AI학습자료_아카이브/08_로고&워터마크/_assets/logo/...`
   - 가이드허브 2단계 하위 (coo/notice/) → `../../../1. AI학습자료_아카이브/08_로고&워터마크/_assets/logo/...`
3. 인쇄·새 윈도우(window.open)에서 상대경로 사용 시 `<base href="${window.location.href.replace(/[^/]*$/, '')}">` 트릭으로 부모 페이지 기준 해석.

**Why:** GM 지시 — 가이드허브 하위에 두지 말고 학습자료 아카이브에 통합. 자산 SSOT 단일 위치 (브랜드 가이드 PDF와 동일 폴더 트리). 또한 매번 base64 회수가 오래 걸린다는 GM 지적 해소.

**How to apply:** 새 페이지·도구 만들 때 로고 필요 시 `<img src=".../1. AI학습자료_아카이브/08_로고&워터마크/_assets/logo/wellperion_wordmark.png">` 한 줄로 끝. 로고 교체 시 이 폴더 PNG만 갈아끼우면 모든 페이지 자동 반영.

연관:
- [[project_asset_locations]] — 자산 위치 SSOT 일반 정책
- 브랜드 색상 SSOT: `1. AI학습자료_아카이브/06_공지_안내/wellperion_brand_identity(최종시안).pdf`
- 사업부별 색상 + 워터마크 파일명 매핑표: 위 폴더 내 `_README.md` (logo + watermarks 각각 1개)
