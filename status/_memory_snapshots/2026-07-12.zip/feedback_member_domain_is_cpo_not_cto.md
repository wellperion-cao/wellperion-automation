---
name: feedback_member_domain_is_cpo_not_cto
description: "회원·문의회원·회원관리·등록전환 로직은 시포(CPO) 영역 — 시토는 진단·인프라까지만, 구현은 시포 위임"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 27614e26-629d-451c-baf7-f3bd0b1dee2a
---

회원 DB·문의회원.html·회원관리.html·문의→등록 전환 로직(member_* GAS 액션, _regUpsert_ 등)은 **R/R상 시포(CPO) 소관**이다. 시토(CTO)는 진단·서버·텔레그램 알림 배관까지만 하고, 회원 도메인 구현은 시포에 배정·위임한다.

**Why:** 2026-06-26 시토가 '문의→등록 전환 자동화(A안)'를 진단하면서 "정본 이관 구현은 시포에 배정"이라 스스로 말해놓고, '알림·자동화 인프라'로 자기합리화하며 구현까지 [시토] 태그로 직접 해버림 → GM이 "이건 시포건데 왜 너가해?"로 월권 지적. 진단·인프라(알림 라우팅·dedup·서버)는 시토 정당하나, 회원 데이터·전환 정책 구현은 CPO 라인.

**How to apply:** member_inquiry_*·member_active_*·member_registered_*·_regUpsert_·문의회원/회원관리 페이지 작업이 나오면 → 진단·서버·알림 배관은 시토가 받쳐주되, 실제 회원 로직 편집·완료는 시포 배로 띄워 위임. 커밋 태그도 [시포]. 관련 [[project_ai_clevel_to_practitioner_mapping]] · [[feedback_welly_handsoff_clevel_selfdef]] · 경계 흐리지 말 것([[feedback_scope_and_model_discipline]]).
