---
name: reference_drive_move_delete_via_gas
description: 구글 드라이브 파일 이동/삭제는 연결된 Drive MCP로 불가 — GAS DriveApp 함수를 GM이 실행
metadata: 
  node_type: memory
  type: reference
  originSessionId: 260c4dac-9847-42a6-a1ac-9aeca99e374c
---

연결된 claude.ai Google Drive MCP는 **읽기·생성·복사만** 지원한다(`read_file_content`·`get_file_metadata`·`search_files`·`copy_file`·`create_file`·`get_file_permissions`·`list_recent_files`). **이동(부모 변경)·삭제·휴지통 도구가 없다.**

→ 파일을 **옮기거나 휴지통**으로 보내려면 시모가 직접 못 한다. **GAS DriveApp 1-함수**를 만들어 GM이 1회 실행:
- 이동(ID 보존, 링크 안 깨짐): `DriveApp.getFileById(id).moveTo(DriveApp.getFolderById(folderId))`
- 휴지통: `DriveApp.getFileById(id).setTrashed(true)`
- ⚠️ 폼/시트는 **복사(copy_file) 금지** — 새 ID 생성으로 FORM_SHEETS·문의페이지 폼 링크가 깨진다. 반드시 moveTo(원본 이동).
- 첫 실행 시 DriveApp 권한 새로 승인 필요. 코드→메모장·크롬 동반은 [[feedback_gas_deploy_notepad_chrome_pair]]. 실측 2026-06-15(트래시·폴더이동 2회 요청 모두 MCP 불가→GAS).
