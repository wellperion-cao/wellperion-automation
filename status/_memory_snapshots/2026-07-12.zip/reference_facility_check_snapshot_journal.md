---
name: reference_facility_check_snapshot_journal
description: 시설 점검 제출 이력=점검일지_facility 스냅샷(지원부 점검일지_support의 시설 트윈). 입력률+이상건수 기반, 이상은 서버 자동계산
metadata:
  node_type: memory
  type: reference
  originSessionId: e104ce56-2d78-47aa-92cf-94f2b9116ce5
---

**점검일지 스냅샷 = 제출 단위 요약 1행 적립**(감사 이력 + 월간집계 소스). 정본 = `.deploy-check/지원팀 일일점검.js`. 시트명 = `_snapshotTabName(dept)` = `점검일지_` + dept코드(영문). 지원부=`점검일지_support`, 시설부=`점검일지_facility`(운영/주차는 미구현).

**함정(2026-07-07 GM 포착):** 시설부는 제출 시 `saveFacilityMeasure`가 `시설_공용구역`에 **항목별 측정행만** 기록하고 `snapshot_append`를 안 불러 **제출 요약 스냅샷이 없었다**(지원부는 제출마다 점검일지_support 적립). "누가 언제 몇 항목·이상 몇 건" 이력이 안 남음. GM이 "점검일지_support처럼 점검일지_시설도 있어야" 지적 → 신설.

**구현(2026-07-07 시우, 커밋 29549129·f0cf7018):**
- `_initFacilitySnapshot()` + `FACILITY_SNAPSHOT_HEADERS`(13열): 제출시각·날짜·부서·회차·점검자·총항목·입력완료·**입력률(%)**·이상건수·이상내용·점검시작·점검완료·소요(분). ⚠️완료율 아님 — 시설 지표=입력률+이상건수([[reference_dept_check_metric_map]] L05 억지통일 금지).
- `saveFacilityMeasure`가 `시설_공용구역` 기록 뒤 `점검일지_facility`에 요약 1행 append((날짜,회차) 중복=덮어쓰기·제출시각 내림차순). try/catch로 감싸 스냅샷 실패가 본 저장 안 깨게. **지원부 경로 무접촉**.
- **이상 자동계산**: 프론트는 측정값만 전송(이상 미전송) → 서버가 제출시점에 `_facilityRangeHits(measureStr)`(FC_MEASURE_RANGES 대조, 라인 ~3214·3226)로 이탈 판정 → 이상건수·이상내용 채움. **monthly report(`_aggregateMonthlyFacility`)와 같은 함수 재사용 → 대시보드 이상건수와 스냅샷 항상 일치**.
- `dump_snapshot&dept=facility` 액션은 원래 support 열스키마 하드코딩이라 facility idx8/9(이상)만 별도 노출하도록 보강.

**후속(선택):** 과거 시설_공용구역 이력은 스냅샷 백필 안 됨(going-forward만). 월간집계 1차 소스를 시설_공용구역→점검일지_facility로 전환은 미실시(현행 유지, 회귀 방지). 배포=clasp(.deploy-check·cao), 실배포ID AKfycbyXw4ZaA6hLK…(URL 보존·기존 배포 업데이트).
