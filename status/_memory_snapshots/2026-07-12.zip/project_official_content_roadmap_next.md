---
name: project_official_content_roadmap_next
description: 공식계정 다음 발행 항로 — F3(회복) 다음 강습 3편
metadata: 
  node_type: memory
  type: project
  originSessionId: ad3d48ad-6510-4c51-82ae-0dc076e3ba8d
---

웰페리온 공식계정(@wellperion) 발행 항로 (2026-07-09 GM 지정):
- **2026-07-10(내일) = 공식 #F3 — 회복(사우나·건식사우나 등)** 발행 (F1 운동시설·F2 편의시설 완료, 5채널)
- **그다음 = 강습 3편** 시리즈 (성인·유소년 강습 소재, 3편)

시설 F시리즈(F1~F3)를 닫고 강습 시리즈로 전환한다. 제작 루프 로드맵(`instagram/_AI시리즈_로드맵.md`)·CMO 큐에 이 순서를 반영. 5채널(IG·블로그·카페·카카오·당근) 자동발행+링크회수 완결은 [[project_official_content_roadmap_next]]과 함께 시모 배826 과제. 관련: [[project_official_facility_series_unified_main_page]] · [[project_cmo_marketing_pipeline_loop]]
