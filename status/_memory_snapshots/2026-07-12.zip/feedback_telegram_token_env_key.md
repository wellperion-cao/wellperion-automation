---
name: 텔레그램 봇 토큰 환경변수 키명 = TELEGRAM_BOT_TOKEN 단일
description: 모든 모듈에서 봇 토큰 환경변수 키명은 `TELEGRAM_BOT_TOKEN`으로 통일. TELEGRAM_TOKEN·NAMUKI_BOT_TOKEN 등 변형 키명 신규 도입 금지. 평문 하드코딩 절대 금지.
type: feedback
originSessionId: 330cdb86-ca8b-4bed-8ffa-f36af02b5c6d
---
텔레그램 봇 토큰을 코드에서 로드할 때 환경변수 키명은 `TELEGRAM_BOT_TOKEN` 단일로 통일한다. 변형 키명(`TELEGRAM_TOKEN`, `NAMUKI_BOT_TOKEN`, `BOT_TOKEN` 등) 신규 도입 금지. 모든 `.env`·코드·문서·헬프 메시지가 같은 키를 참조해야 한다.

**Why:** 2026-04-28 화 CHRO 발송 시 HTTP 401 사고 발생. 진단 결과 프로젝트 전체에 키명이 3종(`TELEGRAM_BOT_TOKEN` / `TELEGRAM_TOKEN` / `NAMUKI_BOT_TOKEN`)으로 분산되어 모듈마다 서로 다른 키를 조회하며 일부는 빈 토큰으로 API 호출 → 401. 추가로 `telegram-report-bot/bot.py`에 토큰 평문 하드코딩 발견 (`feedback_credentials_policy` 위반). 키명 분산은 보고 라인 마비를 유발하고, 평문 하드코딩은 보안 사고를 유발한다.

**How to apply:**
- 신규 모듈·스크립트 작성 시 토큰 로드는 항상 `os.getenv("TELEGRAM_BOT_TOKEN")` 또는 동등한 표현으로 키명 고정.
- 변형 키명(`TELEGRAM_TOKEN` 단독·`BOT_TOKEN`·`NAMUKI_BOT_TOKEN` 등) 도입 시 코드 리뷰에서 즉시 차단.
- `.env`·`.env.example` 등 환경변수 파일도 동일 키명. 토큰 평문은 코드·주석·로그 어디에도 작성 금지 (`feedback_credentials_policy` 병행).
- 모든 봇은 `@namuki_report_bot` 단일 (`feedback_telegram_bot_unified`). Chat ID는 코드 상수 `8254867551` 고정.
- 변경·점검 시 grep 명령: `TELEGRAM_TOKEN`(단어 경계, `_BOT` 미포함) 0건 / 평문 토큰 패턴(40자+ 영숫자:콜론) 0건 검증 의무.
