---
name: project_account_logo_distinction
description: 인스타 계정별 슬라이드 로고 규칙 — 개인=W심볼만 / 회사=풀로고
metadata: 
  node_type: memory
  type: project
  originSessionId: ced1afb5-23bf-43f9-a20c-50b4070001c7
---

GM 확정(2026-06-02). 슬라이드 마지막 장(및 로고 노출) 로고는 **계정 성격에 따라 구분**한다:

- **개인계정 namuk.wellperion**: **W 심볼만 미니멀**. (기존 발행분 왜AI·AI직원효율과 동일 톤)
- **회사 공식계정 wellperion**: **풀 로고** (W심볼 + WELLPERION + 하단 영문).

이유: 개인계정은 GM 1인칭 개인 톤이라 미니멀, 회사계정은 정식 브랜딩. 계정 혼동 방지.

주의:
- 2026-06-02 사고: AI #3편(개인계정)이 실수로 풀 로고로 제작됨 → W심볼만으로 교체. 시모 보고("SPORTFITNESS 로고")는 산출물과 불일치였고, GM 실측("W만 잘려 보임")이 발행분 'W만' 로고를 정확히 짚음. → [[feedback_screenshot_visual_verify]] 재확인.
- 회사 풀 로고의 'SPA&FITNESS' 영문 중 'FITNESS'는 브랜드 용어원칙([[feedback_brand_terminology]])과 상충 — 회사 로고 자산 차원 별개 사안, GM 추후 판단.

**개인계정 CTA 규칙(2026-06-02 GM 확정):** 개인계정 namuk.wellperion은 litt.ly CTA를 쓰지 않는다 → **'DM 문의' + '함께 성장합시다'** 메시지로 통일. (회사·공식 IG는 [[feedback_ig_inquiry_only]] litt.ly 유지 — 개인계정만 예외)

[[project_logo_assets_ssot]] [[project_main_slide_template]] [[feedback_personal_account_tone_and_review_gate]]
