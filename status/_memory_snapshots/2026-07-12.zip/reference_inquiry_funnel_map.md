---
name: reference_inquiry_funnel_map
description: "문의 퍼널 전체 지도 — litt.ly 4폼 → 운영시트, 자체 inquiry.html 대체 허브"
metadata: 
  node_type: memory
  type: reference
  originSessionId: aea490b8-e1de-49aa-841c-d7a7ab765295
---

웰페리온 문의 수집 구조 (2026-06-03 실측 학습).

**litt.ly/wellperion = 단순 4버튼 허브** → 각 구글폼 → 폼응답이 운영시트에 누적 → 옆 현황 탭 분석:
1. 멤버십(회원권) 문의 → `forms/d/1kvQqON12GTQssWsUZsb6l9sSfi5Up1jFW6T_GHiWer8` → 시트 `12AWcAlgmmYKr2nUbWmVpa71_z3zi0BaU4ZdnOwrI_7U`("1-1) 멤버십 문의 관리(26년도)" / 26년 신규문의 탭 gid 953023270). 폼 문항: 성함·연락처·관심콘텐츠(헬스/수영/골프/사우나/강습)·알게된채널·투어희망일·운동목적.
2. 강습 문의(성인) → `forms.gle/ad6xrR9ECRRDnzmE9` → 시트 `1b0XU1oTHlXzBhEzUOar5GEm44vjopdO25qfsh-awDXw` 성인 탭 gid 111889422. 문항: 성함·연락처·연령대·종목(PT/수영/아쿠아/골프/스쿼시/필라)·문의경로·레슨시간·담당자·개인정보동의.
3. 강습 문의(유소년 5~16세) → `forms.gle/RaFbZLxypNMMV9f17` → 같은 시트 유소년 탭 gid 268994754. 문항: 이름·연락처·나이·WSC종목(수영/체조/스쿼시/골프/키성장PT/모자수영/필라/뮤지컬)·문의경로·보호자.
4. 26년 유소년 여름 방학특강 → `forms.gle/UEMcgWwsZVeTwVBg9` (5종목 하위폼 허브: 수영/체조/스쿼시/골프/유소년PT).

**최종 단일 진입점 = 워드프레스 문의 페이지 `http://wellperion.com/ko/inquiry/`** (GM 확정 2026-06-04, 커밋 dd62b0b). SSOT 본문=`3. 웰페리온 가이드/cmo/survey/wp_inquiry_block.html`(id 8394, `--mode draft-inquiry --post-id 8394` 재주입). 4폼 버튼 + `wpTrackClick`→동일 Apps Script `track_click`(utmSource=homepage) 보유 → M4 대시보드 데이터 유지. **사이트 HTTP 전용·HTTPS 미지원이라 href는 반드시 `http://` 풀경로 `/ko/inquiry/`** (단축 `wellperion.com/inquiry` 작동 미검증).

**폐기(2026-06-04):** 구 자체 페이지 `cmo/survey/inquiry.html` = git rm 삭제. 전 채널 CTA(가이드허브·마케팅대시보드·당근/카카오 README·expansion_plan)의 `inquiry.html`·`litt.ly/wellperion` → `wellperion.com/ko/inquiry/` 일괄 전환 완료. **litt.ly는 더 이상 공식 CTA 아님**(외부 서비스라 페이지 자체는 GM이 외부에서 정리). 백엔드 `apps_script_survey.js`(submit_inquiry·track_click·inquiry_list·funnel_conversion, 회원부 유효회원 탭 휴대폰 매칭)는 워드프레스도 공유 → 유지.

미전환 잔존: **워드프레스 홈 메인(`http://wellperion.com/`) "방문 예약하기" 버튼이 아직 `litt.ly/wellperion`** (CMO 라이브 실측 2026-06-04 발견 — 오늘 CTA sweep이 이 nectar-button 위젯 누락, 코드 아닌 WP어드민 href라 sweep 비대상). 리틀리 최대 노출 지점이라 전환 마무리 핵심 = WP어드민에서 `http://wellperion.com/ko/inquiry/`로 교체(GM 또는 CTO). [2026-06-05 실측] 홈 "방문 예약하기"(nectar-button jumbo)는 이미 `http://wellperion.com/ko/inquiry/`로 교체 완료 — 홈 전체 litt.ly 0건. 남은 litt.ly 후보 = ①IG 바이오(★미검증 — 비로그인 스크랩은 external_url 미노출, 라이브 확인 필요. 홈 버튼처럼 이미 정리됐을 수 있음) ②litt.ly 페이지 자체(외부). ※ 메모리의 'IG 바이오 litt.ly'는 2026-06-03 추정치로 실측 안 됨 — 단정 금지(레포 잔존 51건은 과거IG·아카이브 정적자산, 신규노출 위험 없음). `CLAUDE.md` 공식링크는 2026-06-04 `http://wellperion.com/`(홈)+문의 `/ko/inquiry/` 병기로 GM 결재 반영(커밋 512e0c7). 그 외 `onboarding/game.html`·`quiz_bank.json`·`cpo/member/회원관리.html`(CPO 영역)·`instagram/` 과거 콘텐츠(이력 불변).

**영문 퍼널 = `http://wellperion.com/en/inquiry/`** (WP page-id 8408, SSOT=`cmo/survey/wp_inquiry_block_en.html`). 영문 폼 4종(멤버십 `1FAIpQLSfOFxaqO5...`·성인 `1FAIpQLSdirIB05e...`·유소년 `1FAIpQLScqZum8z...`·여름 `1FAIpQLSchg7_9bm...`, `/forms/d/e/{ID}/viewform`). **[해결 2026-06-04] 4종 전부 401 로그인벽**(Workspace 계정 생성 폼 기본=조직 로그인 강제, `setCollectEmail(false)`만으론 안 풀림) → `create_english_forms.gs`의 `updateEnglishFormsAccess()`(GM이 GAS 1회 실행, 폼 소유자 cao)로 `setRequireLogin(false)`+`setCollectEmail(false)` 적용 → 401→200 실측 확인. **함정 2가지:** ①첫 실행 시 4종 `Failed to edit the form. Please wait and try again.`(일시적 rate-limit) → 작업별 try/catch+3회 backoff 재시도+폼간 2.5s sleep으로 해결. ②`form.requiresLogin()` 조회는 계정에서 read-fail 예외 → 로그인상태 코드확인 불가, **반드시 익명 curl/시크릿창 200 실측으로 검증**. 영문 폼 description CTA는 `/en/inquiry/`(과거 `/ko/` 오기 교정 커밋 979b99c).

**[2026-06-05 해결] 대시보드 문의 집계 빈틈 메움:** `apps_script_survey.js`에 `FORM_SHEETS`(멤버십 gid 953023270·성인 gid 111889422·유소년 gid 268994754) gid조회+헤더키워드 매칭 추가, `inquiry_list`·`funnel_conversion`이 구글폼 응답 union. 재배포(Survey.gs 교체+새버전, GM 2026-06-05) 후 /exec 실측 = **문의 8,278 / 등록 1,193 / 전환 14.4%** (이전 0). 여름특강 5종 미포함. Survey.gs ≠ Wellperion_EN_Forms.gs(영문폼 생성기, create_english_forms.gs).

**[2026-06-13 채널 표준화 완료·라이브검증]** 자유텍스트로 315종 난립하던 유입채널 = **마케팅용 공식 10버킷**으로 확정(GM 승인). 정본 = `apps_script_survey.js`의 `_canonicalChannel_()`(읽기 시점 정규화, 시트 원본 불변·비파괴) — funnel_conversion·period_breakdown 집계 4지점 적용. 10종: 네이버 / 동부이촌동 커뮤니티 / 인스타그램 / 카카오톡 / 당근마켓 / 소개·지인 / 기존·과거 회원 / 오프라인 / 유선전화 / 기타·미상. **과거 리셉션 '온라인 (…)' 묶음 약 26%는 단일귀속 불가→기타·미상**(=채널 ROI는 신규 데이터부터 정확). 예방책으로 **구글폼 4종 중 멤버십·성인·유소년 3종 유입경로를 객관식 드롭다운으로 전환**(폼 옵션 문구는 함수 키워드와 정합 검증됨), 여름특강은 수집대상 아니라 미적용(GM OK). 발견된 ROI 신호: 기존·과거 회원 전환 41%(최강)·당근 33%·동부이촌동 22%·네이버 16% vs 인스타 7.7%. Apps Script 프로젝트명="문의Survey"(`1A77oDRaa21K…`, clasp 아님·수동붙여넣기+새버전 배포).

**[2026-06-13 UTM 채널 귀속 + 주간추세]** 클릭 출처 추적 추가. ① `wp_inquiry_block.html` wpTrackClick이 인바운드 URL의 `utm_source`/`utm_medium`를 읽어 클릭로그에 기록(없으면 `homepage`=직접/홈). ② `apps_script_survey.js`: click_stats에 `byUtmSource` 집계(캐시 cs_v2, homepage·빈값→'직접/홈') + 신규 action `weekly_trend`(최근 8주 문의·클릭 시계열, 캐시 wt_v1). ③ 대시보드: '유입 클릭 출처' 막대 + 주간 추세 스파크라인(renderUtmSources/renderWeeklyTrend/loadWeeklyTrend). **utm_source 표준 5종(채널 발행 링크에 부착): `instagram`·`naver_blog`·`naver_cafe`(동부이촌동)·`kakao`·`danggn`.** Part B(출처 딱지) **완료(2026-06-13 db7276bf)**: `scripts/cta_utm.py`(공용 SSOT·CHANNEL_UTM 맵·apply_cta_utm) + 당근·카카오·블로그 업로더가 발행 직전 본문 CTA URL에 채널 utm_source 자동 부착(copy.md 원본은 깨끗 유지). 이미 태깅분·미지원채널·빈본문 가드. ⚠️ 다음 발행분부터 적용(기존 라이브 글은 소급 안 됨). IG 개인시리즈는 문의 URL 자체 금지(ig_series_producer 규칙)라 대상 외. 네이버 카페는 전용 업로더 없어 미적용(자동화 시 naver_cafe 코드 추가).

**[2026-06-13 대시보드 단일화]** `문의채널현황.html`·`문의흐름지도.html` 두 페이지를 **마케팅 대시보드(마케팅현황대시보드.html, 표시명="마케팅 대시보드")로 합병** → 둘 다 meta-refresh 리디렉션 스텁으로 교체(파일명·링크 보존). 대시보드 단일 surface 구성: 핵심 KPI 3카드 + 월목표 게이지(MONTHLY_INQUIRY_TARGET=200) + 주간추세 스파크라인 + 실시간 클릭 2단(버튼별/유입출처) + 핵심 전환 흐름(renderConversionFlow: 클릭→문의→등록 3카드) + 채널별 비교 + 문의 진입점·폼(접힘) + 개선 실험로그. 월 네비(◀▶ custom range). 한줄 인사이트(최강/약세 채널)는 대시보드에서 빼고 `월간마케팅보고서.html` 전환요약으로 이관. ⚠️ '이번 달 문의'는 온라인 폼+문의접수 시트만 카운트(리셉션 직접 문의 미포함) → 목표 200 대비 낮게 보임. 리셉션 합치기는 미착수 후속(운영부 데이터 연결 필요).

**[2026-06-13 F1 완료 — 멤버십 실제 문의 연결]** 멤버십 집계 소스를 폼응답탭(gid 953023270·온라인 3건만)→**'26년 신규문의' 스태프 로그(ssId 12AWcAlgmm…, gid 1902010032)**로 교체. ⚠️함정: 이 탭은 **타임스탬프가 B칸**(구글폼 응답탭은 A칸)이라 r[0] 고정 읽기로는 이번달 0 회귀 발생 → `_collectFormInquiries_`가 헤더 키워드('타임스탬프' 등)로 날짜 칸 **동적 탐색(idxDate)**하도록 수정. + `_parseAnyDate_`로 한글 날짜('2026. 6. 5') 파싱(정오 고정). 결과: 이번달 문의 3→**102**(멤버십24=GM실측일치·성인33·유소년45), 전환 11/10.8%. **보너스: 강습 폼도 날짜 칸이 A가 아니라 그간 누락됐던 게 같이 정상화**. 멤버십 채널은 '온라인(…)' 묶음→기타·미상(세부는 '문의 경로(중분류)' 칸으로 후속 정밀화 가능). 강습=1b0XU1oTHl… 시트 유지. ⚠️ 배포: 이 GAS·문의블록 변경은 GAS 새버전 재배포 + WP page-id 8394 재주입 1회씩 해야 라이브 점등. 대시보드 월목표 게이지=`MONTHLY_INQUIRY_TARGET`/`MONTHLY_CONVERT_TARGET` 상수(미설정 시 안내, GM이 값 지정).

**클릭로그·문의접수 정본 = 별도 "랜딩 추적" 시트 `1g9Ohmd8C_WxyvWt9EX58oEFZLiOAJ_EG7t7XteJFuGE`** (apps_script_survey.js `LANDING_SPREADSHEET_ID`). track_click→클릭로그, submit_inquiry→문의접수 모두 이 랜딩시트에 적재. 대시보드(M4 마케팅현황·문의채널현황)는 `/exec?action=click_stats|funnel_conversion|inquiry_list`로만 읽음(시트 직접접근 X). 회원시트 `12AWcAlgmm…`는 `funnel_conversion`이 **유효회원 탭(전화번호)만** 읽음. **[2026-06-04 판정] 회원시트에 있던 동명 탭 클릭로그·문의접수 = 잔재(라이브 미참조) → GM 삭제 OK.** 라이브 실측: click_stats=23(랜딩서 집계 정상)·inquiry_list=0(자체폼 폐기로 문의접수 비어있음, 구글폼은 각자 응답탭에 적재). 자체폼(submit_inquiry) 경로는 사실상 휴면.

주의: 강습 시트는 "anyone viewer"여도 export?csv는 익명 쿠키벽 → 익명 curl 불가. 폼 문항이 곧 접수 스키마. [[reference_wordpress_site_structure]] [[project_member_db_sheet]] [[feedback_m5_preview_must_be_in_guide_folder]] [[feedback_ig_inquiry_only]]
