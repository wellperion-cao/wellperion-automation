---
name: project_g1_done_today_past_search
description: G1 입항(완료) 3층 모델 — 입항 완료(오늘)/지난 입항 완료/검색=전체(폐기 포함)
metadata: 
  node_type: memory
  type: project
  originSessionId: bbe8dc19-5dc1-4064-b35e-2ad390f94ad1
---

G1 항로의 완료 표시는 **3층 구조**다 (GM 2026-06-07 확정. '오늘만'→'30일창'→이 모델로 정착, 다시 바꾸지 말 것):

1. **⚓ 입항 완료 (오늘)** = 오늘 완료한 것만. 완료일(`_doneDate`) == 오늘.
2. **🗄️ 지난 입항 완료** = 오늘 이전 완료 전부. 접힌 별도 토글, 숨기지 않고 보존(지난기록). 날짜칩 표시.
3. **🔍 검색 = 전체** = 오늘·지난·폐기 다 검색됨. 폐기(🗑️)는 검색 시에만 별도 섹션 노출.

**완료일(_doneDate) 출처:** 시트=수정일(로컬), AI배(_queue)=`processed_at`. 없으면 '지난'으로 분류(안전).
**_history 용도 축소:** 완료·보류는 이제 안 숨김(항상 표시). _history=true는 **폐기만**(검색 전용).
**텔레그램 8시 보드는 다름(의도):** 일일 다이제스트라 '입항 완료=최근 3일'. 영구 대시보드(G1)만 오늘/지난 분리.

관련: [[project_g1_ai_ship_readonly]] · [[project_hangro_task_single_def]] · [[feedback_welly_verification_standard]]
