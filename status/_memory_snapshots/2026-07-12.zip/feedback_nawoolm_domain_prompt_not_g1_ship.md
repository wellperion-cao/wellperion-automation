---
name: feedback_nawoolm_domain_prompt_not_g1_ship
description: 나우열M 영역(CFO 재무·CHRO 인사) 후속=AI 항로 배 금지·나우열M용 프롬프트로 넘김
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 8e6a94c1-0701-48f1-af38-3bbdc0d05c2b
---

**CFO(재무)·CHRO(인사) = 나우열M(실무책임자) 영역.** 이 영역 후속 과제는 **AI 항로(_queue)에 배로 만들지 말고, 나우열M이 AI(cao 계정)로 직접 처리할 '프롬프트'로 넘긴다.**

**Why:** 2026-07-02 GM — "CFO는 우열M 역할이라 프롬프트를 줘, G1 항로에 남기지말고." 직원들이 AI 습득해 cao 계정으로 각자 ERP 자가구축하는 방향([[feedback_formal_titles_for_upward_reports]] 회장 보고 어필 포인트)과 정합. CHRO·CFO 배는 이미 항로 제외(나우열M 실무).

**How to apply:** 재무·인사 도메인 후속(예: 구매성 라이브화·CFO 재무현황 개선·인사 관리)이 나오면 → 웰리는 배를 만들지 말고 **자기완결형 프롬프트**(배경·목표·할일·원칙·검증 포함, 실무자가 붙여넣어 AI가 바로 실행)를 작성해 GM에게 전달. G1/_queue에 남기지 않음. 시토(기술)는 배관·조사만 돕고 도메인 실행은 나우열M. 관련 [[project_ai_clevel_to_practitioner_mapping]]·[[project_3line_org_structure]].

**2026-07-03 확장 — 06:30 북극성 추천기 대상서도 cfo·chro 제외.** GM 지시로 daily northstar recommender(scripts/northstar_recommender.py·배213) top3 후보 대상을 7역할→**5역할(ceo·cmo·coo·cto·cpo)** 로 축소. cfo·chro는 나우열M 실무라 추천 카드로도 안 띄운다(스펙 G3 반영). 자율 개선 상시 위임 대상도 시모·시우·시토·시포 4역할(시뽀·시로 제외). 관련 [[feedback_autonomy_standing_mandate]].

**2026-07-03 역할 재정의(중요) — 나우열M = "재무"가 아니라 「운영 매출&지출」 + 「인사 실무」.** GM: "나우열M 재무가 아니라 운영 매출&지출 / 인사 실무로 해줘." 즉 나우열M 담당 = ① 운영 매출&지출 실무(재무 타이틀 X) ② 인사 실무. 시뽀(AI CFO)·시로(AI CHRO)는 AI 조력이고, 실제 이 도메인 일은 나우열M. **지출은 아직 구조 개선 중 → 나우열M가 진행**(월간계획 부서별 매출&지출표의 지출 side는 웰리가 더 만들지 말고 '나우열M 구조개선 중'으로 표기). 매출(목표 vs 실적)·운영 지표는 웰리/시우 페이지 유지 가능, 지출 배관·재무 정의는 나우열M. 라벨링도 '재무'보다 '운영 매출&지출'로.
