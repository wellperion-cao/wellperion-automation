---
name: feedback_log_adhoc_work_to_g1
description: CLI 세션에서 한 굵직한 ad-hoc 작업도 끝나면 G1(_queue)에 입항완료로 기록한다
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 260c4dac-9847-42a6-a1ac-9aeca99e374c
---

**✅ 2026-06-18 자동화됨(수동 append 불필요):** ad-hoc CLI 실작업 커밋은 이제 **post-commit 훅(`scripts/auto_log_adhoc_to_queue.py`)이 자동으로 `status/_queue.json`에 입항완료(DONE·terminal) 배로 기록 + 미러 동기 + push**한다. 귀속은 **커밋 제목**의 태그로 판별(`[시우]`·`feat(S2-COO)`→coo, `시토`→cto…), 태그 없으면 전사 소유자 ceo(웰리). 자동발행·큐전용·중복 커밋은 자동 제외(무한루프 차단)·멱등·fail-open·GitLock 직렬화. **그래서 C-Level은 본인 CLI 커밋 제목에 `[닉네임]` 또는 `(scope)`를 달기만 하면 G1에 자동 표시된다**(안 달면 웰리로 귀속). ⚠️ 귀속은 **제목만** 본다 — 본문에 타 닉네임/역할 단어가 있어도 무해(2026-06-18 멀티세션 오귀속 수정). 아래 '수동 append'는 자동화 전 절차로, 훅이 안 도는 환경에서만 폴백.

(이하 자동화 전 맥락) CLI 세션에서 GM 지시로 처리한 **굵직한 standalone 작업(콘텐츠 발행·정리·삭제 등)**도 완료되면 **`status/_queue.json`에 입항완료(DONE·terminal·processed_at) 배로 기록**한다. 사전 _queue 배가 없던 ad-hoc 작업은 git 이력엔 남지만 G1 보드엔 안 보여, GM이 "G1에 기록되고 있나?"라고 누락을 지적함(2026-06-15).

**Why:** G1 항로 = `업무현황 SSOT(GAS todo_list) + _queue` 머지. .bat post_action(브릿지)만 자동기록하고, CLI에서 직접 한 작업은 자동기록 안 됨 → 수동으로 _queue에 DONE 배 추가해야 G1이 현실을 반영한다.

**How to apply:** 세션 끝/작업 완료 시, 별도 _queue 배가 없던 의미 있는 산출물은 `{task_id: CMO-YYYY-MM-DD-…, clevel, status:DONE, terminal:true, processed_at, title:[시모]…, note:✅…, next}`로 append + 커밋. 완료도장(DONE 전환)은 본래 웰리 권한이나 GM 직접 지시 시 시모가 찍음. 관련 [[project_bridge_mechanized]] · [[project_hangro_task_single_def]].

**⚠️ 기존 항로 완료 처리도 놓치지 말 것 (2026-06-16 GM 재지적 — "웰리 G1 항로 #01 완료한 거 아냐? 이런 거 자꾸 놓치는 거야?"):** 신규 ad-hoc 기록뿐 아니라, **이미 _queue에 있던 PENDING 항로가 완료됐는데 DONE(입항완료)으로 안 내리는 것**도 자주 놓친다. 특히 **웰리 자기(ceo) 항로**(CEO-2026-05-30-REPORT-CONTENT-POLISH '웰리-01'이 완료됐는데 PENDING으로 방치돼 GM이 G1에서 발견). **작업 사이클 마감/대기 전환마다 본인 ceo PENDING을 전수 점검해 완료된 건 즉시 입항완료**한다. (S2 CEO 헌법 '대기 전환 시 진행현황+남은할일' 스텝에 '완료건 입항완료 점검'을 함께 박도록 시토에 제안 — 코드/체크리스트로 강제해야 반복 안 됨.)
