---
name: project_ig_upload_ssot
description: IG 업로드 SSOT=M5 통합 — 폴링폐기→승인시 봇 on-demand·미리보기=cmo/review에
metadata: 
  node_type: memory
  type: project
  originSessionId: ced1afb5-23bf-43f9-a20c-50b4070001c7
---

GM 확정(2026-06-02). 인스타그램(및 공식 채널) **업로드 관련 단일 SSOT = 가이드허브 M5 "콘텐츠 검수·자동업로드" 페이지** (`data-doc="cmo-publish"`, data-id=M5).

흐름: 제목 → 슬라이드·캡션 생성 → 검수 → 승인 발행 (공식 5채널 · 인스타 2계정).
연결 자산: `scripts/slide_compositor.py` · `scripts/instagram_upload_playwright.py` · 검수 큐 `cmo/review/review_queue.json` · 승인 중계 `review_set_status`(Apps Script).

**원칙:** 모든 채널 콘텐츠의 검수·업로드는 M5 페이지 단일 경유. 시모 산출물(슬라이드·캡션)도 최종적으로 M5 검수 큐 등록 → GM 승인 → 발행. 발행은 GM 시각 승인 게이트 필수(비가역).

**표준 종료 절차(2026-06-02 GM 지시):** 모든 슬라이드/콘텐츠 '제작 완료' = 항상 ①텔레그램 1줄 알림+montage ②M5 검수 큐 자동 등록(status='검수 대기')까지가 기본 종료 상태.

**M5 [승인] = 즉시 발행(2026-06-02 GM 확정):** GM이 M5에서 [승인] 누르면 그게 발행 신호 = 시모 즉시 발행. 별도 '발행 go' 텔레그램 재확인 묻지 말 것. 예외: 승인 후 내용을 수정한 경우에만 status를 '검수 대기'로 되돌려 재승인.

## IG 폴링 발행 감시기 폐기→on-demand

GM 결재(2026-06-03)로 **IG 발행 폴링 감시기 폐기**. 예약작업 `Wellperion-IG-Publish-Watcher` = Disabled(삭제 아님, 가역적), 상주 프로세스 종료.

**왜 폐기:** 로그 1,386줄 중 649줄(47%) 순수 idle. **자동발행 성공 0건**(큐 8건 전부 GM/CMO **수동 발행 후 상태기록**). 매 120초 `git pull --rebase --autostash` = 동시성 충돌·autostash churn 유발.

**전환 방향 (GM 승인, 미구현):** 폴링 폐기, **발행 엔진 스크립트(`scripts/ig_review_publish_watcher.py`)는 보존** → 봇이 승인 시 `--once`로 on-demand 1회 호출. 복구: 예약작업 Enable + 봇에서 폴링모드 재기동.

## M5 미리보기=cmo/review에 (instagram/ raw=404)

M5(cmo-publish) 검수카드의 `preview`(미리보기 이미지)·본문 등 모든 표시 자산은 반드시 `3. 웰페리온 가이드/cmo/review/` 하위에 둬야 한다. `instagram/...` raw 경로를 가리키면 라이브에서 404 → 미리보기 안 뜸.

**Why:** `.github/workflows/pages.yml`은 `3. 웰페리온 가이드/**` + 로고 assets만 `_pages_build`로 복사해 배포한다. repo 루트의 `instagram/` 폴더는 배포 대상이 **아님**. 또한 스쿼시 이미지처럼 git 미추적이면 커밋조차 안 돼 이중으로 404.

**How to apply:** 블로그/카페/IG 검수 등록 시 ① 대표 미리보기 이미지를 `cmo/review/{name}_preview.jpg`로 복사 ② 본문 txt(body_file)는 배포 안 되므로 큐 JSON에 `body` 필드로 인라인 ③ preview 경로는 `cmo/review/...` 상대경로. 검증은 `https://wellperion-cao.github.io/wellperion-automation/cmo/review/...` HTTP 200으로.
