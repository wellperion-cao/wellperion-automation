---
name: reference_reception_6categories_complaint_hidden_trap
description: 종합접수처=6종 접수(컴플레인 포함). 폼 카테고리만 있고 표시 배선 누락 시 데이터가 조용히 안 보이는 함정
metadata: 
  node_type: memory
  type: reference
  originSessionId: e104ce56-2d78-47aa-92cf-94f2b9116ce5
---

**종합접수처(coo/reception) = 6종 접수** (2026-07-07 컴플레인 연결로 확정):
분실물(운영부)·시설고장(시설부)·청결(지원부)·칭찬(운영부)·쓴소리(운영부)·**컴플레인(운영부·SLA48h)**.

**함정(2026-07-07 실사례):** 회원 폼(reception_block.html)엔 `complaint` 카테고리 버튼이 있어 회원 제출→`접수_컴플레인` 시트에 저장은 되고 있었으나, 백엔드 `REG_CATEGORIES`·현황 `CAT_META`에 complaint가 없어 **reg_board가 반환 안 함→현황 보드에 조용히 안 보임.** 실제 회원 컴플레인 2건(VOC-5·6)이 표시 안 돼 방치(1건 SLA 임박). 코드상 "저장 안 됨"으로 오판했으나 라이브 실측=저장은 됨·표시만 끊김(L03 현실확인의 중요성).

**배선 SSOT = apps_script_voc.js** `REG_CATEGORIES`(라우팅·시트·dept·slaHours) + `REG_EXTRA_HEADERS`(카테고리별 추가컬럼). 새 카테고리 추가 시 **전 소비처 배선**([[feedback_new_ledger_subkey_wire_all_consumers]]): 백엔드 2곳 + 종합접수처_현황 CAT_META/EXTRA_LABEL + 월간운영계획 VOC_CAT_META + 허브 안내문 "N종". 하나 빠지면 그 화면서 조용히 누락.

VOC GAS 배포=clasp(.deploy-voc·cao 인증)→`clasp push -f`+`clasp deploy -i <배포ID>`(URL보존). REG_API=AKfycbwk2XS1…. 컴플레인 필드=분야(직원응대/운영·정책/이용에티켓/기타)·발생시점·발생위치·내용. 별개 시스템=[[project_coo_issue_sheet_name]] 리셉션 컴플레인 탭(수동).

**VOC 스프레드시트(2026-07-07 감사)**: ID=1akZLs7ITs3FZWFIzMQvSYrdRucGQglmerOvTC2TLEcQ(ScriptProperty SPREADSHEET_ID). 리셉션·운영부 **공용 시트**(60여 탭·락커/시재금/GX 등 VOC무관 업무데이터 혼재 — VOC 정리 시 손대지 말 것). ⚠️**성능 함정**: VOC 6종은 6탭만 읽지만 이 60여탭 공용시트 안이라 매 reg_board 로드시 openById가 큰 파일 전체를 엶→리셉션시트 커질수록 '점점 느려짐'(폴링X·재정렬은 GATED·데이터~8건=원인아님). 근본해결=VOC 7탭(접수 VOC+6종)을 작은 전용시트로 분리+SPREADSHEET_ID 교체+기존배포 업데이트. 즉효=reg_board CacheService 30~60초+쓰기시 무효화. 2026-07-07 GM이 전용시트분리를 실무 최준용M에 위임→핸드오프 status/briefs/종합접수처_속도개선_VOC전용시트분리_최준용M_핸드오프.md. **완료(2026-07-07)**: 최준용M이 7탭을 새 전용시트 `17ly-_udUYgOoPZnv6FFV9vq_R2D41q4ZYrGaGYt9rto`로 복사→시우가 SPREADSHEET_ID 교체+재배포(주소만 바꿈·옛 1akZLs 7탭은 폴백 보존·미삭제). + reg_board ScriptCache 45초 캐시(키 reg_board_v1)+쓰기(submit/update/delete/renumber)시 remove 무효화 배선·라이브. **실측 속도: 캐시미스 ~4.4s·히트 ~1.7s** — 재조회·다수열람만 빨라짐, 첫 호출 ~4초는 **앱스스크립트 /exec 302리다이렉트+플랫폼 지연=바닥**(전용시트·캐시로 못 줄임). 1초미만 즉답=앱스스크립트 탈피(자체서버 API·시토21·~2026-09)가 근본. 롤백=SPREADSHEET_ID를 1akZLs…로. **정본 VOC 시트=7개**: `접수 VOC`(레거시 VOC_SHEET·voc_submit 저장처·현재 0행) + 6종 카테고리 시트. 삭제됨(2026-07-07): `접수_휴회`(빈 고아)·`회원셀프VOC`(3행·백업 status/briefs/회원셀프VOC_backup_20260707.json 후 GM승인 삭제). **함정 재발**: 옛 셀프 폼이 `회원셀프VOC`로 저장했는데 코드는 `접수 VOC` 읽음→회원신고 3건 방치. 시트 삭제=Drive MCP 불가·GAS deleteSheet(화이트리스트+confirm 하드가드 임시액션→사용후 즉시제거·재배포).
