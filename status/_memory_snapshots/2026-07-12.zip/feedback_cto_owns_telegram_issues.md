---
name: feedback_cto_owns_telegram_issues
description: 2026-06-29부터 텔레그램 관련 문제·해결은 시토(CTO) 소유 — 위임받아 진단·수정
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9b09999d-0254-4086-939a-1db5824ac1e0
---

GM 지시(2026-06-29): **텔레그램 관련 건은 오늘부터 시토(CTO)가 위임받아 문제 감지·해결을 소유한다.** 봇(telegram_bot/bot.py·daily_scheduler.py)·알림 배선(점검 알림·검수카드·C-Level 보고)·chat_id 라우팅·토큰(.env TELEGRAM_BOT_TOKEN)·발송 실패 진단 등 텔레그램 전반.

**+추가(2026-06-29): GM 시간별 루틴 보고 전담.** GM이 매일 텔레그램으로 받는 시간대별 루틴 보고(06:00·06:30 북극성추천·07·08·09·12·15·18·21·22·22:30·23시) 전체를 시토가 전담한다(텔레그램이므로). 빌더=`daily_scheduler.py`(06·07·09·12·15·18·21·22·23 + 22:30 디제스트)·`ceo_morning_pipeline.py`(08시)·`northstar_recommender.py`(06:30, 두뇌=웰리/엔진=시토). 보고 내용·시각·중복 정리도 시토 소유(08시 아침 파이프라인 포함 — 구 웰리 영역이나 텔레그램 루틴이라 시토 전담으로 이관). 정본 기록=헌법 매트릭스 GM 파이프라인 칸(bootsetup_matrix.json roles[0].dims[1]).

**+추가(2026-06-30): 면밀 모니터링 + 자율 자동화 상시 권한.** GM 지시 "텔레그램은 시토가 면밀히 보고, 자동화 가능한 건들은 자동화 진행해줘". 이슈 대응(수동)만이 아니라 **선제 모니터링·신뢰성 강화·자동화를 시토가 자율 발의·진행**한다(승인게이트는 라이브 행동 변경 시만). 촉발 사건=종합접수처 분실물 알림이 **조용히 실패**(VOC GAS에 TELEGRAM_BOT_TOKEN·CHAT_ID 미설정 시 `_vNotifyTelegram` 말없이 false 반환 → 저장은 되고 알림만 누락, GM이 우연히 발견). 교훈=**알림 발송 경로의 silent-failure가 핵심 위험** → 1순위 자동화=알림 헬스체크(설정 누락·방 미초대·발송 0건 이상 탐지).

**Why:** 시토 R/R이 원래 '진단·서버·알림 배관까지'였는데(=[[feedback_member_domain_is_cpo_not_cto]]), GM이 텔레그램 전체를 시토 소유로 명시 확장. 2026-06-30 다시 '면밀 모니터링+자율 자동화'로 능동 범위 확장.

**How to apply:** 텔레그램 이슈("알림 안 옴/잘못 옴/방 분리/토큰" 등)는 시토가 받아 진단→수정→라이브검증. 봇 코드 변경은 라이브 발효=아침 자동재기동/GM 재부팅 필요([[reference_bot_elevated_restart.md]]). chat_id 3방 분리=[[project_telegram_3room_split]]. 토큰 키명=[[feedback_telegram_token_env_key]]. 단, 콘텐츠 검수카드 '내용·발송정책'은 시모(CMO) 소관(시토는 전송 인프라) — 경계 주의.
