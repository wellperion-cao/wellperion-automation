---
name: reference_inquiry_qa_utf8_injection
description: 문의 QA 주입은 반드시 requests(UTF-8)—손 curl 한글=CP949 mojibake. 정본=scripts/qa_inject_inquiry.py
metadata: 
  node_type: memory
  type: reference
  originSessionId: 6160b796-c8c8-42e9-a1cd-890323eae1a1
---

**문의 알림 한글 깨짐 = QA 주입 인코딩 문제(발송코드 정상).** 2026-07-08 [자동QA] 테스트가 문의 알림방(-5516675010) 한글을 "전화"→"������ȭ" 식으로 깨뜨림.

- **원인 = CP949→UTF-8 오독.** Funnel GAS(Survey.js) `doGet`은 모든 action을 쿼리파라미터로 처리 → Windows에서 `curl "...?name=한글"` 하면 한글이 CP949(윈도우 기본)로 퍼센트인코딩돼 GAS가 UTF-8로 오독. 발송부 `_notifyTelegram`은 `application/json`+`JSON.stringify`라 UTF-8 정상 — **손대지 말 것**(같은 알림의 하드코딩 "유형: 멤버십"은 안 깨진 게 증거).
- **정본 주입 도구 = `scripts/qa_inject_inquiry.py`** (requests=params 항상 UTF-8). 손 curl 한글 주입 금지. 모드: `scan`(폼시트 mojibake 색출·읽기전용), `verify`(UTF-8 테스트 주입+readback), `alert-test`(무행성 TEST 알림).
- **깨진 mojibake는 시트에 지속 저장 안 됐던 사례:** inquiry_list 8694건·폼시트 preview 스캔 0건 → 알림만 순간 발생(transient), 삭제 대상 없음. 진단 시 **저장행 실재부터 확인**(inquiry_list `_collectFormInquiries_`는 유입채널 비마스킹이라 mojibake 탐지 가능).
- Funnel exec URL = `AKfycbzdwSCC…delg0xA/exec`(=scripts/telegram_health_check.py `_FUNNEL_DIAG_URL`). scriptId=`1A77oDR…`(정본=.deploy-funnel/Survey.js). 관련: [[reference_gas_post_curl_no_follow_redirect]] · [[reference_python_console_utf8_env]] · [[reference_funnel_gas_script_id]] · [[reference_inquiry_funnel_map]].
- **선택 방어(미적용):** 발송 전 U+FFFD(�) 감지 가드는 라이브 GAS 재배포 필요(되돌리기 경로 확보 후) — 정본 스크립트가 원천 UTF-8 강제하므로 재발 방지엔 불필요. 필요시 후속.
