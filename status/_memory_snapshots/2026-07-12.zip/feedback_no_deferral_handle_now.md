---
name: feedback_no_deferral_handle_now
description: "GM는 '다음 정리 때', '나중에', '후속으로' 미루기를 금지 — 발견한 잔손질·죽은코드·정리는 그 자리에서 즉시 처리"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 84a761b5-4cfb-4b3c-9eaa-ac24dcbeab1e
---

GM 지시(2026-07-09): "다음 정리 때 제거 등 다음으로 미루는건 하지마, 당장 처리해."

죽은 코드·잔손질·정합 흠집을 보고서에 "다음에 정리하겠습니다"로 남기자 즉시 교정 지시.

**Why:** 미룬 정리는 쌓여서 부채가 된다. GM은 한 배(작업)를 끝낼 때 그 안의 잔손질까지 그 자리에서 닫힌 상태를 원한다. "무해하니 나중에"는 GM 기준 미완료.

**How to apply:** 작업 중 죽은 코드·중복·정합 흠집을 발견하면 그 커밋/세션에서 바로 제거·수정한다. 보고에 "후속/다음 정리 때/나중에" 미루는 문구를 쓰지 않는다. 정말 별건이라 지금 못 하면 그 이유와 함께 즉시 별도 배로 등록(표류 금지). 3렌즈 단순화([[feedback_always_structure_simplify_advance]])·정리=병합이관삭제([[feedback_cleanup_merge_relocate_delete]])의 실행 강화 — 발견 즉시 net-zero.
