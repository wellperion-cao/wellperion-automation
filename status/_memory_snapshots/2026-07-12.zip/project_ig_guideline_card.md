---
name: ig-guideline-card
description: "매 IG 콘텐츠 슬라이드 모음 마지막에 표준 가이드라인 카드 자동 첨부. 영상 있으면 영상이 진짜 마지막. (문의 CTA 카드는 IG 아님 — 4채널 전용, 본 메모리 하단 참조)"
metadata: 
  node_type: memory
  type: project
  originSessionId: f39f6807-2207-4271-821b-7bbede864929
---

매 IG 콘텐츠 슬라이드 모음의 마지막 슬라이드(영상 있으면 영상 직전)에 표준 **WELLPERION GUIDE 카드**를 자동 첨부한다 (2026-05-20 GM님 확정).

## ★ 문의 CTA 카드 — IG 아님, 4채널 전용 (2026-06-19 GM 확정)

문의 CTA 카드는 **IG 슬라이드엔 넣지 않는다**(IG는 캡션·bio·가이드카드가 담당). **네이버 블로그·카페·당근·카카오 4채널 발행물의 '마지막 이미지'로만** 자동 첨부한다.
- 카드 자산: `instagram/_assets/cta_card.jpg` (1080×1080) · 생성기: `scripts/compose_cta_card.py`
- 카피: "한남동 프리미엄 라이프스타일 스포츠클럽 / 방문을 예약하세요 / 모든 방문·상담 사전 예약제 / 문의·예약 → wellperion.com/ko/inquiry / 02-6261-1200·주소". 금지어(피트니스·하이엔드프라이빗·사교) 0.
- ⚠️ 이미지라 **클릭 불가 = 시각 강조용**. 실제 추적은 본문·프로필 텍스트 링크(utm)가 담당.
- **자동 첨부 = `cta_utm.append_cta_card(images)`** — 4개 업로더(naver_blog·cafe·danggn·kakao)가 `collect_images` 직후 호출(멱등·카드없으면 무동작). **IG 업로더(instagram_upload_playwright)는 호출 안 함.**
- namuk 개인(AI시리즈)은 본래 4채널 발행 대상 아님(개인 IG 한정) → 자연 제외.

## 카드 SSOT

- 자산: `instagram/_assets/guideline_card.jpg` (1080×1080)
- 합성 스크립트: `temp/compose_guideline_card.py`
- 본문 SSOT: Notion SOP DB `[웰니스 스튜디오] 회원·강사·시설물 이용 가이드` (URL: https://www.notion.so/3660407da9488173abddcd1eb635308c)

## 카드 구성 (v1.1 — 2026-05-20)

- 좌상단: 정식 베이지 로고 PNG (`wellperion_beige_alpha.png`)
- 우상단: WELLPERION 칩
- 헤더: WELLPERION GUIDE
- 슬로건: **"A Day, Well Completed. / 하루의 완성"**
- 철학 부연 한 줄: "정성스러운 하루가 모여, 더 나은 일상을 만듭니다"
- 3섹션 — **모든 항목 한국어(English) 병기 형식** + **5/5/5 균형 (v7 — 행동 룰만)**:
  - FOR MEMBERS (회원님들) — 5항목 (예약 / **1:8 클래스 정원** / **본인 원위치** / 그립삭스 / 음식 금지). 1:8과 원위치는 다른 카테고리라 분리 (2026-05-20).
  - FOR INSTRUCTORS (강사님들) — 5항목 (도착 / 촬영 금지 / 안전 / 위생 / 톤매뉴얼)
  - FOR FACILITY USE (시설물 이용) — 5항목 (락커룸 / 청결 / 향수 / 공동 공간 배려 / 시설 이상 시 즉시 리셉션 공유)
- **OPERATIONS 운영 안내 영역 (v7 신설)** — 운영시간·휴관일은 회원 행동 룰이 아니라 시설 정보 → 카드 하단 별도 영역 + SOP 본문 별도 섹션
- 풋터: 문의 (Inquiry) : litt.ly/wellperion · WELLPERION · 한남동 현대하이페리온 · 서울 용산구 서빙고로 413
- 풋터: 문의 (Inquiry) : litt.ly/wellperion · WELLPERION · 한남동 현대하이페리온 (Hannam-dong)

## 첨부 위치 (영상 룰과 결합)

- **영상 있음**: 1p~Np 사진 + (N+1)p **가이드라인** + 마지막 영상 → 영상이 진짜 마지막, 가이드라인 직전
- **영상 없음**: 1p~Np 사진 + (N+1)p **가이드라인** → 가이드라인이 진짜 마지막
- 카운터 TOTAL = 슬라이드 + 가이드라인 (+ 영상)

**Why:** 매 콘텐츠 회원/강사/시설 안내가 끊임없이 반복됨 → 표준 카드 1장 + 자동 첨부로 일관성·재사용성·정보 전달 동시 충족. SOP라인 SSOT 본문이 바뀌면 카드 재합성 → 모든 콘텐츠에 자동 반영.

**How to apply:**
- compose_ballet.py · compose_barre.py 등 콘텐츠별 매핑 스크립트 끝에서 `shutil.copy(guideline_card.jpg → output/ig_{TOTAL}.jpg)` 자동 첨부 코드 포함
- TOTAL 카운터 = 실제 슬라이드 + 가이드라인(+영상) 합산
- 카드 본문 변경 시 절차: ① SOP DB 본문 갱신 → ② compose_guideline_card.py 매핑 patch → ③ 실행 → ④ 발레/바레 등 콘텐츠 자동 반영 (카드 1장만 SSOT)
- 로고는 항상 `*_alpha.png` 사용 (메모리 룰 — PIL로 W 직접 그리지 말 것, [[project_brand_ontology]])
- 슬로건은 본 메모리 + SOP에 명시된 "A Day, Well Completed. 하루의 완성"으로 통일. 변경 시 GM님 결재.
