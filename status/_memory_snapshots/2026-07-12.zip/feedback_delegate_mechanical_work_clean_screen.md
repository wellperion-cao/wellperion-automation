---
name: feedback_delegate_mechanical_work_clean_screen
description: "기계 작업(커밋·검증·다단계 bash·패치)은 서브에이전트 위임 — GM 메인화면엔 결론·표만, 도구호출 ID(call_xxx) 노이즈 제거"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 4d3c70c1-d7af-4890-b593-97e6bc487660
---

GM이 작업 중간에 `call_xxx`(도구 호출 ID)·도구 실행 과정이 화면에 떠 "읽기 힘들다"고 반복 지적(2026-06-24).

**Why:** 도구를 메인 스레드에서 직접 돌리면 호출마다 ID·과정이 GM 화면에 노출됨 = 약속 L17 위반(기계 과정은 GM 화면 밖에서 처리). 반복 지적 = 말로만 약속하지 말고 행동을 바꾸라는 신호.

**How to apply:** 커밋·검증·왕복 bash·코드 패치·grep 등 **기계 작업은 executor/general 서브에이전트로 위임**해 메인 스레드 밖에서 처리한다(서브에이전트의 도구 호출은 GM 화면에 안 뜸). 메인 화면엔 **결론·표·결정 필요분만**. 판단·설계·GM 보고는 메인 유지. 내부 ID·약어·줄번호·커밋해시 화면 노출 금지. 단 한두 개의 가벼운 조회는 굳이 위임 안 해도 됨(과한 위임=지연·토큰 낭비) — 다단계·반복 churn일 때 위임. 관련 [[feedback_report_final_value_decision_support]] · [[feedback_welly_delegate_not_execute]] · [[feedback_gm_reports_short_scannable]]
