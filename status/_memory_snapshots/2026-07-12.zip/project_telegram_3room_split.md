---
name: project_telegram_3room_split
description: 핵심멤버방 3분류 분리 — 점검관리/문의알림/종합접수처 chat_id 매핑과 라우팅
metadata: 
  node_type: memory
  type: project
  originSessionId: 5892934a-be8f-48de-8f53-e7af1cd0b47a
---

시우 102 (2026-06-24): 텔레그램 핵심멤버방을 3개로 분리. 방별 chat_id:
- **점검 관리** = `-5136037543` (.env `TELEGRAM_CHECK_CHAT_ID`)
- **문의 알림** = `-5516675010` (.env `TELEGRAM_INQUIRY_CHAT_ID`)
- **종합 접수처** = `-5065206276` (.env `TELEGRAM_RECEPTION_CHAT_ID`) — **구 핵심멤버방(CORE_GROUP)을 GM이 '종합 접수처'로 전환**. 동일 ID.

라우팅: 점검 알림→점검관리 / 강습·멤버십 문의→문의알림 / VOC·종합접수→종합접수처.

코드 측 완료: `.env` 3키, `telegram_bot/daily_scheduler.py` 점검 독려(`CHECK_NUDGE_CHAT_ID`)→점검관리방(다음 봇 재기동 시 발효).
GAS 측(ScriptProperty `TELEGRAM_CHAT_ID`, 코드·재배포 불필요·런타임 읽음): 점검GAS(1FLQAzjq…)→점검관리, 강습문의GAS→문의알림, VOC GAS(1_jF5yhX…)=종합접수처 유지. ScriptProperty는 원격 설정 불가 → GM이 각 GAS 에디터에서 변경.

봇=@namuki_report_bot. 프라이버시 모드라 그룹 평문 미수신 → **봇 관리자 승격**해야 수신·발송. chat_id 조회=getChat(폴링 무관, 409 회피). getUpdates는 라이브 봇 폴링과 409 충돌. 관련 [[reference_bot_elevated_restart]].
