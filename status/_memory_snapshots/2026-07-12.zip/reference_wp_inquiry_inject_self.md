---
name: reference_wp_inquiry_inject_self
description: 워드프레스 문의 페이지 주입은 시모가 직접 가능 — wordpress_admin_playwright.py(GM 수동 아님)
metadata: 
  node_type: memory
  type: reference
  originSessionId: 260c4dac-9847-42a6-a1ac-9aeca99e374c
---

WP 문의 페이지(`wellperion.com/ko/inquiry/`) `[vc_raw_html]` 갱신은 **시모가 직접 실행**한다. GM 수동 복붙 기본값 아님(2026-06-15 GM 확인 "시모도 주입 가능하잖아" → 직접 처리 성공).

- 도구: `scripts/wordpress_admin_playwright.py` (Playwright headful + `profiles/wordpress/` 로그인 세션)
- 한국어 문의 페이지 **post_id = 8394** (KO_INQUIRY_POST_ID 고정) · **영어(EN) 문의 페이지 post_id = 8408** (`/en/inquiry/`, shortlink `?p=8408`로 확인 — body class page-id-8394는 WPML 잔재라 신뢰 금지). EN 재주입 = `--mode draft-inquiry-en --post-id 8408` (`wp_inquiry_block_en.html`)
- 절차: ① `--mode check`(세션 유효 확인) → ② `--mode draft-inquiry --post-id 8394` (= `wp_inquiry_block.html`을 base64(urlencode) `[vc_raw_html]`로 감싸 #content 전체교체, 발행상태면 #publish로 업데이트=발행 유지). 영어판=`--mode draft-inquiry-en --post-id <EN_ID>`(`wp_inquiry_block_en.html`).
- ⚠️ draft-inquiry는 본문 **전체 교체**(백업 없음) — 페이지 SSOT=`wp_inquiry_block.html`이라 안전하나, 부분수정은 `--mode swap-href --find --repl`(단일치환 가드+백업) 사용.
- **종합접수처(VOC)도 동일 구조 (트랩!):** 회원용 폼 = WP 페이지 **post_id=8434**에 `reception_block.html`을 `[vc_raw_html]`로 주입한 **사본**. GitHub/Pages 수정만으론 라이브 폼 반영 안 됨 → 반드시 `--mode draft-reception --post-id 8434` 재주입해야 회원 화면 갱신(발행 상태라 라이브 바로 갱신). 발행은 `--mode publish-reception`. 2026-07-08 '장소' 라벨 수정 시 재주입 누락으로 GM이 옛 '위치' 목격 → 재주입 후 해결. 폼/블록 수정 = **항상 재주입까지가 완료**.
- 선행: WP는 HTTP 전용·자체서명(ignore_https_errors)·Salient/WPBakery. 세션 만료 시 `--mode setup`(GM 1회 로그인). headful이라 GM 데스크톱 세션 필요. [[reference_wordpress_site_structure]] · [[feedback_gas_deploy_notepad_chrome_pair]]
