---
name: ig-content-folder-standard
description: 콘텐츠 작업 폴더·output 4채널·매핑·자동 첨부·영상 룰 영구 표준 (2026-05-20 GM 확정, 2026-05-21 4채널 output 진화).
metadata: 
  node_type: memory
  type: project
  originSessionId: f39f6807-2207-4271-821b-7bbede864929
---

웰페리온 콘텐츠 작업의 영구 표준 구조. 다음 콘텐츠부터 본 표준 자동 적용 (2026-05-20 GM 확정, 2026-05-21 output 4채널 진화).

## 📂 폴더 표준 (3종 작업 폴더 + 원본 + 표준 모듈)

```
instagram/
├── 260426_WJO_스쿼시_대회/      ← 작업 폴더 표준 #1
├── 260520_발레_런칭/             ← 작업 폴더 표준 #2
├── 260520_바레_런칭/             ← 작업 폴더 표준 #3
├── Image/
│   ├── WJO_스쿼시 대회(원본 이미지)/
│   ├── 발레_런칭(원본 이미지)/
│   └── 바레_런칭(원본 이미지)/
├── _assets/
│   ├── logo/wellperion_beige_alpha.png · wellperion_white_alpha.png (정식 자산, PIL W 직접 그리기 금지)
│   └── guideline_card.jpg                (영구 자동 첨부)
├── _재사용_템플릿.py              (메인 페이지 영구 템플릿 — make_main_page)
├── _재사용_스토리_템플릿.py        (스토리 카드 — make_carousel_card)
├── _메인_페이지_템플릿_가이드.md  (v1 가이드 SSOT)
└── _브랜드_온톨로지.md            (브랜드 가이드 SSOT)
```

## 🧩 작업 폴더 내부 구조 (2026-05-21 4채널 진화)

```
260YYMMDD_콘텐츠명/
├── 260YYMMDD_00_main.jpg ~ 260YYMMDD_NN_*.png  (원본 사진 복사·리네이밍)
├── 260YYMMDD_큐레이션_추천.md                    (매핑·카피·발행 메타 — 슬라이더 폴더 루트)
├── output(인스타그램)/                             (IG 가공본: ig_01~NN.jpg + ig_NN.mp4 + 가이드라인 카드)
├── output(블로그)/                                  (네이버 블로그 재합성 1200×900)
├── output(카페)/                                    (네이버 카페 재합성 1080×1080)
└── output(카카오 채널)/                            (카카오 채널 콘텐츠 — 자동 게시 보류, [[project_kakao_bot_rd_closed]])
```

**단일 `output/` 폴더 사용 금지** — 채널별 분리로 게시 흐름·검수 게이트 명확화 (2026-05-21 GM 지시).

## ⚙️ 매핑 스크립트 표준

위치: `temp/compose_<콘텐츠>.py`

필수 호출 (출력은 `output(인스타그램)/`에):
- 1p 메인: `make_main_page()` (메인 페이지 영구 템플릿)
- 2p~Np 스토리: `make_carousel_card()` (1080×1080 + 카운터 N/TOTAL + 워드마크)
- 마지막: **가이드라인 카드 자동 첨부** (`shutil.copy(guideline_card.jpg → ig_TOTAL.jpg)`) — [[project_ig_guideline_card]]
- 영상 있으면 진짜 마지막 슬롯 (가이드라인 직전이 아닌 영상 직전이 가이드라인)

**블로그/카페/카카오 채널은 별도 재합성 X.** IG 가공본을 그대로 각 채널 `output(...)/`로 복사 (2026-05-21 GM 단순화 지시). 채널별 별도 compose 스크립트 폐기.

## 🎬 영상 가공 표준

영상 있는 콘텐츠는 `temp/compose_<콘텐츠>_video.py` 별도 스크립트:
- 1080×1080 정사각 center crop
- 사진 슬라이드와 동일 오버레이 (W 로고·WELLPERION 칩·카운터·BARRE 워드마크·메인 카피·부제)
- moviepy + alpha PNG 사용

## 🌐 발행 흐름 (4채널 디자인 SSOT 일관성 — 2026-05-21 GM 지시)

IG 발행 후 디자인·카피 베이스로 별도 큐:
1. **IG** (`@namuk.wellperion`) — Meta Graph API 자동 게시 + CEO 검수 게이트
2. **네이버 블로그** (wellperion) — 1200×900 재합성 (디자인 SSOT 일관성 의무)
3. **네이버 카페** (동부이촌동) — 1080×1080 재합성 + 격조 톤([[feedback_cafe_tone_elevated]])
4. **카카오 채널** — 콘텐츠 폴더 준비만, 자동 게시 보류 ([[project_kakao_bot_rd_closed]] ToS 회색지대 · ROI 음수). 게시 재개 시 GM 명시 지시 필요.

## 🚫 무관 자산 (이번 정비 2026-05-20)

다음은 삭제됨 (다음 작업 시 만들지 말 것):
- `_extract/` (docx 추출 잔재)
- `drafts/` (구 초안 7건)
- `slides/` (구 산출물 IG·블로그·카페)
- `WJO(...).docx` (구 결과 문서)
- `Image/1. 메인_템플릿_시안/` (디자인 v1 확정 후 무의미)

**Why:** GM님 "불필요·무의미 데이터 삭제" 지시 (2026-05-20). 표준 3폴더 외 잔재 제거하여 다음 작업 시 혼란 방지.

**How to apply (다음 콘텐츠 셋업 절차 — 2026-05-21 단순화):**
1. 신규 원본 이미지를 `Image/{콘텐츠명}(원본 이미지)/`로 적재
2. 작업 폴더 `YYMMDD_콘텐츠명/` 생성, 원본을 `YYMMDD_NN_*.png`로 리네이밍 복사
3. 4채널 output 폴더 자동 신설: `output(인스타그램)/` · `output(블로그)/` · `output(카페)/` · `output(카카오 채널)/`
4. IG 매핑 스크립트 1개만 작성: `temp/compose_<콘텐츠>.py` (make_main_page + make_carousel_card + 가이드라인 자동 첨부) + (영상이면) `compose_<콘텐츠>_video.py`
5. 실행 → `output(인스타그램)/`로 산출 (IG 가공본 = 모든 채널 SSOT)
6. **IG 가공본을 그대로 `output(블로그)/` · `output(카페)/` · `output(카카오 채널)/` 3채널에 복사** (재합성·텍스트 추가 X)
7. 슬라이더 폴더 루트에 `YYMMDD_큐레이션_추천.md` 작성 (채널 중립)
8. GM 검수 → 채널별 업로드 캘린더 DB 등록 → IG·블로그·카페 자동 발행 큐 (카카오는 자동 게시 보류)
