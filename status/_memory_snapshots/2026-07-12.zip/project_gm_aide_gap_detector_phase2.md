---
name: project_gm_aide_gap_detector_phase2
description: "배237(b) 자율 틈 감지기 MVP — 대기/지연 감시. 독립 게이트 AIDE_STALL_APPLY 기본 OFF, 라이브 활성=새 GM go 대기"
metadata: 
  node_type: memory
  type: project
  originSessionId: b80e896f-a369-4178-a165-ab60e7d4a352
---

배237(b) GM 보좌 자율화 phase2 = **자율 틈 감지기**(기대상태↔실제 틈 감지→가역이면 자율/비가역이면 제안). MVP 감지기 = **대기/지연 감시**(정체·재개가능 배). 2026-07-08 구현·검증 완료(코드+드라이런+샘플), **라이브 자율 발효는 안 함**.

**설계 정본:** `docs/superpowers/specs/2026-07-08-gm-aide-gap-detector-design.md` · 계획 `.omc/plans/2026-07-08-…-plan.md`. 코드: `scripts/aide_detectors/{stall_watch,reversibility,auto_actions}.py` + `gm_aide_scan.py` 통합(`run_gap_detector`). 커밋 707c8acf·559390f5·e20adadc.

**핵심(재확인 필수):**
- **반반 구성(2026-07-08 GM 결정, 라이브 활성):** 재개가능 감지(선행 참조배 DONE→depends_on 해소, 정확도 7/7)=**자율 ON**(태그+담당 재촉+depends_resolved). 정체 감지(며칠 무활동, 메모날짜 시차로 오탐 소지)=**surface-only**(자율현황 '⏳정체 의심 배' 정보패널·_queue write 0). 게이트=`AIDE_RESUMABLE_APPLY=1`(gm_aide_scan.bat, 라이브)·기존 `GM_AIDE_AUTO_EXEC`와 분리·**역롤백=.bat 그 1줄 제거**. 정체 게이트는 미추가. 캡 MAX_AUTO_ACTIONS_PER_RUN=5/run(잔여 다음 회차 멱등). 커밋 df1c940c.
- 이유(GM 문답): 기존 안전장치(완료훅 next·phase1 제안·정비5종·부팅가드)와 일부 겹침 → 새 가치는 '진행중 멈춤/재개가능 배'뿐이고 정체 신호 불완전 → 정확한 재개가능만 자율, 정체는 정보표시. 토큰비용 0(순수 파이썬·AI 미호출).
- 정체 방아쇠=note 최신 날짜브래킷 파싱(`updated_at`은 _queue에 없음)→enqueued_at 폴백. 무게별 임계 🛳️2·⛴️3·⛵5일, 미상=5. **한계=note 브래킷은 편집일이지 실작업일 아님**(오탐·시차 가능, 실제 샘플서 #237 자기오탐 관측). 종착=정식 updated_at 배선(후속).
- 자율조치 로그=신규 파일 금지, 기존 `log_auto_exec`→`gm_observation_ledger.jsonl` auto_exec 채널 재사용. 태그=note 아님 구조필드 `ship['aide_flags']` 멱등(INC-010 방지).
- consensus(Architect·Critic)가 실코드 검증으로 배포 전 blocker 3개(updated_at 유령·게이트 오인·--dry-run 미실존) 차단 — 자율 엔진 확장 시 **실 스키마·라이브 게이트 상태 재검증 필수**.

후속 감지기 ②루틴누락 ③KPI드롭 ④GM약속추적 = 같은 뼈대 플러그인(유보). propose 레인은 현재 공허참(정체·재개는 본질 가역)이라 후속 감지기용 스캐폴딩. 관련 [[project_gm_aide_autonomy]] [[project_bridge_mechanized]] [[project_daily_northstar_recommender]].
