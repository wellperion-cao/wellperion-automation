---
name: project_sensitive_page_gate
description: 민감 ERP 페이지 사내 게이트 = _assets/gate.js 단일 공유(커튼·우연차단). 비번 단일출처. ERP메인 제외. 진짜잠금=배21 JWT(보류)
metadata: 
  node_type: memory
  type: project
  originSessionId: 8bfa30eb-8e1c-4659-a50a-27bc52617bb5
---

GM 지시(2026-06-25): 매출지출현황의 비번 가림막을 민감 페이지로 확장.

**방식 = 단일 공유 게이트**: `3. 웰페리온 가이드/_assets/gate.js` 1벌. 각 보호 페이지 `<head>`에 `<script src=".../_assets/gate.js" charset="utf-8">` 1줄만 include. **비번은 gate.js 한 곳에서만 관리**(페이지별 복붙 금지). 비번=`wellperion!@1202`. sessionStorage `welp_gate_ok`로 탭 세션당 1회 통과. body visibility 가림(플래시 방지, 차트 크기 위해 display:none 아님). 배포=`3. 웰페리온 가이드/`가 Pages 루트로 복사(Jekyll 미실행이라 `_assets/` 서빙됨).

**적용 10페이지**: cfo/expense·sales, cpo/member(문의회원·회원관리), coo/todo/결재현황SSOT, cmo/funnel(마케팅현황대시보드·월간마케팅보고서), wellperion_dashboard_web(재등록), **+월간운영계획.html(루트)·coo/reception/종합접수처_현황.html(2026-07-07 추가)**. 2-deep=`../../_assets/`, 루트=`_assets/`.

**2026-07-07 추가 배경**: 종합접수처(VOC reg_board) **접수 내용(content 자유서술)에 회원 실명 다수 박혀 있음**(예 "민문기 회원…", "김유진회원…", "43번 김호성님…"). 구조 필드 name/contact는 서버 마스킹돼도 content 서술이 실명 노출. 월간운영계획에 접수 내용 상세 표시 추가(GM 지시) + 리셉션 페이지는 원래 게이트 없이 full content 공개中이던 것 발견 → **두 페이지 gate 추가(GM 승인)**. 즉 접수 내용 표시는 유지하되 대외 공개만 커튼으로 차단.

**핵심 진실**: 이건 "잠금"이 아니라 "커튼" — 공개 호스팅이라 소스보기로 비번 노출, 작정한 사람은 우회 가능. 우연·실수만 차단. **진짜 잠금 = JWT+자체서버([[project_self_hosted_server_setup]], 배21·101, ≈2026-09 보류)**. 그러므로 이 비번 ≠ 서버·계정 진짜 비번.

**제외**: ① wellperion_guide(main)=ERP메인은 의도적 공개요약층(PII는 HR허브·재무 하위게이트로 siloed)이라 제외 — 메인 허브 가리면 전체 내비 막힘(GM 판단 보류건). ② 자체 게이트 보유 페이지(chro/hub·cfo/finance/매출지출현황·라커대시보드_test)는 무수정. 회원 PII는 페이지 커튼보다 뒷단(GAS) 잠금이 핵심([[project_pii_gate_aggregates_public_no_key_ux]]).

**서버측 잠금 (2026-06-25 GM go '닫기')**: 회원관리.html=정적 SOP(잠글 데이터 없음). 진짜 누수=Survey.js `member_inquiry_list`·`member_active_list`가 공개 액션이라 실명·전화를 토큰 없이 반환(2026-06-22 '전체 공개' 잔존). 조치=Survey.js에 `_piiFull_`/`_svMaskName_`/`_svMaskPhone_` 추가 — ScriptProperty `PII_MASK='on'` + `ACCESS_TOKEN` 설정 시에만, `body.key` 일치할 때만 풀 반환·아니면 마스킹. 집계 액션 공개 유지(대시보드 무중단). **기본 PII_MASK 미설정=현행 풀(배포 영향 0)**, 롤백=속성 삭제. 프론트(문의회원.html)=두 fetch에 `_wpKeyParam()`+'🔓 전체보기'(비번 1회→localStorage `wp_access_token`). 비번 소스에 없음=서버 검증. **활성화=GM 편집기**(새 버전 재배포 + 속성 2개). clasp push 휴면 완료. 정본=`.deploy-funnel/Survey.js`. 커튼 비번=`wellperion!@345`(GM).
