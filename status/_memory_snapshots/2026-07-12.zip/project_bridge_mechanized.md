---
name: project_bridge_mechanized
description: 완료시 '다음' 강제·AI자율화 ③④ 통합 — post_action --next/--terminal·_queue PENDING·화이트리스트·핸드오프
metadata: 
  node_type: memory
  type: project
  originSessionId: 5841da60-6926-442c-aff6-54482211cb13
---

**일의 브릿지(Work Bridge) 장치화 — GM 결정·구현 2026-06-04.** 핵심: '다음'이 사람(웰리) 기억이 아니라 **구조**로 잇게. (브릿지 = 어제 완료가 남긴 '다음' + GM 입력만으로 오늘 할 일 구성, 0에서 재추론 금지.)

**완료 처리기 `wellperion-agents/scripts/clevel_post_action.py`:**
- 완료(DONE) 보고 시 **`--next "다음 한 줄"`** 또는 **`--terminal`**(종결) 입력. **C레벨 완료 보고는 반드시 둘 중 하나를 붙인다.**
- `--next` → `status/_queue.json`(중앙 큐=단일 진실)에 **PENDING 자동 등록**(`task_id=NEXT-{YYYYMMDD-HHMMSS}`, `depends_on=완료id`, `origin=bridge`, `from=clevel`) + 완료 task에 `next` 기록 → 다음 부팅이 그대로 집음.
- `--terminal` → 완료 task에 `terminal=true`. 다음 없음 명시.
- 둘 다 없으면 → `next_missing=true` + 콘솔 경고 + 텔레그램 보고에 `⚠️ 다음 미입력—브릿지 끊김` 병기(**비차단**).
- ※ 브릿지 '다음'은 `_queue.json`에만(단일 출처).

**브릿지 미작동 근본수리(2026-06-05):** 근본원인 = **이중 task 장부** — 개인 `status/{role}.json`의 `active_tasks`에 DONE이 누적('무덤')되고, 부팅 지시가 이 개인 무덤을 `_queue.json`과 동급·status필터 없이 읽어 옛 DONE을 '오늘 할 일'로 부활.
- **부팅 단일출처 명문화**: 6개 에이전트 .md "## 2. 부팅..." 섹션 + CLAUDE.md를 "**단일 장부=`_queue.json`**에서 본인 clevel의 PENDING·IN_PROGRESS만, 개인 `status/{role}.json`은 보조(메타)뿐·DONE 부활 금지, 큐 비면 '대기'"로 교체.
- **끝난 일 자동 정리**: `wellperion-agents/scripts/queue_archive.py` `sweep_old_done(retain_days=2)` = **완료 2일 경과 DONE만** `status/_archive.json`으로 이동. 2일 보존 필수 이유: `ceo_morning_pipeline`·`ceo_evening_wrap`이 `_queue.json`의 어제/오늘 DONE을 읽어 '마무리 건수' 집계.

## AI 자율화 ③④ 완료 상태

AI 자율화 사다리 **③④ 완료(2026-06-24, 웰리+시우)**.

- **④ AI간 자동 핸드오프** = 동작 확인됨. `clevel_post_action.py --next "<설명>" --next-clevel <대상>` → 대상 C-Level 큐에 PENDING 배 자동 생성(origin=bridge·from·depends_on). 받은 C-Level은 부팅 시 본인 clevel PENDING/IN_PROGRESS 필터로 자기 배 인지. 실증: 웰리→시우 왕복 PASS. 코드 무수정(이미 있던 기능).

- **③ 자율실행 화이트리스트** = **S2 공통탭 'GM 결재 영역' 박스 하단**에 표로 명문화(정본 위치). 🟢자율 7종(읽기·집계/상태파일/자기영역 코드·문서/공용문서 커밋푸시/GAS배포 로직무변경/AI큐핸드오프/시크릿검수, 조건=5종 무변경) vs 🔴게이트(결제·보안·금지·전략·공식값 + 보안 라이브발효). 원칙 "애매하면 게이트(보수)".

**코드 강제(2026-06-24, 시토 구현):** `ssot/enforcement.py` + 1-스위치 `ssot/enforcement_mode.json`(off|warn|block, **현재 warn**) + pre-commit 가드 `scripts/precommit_enforcement_guard.py`. 감지 4종(공식값·약속/금지경로/보안 라이브발효/결제=결재흐름 재사용). warn=감지·로그만(fail-open, 커밋 안 막음). 정당 변경 우회=커밋메시지 `[GM-approved]`. **실제 차단 ON = mode를 block으로(=GM go 지점, AI 임의금지)**.

**남은 공백(GM 결정 대기):** ① 차단 ON 발효 — 며칠 warn 관찰→오탐0→GM go(mode=block). ② 핸드오프 **즉시 알림** 없음(배 꽂히면 즉시 텔레그램 알림이 유일 공백).
