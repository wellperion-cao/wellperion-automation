---
name: reference_inquiry_sheet_name_col_trap
description: "26년 신규문의 시트 이름 컬럼 매핑 함정 — '이름' 부분일치가 담당자칸을 먼저 잡음"
metadata: 
  node_type: memory
  type: reference
  originSessionId: fb94dd7a-7ff3-40d6-8ad6-04aaeb58351a
---

'26년 신규문의' 시트(GAS `_MI_SHEET`, id 12AWcAlgmmYKr2nUbWmVpa71_z3zi0BaU4ZdnOwrI_7U) 실제 헤더: `타임스탬프 | 1. 성함 | 2. 연락처 | … | 접수 담당자 혹은 본인 이름(13번) | …`.

회원 성함 = **'1. 성함'(1번칸)**. 13번 '접수 담당자 혹은 본인 이름'은 접수 직원명(담당).

함정: `_miColIdx_` 부분일치라 이름 배열 `['이름','성함']`이면 '이름'이 13번('…본인 이름')을 **먼저** 잡아 회원명 칸에 직원명이 뜸. 담당 배열 `['담당','담당자']`도 13번이라 둘 다 직원명. **반드시 `['성함','이름']` 순서**(웹폼 경로 line 130도 이 순서). 정본 코드=`.deploy-funnel/Survey.js`. 배포: `cd .deploy-funnel && clasp push -f && clasp deploy --deploymentId AKfycbzdwSC…ddA4IAvsNfelg0xA -d "설명"`(clasp 연동됨·/exec URL 유지·GM 손 불필요. 2026-06-24 @70으로 직접 배포해 라이브 해결, [[reference_funnel_gas_script_id]]). 페이지 연결=[[project_member_inquiry_page_wiring]].
