---
name: feedback_always_structure_simplify_advance
description: 모든 작업·산출물은 항상 구조화→단순화→고도화를 거쳐야 한다. 동작만 되는 1회성 땜질은 미완
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d62af51e-72b7-4995-8e21-1b27c755b4d6
---

GM 2026-06-18 지시: **"항상 구조화·단순화·고도화가 되어야 한다."**

**Why:** 동작만 되는 일회성 땜질은 끝이 아니다. 웰페리온의 모든 산출물은 결국 *제품화·재사용·지속 발전*(스포츠클럽 ERP 판매)을 향하므로, 매 작업이 그 수준으로 다듬어져야 한다.

**How to apply (작업 마무리 전 3렌즈로 점검):**
1. **구조화** — 틀·단일출처(SSOT)·일관된 양식으로 정리. 흩어진 걸 한 곳에서 읽게.
2. **단순화** — 군더더기·중복 제거, 비개발자도 한눈에. 실무진이 추가 설명 없이 바로 쓰는 수준([[feedback_work_pipeline_interview_execute_simplify]] L14).
3. **고도화** — 거기서 한 걸음 더 낫게(재사용성·자동화·확장성). "다른 클럽에도 팔리는 제품이 되나" 기준.

자율 실행 위임받았을 때도 이 3렌즈를 스스로 통과시킨 뒤 완료 보고. 관련 [[feedback_guidehub_design_principles]] · [[project_northstar_g1_orchestration_erp]].
