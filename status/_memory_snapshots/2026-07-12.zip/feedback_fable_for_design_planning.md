---
name: feedback_fable_for_design_planning
description: 설계·기획 단계는 Fable 모델 사용 OK (GM 상시 승인) — 구현·실행은 기존 라우팅
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 20ccb973-1182-4783-9d2c-27b363bde02e
---

GM 2026-07-10 명시 확인: **설계·기획 단계에서는 Fable 모델(claude-fable-5)을 사용해도 된다** (상시 방침).

**Why:** 구조 설계·단순화·재설계는 Fable/Opus의 강점 영역(헌법 실행규칙 "판단·구조설계 = Opus·Fable5"와 정합). 이번 세션에서 Fable 설계가 연속으로 유효했다 — 07:30 실전사례 반자동 설계·주간 AI자기학습 Before/After 설계·주간카드 "느껴지게" 재설계. [[project_clevel_autonomy_brain_productization]](Fable세션=뼈대)와 결이 같음.

**How to apply:**
- 설계/기획/재설계 단계 = Fable 서브에이전트(Agent `model: fable`) 자유 사용. GM 재승인 불요.
- **구현·실행·루틴 작업은 기존 라우팅 유지**(Sonnet/Haiku executor). Fable는 설계 산출물(스펙·뼈대)까지, 라이브 변경은 담당 C-Level이 이어서.
- Fable 설계도 실측 기반이어야 하고(추측 금지), 스펙 문서로 남긴다(`docs/superpowers/specs/`).
- 라우팅 규율 [[feedback_scope_and_model_discipline]](가벼운 모델=루틴)의 반대편 축 — 무거운 판단=Fable/Opus.
