---
name: project_coo_dept_monthly_report_tabs
description: "시우(COO)가 4부서 월간 보고·핵심과제 지속 소유 — 부서 체계 페이지 '이달 핵심과제' 탭이 monthly_ops_plan.json 자동연동"
metadata: 
  node_type: memory
  type: project
  originSessionId: e104ce56-2d78-47aa-92cf-94f2b9116ce5
---

GM 지시(2026-07-07): 운영·시설·지원·주차 4부서 **월간 보고서·핵심과제**를 시우가 지속적으로 챙긴다(GM이 다 못 챙김). 참고=월간운영계획.html.

**방식(GM 확정): 라이브 자동 연동 · 핵심과제 중심(가볍게) · 지원부 파일럿 먼저.**
- 각 부서 체계 페이지(`coo/check/{부서} 체계.html`)에 **「📅 이달 핵심과제」 탭** 신설. 읽기 전용.
- 소스 = `status/monthly_ops_plan.json` 단일 SSOT (월간운영계획.html과 동일 파일). `months[당월].objectives[]` 중 `(dept||'').indexOf(부서명)>=0` 필터.
- 시우가 **월간운영계획 한 곳만** 갱신하면 4개 부서 페이지 자동 반영(어긋남 0, L01).
- 롤아웃 = 코드 상단 부서명 상수(`MP_DEPT='지원부'`)만 바꿔 복붙.

**상태(2026-07-07 4부서 「월간 계획·보고」 단일탭 통일 완료):** GM 지시로 각 부서 페이지의 두 탭(GAS 점검 "📊 월간보고" + 계획 "📅 이달 부서 현황")을 **하나 「📅 월간 {부서} 계획·보고」**로 통일. 공통 구조=**🎯 이달 핵심과제(상단·주인공·강조) → 📊 도달율(실무·AI) → ✅ 점검 실적(있는 부서만)**. 월간운영계획.html 구조 참고.
- **지원부**(커밋 4dd7bb54)·**시설부**(c579135c): GAS 점검 monthly_report 탭 존재→계획+실적 **진짜 병합**(#tab-monthly에 mplan 콘텐츠 이동, switchTab('monthly')서 loadMonthlyReport+loadMonthlyPlanTab 둘 다 호출, A3인쇄 보존). 시설부 점검지표=입력률·이상건수(완료율 아님).
- **운영부**(c071d992)·**주차관리부**(d1bb25aa): 점검 탭 없음→mplan 단일탭 **라벨·섹션제목만 통일**(병합 아님, tab id 'mplan' 유지). 
- MP_DEPT: 지원부='지원부'·시설부='시설'·운영부='운영'·주차='주차'(indexOf 부분매칭). objectives는 웰리가 4부서 다 채움(운영부 07-15/16·주차 07-17/18). 채우면 자동표시(코드0).
- **잔여/후속:** ①운영부 페이지 선행결함 `SHIFT_SEED` TDZ 콘솔에러 1건(이번작업 무관·정리대상). ②'더 나은 아이디어'(GM 제안됨·보류): 점검없는 운영부=종합접수처 VOC 실적, 주차=주차매출(parkId1057) 실적 연동하면 4부서 다 살아있는 보고. 주차는 GM이 "초안으로 새로"→현 objective 2건이 초안 역할.

소유 근거=[[project_differential_audit_autonomy]] 배237 / [[feedback_coo_owns_ops_4dept_interior]](지시형이나 이건 GM 구체 지시로 착수). 데이터 구조 상세=objectives 필드 title·dept·status(계획/진행/완료/이월)·progress·target·progress_note.
