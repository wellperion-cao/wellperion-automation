---
name: project_marketing_experiment_results_modal
description: 마케팅 실험 결과는 대시보드 상단 🧪버튼→팝업 모달에 누적(하단 섹션·옛 실험로그 금지)
metadata: 
  node_type: memory
  type: project
  originSessionId: 66b039a3-7972-4f11-82a9-fdb411b01b1a
---

완료된 마케팅 실험 결과의 정해진 표시 위치·방식 (GM 확정·호평 2026-06-30).

**위치:** `3. 웰페리온 가이드/cmo/funnel/마케팅현황대시보드.html` 상단 툴바('📄 월간 보고서' 옆)의 **`🧪 실험 결과` 버튼 → 클릭 시 팝업 모달**(`#exp-modal` / 카드 컨테이너 `#exp-results-list`).

**누적 규칙:** 새 실험 종료 시 `#exp-results-list` 안에 `.exp` 카드 한 장을 **맨 위(최신순)** 로 추가. 카드 = 제목·판정뱃지·기간 + 가설/실측/판정/다음레버 4줄. (실험#1 IG CTA로 시작.)

**금지:** 대시보드 하단에 정적 섹션으로 두거나, 옛 '실험로그(진행 추적)' 섹션을 되살리지 말 것 — GM이 2026-06-19에 진행로그를 빼고 G1로 단일화했음.

**SSOT 분리:** 진행 추적 = G1 항로(`status/_queue.json`) / 전체 분석 = 내부 브리프(`status/briefs/`) / 대시보드 모달 = **완료 실험 요약(보기 전용)**. 관련 [[feedback_marketing_conversion_bottleneck]] · [[project_conversion_funnel_leak_diagnosis]].

**검수 주의:** 이 대시보드는 사내 게이트([[project_sensitive_page_gate]]) 뒤 → 헤드리스 자동검증은 비번벽에 막힘(innerText 빈값). 라이브 검증은 **curl로 소스 확인**(게이트=클라JS라 소스는 통과) + GM이 비번 후 버튼 클릭.
