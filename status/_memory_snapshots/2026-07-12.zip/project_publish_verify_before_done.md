---
name: project_publish_verify_before_done
description: 발행 파이프라인(2026-06-13 GM) — 승인≠발행완료. 시모 자동발행 → 웰리가 IG↔M5 대조 후에만 발행완료. 공식·개인 전 채널
metadata: 
  node_type: memory
  type: project
  originSessionId: 294203ff-a3e2-4cfa-a593-9766af39a0f4
---

IG 발행 파이프라인 **5단계**(2026-06-13 GM 개정, 공식 wellperion·개인 namuk **전 채널 통일**):

1. 제작 → 텔레그램 알림(montage+캡션) + [✅승인]/[❌반려] 카드 — status `검수대기`
2. GM [✅승인] 탭 — status `검수요청`
3. **시모(CMO)가 IG 자동발행**(Playwright) — status `발행검증대기`
4. **웰리(CEO)가 실제 IG 게시물 ↔ M5 캡션·슬라이드 대조** → 일치 시에만 `발행완료` / 불일치 시 경고·재처리

**핵심 = 승인 ≠ 발행완료.** 구버전([승인] 즉시 발행완료 자동확정)은 폐지. 발행완료는 **웰리 실측 대조 통과 후에만** 찍힌다(오발행 사고·내용 불일치 차단 · 헌법 STEP 3.5 실증거 · [[feedback_welly_verification_standard]]).

**Why:** 06-07 북극성 오탭 조기발행 사고 + #13 자동생성 주제 이탈 → 발행 직전 사람/AI 검증 게이트가 없었음. 승인과 완료 사이에 웰리 대조 단계를 끼워 "올라간 게 승인한 것과 같은지"를 보장.

**How to apply:** 봇 `telegram_bot/bot.py` `pub:` 콜백 = 발행 후 `발행검증대기`로만 전환(발행완료 자동확정 금지). M5 보드 `isDone()`에 `발행검증대기`는 미완료(대기)로. 정본 = 로드맵 `_AI시리즈_로드맵.md` §3.4. 첫 검증 대상 = 생크몽드 Ep.1(공식계정).

링크: [[project_ig_upload_ssot]] · [[feedback_telegram_approval_channel]] · [[project_publish_notify_lock_dual_keep]] · [[feedback_welly_verification_standard]]
