---
name: reference_dept_board_gas_is_ssot_not_seed
description: "부서 체계 규정/가이드 트렐로 보드는 GAS 저장본이 SSOT, HTML seed는 fallback — seed만 고치면 GAS 데이터 있는 페이지는 화면 안 바뀐다"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 81a42bf8-a0e6-453b-ba58-f3856a083a15
---

coo/check/{부서} 체계.html 의 규정·가이드·거래업체 트렐로 보드(POLICY_SEED·FAC_GUIDE_SEED·VENDOR_SEED 등)는 페이지 로드 시 `loadXFromBackend()`가 공용 GAS(`?action=board&key=<KEY>`)를 fetch해 **board가 있으면 seed를 덮어쓴다**(`applyStored`: 컬럼별, stored 배열 있으면 그 컬럼만 GAS값·없으면 seed 폴백). 저장키 예: SUPPORT_POLICY_BOARD·FACILITY_POLICY_BOARD·FACILITY_GUIDE_BOARD·FACILITY_VENDOR_BOARD·PARK_POLICY_BOARD.

**함정:** HTML seed만 편집·커밋하면 curl-grep(서버 원본 inline seed)엔 보이지만, GAS에 저장본이 있는 페이지는 **실제 브라우저 화면이 안 바뀐다**(GAS 우선). 페이지 편집(비번 1234)으로 한 번이라도 저장한 보드는 GAS가 진짜 SSOT.

**검수 규칙:** 보드 변경은 ① 해당 GAS board 키를 `?action=board&key=`로 GET해 저장본 유무 확인 ② 있으면 GET→카드 body 수정→`POST {action:saveBoard,key,board}`(Content-Type text/plain)로 GAS 직접 갱신 ③ **Playwright로 실제 렌더해 눈으로 확인**(curl-grep 금지). 약속 L03(기록 아닌 현실 확인)의 구체 적용.

2026-06-25 실측: 지원부 SUPPORT_POLICY_BOARD에 옛 탕청소 카드가 남아 seed 수정('매일 운영')이 화면에 안 나옴 → GAS 직접 saveBoard로 해소. 시설부 POLICY/GUIDE·주차 전 보드는 GAS 비어 seed 렌더 정상. 관련 [[project_support_check_single_source_page]].
