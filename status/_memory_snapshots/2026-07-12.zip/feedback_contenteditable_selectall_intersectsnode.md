---
name: feedback_contenteditable_selectall_intersectsnode
description: "contenteditable 전체선택(Ctrl+A)은 range 끝점이 '편집칸 자체'라 blockOf 류 로직이 막내줄을 놓침 — intersectsNode로 판정. Playwright는 이 버그를 가린다"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 029ac1fc-343f-44e9-a8fc-23f8d6533501
---

contenteditable에서 "여러 줄 선택 후 줄 단위 서식(크기·정렬 등)" 기능을 만들 때, **전체선택(Ctrl+A 또는 `selectNodeContents(editor)`)은 Range의 startContainer/endContainer가 개별 줄(<p>)이 아니라 '편집칸 엘리먼트 자체'**가 된다. 그래서 "끝점이 속한 블록을 찾아 그 사이를 순회"하는 식의 로직은 끝점에서 블록을 못 찾아(null) **마지막 줄을 누락**한다(공지서식 ntFmtSize v2.60 → GM 실사용에서 막내줄만 크기 안 바뀜).

**How to apply:**
1. 선택이 닿는 줄은 끝점 형태에 의존하지 말고 `range.intersectsNode(block)`으로 직접 판정 — 전체선택이든 텍스트-텍스트 선택이든 일관되게 닿는 블록을 모두 잡는다.
2. "한 줄 안 부분 선택"만 따로 구분하려면 `range.compareBoundaryPoints`로 그 블록 전체를 덮는지 확인.
3. **Playwright/headless Chromium은 `selectNodeContents(ed)` 끝점을 텍스트 노드로 자동 보정**해서 이 버그를 통과시킨다 → 자동 테스트만으론 안전 보장 안 됨. 반드시 **편집칸-레벨 range를 명시적으로 만들어**(`var r=document.createRange(); r.selectNodeContents(ed)`) 테스트하거나 실브라우저 GM 확인 병행.
4. 저장본 불러오기(innerHTML 주입) 직후 구조 정규화(맨몸 텍스트→<p>)도 함께. 한글 IME 조합 중엔 정규화 미실행.

관련: [[feedback_wysiwyg_print_unit_parity]], [[feedback_input_no_rerender_ime]].
