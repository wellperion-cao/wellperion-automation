---
name: project-gm-todo-clevel-mapping-v2
description: GM TODO LIST 3대 영역별 C-Level + 실무진(최종 책임자) 매핑 v2 (2026-05-25 변경)
metadata: 
  node_type: memory
  type: project
  originSessionId: 314d921a-1885-4af1-80e5-e572cc2e31a3
---

GM TODO LIST 영역별 담당 구조 (2026-05-25 GM님 지시):

매출영업 전략: AI COO + AI CPO, 실무진(최종 책임자: 이경연 실장)
  운영: AI COO, 실무진(최종 책임자: 최준용M, 어시스트: 윤병현 AM)
  상품: AI CPO, 실무진(최종 책임자: 임정은M)

인사재무 전략: AI CHRO + AI CFO, 실무진(최종 책임자: 나우열M)
  인사: AI CHRO, 실무진(최종 책임자: 아직 없음)
  재무: AI CFO, 실무진(최종 책임자: 관리부)

마케팅&시설&기술: AI CMO + AI CTO, 실무진(최종 책임자: 김남욱 GM)
  마케팅: AI CMO, 실무진(최종 책임자: 김남욱 GM)
  시설환경: AI CTO, 실무진(최종 책임자: 이정헌 소장)

**Why:** 기존 매핑 대비 영역 재편 + 시설환경 최종책임자 이정헌 소장 신규 등록.

**How to apply:**
- GM TODO LIST DB 등록/업데이트 시 이 매핑 참조
- 업무 라우팅 시 영역별 C-Level + 실무진 쌍으로 지시
- 이전 매핑(`project_ai_clevel_to_practitioner_mapping`) 대비 영역 그룹핑이 추가됨

[[project-ai-clevel-to-practitioner-mapping]] [[project-gm-todo]]
