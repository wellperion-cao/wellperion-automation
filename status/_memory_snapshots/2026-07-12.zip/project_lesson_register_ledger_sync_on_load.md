---
name: project_lesson_register_ledger_sync_on_load
description: 강습 등록일 부재 해결 — 강습 등록현황 원장 + sync-on-load. 금일 등록은 내일부터 정확
metadata: 
  node_type: memory
  type: project
  originSessionId: 11a755b4-f00e-4ff6-979f-4e7dac9012cd
---

강습(성인/유소년)은 종목별 팀시트(LESSON_TEAM_SHEETS)에 **상태값(등록/SUC)만 있고 '등록일'이 없다** → '금일 등록'을 소급 산출 불가(시스템에 '등록일 데이터 없음'으로 기존 명시). 멤버십은 26년 등록현황 시트에 등록일이 있어 정확.

**해결(2026-06-27 시포·GM):** 멤버십과 동형의 **'강습 등록현황' 원장 시트**(_MI_SS_ID 내) 신설. 카드 로드 시 `_syncLessonRegistry_()`가 팀시트 SUC roster를 원장에 전화키 dedup upsert — 신규=등록일 today 도장, 기존=등록일 보존(5분 CacheService 가드 + LockService). 최초 동기화는 기존 전체를 등록일 **2000-01-01 기준선**으로 시드(금일 제외). 액션 `lesson_registry_list&type=&from=&to=`. 트리거 불필요(sync-on-load).

**중요 한계:** 등록일='우리가 처음 감지한 날' → **오늘 이후 신규 SUC부터 금일 정확**, 과거 소급 불가. 시드 직후 금일=0이 정상. 멤버십은 등록일 있어 과거 포함 정확.

정본 코드=`.deploy-funnel/Survey.js`(@108), 화면=`문의회원.html` 강습 '금일 등록 현황' 카드. 설계=`.omc/specs/deep-interview-lesson-register-member.md`. 관련: [[project_cpo_inquiry_system_unification]] · [[reference_funnel_gas_script_id]] · 측정 못하는 걸 지어내지 않기=[[project_dashboard_conversion_data_honest_limits]].
