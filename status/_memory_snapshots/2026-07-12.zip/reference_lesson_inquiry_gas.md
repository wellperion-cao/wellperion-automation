---
name: reference_lesson_inquiry_gas
description: "강습 문의 접수 알림 GAS — 시트 바인딩 standalone(저장소 밖), scriptId·종목→팀장 메일 라우팅·핵심멤버방 텔레그램"
metadata: 
  node_type: memory
  type: reference
  originSessionId: aada9a37-c277-456a-853a-4e6c29976195
---

강습 문의 알림 = 강습 문의 접수 시트(`1b0XU1oTHlXzBhEzUOar5GEm44vjopdO25qfsh-awDXw`, gid 111889422)에 바인딩된 **standalone Apps Script**. **저장소에 없음** → clasp로만 관리. scriptId=`1Q5RiwzqX3Ro1GHLPM9v__CH3DKeOxM4i7NecqI7w_rv6ev0yta4PhGP0`, 파일=`자동 접수 알림.js`. `onFormSubmit` 설치형 트리거(웹앱 배포 아님 → clasp push만으로 즉시 발효).

**동작:** 폼 제출 시 ① 희망종목→담당 팀장 G메일 라우팅(수영/아쿠아=seo861027·PT=psykss0420·필라테스=ej9582·골프=jun88020800·스쿼시=h00nster15·체조=a23718619·뮤지컬=lizziepyun, 미매칭=cao 폴백) ② 핵심멤버방 텔레그램(group `-5065206276`, 봇=@namuki_report_bot)에 동일 본문 전달.

**2026-06-23 수정:** 기존 `e.namedValues` 키워드 매칭이 폼 제목 불일치(이름은 '유소년' 잔재 키워드)로 문의자·경로·내용을 '미기재'로 빠뜨림 → **제출 시트 행을 실제 헤더(성함/문의 경로/문의 사항) 직독**으로 교체(namedValues는 폴백). 시트 헤더 직독이라 폼 제목 바뀌어도 안전. 부작용: 종목도 정상 추출돼 이제 GM 폴백 대신 실제 팀장에게 라우팅됨.

시트는 공개 export로 직독 가능(`/export?format=csv&gid=`), MCP read는 차단(Workspace AI 정책). 향후 방향: 시트 연동 탈피 → ERP "강습 문의 회원관리" 페이지화·시트=DB only (큐 CPO-2026-06-23-LESSON-INQUIRY-PAGE), 핵심멤버방 용도별 분리(큐 COO-2026-06-23-CORE-ROOM-ALERT-SPLIT). [[project_self_hosted_inquiry_db_goal]] · [[project_funnel_stage_pages]] · [[reference_clasp_webapp_redeploy]]
