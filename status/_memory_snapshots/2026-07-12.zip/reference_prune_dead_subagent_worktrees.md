---
name: reference_prune_dead_subagent_worktrees
description: .claude/worktrees 죽은 서브에이전트 워크트리가 수십GB 누적 → 주기 정리법
metadata: 
  node_type: memory
  type: reference
  originSessionId: ac72b438-1642-4dbf-ace0-7a583b563e64
---

isolation:worktree로 뜬 서브에이전트가 **변경을 남기면 자동 정리(auto-clean)가 안 돼** `.claude/worktrees/agent-*`에 누적된다. 2026-07-04 실측 = 32개 **58GB** 쌓임(각 워크트리가 레포 전체 사본).

**정리법(안전):**
1. `git worktree list --porcelain`로 열거(메인 제외).
2. 각 워크트리 `git -C "<경로>" status --porcelain` → **clean인 것만** `git worktree remove`. 미커밋 있으면 삭제 금지·보고([[feedback_no_destructive_git_in_shared_worktree]]).
3. 미커밋 dirty 워크트리는 변경을 **현재 메인과 대조**(Explore 위임) → 대개 이미 커밋된 배의 중복·구식 → GM 확인 후 `--force` 삭제.
4. `git worktree prune -v`로 유령 등록 제거.
5. **활성 잠금(pid 사용 중) 워크트리는 건드리지 말 것**(작업 끝나면 자동 정리).

주의: 메인 워킹트리는 절대 remove 금지. 대용량 삭제라 백그라운드 위임 권장. 주기적(월 1회 등) 점검하면 재누적 방지.
