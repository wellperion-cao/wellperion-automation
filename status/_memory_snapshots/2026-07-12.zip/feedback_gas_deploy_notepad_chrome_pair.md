---
name: feedback_gas_deploy_notepad_chrome_pair
description: "GM이 손댈 작업은 도구(크롬·메모장 등) 최대 ON + 작업 용이성↑, 최선은 웰리 자력완결 — 링크→크롬·코드→메모장 자동"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 260c4dac-9847-42a6-a1ac-9aeca99e374c
---

GM에게 응답할 때 **URL/링크가 있으면 항상 크롬에 띄우고(`Start-Process chrome <url>`), 코드(GAS·스크립트 등)가 있으면 항상 메모장에 띄운다(`Start-Process notepad <파일>`)**. 말로만 주지 말고 자동으로 띄울 것. GAS 배포 코드는 둘 다(메모장 + 크롬 에디터) 함께 + 클립보드 복사(Set-Clipboard)까지.

**Why:** GM은 링크를 직접 클릭해 열고, 코드를 메모장에서 복사해 붙여넣는 흐름으로 작업한다. 띄워주지 않으면 매번 추가로 요청해야 해 번거롭다(2026-06-15 GM 지시, 2회 강조 — "링크 있으면 항상 크롬, 코드 있으면 항상 메모장").

**How to apply:** 응답에 링크가 포함되면 같은 턴에 `Start-Process chrome -ArgumentList <url들>`로 띄운다(여러 개면 한 번에 탭으로). 코드/스크립트면 `Start-Process notepad <파일경로>`. 퍼널 GAS 에디터 직행 = [[reference_funnel_gas_script_id]], clasp 미연동 수동배포 = [[reference_clasp_webapp_redeploy]].

**확장 (2026-06-16 GM):** GM이 직접 해야 할 작업이 생기면 관련 **도구를 최대한 미리 ON**(열 링크는 크롬에, 붙여넣을 내용·코드는 메모장에, 클립보드 복사까지)하고 작업 용이성을 높인다. **단, 최선은 웰리가 스스로 다 완결해 GM 손이 아예 안 가게 하는 것** — 도구 ON은 자력완결이 불가능할 때의 차선. GM 라이브 검증(Ctrl+Shift+R 등)이 필요하면 해당 화면을 크롬에 미리 띄워둔다.
