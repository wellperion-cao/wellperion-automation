---
name: reference_northstar_reissues_completed_measurement
description: "북극성 추천기가 이미 완료된 측정 배를 collector 일시 null 때문에 '미측정'으로 오판해 재발행하는 함정"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 492641e4-acfd-4dc6-ab98-e5d23fa39459
---

북극성 추천기(`scripts/northstar_recommender.py`)가 **완료된 측정 배를 매일 새 카드로 재발행**해 "하다가 말다가"처럼 보이는 함정.

**증상:** 시포 전환율 측정 개통은 2026-07-04에 완료(아카이브 배 4척: 측정개통·채널별·정밀화·기간별, 누적 전환율 39.4% 라이브·문의 8,669→가입 3,414). 그런데 07-05 추천기가 똑같은 배(ship482)를 새로 발행.

**뿌리 2겹:**
1. 추천기가 `kpi_values` 스냅샷만 보고 KPI=null이면 신호②(미측정)로 측정개통 카드 발행 — **완료된 측정 배(_queue_archive)를 대조 안 함.**
2. `kpi_collector`가 GAS 일시 실패 시 해당 역할 지표를 **전부 null 반환**(07-05 cpo 전환율 전 지표 None) → 1회 장애를 '미측정'으로 오독.
   ※ null=측정불가/데이터 얇음이지 '개통 안 됨'이 아니다. `이번달_전환율`은 그 달 등록이 얇으면 정상적으로 null(누적 39.4%가 진짜 측정값).

**가드(시토 배 496):** ①run()에서 candidates를 완료·아카이브 배 제목과 dedup ②측정개통류 신호②는 '최근 N일 연속 null'일 때만 발행(1회 null 억제). 발효=GM go·역롤백.

**처리 원칙:** 이런 재발행 착시 카드는 [[project_daily_northstar_recommender]] 특성이니, 입항 처리(측정 이미 개통)로 닫고 재발행 차단은 엔진 가드로. GM KPI 오판 방지는 [[feedback_gm_decides_by_seeing_kpi_path]] 결.
