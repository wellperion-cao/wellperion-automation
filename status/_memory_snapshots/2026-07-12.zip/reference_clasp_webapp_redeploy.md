---
name: reference_clasp_webapp_redeploy
description: clasp push만으론 GAS 웹앱(/exec) 미반영 — 새 버전 배포 별도 필요
metadata: 
  node_type: memory
  type: reference
  originSessionId: ced1afb5-23bf-43f9-a20c-50b4070001c7
---

Apps Script 백엔드(GAS) 수정 후 라이브 반영 시 주의(2026-06-02 결재 백엔드 배포에서 발견):

- **`clasp push`는 코드(HEAD)만 업로드**한다. 웹앱(`/exec`)이 '특정 고정 배포버전'에 묶여 있으면 push해도 새 코드를 실행하지 않는다(라이브 미반영).
- 라이브 `/exec`에 반영하려면 **새 버전 배포가 별도로 필요**:
  - 편집기: Apps Script → **배포 → 배포 관리 → 기존 웹앱 편집(연필) → 버전 '새 버전' → 배포**. (/exec URL 불변)
  - 또는 CLI: `clasp deploy -i <deploymentId>` (기존 배포 갱신, 인자 없는 `clasp deploy`는 새 URL 생성하니 주의).
- `clasp login` 재인증은 브라우저 대화형 → 헤드리스/에이전트 환경 불가, GM 직접(세션에선 `! clasp login`).
- ★검증: 배포 성공출력만 믿지 말고 **테스트 항목으로 신버전 동작 실측**(예: 새 action 응답, 변경된 로직 결과) 후 삭제. [[feedback_ig_publish_verify_grid_existence]] 같은 false-negative/positive 방지.

라이브 결재 todo API GAS: `.deploy-todo/`(clasp 프로젝트), 가이드허브 사본과 별개 superset. 스크립트ID는 .deploy-todo 설정 참조.

**자율 배포 성공 절차(2026-06-03 시우, 난이도 컬럼 배포에서 실증):**
- 편집 대상 = **`.deploy-todo/업무&결재 현황.js`(실배포 source)** — repo `coo/todo/apps_script_todo.js`는 stale 사본이었음(검수중계 review_set_status·commit_file·결과보고서URL 누락). ⚠️stale본을 deploy하면 CMO 검수 파이프라인 소실. **반드시 .deploy-todo를 편집**, 그 뒤 repo 사본을 동기화(2026-06-03 동기화 완료).
- 프로덕션 deployment ID = `AKfycbxDwFkrxK1YIaEoSNcuw2MiHiZQ-7o5N6311ytksSyeEd86ZFOhLknOWqQgNArQvZ-7`(=프론트 /exec와 동일 문자열). HEAD용 별도 1개 더 존재.
- 명령: `(cd .deploy-todo && clasp push -f && clasp deploy -i AKfycbx…QvZ-7 -d "설명")`. 버전 @34→@35식 증가, URL 불변.
- 인증 만료 시 `invalid_grant/invalid_rapt` → GM이 `! clasp login` 1회(브라우저), 이후 에이전트가 push·deploy 자율 가능.
- 검증: `/exec?action=todo_list`로 신규 컬럼 키 등장 + 기존 컬럼·행수 보존 실측.
