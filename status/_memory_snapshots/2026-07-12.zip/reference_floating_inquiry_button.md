---
name: reference_floating_inquiry_button
description: 홈 떠다니는 문의 버튼(Buttonizer) 사양·편집법·언어별 라벨 해결법
metadata: 
  node_type: memory
  type: reference
  originSessionId: 5841da60-6926-442c-aff6-54482211cb13
---

워드프레스(wellperion.com) 사이트 전역 떠다니는 문의 버튼 = **Buttonizer 플러그인**(WP 관리자 → Buttonizer). 그룹 "BUTTONIZER" → 버튼 "인덱스 페이지" 1개.

**최종 사양(2026-06-04 완성, 실측 검증):** 봉투 아이콘 `fa-envelope-open` + 링크 `http://wellperion.com/ko/inquiry/`(http 전용·https 금지). 라벨은 **한 문의하기 / 영 Inquiry**(브라우저 언어 자동 분기). 구 카카오 채널(`pf.kakao.com/_cgxiKj`) 버튼에서 전환(채널 자체는 미폐쇄). 문의 페이지(한·영)에선 버튼 숨김.

**Buttonizer 편집법(자동화 노하우):**
- 편집창은 **왼쪽 패널 "인덱스 페이지" 글자를 Playwright 네이티브 클릭**해야 열림(JS `.click()`은 React 무반응 / 오른쪽 미리보기 버튼 클릭하면 링크 따라감). 탭=General/Style/Advanced.
- 라벨: General → "Label" 섹션 펼침 → input(좌표 ~215,558). 아이콘: Style→Icon. 발행=Publish(우하단).
- **함정: Buttonizer 편집창 값 ≠ 라이브 렌더.** 버튼 Style→Background→Base 색을 바꿔도 보이는 노랑(#FAC100)은 안 변함(노랑 출처 못 찾음 — 미해결, 현행 노랑 유지). 라벨/아이콘은 발행 후 **라이브 실측 필수**(`a.buttonizer-button` querySelector로 text/iconClass/visible 확인).
- WP 사용자정의(Customizer)는 **자동화 불가**(headless·headful 둘 다 미리보기 연결 실패 → wp.customize ready 안 됨). 추가 CSS는 GM이 직접 붙여야 함.
- 라벨 DOM: `<a class="buttonizer-button"><div class="buttonizer-label">문의하기</div><i class="fa fa-envelope-open"></i></a>`.

**문의 페이지 버튼 숨김:** WP 외모→사용자정의→추가 CSS에 `body.page-id-8394 .buttonizer, body.page-id-8408 .buttonizer{display:none!important;}` (8394=ko/inquiry, 8408=en/inquiry). GM이 붙여 적용.

**[해결] 언어별 라벨(한 문의하기 / 영 Inquiry):**
- Buttonizer 라벨은 글로벌 1개 → "문의하기" 넣으면 한·영 모두 한글. WPML String Translation은 **Buttonizer 라벨 미등록**(buttonizer 도메인 559문자열 있으나 라벨 없음)이라 번역 불가. CSS도 불가(홈 한/영 = 동일 `page-id-6`, 둘 다 `html lang="ko-KR"`).
- **해결책 = "Insert Headers and Footers" 플러그인(설치·활성됨)의 footer에 JS 주입**: `options-general.php?page=insert-headers-and-footers` → `#ihaf_insert_footer` textarea(표준, 자동화 OK). 스크립트: `if(/^\/en(\/|$)/.test(location.pathname)){ .buttonizer-label 의 textContent==='문의하기' → 'Inquiry' }` + 0.5s 폴링 20회(Buttonizer 지연 렌더 대응).
- **작동 원리:** WPML **브라우저 언어 리다이렉트** 활성 → en 브라우저는 `/en/`에 남고(JS 발동), ko 브라우저는 `/en/`→`/ko/` 튕김. 즉 실제 영어권 사용자는 `/en/`에서 Inquiry 표시.
- **[필수 함정] 검증은 반드시 `Accept-Language=en-US` 브라우저로.** ko/기본 로케일로 `/en/` 열면 `/ko/`로 튕겨 pathname=`/ko/`라 JS 안 먹는 것처럼 보임(오진 주의). 서버는 /en/ 리다이렉트 안 함(curl 0 redirects) — 클라이언트 JS 리다이렉트.

연관: [[reference_inquiry_funnel_map]] [[reference_wordpress_site_structure]]
