---
name: reference_4channel_publish_execution
description: 4채널 실행법 — 디스패처는 draft 전용·카카오/당근 발행은 직접호출·copy=제목
metadata: 
  node_type: memory
  originSessionId: ce65ab07-aa07-4709-b674-d44aa113df4a
---

본문
metadata:
  type: reference
---

★정책 갱신(2026-07-10 GM): **4채널(블로그·카페·카카오·당근) 전부 완전 자동 '발행'** — 블로그·카페도 임시저장이 아니라 `--mode publish --i-am-sure`로 실발행(구 '블로그·카페=임시저장만' 폐기). 블로그/카페 업로더에 어제(07-09) 본문소실·조립순서·발행버튼 3버그 수정 반영됨. IG는 M5 검수큐로 별도(이 4채널에 안 들어감). 콘텐츠당 ep별 분류해 진행. ⚠️복사 이미지가 `post_*.jpg`면 블로그·카페는 `--image-glob "post_*.jpg"` 필수(기본 blog_*/cafe_* 아님). ⚠️네이버 블로그는 임시저장함 0건일 때만 본문 lazy-load 정상(stale 초안 있으면 본문소실→발행 전 비우기). [[project_4channel_dispatcher]] [[project_4channel_standard]] [[project_ig_upload_ssot]] 보완.

**실행 메커니즘(비자명 — 한 번 발행 실패로 알아냄):**
- `publish_4channel_dispatcher.py` = **전 채널 draft(임시저장) 전용**(--mode draft 하드코딩). 블로그·카페 임시저장만 이걸로: `--content-dir <ep폴더> --channels blog,cafe --run --i-am-sure`. 네이버 세션은 Persistent Profile 살아있음(이미지+스티커 자동, 임시등록).
- **카카오·당근 '발행'은 디스패처로 안 됨** → 스크립트 직접호출: `kakao_channel_upload_playwright.py`/`danggn_upload_playwright.py --mode publish --i-am-sure --body-file <copy.md> --image-dir <output폴더> --image-glob "*.jpg"`. `--mode dryrun`으로 제목·본문 파싱 먼저 검증 후 발행(공개=되돌리기 어려움).
- **copy 파일 형식 = `제목\n---\n본문`** (parse_copy_file: 첫 `^---$` 라인 기준 분리). `# 카카오채널 본문` 같은 헤더를 첫줄에 두면 그게 제목으로 오파싱됨(구 바레/생크몽드 copy가 이 함정). 본문 em-dash(—)·`▍`는 안전(3+dash 라인만 구분자).
- copy 경로: 스크립트는 `--body-file` 없으면 `content-dir 루트/{kakao,danggn}_copy.md`만 자동탐색(output(채널)/ 하위 아님). **항상 `--body-file` 명시**가 안전. 이미지는 append_cta_card로 마지막에 cta_card.jpg 자동추가(슬라이드5+1=6장).
- 당근 세션 쿠키 TTL 8~9h 만료해도 스크립트가 cao@wellperion.com 자동 재로그인. 발행 증거 스크린샷=`scripts/poc-evidence/`.
- **카카오 공개 글 URL 회수(2026-07-10 확정):** 발행 스크립트·관리자 화면은 공개 postid 미노출 → **공개 프로필 `pf.kakao.com/_cgxiKj/posts` 를 렌더**해 최신 글(피드 최상단) 링크 `pf.kakao.com/_cgxiKj/{postid}` 를 뽑는다(본문 대조로 해당 글 확인, 순번 F1=113851764·F2=113916460·F3=113926646 연속). 로그인 불필요.
- **발행완료 문의알림방(-5516675010) 응원 메시지(GM 표준):** notify_published_links.py 기본형(밋밋한 '📲 발행 링크 모음')이 아니라 **따뜻한 응원 포맷**으로 보낸다 — 헤더 `📢 웰페리온 공식 #FN '주제' 발행 완료 — 응원 부탁드려요!` + 1줄 설명 + `❤️좋아요·💬댓글` 유도 + 채널별 이모지(📷IG·📝블로그·☕카페·💬카카오·🥕당근)+실URL + 끝 `좋아요·댓글로 응원 부탁드립니다 🙏`. notify_published_links.py 는 기본 `TELEGRAM_CHAT_ID`(GM개인)로 가므로 문의알림방 발송은 `TELEGRAM_CHAT_ID=-5516675010` 오버라이드 또는 직접 발송. (후속: 이 응원 포맷을 notify 스크립트 템플릿으로 승격 — 콘텐츠별 1줄 태그라인 필드 필요.)
