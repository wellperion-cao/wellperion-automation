---
name: reference_inquiry_telegram_alert_needs_trigger
description: "문의 텔레그램 알림은 GAS 시간트리거 의존 — clasp 배포론 안 깔림, 에디터서 1회 실행 필수"
metadata: 
  node_type: memory
  type: reference
  originSessionId: c686fce2-689c-4997-a922-42cd3672844c
---

문의 접수 → 텔레그램 '문의 알림' 방(-5516675010) 자동 알림은 `.deploy-funnel/Survey.js`의 5분 폴링 함수 `_notifyNewInquiries_`(FORM_SHEETS=멤버십'26년 신규문의'+성인/유소년 강습 시트의 신규행 감지)에 의존한다.

**함정:** `clasp push/deploy`는 시간기반 트리거를 설치하지 않는다. GAS 에디터에서 `installInquiryNotifyTrigger()`를 **1회 수동 실행**해야 5분 트리거가 깔린다. 이 단계를 누락하면 문의가 와도 알림이 조용히 0건(증상: 발송경로·토큰·chat_id는 정상=테스트 200인데 실제 알림만 안 옴). 진단용 `action=ping_inquiry_notify`로 발송경로 정상 여부 확인 가능.

**baseline 억제:** 트리거 첫 실행은 그 시점 lastRow(기준선)만 기록하고 그 사이클은 무발송 → 트리거 깔기 전 이미 들어온 문의는 소급 발송 안 됨(수동 인수 필요).

2026-06-24 시모 셋업 때 트리거 1회 실행 누락 → 6/24~25 문의 20건 알림 0건 사고. 트리거 install은 GM 에디터 작업(로그인). 근본 개선안=폼 onFormSubmit 즉시 발송으로 전환(시간트리거 의존 제거). 관련 [[reference_lesson_inquiry_gas]] · [[project_telegram_3room_split]] · [[reference_clasp_webapp_redeploy]].
