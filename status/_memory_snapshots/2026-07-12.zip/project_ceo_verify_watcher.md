---
name: project-ceo-verify-watcher
description: "CEO push 검증 watcher 가동 구조 + CEO 수동 [DONE] 커밋이 MISMATCH 유발하는 주의점"
metadata: 
  node_type: memory
  type: project
  originSessionId: 5564831a-f865-4fe7-9415-8193cfe98360
---

0단계 인프라로 구축·가동한 CEO push 검증 watcher 운영 메모 (2026-05-29 가동).

- 실행체: `notion-c-level-agents/scripts/ceo_verify_watcher.py --watch` ← 런처 `start_ceo_verify_watcher.bat`(루트) ← 예약작업 **`Wellperion-CEO-Verify-Watcher`** (ONLOGON, RunLevel Highest). 같이 운영: **`Wellperion-Morning-Update`**(매일 05:40, `morning_update.bat`) = 세션 前 클로드/OMC 자동 업데이트로 EBUSY 회피.
- 이중신호: 커밋 `[DONE][CL][task_id]` + `status/<cl>.json:DONE` **둘 다**여야 검증. 정상 운영은 C-Level .bat(`clevel_post_action.py`의 `write_status_file`)이 status JSON을 DONE으로 써서 충족. 검증 = 1층 기계(커밋·URL 200·SSOT중복) + 2층 AI(`claude -p`). 반려 시 자동재작업 금지·텔레그램만.
- **주의(겪은 사고):** AI CEO가 인터랙티브 세션에서 수동 `git commit [DONE][CTO][...]` 하면 status JSON이 안 써져 watcher가 MISMATCH로 보고 **커서가 거기 묶여** 미래 C-Level 검증으로 못 넘어감 + stale 텔레그램 노이즈. 해결 = watcher 정지 → `status/_ceo_cursor.txt`를 현재 origin/master HEAD로 set → `status/_ceo_mismatch_stale.json` 삭제 → 재가동(신규 commit 없음 확인). 관례상 CEO 검증 커밋은 `[VERIFIED][CEO]` 태그, `[DONE]`은 C-Level 전용.
- 샌드박스 제약: Claude Code 세션 내에선 cmd.exe 배치 실행이 가로채여 .bat 런타임 검증 불가 → 실가동은 예약작업/외부 터미널에서. watcher는 ONLOGON으로 매 로그온 자동 재가동. 관련 [[feedback_always_verify_completion]].
