---
name: reference_naver_blog_cafe_publish_format_rules
description: 네이버 발행 포맷·SmartEditor 자동첨부·스티커 함정 통합 — normalize_body·태그칸·스티커3함정
metadata: 
  node_type: memory
  type: reference
  originSessionId: c686fce2-689c-4997-a922-42cd3672844c
---

네이버 블로그·카페 발행 포맷 규칙(GM 2026-06-25 확정)은 코드에 박혀 매 발행 자동 적용된다.

정본 위치: `scripts/cta_utm.py` `normalize_body(body, for_cafe=)` —
① 소제목(▍) **바로 아랫줄**에 내용(소제목 다음 빈 줄 제거)
② 인라인 CTA 줄('wellperion.com/ko/inquiry') 제거(중복방지)
③ 해시태그 정렬: 지역·종목·타겟 먼저 + 고정 꼬리 `#종합스포츠클럽 #웰페리온 #WELLPERION` 끝, `#스포츠클럽`→`#종합스포츠클럽` 치환
④ **블로그·카페 모두** 본문서 해시태그 제거하고 태그리스트로 반환(블로그도 본문에 안 둠)

**해시태그=둘 다 별도 태그칸(본문 아님).** 카페 태그칸 셀렉터=`input.tag_input`(placeholder "태그를 입력해주세요 (최대 10개)"), 글쓰기 화면에 있어 임시저장 단계서 `_fill_tags()`로 입력. 블로그는 **'발행' 레이어에만** 태그칸 있음(셀렉터 `input#tag-input`) → `_fill_publish_tags()`가 발행 시 자동입력 ⇒ 블로그 태그 자동화는 곧 '공개 발행'을 의미(임시저장으론 태그 못 넣음).

**블로그 표준 발행 순서:** 제목 → 스티커(가운데) → 내용(소제목 바로 아래) → CTA(문의 링크카드) → 사진 → 발행 → (발행 레이어)해시태그 입력. 카카오·당근·IG는 이 규칙 대상 아님.

## SmartEditor 텍스트+이미지 통합 자동첨부

블로그(love4langhe)·카페(ichon1dong) SmartEditor 텍스트+이미지 통합 임시저장 자동화. **2026-05-21 v3.0 회귀 해결** — v2.0이 file_chooser는 정상이었으나 직후 "사진 첨부 방식" 모달(`.se-popup-image-type`) 단계 누락으로 session-key·simpleUpload API 사슬이 끊겨 본문 삽입이 영구 실패했다. v3.0은 `#image-type-slide` 자동 클릭 1단계 추가로 사슬 정상화.

**SSOT 스크립트**: `scripts/upload_with_images.py` — 두 채널 통합.
핵심 패턴:
- `expect_file_chooser` + `set_files([...])` 이미지 일괄 주입
- **popup killer**: `.se-popup-dim, .se-popup-alert, .se-popup-alert-confirm, .blog-se-alert, .se-help-panel, [data-group="popupLayer"]` → MutationObserver + `setInterval(700ms)` 지속 제거
- **사진 첨부 방식 모달 (v3.0 핵심 추가)**: `.se-popup-image-type` + `#image-type-slide` 자동 클릭

**발행(publish)은 영구 차단 — 임시저장만 자동** (사람 검수 게이트).

## 스티커 삽입 함정 3가지

네이버 SmartEditor 스티커 자동 삽입 시 실측으로 확인된 함정 (2026-06-03):

**1. 팝업 킬러 충돌 (카페 0개의 진짜 원인):** 발행기의 `_install_popup_killer`(이어쓰기·이미지 팝업 제거용 MutationObserver+interval)가 **스티커 모달(팝업 레이어)까지 삭제**한다. 스티커 열기 직전 `_stop_popup_killer(page)`로 정지, 삽입 후 `_install_popup_killer`로 복구.

**2. 패널 구조가 채널마다 다름:** 블로그 = 우측 사이드바(한 번 열면 유지 → 여러 개 연속 클릭 가능). 카페 = **중앙 팝업 모달**(scope 프레임이 아니라 다른 프레임에 렌더 → `page.frames` 전체 스캔 필요, 하나 고르면 모달 닫힘 → `count`만큼 **패널 재오픈** 반복).

**3. 검증은 로그 아닌 실측:** "주입/클릭" 로그는 false-positive 상습. `document.querySelectorAll('.se-component.se-sticker').length` 전후 비교 + **스크린샷 육안**으로만 확인.

## 카페 자동발행 함정 (2026-06-30 · `cafe_upload_playwright.py`)

GM '네이버도 자동발행' 지시로 카페 publish 실가동하며 실측. 모두 코드 박제됨.

**1. '등록'(발행) 버튼 = `<a class="BaseButton BaseButton--skinGreen">등록</a>`** (새 ca-fe 에디터). 기존 셀렉터 `button:has-text("등록")`은 `<a>`라 못 잡고 엉뚱한 `<button>` 클릭 → **'등록 완료' 로그만 찍고 실제 미게시**(글쓰기 폼 잔류). 1순위 셀렉터 `a.BaseButton--skinGreen:has-text("등록")`.

**2. 등록확인 레이어를 팝업킬러가 삭제** → 게시 안 됨. 등록 클릭 **직전** `_stop_popup_killer(page)` 필수(스티커와 동일 함정).

**3. 게시 검증 = URL 이동으로만.** '등록 완료'는 클릭 후 무조건 출력(검증 아님). `/articles/write`는 글쓰기 URL이라 `**/articles/**` 매칭은 오탐 — `/write` 제외하고 `ArticleRead`/articleid 이동을 폴링. 실게시 최종확인=클래식 iframe 글목록(`ArticleList.nhn`)에서 제목 조회(새 ca-fe SPA는 평면 querySelector로 안 잡힘).

**4. 말머리(카테고리) 선택:** `get_by_text("웰페리온", exact=True).first`는 우상단 내비 '웰페리온'을 먼저 집어 실패. 드롭다운 열고 정확매칭 중 **bounding_box y가 가장 큰(화면 아래=옵션)** 요소를 실제 Playwright 클릭 → 칩 inner_text로 반영 검증. JS `el.click()`은 네이버 옵션 핸들러 미발화(실클릭 필요).

**5. 스티커 식별:** 기본 움직이는 스티커팩 24개 전부 alt='움직이는 스티커'(속성 식별 불가) → 패널 스크린샷 실측으로 인덱스 고정. **idx10(2행6열)=보라색 '!' = 놀라는(surprise).** DOM 순서=시각 행순서 일치.

**6. 카페 본문 톤 린터:** '이웃분' 등 비격식어 경고(feedback_cafe_tone_elevated). 학부모님 등 격식어로.
