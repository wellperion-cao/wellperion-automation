---
name: reference_business_guide_card_design_standard
description: 업장 가이드 카드(포스트 마지막 GUIDE 정보 카드) 디자인 표준 위치·규칙
metadata: 
  node_type: memory
  type: reference
  originSessionId: 67e0f05a-5661-4ca7-99a1-7c1928282b51
---

업장 가이드 카드 디자인 표준 SSOT = `instagram/_assets/업장_가이드_디자인_표준.md` (2026-06-22 박제).

핵심 규칙: **마스터 `instagram/_assets/guideline_card.jpg` 상속 + 가운데 3섹션 텍스트만 패치.** 코드로 카드 전체 from-scratch 재작성 금지(골프 v2 사고 — 제목46·항목20·헤더밑줄·배경변형·여백압축 드리프트).

★완성 가이드 보관(2026-06-22 GM): 완성 업장 카드는 모두 `_assets/각 업장 가이드/{업장} 가이드.jpg` 한 폴더 단일출처(웰니스·필라테스·골프). 골프=`각 업장 가이드/골프 가이드.jpg`(루트 guideline_card_golf.jpg 폐지), compose_guideline_card_golf.py·compose_golf.py가 직독. 마스터(guideline_card.jpg 루트)=빌드 베이스 별개. 골프 카드=한 장 3맥락(회원님들·프로님들·골프 연습장 이용)·실제 연습장 사인 반영(타석·60분·키오스크·피팅존·소속프로 외 레슨금지).

정본값(마스터 실측): 배경 #221F20 / 헤더 Bold·Medium 22(영문 베이지·국문 흰) / 항목 Medium 16 연회색(200,198,199)·줄간격24 / 중앙 세로구분선 1개·헤더밑줄 금지 / OPERATIONS y≈900 큰 여백. 좋은 예=웰니스·필라테스 카드, 참고 구현=compose_pilates.compose_guide_card_pilates(텍스트 패치)·compose_guideline_card_golf v3(본문만 마스터 위 재렌더). 새 업장(스쿼시·수영·체조 등)=이 표준대로. 색·폰트 코드상수=[[project_slide_engine_canva_independence]] brand_constants.py.
