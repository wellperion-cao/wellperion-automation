---
name: reference_gas_post_curl_no_follow_redirect
description: GAS saveBoard 등 curl POST 시 -L(리다이렉트 추적)과 --data-binary 조합은 411 에러 — POST는 -L 없이 보내고 302 Location만 별도 GET
metadata: 
  node_type: memory
  type: reference
  originSessionId: ed1390fd-79c6-4e24-8cd4-0a01ea24fd9e
---

Apps Script 웹앱(/exec)에 curl로 POST(예 saveBoard·todo 쓰기)할 때: **`-L`(follow redirect) + POST `--data-binary` 조합이 411 Length Required 에러**를 낸다(GAS가 302 리다이렉트를 던지는데 mingw64 curl이 리다이렉트 후 재요청에서 바디/길이 처리 실패). 

**우회:** POST는 `-L` 없이 보내고, 필요하면 응답 302 `Location`(googleusercontent echo URL)을 **별도 GET으로 따라가** 실제 응답을 읽는다. GET 읽기(action=board 등)는 `-L` 정상.

한글 바디는 GET 쿼리로 보내면 깨지므로(→ [[reference_appsscript_korean_write]]) **UTF-8 파일로 써서 `--data-binary @file` + `Content-Type: application/json`**. 지원부 보드 저장 포맷 = `{"action":"saveBoard","key":"SUPPORT_MANUAL_BOARD","board":{...}}`, 읽기 = `?action=board&key=...`. 정본 페이지=[[project_support_check_single_source_page]].
