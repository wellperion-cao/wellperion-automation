---
name: ssot
description: 가이드허브(GitHub Pages 웹앱) = GM님 업무·루틴·건강관리·자동태스크 통합 SSOT. 식별자(data-id) 단일 체계 — 메뉴/문서/URL 모두 data-id 기준, 옛 별칭 data-doc·#g10은 LEGACY_TO_ID 안전망으로만 변환.
metadata: 
  node_type: memory
  type: project
  originSessionId: 53b64db4-aecb-45f0-8341-87c1406eeb0d
---

가이드허브(`3. 웰페리온 가이드/wellperion_guide(main).html`) = GM님의 단일 참조 문서(SSOT) + 식별 체계 = **식별자(data-id) 단일** (2026-06-13 GM "사람=코드 이름 일치" B안으로 별칭 이중구조 폐지).

**배포:** GitHub Pages — https://wellperion-cao.github.io/wellperion-automation/ · 라이브 URL엔 `3. 웰페리온 가이드/` 접두사 없음([[reference_pages_url_no_guide_prefix]]).

**GM님 할일 SSOT = 가이드허브 「G1 김남욱GM」 페이지 (2026-05-27 확정)**
- G1 "오늘의 항로" 영역이 GM님 개인 할일의 유일한 기준 (제목 표준=「🧭 오늘의 항로」, CLAUDE.md §3-1)
- 매 세션 시작 시 확인 → 전날 완료 정리 + 오늘 갱신, 종료 전 다음날 기록 인수인계
- 완료·보류·삭제 3버튼으로 처리, 완료/보류는 토글에 시간 기록 보관
- Notion·메모리·텔레그램 등 다른 곳은 보조 참고만. G1이 최종 기준
- 관련 섹션: 오늘·이번달 업무 / 보충제·루틴·건강(CHRO 검토·탭3) / 자동 태스크 현황(실가동 기준·불일치 표시)

**식별자 = 사람·코드 공통 단일 이름** (홈 "사용법" 표 머리글자):
- S1=공통가이드라인 S2=AI C-Level운영 S3=업무&결재현황SSOT
- F1=지출현황 H1=취업규칙 / O1=운영통합체계 O2=공지/안내문 O3=재등록대시보드
- M1=공식채널 M2=콘텐츠제작 M3=오프라인홍보물 M4=마케팅대시보드 M5=콘텐츠검수·자동업로드
- T1=기술인프라 T2=업무자동화 T3=AI교육 / G1=김남욱GM
- (home·dashboard·g9는 메뉴 미등록 문서 — 식별자 없이 옛 id 유지)

**구조 (이중매핑 제거됨):**
- 메뉴 `<a>` = `data-id`만 (옛 `data-doc` 속성 폐지). home은 `data-id="home"`.
- 본문 문서 `<article>`의 `id` = 식별자(예: `id="S2"`). data-tabs도 식별자.
- 라우터 JS: 모든 셀렉터·해시·active 토글이 `data-id`/식별자 기준. 옛 `PUB_TO_DOC`/`DOC_TO_PUB` 런타임 매핑 삭제.
- URL 해시 = 식별자(`#S2`·`#S2/ceo`). 옛 별칭 주소(`#g10` 등 외부 북마크·워드프레스)는 `LEGACY_TO_ID` 맵 한 줄이 식별자로 변환(하위호환 안전망, 사람 눈엔 안 보임).

**보존(통일 범위 외 — 사람이 안 보는 내부):** 함수명 `gm1FetchSsot`, CSS 하위 id `gm1-todo-section`·`gm1-review-section`, 탭 독립이름 `cmopub-ch`, 미등록 문서 `g9`·`dashboard`. = 손대지 않음.

**How to apply:** 가이드 링크·딥링크는 식별자(`#S2`)로 작성. 새 가이드 = 홈 표에 식별자 행 + nav에 `data-id` + article `id="식별자"` + `data-tabs="식별자"`. data-doc은 더 이상 쓰지 않는다. 옛 별칭(g10 등) 신규 링크 금지 — 안전망은 기존 외부 링크용. 업무·루틴·건강 변경 = 이 HTML 직접 수정. 배포=GitHub Pages, commit+push+라이브 실측까지가 완료([[feedback_guidehub_commit_must_push_and_live_verify]]). 동시 세션 커밋 직렬화([[feedback_git_commit_atomic_vs_watcher_reset]]·[[reference_guidehub_concurrent_commit_corruption]]). 최종 목표: "일과 일상이 하나되는 루틴".
