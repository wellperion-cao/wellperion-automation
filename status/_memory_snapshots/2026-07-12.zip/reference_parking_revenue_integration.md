---
name: reference_parking_revenue_integration
description: 주차 매출 자동 수집·home KPI 합류 — 주차시스템 API·매출 필드 정의·연동 구조
metadata: 
  node_type: memory
  type: reference
  originSessionId: e89882d0-7b19-40b4-af50-7eb2568ced32
---

웰페리온 주차 매출 자동화 (2026-06-19 시토 구축, 라이브 검증).

**주차시스템 (THEHAM PMS):** `http://ppark-wall.iptime.org:8280` · parkId=**1057** · 로그인 ID/PW=`telegram_bot/.env` PARKING_LOGIN_ID/PW (현재 admin/admin) · 로그인=`/login.htm` 평문 폼POST(loginId/loginPw·암호화/캡차 없음)→세션쿠키 JSESSIONID_ADMIN. 데이터=POST `/report/getParkCloseList` (application/json, body: searchParkId·searchType:"start"·searchStartDt·searchEndDt **YYYYMMDD**·searchDcSellYn:0) → result.data[] 일별 행.

**매출 필드(중요):** **`payAmt` = 매출(카드 총 정산액, GM 확정)**. `dcAmt`=할인감면(회원 무료, 매출 아님·매우 큼). cancelPayAmt=취소. 2026-06 실측 payAmt 215만/393건 vs dcAmt 1억300만(회원 무료가 거의 전부).

**연동:** `scripts/parking_revenue_crawler.py` (urllib·fail-safe·--push) → `status/parking_revenue.json` 발행 · daily_scheduler 매일 07:00 작업(봇 재기동 시 발효). home 매출 KPI 합류=home_kpi GAS `_kpiParkingRevenueRow()`가 **raw GitHub**(`raw.githubusercontent.com/wellperion-cao/wellperion-automation/master/status/parking_revenue.json`) 직독→breakdown 'GXE'(매출 팀 목록 마지막 라벨) 바로 아래 '주차' 행 삽입. **시트 총합/hero는 불변**(주차=표시행, 헤드라인 총액 미합산=정직표기). home_kpi GAS=`.deploy-todo/업무&결재 현황.js`(결재·할일 공용, clasp 연결) deploymentId=`AKfycbxDwFkrx…`@81. 관련 [[project_home_kpi_wiring]] [[reference_clasp_webapp_redeploy]] [[reference_bot_elevated_restart]].
