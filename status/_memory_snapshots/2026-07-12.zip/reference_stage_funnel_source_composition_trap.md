---
name: reference_stage_funnel_source_composition_trap
description: "stage_funnel 재배선 함정 — 7,000 미추적 풀은 문의접수 아닌 폼시트에 있고 칸키워드 파생은 큰 시트서 오매칭"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 492641e4-acfd-4dc6-ab98-e5d23fa39459
---

문의 퍼널(stage_funnel, Survey.js) "정직 재배선" 시도 중 겪은 모델 오류. 재시도 전 반드시 읽을 것.

**틀린 모델(내가 처음 세운 것):** gviz count로 소스별 행수를 셌더니 26년신규문의607·성인강습448·유소년강습610=1,665뿐 → "나머지 7,000은 문의접수(CTA 웹) landing에 있다"고 추론. **틀렸음.**

**완전 규명(getLastRow 진단액션 실측):** 문의접수 landing=0行 · 26년신규문의=750 · **성인강습=3,781 · 유소년강습(WSC)=4,669** · 나머지 폼=빈. ⇒ 7,000 정체 = **강습 폼 응답(성인3,780+유소년4,668=8,448)**. gviz `count()`가 강습시트를 448/610으로 **대폭 undercount**(초반 칸 빈값→count 왜곡). 진실=getLastRow. **gviz는 이 시트들에 신뢰 불가 → 검증은 임시배포(clasp deploy 새 URL)로 getLastRow/실집계 실측해야 함(로컬 gviz 검증 불가).**

**진짜 문제:** 원본 stage_funnel이 **멤버십 문의(749)+강습 폼(8,448)을 한 퍼널로 섞음** → "문의 8,677"은 멤버십 아님. 진짜 멤버십 문의 퍼널 = **26년신규문의(gid1902010032)만, ~749**. 강습은 별도(등록 정본=LESSON_TEAM_SHEETS).

**두 번째 함정:** 칸키워드 파생(`_findCol_(['담당자'])·['투어']·['확정시간']`)을 **전 폼시트에 일괄 적용**하면 큰 시트에서 엉뚱한 칸이 매칭돼 응대 1,546→**8,314 폭증**. 파생은 검증된 특정 시트(26년신규문의 gid1902010032)로 **스코핑**해야 함.

**원본 퍼널(정상·v132 확정):** 문의8,677→응대1,546→예약1,505→방문1,456→가입1,439. 응대 이상은 **93%가 가입**(건강). 진짜 병목=8,677 중 ~7,131이 신규 고정(폼시트 미추적).

**재시도 SOP:** ①소스구성 실측(어느 폼시트가 대량 보유·GAS getLastRow 기준) ②칸 파생은 특정 gid로 한정 ③로컬 시뮬로 워크드 퍼널 재현 확인 **후에만** 재배포. stage_funnel 소비처=[[reference_northstar_reissues_completed_measurement]] 무관·문의회원.html loadStageFunnel 카드 하나뿐(블라스트 작음). 검증 없는 SSOT 변경 금지(약속 L03). 롤백=clasp deploy --deploymentId ...A -V <이전버전>.
