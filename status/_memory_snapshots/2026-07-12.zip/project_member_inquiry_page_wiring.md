---
name: project_member_inquiry_page_wiring
description: "문의회원.html·회원관리.html(CPO) 라이브 연결 구조 — 퍼널 Survey GAS의 member_* 전용 액션·등록현황 carry-over, 기존 inquiry_list와 혼동 금지"
metadata: 
  node_type: memory
  type: project
  originSessionId: c839e4a1-7906-4f44-97e1-c4aea5849bca
---

CPO `cpo/member/문의회원.html`(등록前 잠재고객)·`cpo/member/회원관리.html`(등록後)은 퍼널 **Survey GAS**(`.deploy-funnel/Survey.js`, scriptId 1A77oDRaa21K25c3-M1AgewNfUzfW-zamfRhYWjlYUrvIdPCYazs8KQru, 운영 /exec `AKfycbzdwSCCSSJ6JXLDoWuo7HG0JmBM2iy10TujFQ_O5JbTjnWaN7gOk-ddA4IAvsNfelg0xA`)의 **member_* 전용 액션**을 직독. /exec는 각 페이지 `var GAS_URL`(1곳)에만. **clasp 연동됨**(2026-06-25 확인) — `.deploy-funnel/`에서 `clasp push -f && clasp deploy --deploymentId AKfycbzdwSC…A -d "메모"` 로 **AI가 직접 재배포**(같은 /exec 유지). 커밋만으론 서버 미반영 — push≠재배포.

전용 액션 (전부 `_SURVEY_PUBLIC_ACTIONS`, '26년 신규문의' SS `12AWcAlgmmYKr2nUbWmVpa71_z3zi0BaU4ZdnOwrI_7U`):
- **member_inquiry_list** (실명·전화·메모 전부 노출·2026-06-22 전체공개) / **member_inquiry_add**(전화·직접 문의 수기추가, 채널 기본'유선전화') / **member_inquiry_update**(전 컬럼 패치) / **member_calendar**(상담/체험 일정+시간, **실명·전화 노출** 2026-06-25 GM — 달력 칸·상세에 이름·연락처 표시) / **member_inquiry_delete**(rowIndex 행삭제 — 단 문의 페이지엔 삭제버튼 없음, ALLOW_DELETE=false 2026-06-23).
- **유입채널**: 10버킷(CANONICAL_CHANNELS, `_canonicalChannel_` 정규화) 컬럼·수정 드롭다운. **STATUS_OPTIONS**=신규·컨택중·가망·예약·방문·SUC·단기SUC·LOSS (결제완납 제거 2026-06-23).
- **'26 신규문의' 시트 실제 열 지도(2026-07-02 GM 헤더 제공·확정)**: A일정·B타임스탬프·C이름·D핸드폰 연락처·E거주지·F관심 프로그램·G문의채널·H경로(중)·I경로(소)·**J=시설투어 및 상담 예약(날짜)·K=체험1 확정시간·L=시설 체험 예약2(날짜)·M=체험2 확정시간·N=기타 웰페리온 문의사항(자유서술)**·O접수담당자·P/Q/R=Contact1/2/3·S진행현황·T미등록사유·U비고·V당일컨택. (MCP 시트 직독 차단 → 열레터는 GM만 앎, 재확인 필요 시 GM에 헤더 요청)
- **일정 = 체험1·체험2 2종, 날짜·시간 분리칸(2026-07-02 시포·GM #4)**: **상담=체험1(동일 1차 방문)**. 체험1 날짜→J·시간→K / 체험2 날짜→L·시간→M. 저장 payload=exp1Date/exp1Time/exp2Date/exp2Time(결합 아님). 읽기 폴백=분리 날짜칸(J/L) 비면 옛 결합칸(K/M) 날짜부로 무손실. 상담(tour)·visit2·체험3 필드는 폐지(흡수). 시간 드롭다운=**30분 단위**(06:00~22:30·달력모달+그리드). 
- **문의 내용(N열)**: member_inquiry_list `inquiryContent` 반환, 표에서 Contact 앞 칼럼·인라인 편집(_activateCellInquiry). add/update가 N열 write.
- **문의현황 검색**: 전체 항목(이름·연락처·프로그램·상태·채널·담당·메모·Contact·일정) + 연락처 하이픈 무시 숫자 매칭(searchDigits).
- **회원관리.html 동적**(2026-06-23): '등록회원' 탭. **carry-over** — member_inquiry_update/add 에서 진행상황=**SUC·단기SUC** 되면 별도 **'26년 등록현황' 탭**(같은 SS, 서버 자동생성: 이름·전화·프로그램·등록일·1~12월)에 전화 키로 자동 upsert(등록일=그날). **member_registered_list**(등록기간 from~to 필터·1~12월 체크 boolean[12]) / **member_registered_setmonth**(월 토글) / **member_registered_delete**(등록 해제, 전화 키 deleteRow·해제버튼 확인+PIN 1531).
- ⚠️ **기존 `inquiry_list`(대시보드 집계·구글폼 합류·한글키)와 완전 별개.** 빌려쓰면 키·시트 어긋나 깨짐.

🚨 **GM '전체 공개'(2026-06-22 문의목록 → 2026-06-25 달력·멤버십 회원현황까지 확대)**: 공개 github.io에 고객 실명·전화 노출 + 무인증 수정·삭제. 2026-06-25 추가로 member_calendar(name/phone)·member_active_list(전화 풀)·member_inquiry_list(`_miFull=true` 강제) 모두 마스킹 해제. GM 위험 명시 수용. 되돌리려면 _miReadRows_/member_calendar/member_active_list 마스킹 복원 + member_inquiry_list `_miFull=_piiFull_(body.key)`. 접근통제(로그인 게이트)=시토 인증게이트 권장 후속. [[feedback_security_live_activation_needs_gm_go]] [[project_pii_gate_aggregates_public_no_key_ux]]

함정: ① **미연동 판별 = `GAS_URL === GAS_PLACEHOLDER`**(`'__PASTE_GAS_EXEC_URL__'` 센티넬). 과거 가드가 **연동된 실제 URL과 비교**해 항상 참→가짜 '미연동'(데이터 로드 안 됨) 버그였음(2026-06-23 수정). 절대 센티넬을 실제 URL로 두지 말 것. ② **curl로 /exec POST는 리다이렉트에서 411/405 뜨지만 서버 쓰기는 실제 실행됨** — 결과는 list 재조회로 검증(POST 응답 코드 신뢰 금지). GET 쿼리는 doGet이 body로 병합(`params` 변수 없음 — body.* 만 사용). ③ 재배포=clasp 자동(`clasp push -f && clasp deploy --deploymentId …A -d`, AI 직접). 라이브검증=시크릿 크롬+NFC URL. 관련: [[project_funnel_stage_pages]] [[reference_inquiry_funnel_map]] [[member_db_sheet]] [[reference_funnel_gas_script_id]] [[project_self_hosted_inquiry_db_goal]]
