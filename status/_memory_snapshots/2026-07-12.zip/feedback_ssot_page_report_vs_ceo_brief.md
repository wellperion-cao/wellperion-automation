---
name: feedback_ssot_page_report_vs_ceo_brief
description: "SSOT 페이지 '보고 체계' 기술 시 페이지 자체(라이브 대시보드)와 CEO 08:00 통합보고(GM 단독)를 층위 분리 — 08:00을 헤드라인에 올리지 말 것"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 46ae87e4-1531-4d0d-b840-0561c56ba9a0
---

C-Level SSOT 페이지(예: S3 업무·결재 현황)의 "보고 체계" 섹션을 쓸 때, 두 층위를 섞지 말 것.

- **페이지 자체 = 보고서** — KPI 스트립·실시간 피드(최근 변동·마감 임박·결재 대기)가 헤드라인. "열면 바로 파악"이 핵심.
- **CEO 08:00 통합보고** = 하류 소비처. `ceo_morning_pipeline.py`가 `todo_list` 호출해 이 SSOT 데이터를 끌어가지만, 그건 CEO 파이프라인 산출물이지 그 페이지의 기능이 아니다. 게다가 **텔레그램은 현재 김남욱 GM 단독 1:1 수신** — "통합 보고"를 헤드라인에 올리면 팀 전체가 받는 것처럼 오독됨.

**Why:** 2026-06-06 GM이 "텔레그램은 GM 단독인데 보고 체계에 매일 08:00 통합보고가 헤드라인으로 맞나?"라고 지적. 층위 혼선이 맞았음.
**How to apply:** 08:00은 맨 아래 "(연계) … CEO 08:00 통합보고에 자동 요약 — 현재 텔레그램 GM 단독 수신" 각주로만. 헤드라인은 페이지 라이브 대시보드. 다른 C-Level SSOT 페이지에도 동일 적용. 관련 [[feedback_telegram_approval_channel]] · [[project_principles_s2_single_source]].
