---
name: project_differential_audit_autonomy
description: "자율 개선은 '차등 점검'—안정 페이지 제외, 신규·변경분만. 토큰 절감+자율화 한 틀"
metadata: 
  node_type: memory
  type: project
  originSessionId: 4f884a23-0e5e-48ab-b2ac-4bf94ba9f88f
---

**자율화 구조 = 「차등 점검(Differential Audit)」 (2026-07-03 GM 확정·박제).** 자율 개선은 매번 전 페이지가 아니라 **'마지막 점검 이후 새로 생기거나 바뀐 것만' 본다.** 대상을 좁히는 게 곧 토큰 절감이자 지속가능한 자율화. 배237 GM 보좌 자율화의 ③층(실행 규모·비용 게이트) = 비어 있던 층을 채운 것.

**Why:** 2026-07-03 자율 개선 4척 동시 딥점검 = 약 66만 토큰. 원인 = 안정 페이지까지 매번 통째로 읽음. 자율화에 '무엇·누가·보고'(배237)는 있었으나 '얼마나 크게·비용 얼마나'가 빠져 있었다. GM 통찰 = "안정 페이지 제외, 새로 만드는 페이지만 전수."

**How to apply:**
- **대상:** 안정 대장(`status/audit_registry.json`)에 없으면 신규→딥점검 / 등록 이후 변경분→좁은점검 / 등록+무변경→**제외(다시 통째로 안 읽음)**. 산출은 git 대조 스크립트가 자동.
- **규모·모델:** 좁혀진 대상을 1~2척·Sonnet·Explore 선훑기. 딥 전수는 **신규 페이지에만**. 오늘식 전 페이지 동시 딥점검 폐기.
- **안정 등록:** 웰리 검수 통과(또는 GM 확인) 시 `{path, audited_commit=HEAD}` 기록. 베이스라인=2026-07-03 현재 가이드 html 전부 stable@HEAD 시드.
- **게이트(기존):** 가역=자율 / 비가역=제안 · 금지5종 · 담당 실행→웰리 검증→G1. 세션 토큰 상한 초과 시 GM 확인.
- **박제 위치:** 스펙 `.omc/specs/differential-audit-autonomy.md` · 코드 registry+스크립트(진짜 강제) · 헌법한장.html+ssot/CONSTITUTION.md · 본 메모리 · 배237 스펙 ③층.

관련 [[feedback_scope_and_model_discipline]]·[[project_gm_aide_autonomy]]·[[feedback_autonomy_standing_mandate]]·[[feedback_delegate_mechanical_work_clean_screen]].
