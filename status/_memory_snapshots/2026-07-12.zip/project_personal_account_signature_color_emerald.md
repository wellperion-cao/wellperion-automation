---
name: project_personal_account_signature_color_emerald
description: 개인계정 @namuk.wellperion 시그니처 색 = 에메랄드 그린 (GM 확정 2026-07-04)
metadata: 
  node_type: memory
  type: project
  originSessionId: ee9f575c-c22c-4e37-84c3-5266660a896c
---

개인계정 **@namuk.wellperion**(GM의 AI/운영 스토리텔링 계정)의 **시그니처 색 = 에메랄드 그린**. GM 확정("개인 계정 색상은 에메랄드색 너무 좋아", 2026-07-04). AI 벤치마크 시안의 딥그린 액센트에서 확정됨 — 라이트 `#2E6E5B` / 다크 `#63BBA0` 계열.

**How to apply:** 개인계정용 비주얼(IG 시리즈 슬라이드, 한달 캘린더 시안, 제안 아트, 릴스)은 에메랄드 그린을 시그니처 액센트로 통일. 따뜻한 종이·먹빛 텍스트와 페어링(회복·성장 톤).
- 회사계정 **@wellperion**은 별도 브랜드(프리미엄 라이프스타일 클럽·풀로고) — 개인계정 색과 구분. [[project_account_logo_distinction]]
- 제안은 디자인 시안으로 [[feedback_gm_prefers_designed_artifact_proposals]].
