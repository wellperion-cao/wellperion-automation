---
name: 인스타 메인 페이지 영구 템플릿 v1.0
description: 모든 콘텐츠 인스타 1p가 따르는 영구 디자인 템플릿. 65/35 분할·W로고·사업부 컬러칩·영문대제목·한글부제목·일자장소·풋터.
type: project
originSessionId: 2138dc54-da18-4989-81b9-abb9133339d9
---
모든 향후 인스타그램 메인 페이지(1p)는 본 템플릿을 영구 적용. 사업부 컬러만 교체, 그 외 구조·폰트·색·레이아웃 동일.

**Why:** 2026-05-06 GM님 직접 큐레이션 가이드(`260426_큐레이션_추천.md`)에서 "이번 1회로 끝이 아니라 모든 향후 인스타그램 메인 페이지가 따라야 할 템플릿"으로 명시. 브랜드 일관성 = 콘텐츠 인지도의 누적 자산.

**How to apply:**

## 레이아웃 (1080×1350 기준)

```
사진 영역 (상단 65%)
- 상단 좌측: W 로고 (Pretendard Bold, 사업부 primary 컬러, 어두운 반투명 박스 배경)
- 상단 우측: 사업부 컬러 칩 (사업부 primary 배경 + 흰색 사업부명 텍스트)

정보 영역 (하단 35%, 캔버스 #221F20)
- 베이지 가는 분리선 (사업부 primary)
- 영문 대제목 UPPERCASE (Pretendard Bold, 자간 +0.08em, 흰색)
- 한글 부제목 (Pretendard SemiBold, 사업부 primary)
- 일자·장소 (Pretendard Medium, 회색 #C8C8C8)
- 풋터 WELLPERION 워드마크 (중앙 정렬, 사업부 primary)
```

## 색상 (영구 고정)
- 캔버스 배경: `#221F20` (메인 BLACK)
- W 로고·풋터·한글 부제목·분리선·컬러 칩 배경: 사업부 brand.primary
- 영문 대제목: 흰색 #FFFFFF
- 일자·장소: 회색 #C8C8C8
- 컬러 칩 텍스트: 흰색

## 사업부 매핑
- 메인 콘텐츠 → `main` (Beige & Black)
- 주니어/대회/SPORTS CLUB 행사 → `sports_club` (Blue & Navy)
- 종목 콘텐츠 → 종목별 (squash/pt/golf/swimming/pilates/gymnastic)

## 함수
- `slide_compositor.compose_main_slide(base_image, title_eng, title_kor, date_location, output, aspect, brand_key)`
- 스토리 슬라이드(2p~)는 `compose_slide(layout="bottom")` 그대로 사용

## 영구 표준 의무
- 본 템플릿 위반 = 브랜드 일관성 훼손, 즉시 재합성 + 사고 등록
- 변경 필요 시 GM님 직접 결재 후 patch + 버전 +0.1
