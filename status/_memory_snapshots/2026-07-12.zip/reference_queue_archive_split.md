---
name: reference_queue_archive_split
description: "_queue.json은 활성 배만(~28건), DONE/terminal은 _queue_archive.json으로 분리됨 — '큐 급감=손실' 오판 금지"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 4d3c70c1-d7af-4890-b593-97e6bc487660
---

`status/_queue.json` = **활성 배만**(PENDING·IN_PROGRESS + 최근 DONE 소수, 2026-06-24 기준 ~28건). DONE·terminal 배는 `status/_queue_archive.json`(~359건)으로 이관된다. 둘 다 발행미러 `3. 웰페리온 가이드/status/`에 동기화.

**Why:** 시우 정리로 누적 DONE을 아카이브 분리. 활성 큐가 383→28로 보이면 손실로 오판하기 쉽지만, 활성+아카이브 합이 ~387이면 정상.

**How to apply:** 큐 편집 전 `len(active)>=380` 류 가정 금지. 본인 활성 배(PENDING·IN_PROGRESS)만 활성 파일에서 찾고, 없으면 아카이브 확인. queue-guard '93% 급감' 경고도 아카이브 직후엔 FP — 활성+아카이브 합으로 검증. 관련 [[project_g1_done_today_past_search]], INC-007.
