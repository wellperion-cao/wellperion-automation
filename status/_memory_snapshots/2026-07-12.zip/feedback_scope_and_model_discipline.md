---
name: feedback_scope_and_model_discipline
description: GM이 지목한 범위만 처리 + 단순 작업엔 가벼운 모델. 옆 파일 확산·Opus 남용 금지
metadata: 
  node_type: memory
  type: feedback
  originSessionId: a30c5b74-7d5e-4381-9ed8-d08b6dd748bc
---

GM이 "지원부 체계 수정"만 물었는데 웰리가 4개 부서(지원·운영·시설·주차) 전체를 Opus executor로 9분 돌려 ~$10.26 발생 → GM이 비용 지적(2026-06-09).

**Why:** 한 페이지 진단·소규모 수정이 4천 줄 파일을 Opus가 여러 번 읽는 대형 작업으로 번짐. GM은 토큰 방어를 CLAUDE.md에 강하게 박아둠.

**How to apply:**
- GM이 짚은 **딱 그 범위만** 처리. 같은 버그라도 옆 파일(sibling)까지 확산할 땐 **먼저 여쭌다**("지원부만 할까요, 4부서 같이 할까요?"). 자동 확장 금지.
- 단순 진단·소규모 수정 = 가벼운 모델(Haiku/Sonnet executor 또는 직접). Opus executor는 판단·복잡·로드베어링 건만.
- 4천 줄+ 대형 파일은 grep으로 핀포인트, 전체 재독 금지.

[[feedback_update_existing_not_add_new]] [[feedback_report_final_value_decision_support]] (토큰 라우팅 매트릭스 = S2 g10 공통탭⑨)
