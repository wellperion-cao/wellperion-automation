---
name: feedback_gm_prefers_designed_artifact_proposals
description: "GM은 콘텐츠·아이디어 제안을 텍스트/문서 말고 '디자인된 비주얼 시안'으로 보여주는 방식을 매우 선호"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: ee9f575c-c22c-4e37-84c3-5266660a896c
---

GM은 콘텐츠·컨셉 제안을 **문서식 텍스트가 아니라 디자인까지 마친 비주얼 시안(Artifact 등)**으로 보여주는 방식을 매우 좋아한다("제안방식은 너무 마음에 든다", 2026-07-04).

**Why:** GM은 비개발자·감각형 — 추상 설명보다 '와닿게' 눈으로 보고 반응한다. 디자인된 실물이 있으면 톤·방향 판단이 빠르고, 텍스트 왕복보다 재작업이 준다.

**How to apply:** 콘텐츠 아크·컨셉·카피 방향을 제안할 땐 마크다운 표 나열 말고 Artifact로 **디자인 시안**을 만들어 보여준다(쉬운 말·라이트/다크·반응형). [[feedback_offer_numbered_options]](클릭 카드 선호)와 짝 — 결정은 카드, 컨셉은 디자인 시안.
★콘텐츠 눈높이 함정: '얻는 이득'을 추상적으로 쓰면 **안 해본 사람은 못 알아듣는다**. 누구나 아는 **구체적 순간**('이럴 때 있죠? → 이렇게')으로 써야 입문자에게 와닿는다(2026-07-04 GM 지적). [[feedback_ai_series_cs_storytelling_won]] 초등눈높이 원칙의 연장.
