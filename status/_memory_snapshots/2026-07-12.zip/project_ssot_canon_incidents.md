---
name: project_ssot_canon_incidents
description: "진실 단일화 헌법 + 재발방지 로그 캐논 = /ssot/ (CONSTITUTION.md + incidents.json). 사고는 OPEN→GUARDED, 문서로 안 닫음"
metadata: 
  node_type: memory
  type: project
  originSessionId: 3cb6e0c0-3b7e-4d9a-b0a1-af5f6bb90ba6
---

GM 2026-06-15 지시로 신설한 **진실 단일화·재발방지 구조**의 캐논 = `ssot/` 폴더.

- **`ssot/CONSTITUTION.md`** = 웰리 헌법: 불변원리3(①한진실 한곳·복사금지 ②결정·교훈은 일하는 코드/설정에 박고 그 자리서 가동확인 ③검증은 결과물에서 웰리가) + 구조0(사람·AI·기계가 같은 한 원천 보는지 정합 게이트) + 구조1(ERP=/ssot/*.json 직독, 웹은 렌더·수기금지) + 구조2(incidents 로그) + **GM 정합성 가드**(GM 지시도 SSOT와 어긋나면 침묵복종 금지, 1줄 대조+대안+판단요청. 의식적 override는 incidents에 기록).
- **`ssot/incidents.json`** = 재발방지 로그. 필드 고정(id·date·증상·본질·뿌리분류[복사/문서박제/검증멈춤/정합어긋남]·차단조치·상태[OPEN/GUARDED]·검증증거). **'문서에 적었다'로 닫지 않는다 — 차단조치를 실제 재현검증해야 GUARDED.** 같은 본질 2회+ = 구조로 안 막음 = 자동 에스컬레이션.

**구축된 도구(2026-06-15 전부 라이브):** `ssot/canon_values.json`(캐논값 8종 레지스트리) · `ssot/divergence_scan.py`(하드코딩 복사본 탐지·allow_globs로 FP통제) · `ssot/canon.py`(헬퍼 get) · `ssot/publish_verify_pending.py`(발행검증 적체 가시화=INC-003 가드) · **`ssot/dashboard.html`(GM이 보는 사람용 화면 — 라이브 https://wellperion-cao.github.io/wellperion-automation/ssot/dashboard.html , /ssot json 실시간 fetch 렌더, pages.yml에 ssot/** 빌드 추가).**

**incidents 현황(2026-06-15):** INC-001(IG producer 단일출처)·INC-003(발행검증 가시화)·INC-004(텔레그램 chat_id env 직독)·INC-005(문의URL canon 직독)=**GUARDED** / **INC-002(PC종료 −1h, [[reference_pc_auto_shutdown_2330]])=OPEN — 오늘밤 oplog 실측 후 근본가드.** '복사' 뿌리분류는 전사 청소 완료.

⚠️ **남은 후속:** ① INC-002 근본가드(내일 아침) ② 구조1(ERP 전체 → /ssot 직독 이관, 대형·라이브·GM게이트) ③ v2 브랜드 금지어 위반탐지 가드(피트니스·현대하이페리온 — '복사' 아닌 '위반'). 박제 우선순위 = 코드>훅>SSOT>헌법>메모리([[project_principles_s2_single_source]] S2와 충돌 아님 — S2=원칙, /ssot=데이터·집행).
