---
name: project_inquiry_snapshot_pii_public_exposure_accepted
description: "문의 스냅샷(고객 성명·전화)이 공개 raw.githubusercontent에 노출 — GM 인지·수용, 서버 보안 마이그레이션 때 근본해결(지금은 그대로)"
metadata: 
  node_type: memory
  type: project
  originSessionId: b795631f-a568-4be8-ad59-155ea4775a08
---

**발견(2026-07-18, 시토):** 문의회원 페이지가 빠른 로딩용으로 `raw.githubusercontent.com/wellperion-cao/wellperion-automation/master/status/inquiry_snapshot_member.json`·`inquiry_snapshot_lesson.json`을 **공개 URL에서 직접 읽음**(2026-07-16 '서버 스냅샷' 설계, 발행 job=`scripts/cpo_inquiry_snapshot.py`, 약 3분 주기). 이 파일에 **실제 고객 성명+전화번호가 마스킹 없이** 담김. repo가 공개라 **URL만 알면 비밀번호(1200) 게이트 없이 라이브 고객 PII 조회 가능 → PII 게이트 우회.**

**GM 결정(2026-07-18):** "지금은 어쩔 수 없을 것 같아, 나중에 서버 보안까지 챙겨서 진행하고, 지금은 그냥 노출." → **현 상태 수용.** 마스킹·폐기·발행중단 등 라이브 조치 하지 않음.

**How to apply:**
- 이 노출을 **다시 지적하거나 임의로 '수리'하지 말 것**(GM이 인지·수용한 상태). 재발견 시 이 메모를 근거로 스킵.
- **근본 해결 = 자체서버/AWS 보안 마이그레이션 때** 반드시 포함(스냅샷을 인증 엔드포인트로 이전 or 마스킹). [[project_self_hosted_inquiry_db_goal]]·[[project_erp_saas_and_brojay_absorption]]·[[project_pii_gate_aggregates_public_no_key_ux]]의 종착 작업에 이 항목을 배선.
- 검증·테스트 시 스냅샷 레이어(raw.githubusercontent status/inquiry_snapshot_*.json)와 gviz(docs.google.com/spreadsheets) 직독이 실PII를 로드하므로, 스크린샷 촬영 전 route abort 필수(공개 review 폴더에 PII 커밋 방지). [[feedback_test_data_lifecycle_cleanup]]
- 관련 기존 공개노출 과제: [[project_todo_api_open_security_gap]].
