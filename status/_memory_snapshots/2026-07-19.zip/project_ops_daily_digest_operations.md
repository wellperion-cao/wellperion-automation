---
name: project_ops_daily_digest_operations
description: "★운영부 아침 = 종합 운영 다이제스트(대화+운영현황 체크·리마인드), KPI카드 폐기"
metadata: 
  node_type: memory
  type: project
  originSessionId: 3840ce49-bb96-4930-befc-e78bfcf1093e
---

GM 2026-07-14 결정. ★운영부 카톡방 아침 자동 요약 = **종합 운영 다이제스트** (엔진 `scripts/ops_daily_digest.py`, 두뇌=claude CLI/model_router).

**KPI 요약카드(`scripts/kakao_summary_card.py` — 매출·전환·점검·주차 타일)는 ★운영부용 폐기.** 사유: 09:30 매출보고와 소스·내용 중복 = "허접". (카드 자체는 09:33 1회 발송된 이력 있음.)

**다이제스트 최종 구성(2026-07-14 GM 확정·발효):** 순서 = 🌅헤더 → 👤어제 방 대화(LLM·사람별) → ⚠️오늘 챙길 것 → 🗂️업무(실무진 업무현황=SSOT_API_URL `action=todo_list`·_queue 아님 + 📌인사평가 반영 푸시) → 📩문의·등록·예약(FUNNEL inquiry_list/member_registered_list + 예약 합침) → 📣종합접수(VOC_EXEC_URL reg_list 6종·미해결 경과일순: 🔴계속챙길것 2주이내 / ⏸️대기·보류 2주+ 자동이관·유형아이콘 🗣️컴플레인🔑분실물🔧시설고장🧹청결) → 💪격려(★항상·매일 필수). **🏢점검 제외**(23시 밤 점검공유 cto-kakao-check-share가 담당). **강습 예약 삭제**(GM). **카톡=색·굵기 불가→텍스트+맥락이모지**(종목🏊⛳🧘·장비💳📱🖨️🔑·상황💸🚫📅, 핵심 항목에만 절반이하·남발금지). 발송=send_ops_digest.py(킬스위치 status/ops_digest_send.json·sent 마킹). 라이브 발효 완료(07:30 예약·고지문·가이드 발송 완료). 월간운영계획 참고. 최종 커밋 39b97dcf.

**철칙:** 데이터 정확성 최우선 — 소스에서 검증된 값만, 없으면 "측정 불가" 정직 표기, 숫자 추측 금지. PII(대화·요약·원장)는 gitignore된 `1. AI학습자료_아카이브/11_카카오톡/★운영부/`에만 저장·커밋 안 함. 최종본=`_pending_digest.json`(sent:false).

**내보내기(어제 대화 txt 다운) — 무인 완성(2026-07-14, `scripts/kakao_export_chat.py`, 커밋 30bc0454):** 카톡 '대화 내보내기'=**Ctrl+S 단축키가 먹는다**(아침에 안 됐던 건 창 포커스가 틀렸던 것·이 버전은 바인딩됨). GM 데스크톱은 창이 많이 겹쳐 전역 hotkey/좌표클릭이 위 창에 먹히므로 **핵심 = [[reference_kakao_report_sender]]의 `focus_window`(pywinauto)로 방 창 전면화 후 `room.type_keys('^s')`를 창에 직접 꽂기.** 그 뒤 '다른 이름으로 저장'(#32770)에 전체경로 set_edit_text→저장→덮어쓰기'예'. 성공레시피=ensure_kakao_foreground→open_room_via_search→focus_window→type_keys('^s')→저장다이얼로그 드라이브. e2e 실측 성공. **발송=★운영부 방, 라이브 발효=GM go + 구성원 고지문.** 배906(CTO). 관련 [[project_kakao_bot_rd_closed]]·[[reference_kakao_report_sender]].

**카톡 자동화 = 총 3종(2026-07-14 정합·자율현황 CTO카드 요약표):** ①07:30 ★운영부 종합 다이제스트(예약 `Wellperion-Ops-Morning-Digest-0730`·모듈 cto-ops-morning-digest·발송 게이트) ②09:30 3방 매출보고(`Wellperion-Kakao-Sales-Report-0930`·cto-kakao-sales-report·라이브) ③23:00 ★운영+시설+지원+주차 밤 점검 공유(`Wellperion-Kakao-CheckStatus-Share-2300`·cto-kakao-check-share·라이브). **폐기: 옛 KPI 아침카드**(kakao_summary_card, 매출보고 중복 '허접')=킬스위치 kakao_summary_card_send.json OFF + 예약 `Wellperion-Kakao-Morning-Card-0730`·구 `-0800` 삭제(재발 시 이 둘이 부활 안 했나 확인).

**별개 자동화 — 밤 23:00 점검 마감 공유(`scripts/kakao_daily_check_share.py`, GM 2026-07-09 지시):** 매일 23:00 예약작업(`Wellperion-Kakao-CheckStatus-Share-2300`)으로 시설·지원·주차 점검 현황+상세를 카톡 방에 발송. **대상 방=`★운영+시설+지원+주차`** (2026-07-14 GM이 방 이름 변경 → 옛 이름 "웰페리온 운영+시설+지원"과 불일치로 매일 '방 못 찾음' 실패하던 것 수정, 커밋 de563c0d). **무인 신뢰성:** 밤엔 카톡이 트레이로 내려가 메인창 못 찾아 실패 → `ensure_kakao_foreground()`(발송 직전 KakaoTalk.exe 재실행으로 메인창 전면화) 추가(커밋 915bd3df). 데이터·렌더는 원래 정상. 방 이름 바뀌면 또 깨지니 실패 시 여기부터 볼 것.
