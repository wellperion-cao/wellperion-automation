---
name: reference_wp_reception_inline_copy_drift
description: "WP 종합접수처(page 8434)는 reception_block.html의 base64 인라인 사본을 저장 → 리포↔WP 드리프트. 정본=리포, swap-reception-text로 외과교체"
metadata: 
  node_type: memory
  type: reference
  originSessionId: c30ef2d2-a629-4de3-ad9b-c690dd64d7de
---

WP 종합접수처 페이지(wellperion.com/ko/reception/, post_id **8434**)는 `3. 웰페리온 가이드/coo/reception/reception_block.html`의 폼 HTML을 **`[vc_raw_html]` base64 blob 인라인 사본**으로 저장한다(iframe 아님·직접 주입). → **리포 파일을 고쳐도 WP 라이브엔 안 닿음**(둘이 어긋남·SSOT 약속 L01 위반). GitHub Pages reception_block.html은 이 라이브 페이지가 안 씀.

**한 문자열만 바꿀 때(권장):** `scripts/wordpress_admin_playwright.py --mode swap-reception-text` — base64 디코드→`find` 정확히 1건일 때만 교체→재인코드(원 인코더와 동일 rawurlencode→base64)→되쓰기. 다중 가드(count==1·역치환 대조·라운드트립·raw블록 외 불변·원본 백업). 드리프트 미건드리고 라이브 그대로 외과 교체. (2026-07-15 분실물 문구 교체로 검증·swap 모드 신설)

**GM 결정(2026-07-15·웰리 추천 A안):** 정본=리포 `reception_block.html` 단일. 문안 **대량/구조 변경** 시엔 `--mode draft-reception --post-id 8434`로 전체 재주입을 표준 절차로(리포=유일 정본). B안(WP가 Pages reception_block.html 임베드=근본)은 과거 iframe 폐기 이력(로고 잘림·프리필 중계 JS)으로 **보류**. 재발방지=커밋 가드로 박기(reception_block.html 변경 감지→WP 재주입 리마인드). 관련: [[reference_wp_published_page_edit_goes_live_immediately]]·[[reference_wp_inquiry_inject_self]]·[[reference_reception_6categories_complaint_hidden_trap]].

★비가역·외부노출: WP 발행 페이지 편집은 저장 즉시 라이브 공개 → 편집 후 반드시 시크릿 크롬 실측·문제 시 즉시 원복.
