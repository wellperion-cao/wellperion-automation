---
name: project_erp_self_improvement_loop
description: GM 전략방향(2026-07-18) — ERP를 스스로 다듬는 단일 개선 루프. ★새 보고 금지·기존 보고 정확/단순/고도화가 핵심.
metadata: 
  node_type: memory
  type: project
  originSessionId: ca5d031a-83b7-43bd-bfba-3fb30c49b86a
---

GM 지시(2026-07-18): "요즘 너무 많은 것들이 늘어서 정신없다. 현재 ERP를 고도화&단순화하고, 실무진 피드백 루프 + GM 현황보고를 통해 자체 ERP가 스스로 개선됐으면."

**단일 개선 루프 5단계:** ① 실무진 각 페이지 "불편/개선" 클릭→단일 개선큐 ② 건강신호 자동수집(자율현황·module_registry 재사용) ③ 웰리 3렌즈 정리=**고도화/단순화·통합/폐기 — 줄이기 우선** ④ GM에게 현황 전달 ⑤ 가역=C레벨 자율실행·비가역만 GM게이트→자율현황 기록→반복.

**★핵심 제약(GM 확정):**
- **시작점 = 단순화·정리부터** (지금 늘어난 sprawl 즉시 감축). GM 답변: "단순화·정리부터".
- **④는 새 보고 추가 아님.** GM: "지금 받는 보고들만으로도 벅차. 추가 현황보고는 힘들고, **전체 현황 보고의 정확성 + 단순화·고도화**를 희망." → 루프의 산출은 **기존 보고 채널을 정확·단순·고도화**로 흘려보낸다. 새 리포트 신설 금지.
- 따라서 **단순화 1번 타겟 = GM이 현재 받는 보고·알림 자체**(카톡 3종·텔레그램 다방·08:00 브리핑·module_reporter·digest 등). 중복·부정확·과잉을 통합. 연결 [[project_notification_consolidation_pending]](카톡3종+텔레그램 통합정리 재개대기).

**진행:** 첫 단계=GM이 실제 받는 모든 반복 보고/알림 인벤토리 지도화(정확성 확보) → 통합·정확화·고도화 제안(디자인 한장). 신규 기계 최소·기존(자율현황·module_registry·VOC intake·3렌즈·GM보좌 러너) 재활용. 관련 [[feedback_always_structure_simplify_advance]] · [[feedback_gm_reports_short_scannable]] · [[project_gm_aide_autonomy]].

**1단계 정리 실행 완료(2026-07-18, #1348):** repo 위생 sprawl 20건 정리(13삭제 mangled-path 쓰레기·빈스텁·_test중복 / 7이동 백업·일회성스크립트·급여복사본→_archive, 테스트→tests/). 승인화면(Artifact)→GM 11건 전원승인→executor caller-grep 후 안전분만. ★재발방지=이번에 **live 판명나 보존한 것**(다음 정리 재시도 금지): `status/_queue_archive.json`(queue-archive-split 10+콜러)·`status/allhands_archive.json`(전사회의.html:554 raw URL fetch)·`status/_archive.json`(ceo_morning_pipeline·post_action 등 10+)·`scripts/ig_engagement_poc.py`(ops/start_engagement_collect.bat 09:30 스케줄 라이브·이름만 poc). `status/{cfo,chro,coo}.json`=clevel_post_action 쓰기+daily_scheduler·kpi_collector 읽기 라이브(=_queue.json SSOT의 보조미러, 삭제금지). ★"live caller 발견 시 skip+정직보고" 원칙이 실제 4건 걸러냄(약속대로 기능무손실).
