---
name: feedback_default_proceed_ambiguous_deepinterview
description: "GM 운영방식 — 대기 말고 바로 진행, 모호하면 deep-interview로 해소 후 진행"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 7e5f0ab9-c8dc-47f6-8f01-6f4073ef15d1
---

GM은 배정·추천받은 일을 "진행할까요?" 묻고 대기하지 말고 **바로 착수**하기를 원한다. 승인 게이트가 필요한 비가역(발행·삭제·외부전송·결제·보안 발효)만 예외. 그 외 가역 작업은 즉시 진행.

**모호할 때의 해소책 = `/deep-interview`.** 요구가 불명확하면 GM에게 열린 질문을 던지지 말고 deep-interview 스킬로 모호도를 게이트(<5%)까지 좁힌 뒤 실행한다.

**Why:** GM 개입 최소화가 목표. 명확한 일은 바로, 불명확한 일은 구조화된 인터뷰로 스스로 명확화.

증분·후속 단계로 **이어가는 것도 "계속 이어갈까요?" 묻지 말 것** — 한 배 안의 다음 증분은 자동으로 진행(GM 2026-07-14 "이어서 가는건 안물어봐도될듯").

**How to apply:** 배정받으면 (1)가역·명확 → 바로 실행 (2)모호 → deep-interview로 스펙 확정 후 실행 (3)비가역 발효만 GM go. 완료 후 다음 증분은 묻지 말고 바로 착수. [[feedback_autonomy_standing_mandate]] [[feedback_no_deferral_handle_now]] [[project_gm_aide_autonomy]] 확장.
