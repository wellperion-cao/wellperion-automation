---
name: feedback_keep_personal_life_telegram_slots
description: GM 개인 생활 텔레그램 슬롯(06/18/22시)은 의도된 것 — 알림 정리·단순화 때 청소 대상 아님
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b795631f-a568-4be8-ad59-155ea4775a08
---

GM은 하루 개인 알림 중 **06시(아침문구·운동체크)·18시(퇴근인사)·22시(취침안내)** 슬롯을 **의도적으로 유지**한다. 2026-07-18 ERP 알림 단순화 인터뷰에서 명시: "개인 것은 남겨놔줘, 웰리한테도 얘기했던 거야, 나중에 활용할거야, 일만 하는 삶은 싫어."

**Why:** 저정보 정형문구·명언이라 기계적으로 보면 '노이즈'로 잘리기 쉽지만, GM의 삶·루틴 균형을 위한 의도된 장치다. 업무 자동화가 삶을 잠식하지 않게 하려는 GM의 가치 — 나중에 개인 활용 계획도 있음.

**How to apply:** 알림·스케줄러(daily_scheduler.py) 정리·단순화 시 개인 슬롯(personal 06/18/22시)은 **건드리지 말 것**. 통합·축소 대상은 오직 '업무 실정보'(점검·매출·현황 등)의 **중복 발송**이다. 서브에이전트에 청소를 위임할 때도 이 예외를 명시 지시. [[project_notification_consolidation_pending]]
