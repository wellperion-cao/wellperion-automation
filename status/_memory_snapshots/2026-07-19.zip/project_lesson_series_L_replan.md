---
name: project-lesson-series-l-replan
description: 성인 강습 L 시리즈(6편) — 2026-07-14 재기획 예정. 사진 자산 부족이 걸림돌
metadata: 
  node_type: memory
  type: project
  originSessionId: a1296668-1ca2-4a88-bea0-a6119c0f6452
---

**성인 강습 'L 시리즈'** (F1~F3 시설편 다음 공식 콘텐츠). 유소년(방학특강) 다음 = 성인 강습.

**구성(2026-07-13 GM 확정):** 전 6편, 3+3 배치.
- 배치1 = 수영 · P.T · 골프 / 배치2 = 필라테스 · 스쿼시 · 그룹수업(명상+발레+바레)
- **A안 하이브리드**: 표지=종이·손글씨+빨강 손그림 동그라미(잔잔) / 본문=사진+굵은글씨.
- 톤 = [[feedback_content_tone_gentle_inform_not_sell]] (압박 없이 알리는 정도·천천히 루틴·전문성 은근히·개인+공식 항상). GM 레퍼런스=IG real_man_mindset의 '종이·손글씨 표지' 느낌만(내용은 반대라 안 씀).

**보류 사유(2026-07-13 GM 반려):** 수영편 시안 4장(표지+본문3)까지 제작·아티팩트(claude.ai/code/artifact/d5eb2857)로 보여줬으나 GM "사진 한 장 가지고 이건 너무 아니다" → **본문 사진 자산 부족이 근본 문제.** 종목당 공간 사진 1장(수영장·골프장 등)뿐·코칭/동작/사람 사진 0 → 크롭만 바꿔 우려먹으면 빈약. F 시설편이 됐던 건 시설별 사진이 여럿이라서.

**내일(2026-07-14) 재기획:** GM이 **인스타그램에서 배운 디자인 스킬을 정리**해 오면 시모가 학습 후 L 시리즈 다시 기획. 열쇠 = ①종목별 실제 다양한 사진 확보(전문 촬영/회원 동작/여러 각) 또는 ②사진 의존 낮춘 디자인(타이포·일러스트·손글씨 확장). 엔진 자산: `scripts/compose_lesson_series.py`(사진형)·종이손글씨 렌더(`scratchpad/render_paper_cover.py`)·`render_hand_slides.py`(개인 손글씨). 관련 [[project_official_facility_series_unified_main_page]] · [[feedback_visual_match_one_pass_not_iterate]] · [[project_slide_engine_canva_independence]]
