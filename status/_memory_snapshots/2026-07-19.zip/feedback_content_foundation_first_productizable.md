---
name: feedback_content_foundation_first_productizable
description: "콘텐츠는 '기반'(회사소개서·전략·브랜드)에서 파생 — CMO가 기반층 구축·제품화"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f473f4b7-788a-4030-bbff-6564ce545024
---

GM 지시(2026-07-18): 콘텐츠 제작에 **기반(foundation)이 먼저** 있어야 한다.

- **기반 = 회사소개서 + 전략 + 브랜드**(톤·각·금지·두 계정). 이게 뿌리.
- **새 콘텐츠를 만들 때도 그 기반에서만 움직인다** — 기반을 벗어나면 안 됨(브랜드·전략 이탈 방지). 제작 단계가 기반에서 소재·각·톤을 자동 반영.
- **어느 업체든 비슷하게** — 회사마다 자기 기반을 넣으면 그 회사다운 콘텐츠가 나오는 구조(제품화 핵심 = 기반 교체 가능). C-Level 자율화 두뇌 제품화([[project_clevel_autonomy_brain_productization]])·배747과 직결.
- **"이 부분도 CMO가 해내야 해"** — 기반층 구축은 시모(CMO) 소관.

**Why:** 기반 없이 콘텐츠를 만들면 매번 각이 흔들리고 브랜드·전략에서 벗어남. 기반을 단일 뿌리로 두면 반무인/완전무인 자동생성도 안 벗어나고, 회사만 바꿔 끼우면 제품이 된다.
**How to apply:** 이미 있는 [[project_content_production_brief]](웰페리온_콘텐츠_제작기준_브리프.md)를 **정식 기반층으로 승격**(회사소개서·전략 통합). M1 콘텐츠 허브 시안(claude.ai/code/artifact/b0fad77a) 최상단에 '기반' 층 추가 — 기반→제작 파생. 관련 [[project_cmo_content_module_semi_unmanned]] · [[feedback_content_angle_fresh_mind_not_cliche]] · [[project_content_reference_aesthetic]].
