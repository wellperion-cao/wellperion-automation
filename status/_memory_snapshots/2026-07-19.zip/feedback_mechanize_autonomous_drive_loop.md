---
name: feedback_mechanize_autonomous_drive_loop
description: "GM은 '항로 선별→가역배 구동→검수→기록' 루프 자체를 자율화 원함 — 가역 배마다 \"할까요?\" 되묻지 말 것"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 502e688d-53c3-460b-a290-16d3251e6e43
---

GM이 2026-07-14 명시: "이런것 또한 자율화 했으면 참 좋겠네, 계속 이야기하는 것 같은데" — 웰리가 매 배치마다 "○○ 진행할까요?"로 승인을 되묻는 것을 **반복 피로**로 느낀다.

**Why:** 가역·비금지 작업을 여쭙는 것은 이미 [[feedback_autonomy_standing_mandate]]("되돌릴 일 안 여쭙고 바로") 위반인데 실행에서 반복됨. GM은 승인 게이트를 비가역에만 두길 원한다.

**How to apply:**
- 가역(dev·config·집계·검증·문서) + 비금지(금지5종=발행·배포/라이브발효·결제·보안·전략·공식값 아님) 배 = **여쭙지 말고 바로 구동→검수→기록**. GM 화면엔 결과만.
- GM 게이트는 **비가역에만**. 가역 배치 앞에서 "할까요?" 카드 금지.
- 나아가 이 루프('항로에서 가역배 선별→담당 위임 구동→웰리 실측 검수→G1 기록')를 [[project_welly_auto_runner]](현재 CTO·07:30 한정)와 [[project_gm_aide_autonomy]](배237)로 **전 C-Level 무인 자동 구동**까지 기계화 — GM이 "go"를 반복 입력할 필요가 없게.
