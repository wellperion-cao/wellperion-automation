---
name: reference-telegram-burst-send-flood
description: 텔레그램 봇에 짧은시간 다발 발신하면 429 발신제한이 길게 걸리고 재시도가 악화시킴
metadata: 
  node_type: memory
  type: reference
  originSessionId: bb3e33cc-feed-49e3-b161-c4f1fc905d8a
---

공용 업무보고봇 채널(`TELEGRAM_CHAT_ID` = 8254867551)은 하루 종일 자동보고(항로·매출·점검·완료보고 등)가 다발로 발신된다. 여기에 짧은 시간 여러 번 발신하면 `429 Too Many Requests: retry after 8`이 걸린다.

**함정:** 실패 시 즉시 재시도를 반복하면 제한이 **오히려 더 길어진다**(2026-07-15 실측: 60초 간격 15분 폴링·240초 무요청 대기·고유내용 변경 전부 소용없이 15분+ 지속). retry_after가 계속 8로 고정돼 보여도 실제 페널티는 재시도로 누적 연장됨.

**대응:** ① 발신은 넉넉한 간격(수 분)으로만 ② 실패 시 즉시 재시도 금지·완전 멈추고 대기 ③ 자동 루틴(발행당 1회 등)은 문제없음 — 이 이슈는 순전히 수동 테스트 버스트 탓 ④ 확인이 급하면 텔레그램 발신 대신 **아티팩트로 시각화**가 깔끔한 대안(발신 없이 최종본 확인 가능). 정정은 editMessageText.
