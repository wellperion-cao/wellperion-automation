---
name: project-12-slot-facility-status
description: 12시 텔레그램 슬롯 = 시설·지원 점검 현황 (주차부 독립·제외, 트렌드 브리핑 폐기)
metadata: 
  node_type: memory
  type: project
  originSessionId: 314d921a-1885-4af1-80e5-e572cc2e31a3
---

12시 자동 보고 슬롯이 "트렌드 브리핑(미구현 빈칸)"에서 "시설·지원 점검 현황"으로 교체됨.

**Why:** GM님이 12시 트렌드는 의미 없다고 판단. 실시간 운영 현황 파악이 더 유용.

**How to apply:**
- daily_scheduler.py `_build_12_body()` → `_build_checklist_block()` 이 박스표 생성.
- 데이터 소스 = 지원부·시설부 **라이브 GAS 소스** 2종 (2026-07-08 GM 확정): 지원부=`_fetch_support_today_live()` (today_live&dept=support · 완료율) · 시설부=`_fetch_facility_today()` (monthly_report 오늘행 · 입력률+이상건수). 두 지표 체계는 다름(억지 통일 안 함).
- 주차관리부는 SSOT상 독립·점검 제외 부서(weekly 구조상 전부 0) → 12시 표에서 제외.
- ⚠️ 폐기: 옛 `CHECKLIST_API_URL`(오늘 rows=0 빈 응답) · **Notion COO DB(`COO_CHECKLIST_DB_ID`)** · apps_script_v3.js 경로 — 모두 미사용. Notion은 호출 금지(CLAUDE.md §2/§3, ERP·G1 단일화).
- 발송 시 parse_mode=HTML(run_report slot=="12" 분기), 대시보드는 클릭형 앵커.
