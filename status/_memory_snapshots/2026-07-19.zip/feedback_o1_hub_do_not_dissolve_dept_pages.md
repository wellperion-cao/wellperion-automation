---
name: feedback_o1_hub_do_not_dissolve_dept_pages
description: GM 반려 — 운영부 체계 등 부서 체계 페이지를 O1 운영 통합 허브에 녹이지(흡수·임베드) 말 것
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 02815d6f-5d1e-441a-b31d-7a79b9f73bf1
---

2026-07-15 GM: O1(운영 통합 체계) 허브에서 "월간 계획보고 달력 이모지" 지적으로 시작해 → "운영부 체계 페이지를 O1에 정리(O1=운영부 집)" → "링크 말고 O1에 녹여(iframe 인라인 임베드)"까지 진행했으나, 최종적으로 **"이렇게 녹는 건 아닌 것 같아, 다 원상복구"**로 전량 되돌림.

**Why:** GM은 부서 체계 페이지(운영부·시설부·지원부·주차·리셉션)를 O1 허브 본문에 흡수/임베드하는 방향이 실사용에 맞지 않다고 판단. 링크 히어로 카드도, iframe 녹이기도 둘 다 반려. O1은 허브(링크 모음)로, 부서 체계는 각자 독립 페이지로 유지가 GM 선호.

**How to apply:** 앞으로 "부서 체계 페이지를 O1에 통합/녹이기" 방향은 다시 제안하지 말 것. O1 상단 정리·이모지 정합 같은 소소한 개선은 OK지만, 페이지 구조를 O1로 흡수하는 큰 재편은 GM이 명시적으로 다시 원할 때만. 큰 IA 재편은 착수 전 [[feedback_default_proceed_ambiguous_deepinterview]]로 시안·범위를 더 좁히고, 가역적으로(한 커밋에 몰아) 진행해 원복이 쉽게. 원복 시 동시커밋 얽힘 주의 → [[feedback_no_destructive_git_in_shared_worktree]](revert 충돌 나면 원본 blob 복원이 안전).
