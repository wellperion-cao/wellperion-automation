---
name: feedback_readability_tables_for_structured_data
description: 구조적/시간 데이터는 불릿 나열 말고 표로 렌더 · 가독성에 선제 투자하라는 GM 지적
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 1bfd6f7a-9ed5-48db-a212-9ea4652c4559
---

GM 2026-07-14: 헌법한장 매트릭스의 '하루 루틴' 칸이 flat 불릿 목록이라 읽기 힘들다며 "표 안에 표 못 만드나 / 시토는 가독성에 아예 신경 안 쓰는 것 같네"라고 지적. 시간｜내용 표로 바꾸니 만족.

**Why:** GM은 정보의 정확성만큼 **가독성(스캔성)**을 중요히 본다. 시간·단계·항목처럼 구조가 있는 데이터를 줄글/불릿으로 늘어놓으면 "신경 안 썼다"는 신호로 읽힌다.

**How to apply:**
- 구조적 데이터(시간표·단계·요일별·항목별)는 기본을 **표(시간｜내용 등)**로. 불릿 나열은 마지막 선택.
- 렌더 코드가 셀 텍스트를 이스케이프하면 HTML을 JSON에 못 넣음 → 렌더 함수에서 텍스트 토큰을 표/로고로 조립(예: scheduleTable·chanLogo in 헌법한장.html).
- ★함정: 부모 셀렉터 명시도가 높으면(`table.matrix td` = 0,1,2) 내부 표의 `.rtbl td`(0,1,1)를 덮어써 `word-break`로 시간이 세로로 쪼개짐 → `table.matrix` 접두사로 명시도를 올려야 이김. 인라인 스타일도 !important 없으면 안 먹을 수 있음.
- 만들고 끝내지 말고 **Playwright로 렌더해 스크린샷 눈으로 확인 후** 보고([[feedback_gm_prefers_designed_artifact_proposals]]·[[feedback_visual_match_one_pass_not_iterate]]). 관련: [[feedback_gm_page_completion_a3_print_readable]]·[[feedback_gm_reports_short_scannable]].
