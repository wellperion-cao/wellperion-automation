---
name: project_erp_saas_and_brojay_absorption
description: 웰페리온 ERP를 AWS 멀티테넌트 SaaS로 구축·판매 + 브로제이(회원관리) 흡수 전략
metadata: 
  node_type: memory
  type: project
  originSessionId: 9f55ba89-c1da-4331-af8a-3d8201e2e6fc
---

GM 2026-07-16 확정 방향 (배 101 흡수):
- **목표** = 우리만 쓰는 ERP가 아니라 **여러 회사가 쓰는 멀티테넌트 SaaS ERP**로 구축·판매. 웰페리온이 1호 테넌트. 3얼굴 = 직원앱 / 회사관리자 / 슈퍼관리자(우리).
- **기술** = AWS. 자체 윈도우 서버 계획(구 배101) 폐기. 개발=시토 직접(외주비 0). 확정: 직원까지 모두 로그인·핵심3모듈(회원·문의·점검)부터→전체통합·공개홈/사내ERP 분리(둘다 AWS).
- **브로제이** = 회원관리 프로그램. **현재 외부 구독 서비스**. 흡수 = 2단계: ①연동(구독 유지하며 데이터 통합) → ②나중에 **자체개발로 대체**(GM 지향·구독 해지). [[project_self_hosted_inquiry_db_goal]] · 배 21(PII)·18(문의DB) 흡수.
- 설계·견적 아티팩트 = claude.ai/code/artifact/6d60d523 (같은 링크 갱신·A3 인쇄). [[feedback_artifact_overwrite_same_link_on_upgrade]] · [[project_clevel_autonomy_brain_productization]]
- **GM 결재 대기:** Phase 0 착수(AWS계정·💰비용 시작).
