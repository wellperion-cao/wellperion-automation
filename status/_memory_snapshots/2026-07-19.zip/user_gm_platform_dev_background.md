---
name: user_gm_platform_dev_background
description: GM은 과거 플랫폼 개발을 하다 실패한 경험이 있음 — 자체개발 지향
metadata: 
  node_type: memory
  type: user
  originSessionId: 9f55ba89-c1da-4331-af8a-3d8201e2e6fc
---

GM 2026-07-16 언급: "원래 내가 플랫폼 개발을 하다가 망했었어." GM은 **플랫폼/소프트웨어 개발 배경**이 있고 과거 시도가 실패했다. 장기적으로 **자체개발**(외부 구독 탈피)을 지향한다.

**How to apply:** 플랫폼·SaaS 관련 제안 시 ① 기술 대화를 너무 낮잡지 말 것(GM은 개념 이해함) ② **실패 위험을 정직하게** 다루고 완화책을 명시(실 고객 확보·MVP·저비용·번레이트)—막연한 장밋빛 금지 ③ "이번엔 왜 다른가"를 설득력 있게. GM은 [[project_erp_saas_and_brojay_absorption]]로 재도전 중. [[feedback_no_100pct_overclaim_report_actual_progress]]
