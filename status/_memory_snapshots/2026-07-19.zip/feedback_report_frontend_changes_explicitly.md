---
name: feedback_report_frontend_changes_explicitly
description: 보고 시 백엔드 로직/데이터 변경뿐 아니라 프론트엔드(사용자·실무진·고객에게 보이는 UI) 변경도 명확히 구분해 알릴 것
metadata: 
  node_type: memory
  type: feedback
  originSessionId: c30ef2d2-a629-4de3-ad9b-c690dd64d7de
---

GM 2026-07-15: "백엔드에서만 진행하는게 아니라 프론트엔드까지 변경된 점 확실하게 알려줘야 해."

**Why:** 웰리 보고가 백엔드/로직 중심으로 서술돼, 실제로 **화면(UI)이 바뀐 점**(실무진·GM·고객에게 보이는 변화)을 GM이 놓칠 수 있다. GM은 "무엇이 보이게 바뀌었나"를 알아야 실사용·검수·안내를 판단한다.

**How to apply:** 작업 보고(L18 등)에서 변경을 **프론트엔드(보이는 UI) vs 백엔드(로직·데이터·인프라)로 명시 구분**한다. 프론트엔드 변경이 있으면 "무엇이·어디서·누구에게 보이게 바뀌는지"를 한 줄로 분명히(예: 1037-A=문의회원.html에 저장 즉시반영·큐 배지·재시도 버튼이 실무진 화면에 새로 보임). 백엔드만인 건도 "화면 변화 없음"을 명시. decide-by-seeing 원칙([[feedback_always_open_viewable_in_chrome]])과 연결 — 프론트 변경은 크롬으로 열어 보여주기. [[feedback_gm_reports_short_scannable]]·[[feedback_completion_telegram_report]]에 이 구분 추가.
