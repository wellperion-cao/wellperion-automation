---
name: reference_check_ledger_sheet_sot_9kb_ceiling
description: 점검 완료원장=시트 SoT·속성창은 캐시강등(GAS 9KB 천장). INC-014 저장유실 교훈·수리구조.
metadata: 
  node_type: memory
  type: reference
  originSessionId: ca5d031a-83b7-43bd-bfba-3fb30c49b86a
---

지원부 점검(`.deploy-check/지원팀 일일점검.js` GAS)의 완료 체크 원장(ledger) 저장 구조와 2026-07-18 근본수리 교훈.

**사고(INC-014, 2026-07-16~17):** 완료 원장을 GAS PropertiesService(속성창)에 JSON 압축 저장하던 구조(2026-06-11 "옵션A" 시트 최소화). 속성창은 **값당 9KB 하드리밋(구글 고정·상향 불가)** + 자동정리 없음 → 개별 값이 94%까지 차다 07-16 `setProperty`가 한도초과 throw. `_updateCheckLedger`·`_saveGroupSubmits`에 try/catch 부재 → `handleSave` 전체 사망 → `_writePerRoundRows`(시트 저장) 도달 못함 → **07-16·17 점검 유실(양쪽 미생성·복구 불가)**. 게다가 텔레그램 완료 알림(`notify_round`)이 서버 저장 성공과 무관하게 브라우저 계산값으로 발화 → 실패를 완료로 위장(GM이 텔레그램만 보면 다 된 줄 앎).

**수리 구조(현행·@165):**
- **시트 = 완료·이슈 단일 진실(SoT).** today_live 집계·페이지 복원을 시트에서 읽음(`_ledgerFromSheet`/`_resolveLedger`). 속성창은 **순수 성능캐시로 강등**(props-first 병합·없어도 정답 나옴·언제든 시트서 재생성). 9KB 천장이 저장·집계를 영구히 못 막음.
- **저장 fail-soft**: 속성 쓰기는 try/catch로 격리, 실패해도 시트 저장 무조건 진행. 실패 시 `{ok:false}` 반환 + 프론트 빨간 실패배너(조용한 실패 금지).
- **알림 서버-확인화**: completion 텔레그램은 서버 저장 성공 확인 후에만 발화.
- 오래된 `chk_*` 속성 30일 TTL 자동정리.

**교훈:** GAS PropertiesService에 누적 데이터 저장 금지(9KB/값·500KB 총량 천장) → 성장하는 데이터는 시트. "완료를 실증 없이 표시"는 INC-011·013·014 3회 재발 본질 — 완료·저장 상태는 항상 서버 실증 후 표시. 관련 [[reference_check_gas_korean_cell_and_pct_clamp]] · [[reference_check_completion_rate_untrustworthy_multisource]] · [[reference_facility_check_snapshot_journal]].
