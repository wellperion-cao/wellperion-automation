---
name: feedback_always_open_viewable_in_chrome
description: 볼 수 있는 산출물(링크·아티팩트·라이브페이지·렌더/샘플 이미지)은 항상 자동으로 크롬 창에 띄운다 — 여쭤보지 말고
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b368d183-91d4-401e-a773-db2c30fddffb
---

GM에게 **볼거리(링크·아티팩트 URL·라이브 페이지·렌더/샘플 이미지 PNG)를 제시할 때마다 자동으로 크롬 창에 띄운다.** "크롬창으로 열어줘"를 매번 기다리지 말 것.

**Why:** GM은 터미널/사이드패널 미리보기보다 실제 크롬 창에서 크게 보고 판단한다(decide-by-seeing). 이번 세션에 반복해서 "크롬창으로 열어줘"를 지시함 → "항상" 규칙으로 승격.

**How to apply:** 산출물 보고와 함께 `Start-Process "chrome.exe" -ArgumentList <URL 또는 파일경로들>`. 라이브 웹은 URL, 로컬 렌더/샘플은 파일 경로(여러 장이면 배열로 탭 여러 개). 라이브 검증은 시크릿(`--incognito`)이 기본이지만([[feedback_gm_verify_via_incognito_chrome]]), GM이 세션 유지 원하면 일반 창. 아티팩트/이미지 확인용은 일반 창.

관련: [[feedback_gm_decides_by_seeing_kpi_path]]·[[feedback_gm_prefers_designed_artifact_proposals]].
