---
name: feedback_publish_digest_standard_and_staff_room_quality
description: 발행 디제스트 표준(1이미지+5채널 링크 고정) · 실무진 방엔 표준·검증된 것만 발송
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f473f4b7-788a-4030-bbff-6564ce545024
---

GM 강한 피드백(2026-07-18): 발행 디제스트가 오늘 두 번(자동·정정) 다 기본 표준을 못 지켜 실무진 방에 나갔다.

**디제스트 표준 (벗어나지 말 것):**
- **기본 = 1 이미지 페이지(첫 슬라이드 sendPhoto) + 5개 채널 링크**를 **고정 순서**로 모두 표시: **인스타그램 · 네이버 블로그 · 네이버 카페 · 당근 · 카카오채널.**
- 5채널 전부 한 건에. 채널 누락·순서 흐트러짐·링크 미표시·텍스트만 발송 = 전부 표준 위반.

**실무진 방(문의·컨택·등록 알림방, chat -5516675010) 원칙:**
- 이 방엔 **실무진 전원**이 들어와 있다. **관리자(GM·AI)가 기본도 안 된 알림을 공유하면 실무진 신뢰·사기가 떨어진다.**
- 따라서 이 방엔 **표준을 100% 충족하고 검증된 것만** 보낸다. 부분 상태·조기 발송·비표준 즉흥 메시지 금지. **의심되면 방에 보내기 전 GM 미리보기 확인.**

**Why:** 실무진 대면 채널의 품질 = 회사 신뢰. 발행은 잘 돼도 알림이 엉망이면 '관리가 안 된다'는 인상.
**How to apply:** ① 디제스트 엔진 = 그룹 전 채널 발행완료 + URL 회수될 때까지 발송 보류(부분상태 발동 금지) + 표준 포맷 강제 + message_id 저장(편집 가능). ② 실무진 방 발송 전 자기검증(5채널·링크·이미지) 통과 못하면 발송 금지. 관련 [[project_cmo_publish_digest_routine]] · [[reference_telegram_burst_send_flood]] · [[feedback_live_verify_always_then_taper_with_trust]].
