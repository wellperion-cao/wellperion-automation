---
name: project-content-production-brief
description: 콘텐츠 제작 단일 기준 브리프 — 회사·전략·브랜드를 제작에 배선(기반→제작)
metadata: 
  node_type: memory
  type: project
  originSessionId: bb3e33cc-feed-49e3-b161-c4f1fc905d8a
---

콘텐츠 제작의 **단일 기준(북극성)** = `2. 브랜드_공식문서/웰페리온_콘텐츠_제작기준_브리프.md` (2026-07-15 신설·커밋 46903ef5). 8섹션: 우리는 누구(회사)·누구에게·왜(전략)·톤·각(운동↔마음)·금지어·두 계정 구분·CTA/해시태그·제작 전 체크리스트. 근거=회사소개서 v2.19·전략로드맵 v1.4·브랜드 가이드·콘텐츠 메모리(지어내기 0·소스 인용).

**배선:** 브랜드 스킬 `wellperion-brand/SKILL.md`에 **'제작 방향 정본(제작 전 필독)'**으로 물림. 스킬=HOW(비주얼·톤) / 브리프=WHAT·WHY(회사·전략·각) 짝. → 콘텐츠가 반무인으로 자동 생성돼도 이 브리프에서 안 벗어남(GM 확정 취지 실현).

**★주의:** 외부 포지셔닝='프리미엄 라이프스타일 클럽' — '하이엔드 프라이빗·사교'는 내부 표현이라 외부 콘텐츠 금지([[feedback_brand_voice_positioning]]). **확인 필요:** 전략로드맵 v1.4에서 구체 타겟 연령·수치 목표 일부 미기재 → 브리프 §2 '확인 필요' 표기, GM 확인 시 보강. 모듈 흐름=[[project_cmo_content_module_semi_unmanned]] ① 기반 층의 실제 연료.
