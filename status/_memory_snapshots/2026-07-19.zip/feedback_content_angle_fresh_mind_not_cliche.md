---
name: feedback_content_angle_fresh_mind_not_cliche
description: "콘텐츠 각(角)은 진부한 fitness/기능 클리셰 금지 — 참신하게, 운동을 마음·정신건강·현대인의 삶과 연결(따뜻한 철학적 결·접근가능)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b368d183-91d4-401e-a773-db2c30fddffb
---

콘텐츠 각을 잡을 때 **진부한 기능·효능 클리셰 금지.** "1:1 맞춤"·"실내에서 폼부터"·"전신 운동" 같은 건 어느 업장이나 하는 말 = GM이 "이게 뭐야... 다 별로" 반려.

**참신함의 열쇠 = 운동/서비스를 '마음·정신건강·현대인의 삶'과 연결.** GM이 딱 집은 예: 스쿼시="잡생각 제로"(스트레스 해소)·수영="디지털 디톡스"(알림 안 닿는 유일한 30분). 각 종목이 **"왜 이게 지금 나에게?"에 마음으로 답하는** 각 하나를 갖게. 6종목 마음 각 예: 수영=디지털디톡스 / PT=핑계가 안통하는·자기직면 / 골프=조급함·힘빼기 / 필라=몸과 화해·자기수용 / 스쿼시=잡생각제로 / 그룹=어른의 외로움.

**GM 반응 "철학적인 부분도 담겼네?" = 긍정 신호.** 운동을 팔지 않고 **"잠깐 나를 들여다보는 작은 성찰"**을 건네는 게 압박 없이 마음에 남는 힘. 단, **설교조·현학적·AI스러운 미사여구 금지** — 담담한 통찰 선까지만(접근가능·따뜻).

**Why:** 팔지 않고 알리는 톤([[feedback_content_tone_gentle_inform_not_sell]])에서 '참신함'이 곧 도달·기억의 핵심. 기능 나열은 무시당함. **How:** 각 콘텐츠 기획 시 "이걸 마음/삶의 어떤 진실과 연결하나?"를 먼저 묻고, 기능은 그 다음. 관련: [[project_content_reference_aesthetic]]·[[feedback_content_realism_drives_engagement]]·[[feedback_ai_series_cs_storytelling_won]].
