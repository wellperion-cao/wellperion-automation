---
name: reference_telegram_ig_url_link_preview_429
description: 텔레그램 sendMessage에 인스타그램 게시물 URL을 link_preview로 붙이면 429로 실패 — IG가 프리뷰 페처를 막아서. 미리보기 끄면 200 성공.
metadata: 
  node_type: memory
  type: reference
  originSessionId: d910898d-d075-4fe4-8043-344cd832106e
---

텔레그램 `sendMessage`에 **인스타그램 게시물 URL**을 `link_preview_options`(url + prefer_large_media)로 붙이면 **sendMessage 자체가 HTTP 429**로 실패한다. 원인=텔레그램이 미리보기 이미지를 IG에서 페치하려는데 **IG가 봇 프리뷰 페처를 차단** → 429가 발송 실패로 표면화. 재시도·대기·페이싱으로 안 풀린다(항상 실패).

**증상:** 같은 채팅에 미리보기 없는 짧은 메시지는 200 성공하는데, IG URL 미리보기를 단 메시지만 429. 429가 "플러드"처럼 보여 오진하기 쉬움.

**해결:** `link_preview_options={"is_disabled": true}`로 미리보기를 끄면 **즉시 200**. 시각 카드가 필요하면 IG URL 프리뷰가 아니라 **sendPhoto로 실제 이미지 파일을 첨부**한다(캡션 ≤1024자).

실사례: `scripts/publish_digest.py` 발행 다이제스트가 2026-07-15 셋업 후 한 번도 도착 못한 근본원인이 이것(항상 IG 게시물 미리보기 첨부). 2026-07-16 미리보기 비활성으로 해결. 무관한 재발방지로 [[reference_telegram_burst_send_flood]]의 전역 페이싱(배1211)도 별도 구축했으나 이 건의 원인은 아니었음.
