---
name: project_welly_auto_runner
description: 예약 Claude 러너 — 무인 자율 실행 엔진(배237 phase3)·발효 상태·안전 가드·모호 에스컬레이션
metadata: 
  node_type: memory
  type: project
  originSessionId: 0a128379-3fb9-4eef-8ea2-5140aef2bb62
---

**예약 Claude 러너(welly_auto_runner)** = "웰리가 시켜서 완료까지" 무인 자율 실행 엔진. 배237(GM 보좌 자율화) phase3. 봇이 Claude를 못 띄우던 구조 한계를 풀려고, **스케줄이 headless `claude -p` 세션을 띄워** 가역·저위험 배를 실제 실행·검증·커밋한다. 2026-07-13 GM go로 구축·발효.

- 본체 `scripts/welly_auto_runner.py` · 런처 `scripts/welly_auto_runner.bat`+`launchers/welly_auto_runner_hidden.vbs` · 등록 `ops/register_welly_auto_runner.bat`.
- 예약작업 `Wellperion-Welly-Auto-Runner-0730` (매일 07:30). 설계 정본 `docs/superpowers/specs/2026-07-13-welly-auto-runner-design.md` + `2026-07-13-welly-runner-ambiguity-escalation-design.md`.
- **안전 가드(5중)**: ①`RUNNER_LIVE` 게이트(기본 OFF·발효 시 .bat set) ②가역·저위험만(welly_orchestrate.select_autonomous_ships + 발행/배포/삭제/보안/전략/공식값/라이브GAS/시트 제외) ③`_is_concrete_ship`(origin=bridge·NEXT-*·무우선순위 포인터 배 제외) ④`working_tree_guard`(노이즈 allowlist 밖 미커밋 실작업 있으면 실행 거부=남 작업 쓸어담기 방지) ⑤재귀 폭주 방지 + 즉시 역롤백(git revert). 한 번에 1척·쿨다운.
- **모호 에스컬레이션**: `is_ambiguous`(산출물 불명확·복수접근·스코프결정·🛳️크루즈)면 실행 말고 park(`aide_interview_needed` 플래그). `--interview-worklist`로 세션에서 확인→웰리가 deep-interview(AskUserQuestion·폰 원격)로 물음→배 note에 `[GM 인터뷰 답변]` 기록+플래그 해제→다음 사이클 실행. 텔레그램 핑=별도 게이트 `RUNNER_PING_LIVE`(발효됨·GM 개인채널 chat_id 8254867551·dedup·하루 cap 2).
- **정직한 스코프**: 무인은 좁다 — 가역·저위험·비모호·클린트리만. 비가역·판단은 영원히 세션+GM 결재. 리포 워킹트리가 상시 지저분해 클린트리 가드가 자주 막음(보수적). 신뢰-테이퍼: 무결 N회 후 자율 폭 확대(GM 게이트 유지).
- 실증(2026-07-13 감독): stale 배 정직 완료(#252)·실제 콘텐츠 초안 2건 생성(#401). 단 초기 워킹트리 dirty로 남 작업 쓸어담은 사고→클린트리 가드로 근본 차단. 관련 [[project_gm_aide_autonomy]]·[[feedback_welly_delegate_not_execute]].
