---
name: project_naver_danggn_publish_fortress
description: "네이버 블로그·카페·당근 3채널 반복 발행실패 근본해결 = '자동화 요새화'(2026-07-10 GM 결정)"
metadata: 
  node_type: memory
  type: project
  originSessionId: b84aa753-7204-40c2-a4d3-6ecd1d0162ba
---

**문제(2026-07-10 GM):** 네이버 블로그 + 네이버 카페(동부이촌동) + 당근, 이 3채널이 발행 때마다 새 버그로 반복 실패(5회+). 지금까지 증상만 패치(본문소실→조립순서→태그누락→스티커중복→프로필손상)해서 안 끝남. GM 지시=근본해결.

**근본 취약점:** 셋 다 **불안정한 편집기를 브라우저로 긁는 자동화**라 태생적 fragile.
- 네이버 블로그·카페: SmartEditor를 Playwright DOM/키보드로 조작 → 네이버 봇대응(동적 클래스·caret 인터셉트·임시저장함 lazy-load 조건·태그는 발행패널에만·▍vs■ 소제목 사각지대)로 콘텐츠·UI 조금만 달라도 깨짐.
- 당근: 영속 크롬 프로필 반복 손상(STATUS_BREAKPOINT, 07-08·09·10). 프로필 삭제→재생성하면 세션은 즉시 복구되나 근본은 미해결.

**GM 결정 방향 = '자동화 요새화'(완전 무인 자동 유지 + 안전장치로 감싸기). 5기둥:**
1. **사전점검(pre-flight):** 발행 전 세션 유효·임시저장함 0건·프로필 건강 확인. 불충족 시 자동 보정 후 진행.
2. **조립 무결성 게이트:** 발행 버튼 직전 본문 텍스트 온전·이미지 N장·태그 N개·링크카드 위치 검증 **통과해야만 발행**. 실패=초안 유지+알림, **깨진 글 절대 발행 안 함**(과대 '발행완료' 금지).
3. **자가치유:** 당근 프로필 자동 재생성, stale 임시저장 자동 정리, 실패 재시도.
4. **구조 표준화:** caret을 흔드는 불안정 요소(예: 스티커) 제거·레이아웃 단순화로 break surface 축소.
5. **당근=쿠키 인증:** 영속 프로필 대신 쿠키 저장·주입(fresh context)으로 프로필 손상 반복 종결.

**이미 박은 개별 수리(요새화 이전 패치):** IG '다음'·'공유' 버튼 뷰포트밖 잘림→scroll+JS click 폴백. 블로그 `_place_caret_at_body_end`(클릭 기반, Ctrl+End 인터셉트 우회). 블로그 스티커 위치함수 ■ 소제목 인식(기존 ▍만). 블로그 해시태그=본문에 태그줄 없으면 `--tags`로 발행패널 주입(태그는 draft모드 불가·publish 전용). 이미지 glob=복사본이 post_*.jpg면 `--image-glob "post_*.jpg"` 필수.

**구현 상태 (2026-07-13, 배866):**
- **§2 무결성 게이트 = 라이브(3채널).** `scripts/publish_integrity_gate.py`(순수함수 evaluate_integrity) — 발행 직전 본문0·이미지0·이미지누락 N/M=FAIL 차단, 태그/링크=WARN. 블로그·카페 기존 0-체크 대체, 당근은 신설.
- **§1 사전점검 = 라이브(3채널).** `scripts/publish_preflight.py`(check_source_preflight) — 브라우저 런치 前 본문·이미지파일 실존·개수·태그한도·문의줄·링크 검사, FAIL시 브라우저 미실행 return6. 3채널 run_publish 상단 배선.
- **§5 쿠키인증 = 3채널 전부 라이브·활성완료.** 당근·블로그·카페 모두 **영속 프로필 아니라 storage_state 쿠키 주입**(fresh context)으로 인증. `_launch_context`가 `profiles/{채널}_state.json`(danggn/naver-blog/naver-cafe) 있으면 쿠키경로, 없으면 영속 폴백. setup(+당근 check) 성공 시 `_save_cookie_state` 자동저장. **영속 프로필은 이제 setup·migrate-cookies에서만 사용.** state파일=세션쿠키·gitignore(profiles/*) 차단(커밋 안 됨·GM PC 로컬만). 활성 경로: 당근=QR setup(기존 프로필 만료+손상), 블로그·카페=`--mode migrate-cookies`(세션 유효해 재로그인 없이 추출). 실증: 당근 check '쿠키 인증 모드' 세션유지 True EXIT0 / 블로그·카페 migrate write페이지 안착·EXIT0. 재인증 필요 시=`--mode setup`.
- **§3 자가치유 = 라이브(당근 프로필).** `_launch_persistent_with_heal` — 영속 런치 STATUS_BREAKPOINT(0x80000003) 손상 시 `danggn_corrupt_{ts}` 백업 이동+새 프로필 재시도1회. setup/migrate 배선. (수동복구 코드화: 07-13 손상본 danggn_corrupt_20260713.)
- **남은:** §4 카페 구조표준화(스티커 인터리브→끝 이동) · ①블로그 draft-검증(네이버 세션 필요) · 다음 실발행 시 [PREFLIGHT]·[GUARD] 로그로 게이트 실동작 확인.

관련: [[project_m5_channel_sync_gap]] · [[reference_4channel_publish_execution]] · [[reference_danggn_full_auto_publish]] · [[reference_danggn_profile_lock_blocks_scheduled_tasks]] · [[reference_naver_blog_cafe_publish_format_rules]] · 배826(5채널 자동발행 완결)의 근본화.
