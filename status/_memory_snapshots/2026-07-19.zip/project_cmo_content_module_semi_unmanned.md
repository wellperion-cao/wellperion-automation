---
name: project-cmo-content-module-semi-unmanned
description: AI CMO 콘텐츠 모듈 자동화 모델 — 반무인(지금)→완전무인(신뢰 후) + 제품화 프레이밍 내부전용
metadata: 
  node_type: memory
  type: project
  originSessionId: bb3e33cc-feed-49e3-b161-c4f1fc905d8a
---

GM 확정(2026-07-15) — AI CMO 콘텐츠 모듈(제작→검수→5채널 자동발행) 자동화 모델:
- **반무인 = 지금 기본**: AI 자동생성 → **사람 [승인] 1회** → 자동발행.
- **완전무인 = 신뢰 쌓인 뒤**: AI 자동생성 → **자동승인(품질 게이트만)** → 자동발행. 두 모드 차이 = 승인 게이트 하나(자동승인 스위치 기본 OFF·GM go·역롤백). 전환 기준=N회 무결 실증 후(준용 [[feedback_live_verify_always_then_taper_with_trust]]).

**정직 경계(과장 금지):** 제작(창작)=AI엔진/사람 필요(무인 가능하나 AI 없이 무에서 생성 불가) · 발행(배포)=AI 없이 스크립트 무인 · 검수=사람(반무인)/자동(완전무인). 제품 경계="고객·AI가 콘텐츠만 공급→엔진이 5채널 무인 배포".

**★제품화·'AI 없이 도는' 프레이밍은 ERP 페이지에 노출 금지 — GM·시모 내부 지식으로만.** 페이지는 파이프라인 구성·자동화에 집중. 제품화 상세=[[project_clevel_autonomy_brain_productization]]·ship747.

**M1 페이지:** 흩어진 16섹션을 일 흐름(제작→검수→발행→보고)으로 재정렬 + 참고·규칙 하단 토글. 앵커 id(m1-*)·라이브 배선 보존(기능 회귀 0). 설계 정본=docs/superpowers/specs/2026-07-15-cmo-content-module-semi-unmanned-m1-design.md.
