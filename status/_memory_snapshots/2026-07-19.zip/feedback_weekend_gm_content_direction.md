---
name: feedback_weekend_gm_content_direction
description: "개인계정(namuk) 주말 GM편 콘텐츠 방향 — 토=문제 찾고 보완, 일=오롯이 쉼(나·가족)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f473f4b7-788a-4030-bbff-6564ce545024
---

GM 지시(2026-07-18): 개인계정 @namuk.wellperion **주말 GM편**의 방향·정체성을 콘텐츠 안에 드러내라.

- **토요일편**: 첫 페이지(표지)에 **"토요일은 문제점을 찾고 보완하는 요일"** 같은 **요일 정체성 문구**를 넣어, 이 편이 왜 토요일인지(문제 발견→보완) 독자가 알게. 본문은 이번 주 실제 문제→해결(실화, 대필 금지·[GM 확인] 자리).
- **일요일편**: **정말 쉬는 것에 집중** — 오롯이 **나를 위하고, 가족을 위한 시간**을 보내는 내용. 업무·자동화 얘기보다 쉼·사람·여유. (기존 'GM의 일요일: 사람·여유·다음 항로' 결의 강화.)

**Why:** 주말편은 GM 1인칭이라 요일마다 성격이 뚜렷해야 시리즈로 읽힌다(토=일하며 고치는 사람 / 일=잘 쉬는 사람). 지난 편(토10·일11)엔 이 요일 정체성 표지 문구가 약했음.
**How to apply:** 다음주(2026-07-25~) 토·일편 제작부터 반영. 토요일 표지에 요일 정체성 한 줄 고정. 일요일은 소재를 쉼/가족/자기돌봄으로. SSOT `instagram/_실전사례_2주플랜.md` §주간 리듬 토·일 행에도 반영. 관련 [[project_namuk_operator_case_series]] · [[feedback_content_tone_gentle_inform_not_sell]].
