---
name: feedback_test_data_lifecycle_cleanup
description: 테스트 데이터는 실무진 방 알림 금지(개인봇만)+시트(DB) 저장분 삭제까지 해야 완료 — 흔적 0
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b795631f-a568-4be8-ad59-155ea4775a08
---

GM 2026-07-18 지시(2가지, 한 세트):
1. **테스트 알림은 실무진 텔레그램 방으로 보내지 말 것 — GM 개인 업무보고봇으로만.** 실무진이 테스트 문의(가짜번호·깨진 인코딩)를 계속 보면 신뢰가 떨어진다.
2. **테스트를 하면 시트(DB)에 저장했다가 삭제까지 마무리해야 한다.** 테스트 데이터가 DB에 남으면 안 됨.

**Why:** 테스트 잔재가 (a)실무진 눈에 계속 띄면 시스템 신뢰 저하 (b)DB에 쌓이면 실데이터 오염·문의수/전환 집계 왜곡.

**How to apply:** 테스트 사이클 = **저장 → 검증 → 삭제(정리)**까지가 한 세트(끝나고 그 행 삭제). E2E든 수동이든 시트에 행을 쓰면 반드시 정리. 테스트 판별 마커=가짜번호 `010-0000-`·`[자동검증]`·`테스트`·`E2E`·깨진 인코딩(U+FFFD). 자체폼 알림 라우팅은 `.deploy-funnel/Survey.js`(_iIsTest)에서 테스트면 개인봇으로. 삭제는 안전하게(IMPORTRANGE 정렬 안 깨지게 — `cpo_lesson_test_delete` 액션 등, 행삭제 주의 [[reference_lesson_main_importrange_source_no_rowdelete]]). 자체폼 테스트=`?gas=head` 경로로(운영 시트 오염 회피).
