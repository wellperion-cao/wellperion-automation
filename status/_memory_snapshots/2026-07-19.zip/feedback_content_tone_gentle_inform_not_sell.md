---
name: feedback_content_tone_gentle_inform_not_sell
description: "콘텐츠 톤 = 압박 없이 '알리는 정도'·천천히 루틴 만들기 (개인·공식 둘 다·항상)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: a1296668-1ca2-4a88-bea0-a6119c0f6452
---

GM 지시(2026-07-13). 모든 콘텐츠(개인 @namuk.wellperion + 공식 @wellperion) 톤:
- **대놓고 마케팅 금지.** "지금 등록!"·강한 후킹·세일즈 압박 X.
- 강습·서비스 안내는 **"한남동에 성인을 위한 전문성 있는 강습하는 곳이 있다" 정도로 알리는 선까지만.** 압박 0.
- 내용은 **'천천히 루틴을 만드는'** 방향(서두르지 않게·꾸준함).
- 전문성은 **은근히** 강조(과시 아님).
- **항상** 적용 — 개인·공식 두 계정 공통. 느낌(무드)도 동일 톤으로 통일.

**Why:** 하이엔드 프라이빗 스포츠클럽 격 — 세일즈 압박은 브랜드 톤을 떨어뜨린다. 정보 전달·신뢰가 즉각 전환보다 우선(초반 신뢰 최우선 기조와 일치).

**How to apply:** 부제·CTA·캡션을 부드럽게. "혼자 안 되던 게…" 류 세일즈 후킹도 '루틴·배움·꾸준함' 서사로 완화. 강습 안내는 편의 정보처럼 얹기. 관련 [[feedback_brand_voice_positioning]] · [[feedback_cta_standard_bilingual]] · [[project_namuk_operator_case_series]] · [[project_official_facility_series_unified_main_page]]
