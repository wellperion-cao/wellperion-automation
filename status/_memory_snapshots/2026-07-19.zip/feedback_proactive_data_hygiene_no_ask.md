---
name: feedback_proactive_data_hygiene_no_ask
description: GM — 데이터 이상(쓰레기행·불일치·인코딩손상·레거시)은 발견 즉시 여쭙지 말고 깔끔히 정리
metadata: 
  node_type: memory
  type: feedback
  originSessionId: e704ee2f-bc3f-4b52-86f1-67c6521366ec
---

GM 지시(2026-07-15): "항상 깔끔하게 정리해줘 잘못되거나 문제있는 부분은?" — 시트·데이터에서 **쓰레기 행(배포검증 더미·2020 기본날짜)·인코딩 손상(모지바케 U+FFFD)·형식 불일치(레거시 포맷)·중복**을 발견하면 **여쭙지 말고 바로 정리**한다.

**Why:** GM은 데이터 위생을 상시 자율로 원함(2020 더미 vs 실데이터 구분해 여쭙던 것도 "그냥 깔끔히"로 답). [[feedback_no_deferral_handle_now]]·[[project_differential_audit_autonomy]]·[[feedback_cleanup_merge_relocate_delete]] 연장.

**How to apply:**
- **명백한 쓰레기**(테스트 더미·2020/1970 기본날짜·인코딩 손상·빈행) = 즉시 삭제.
- **실데이터인데 형식 레거시**(예: 점검일지_facility 회차통합 2026-07-08 이전 오픈+1일 다중행) = **삭제(유실) 말고 표준 형식으로 병합·정규화**(합산·재계산해 보존). 삭제로 날짜 기록이 사라지면 안 됨.
- GAS 정비는 멱등 액션으로(재실행 안전). 배포=clasp(이미 인증). dump 등 진단 출력도 부서별 열배치 정확히(점검일지_facility: 5총항목·6입력완료·7입력률, 지원부와 열 다름 — [[reference_facility_check_snapshot_journal]]).
- 정리 후 결과(삭제 N·병합 N·최종 일관성)만 GM께 1줄 보고.
