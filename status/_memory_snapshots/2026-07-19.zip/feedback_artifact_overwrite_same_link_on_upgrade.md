---
name: feedback_artifact_overwrite_same_link_on_upgrade
description: 아티팩트 업그레이드본은 항상 같은 링크에 덮어쓰기(기존 삭제)·새 링크 난립 금지
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9f55ba89-c1da-4331-af8a-3d8201e2e6fc
---

GM 2026-07-16: 아티팩트를 고도화·업그레이드할 때는 **항상 기존 아티팩트를 같은 링크에 덮어쓰거나 삭제**한다. 새 버전마다 새 URL 만들지 말 것.

**Why:** 갤러리에 옛 버전이 쌓이면 GM이 어느 게 최신인지 혼란. 항상 최신 한 장만 본다.

**How to apply:** 같은 대화면 동일 file_path로 재발행(Artifact) → 같은 URL 유지. 다른 대화면 `url=` 로 기존 아티팩트 지정. [[feedback_gm_prefers_designed_artifact_proposals]] · 약속 L19(부서태그+같은링크 갱신·통합보드 수렴)의 실천 강화.
