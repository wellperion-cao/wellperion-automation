---
name: project_marketing_dashboard_merged_into_m1
description: "마케팅 성과 대시보드(구 M2 마케팅현황대시보드.html) = 삭제됨. 이제 메인 가이드 M1 섹션 #m1-dash 인라인 임베드가 정본"
metadata:
  node_type: memory
  type: project
  originSessionId: f473f4b7-788a-4030-bbff-6564ce545024
---

GM 지시(2026-07-18): "M2 삭제, M1에 다 들어와서 라이브로 현황 파악." 완료.

- **구 `3. 웰페리온 가이드/cmo/funnel/마케팅현황대시보드.html`(M2) = 삭제됨.** 다시 만들지 말 것. 라이브에서 404가 정상.
- **정본 = 메인 가이드 `wellperion_guide(main).html` M1 섹션(`data-id="M1"`, g14) 안의 `<section id="m1-dash">` 인라인 임베드.** 조회기간 필터·요약(발행/경유문의/게시물당)·채널별 성과+증감·8주 추세·게시글별(측정준비중)·인사이트 전부 여기.
- **이식 방식(수정 시 주의):** M2 JS 전체가 **하나의 IIFE로 격리**됨 — onclick 핸들러는 `window.M2DASH.{switchPeriod,shiftMonth,toggleCustomRange,runCustomQuery,loadYearToDate,printDash}`로만 노출. CSS는 전부 `#m1-dash` 스코프(전역 리셋 제거). fetch 경로 M1 기준(`cmo/review/review_queue.json`, `cmo/funnel/engagement/…`). GAS(funnel_conversion)·IG원장은 절대 URL.
- **period-status 단일 소스 = `refreshPeriodSections()`** (시작=불러오는 중 / resolve=실측 완료·집계 실패). 개별 period 함수에서 조기 '완료' 표기 넣지 말 것(거짓 완료).
- **데이터 지연:** GAS 집계 ~10초 → 초기 스켈레톤 후 채워짐(정상). 검증은 15초+ 대기 후.
- 참조 링크 전부 `#M1`로 재지정됨(자율현황·월간마케팅보고서·문의흐름지도·coo/bootsetup_matrix·메인가이드). module_registry `cmo-marketing-funnel` front_card=window:M1/anchor:m1-dash.
- **④ 게시글별 성과 = 삭제됨(2026-07-18 GM)·재추가 금지.** 이유: 게시물당 문의 귀속은 "아직 안 된" 게 아니라 **원천 불가** — IG·당근은 게시글별 추적 URL이 아니라 프로필 bio 링크로 문의 접수 → 어떤 게시글이 문의를 만들었는지 못 붙임. + 게시글 목록이 M1 검수 섹션과 중복 + 반응지표 sparse. 채널 단위(③)가 최선. 관련 죽은 함수(isOfficialItem·buildPostGroups·loadEngagementFeed·loadIgLedger·lookupPostMetric·renderPostList 등) 제거됨. **굳이 필요하면 블로그·카페만** 부분 가능(게시글별 추적 URL 삽입 가능 채널). IG·당근 불가.
- **모듈 정의 정본 = S2 CMO 본인탭 '콘텐츠 허브 모듈(M1) 정의'**(기반→제작→검수→발행→성과→환류 6단계 + AI없이자체가동·제품화·두계정) + M1 상단 '이 모듈은' 상세 + module_registry.feature. 셋 동기화 유지.
- 채널 단위는 실측(kpi_values `채널별_문의전환`). 관련 [[project_conversion_funnel_leak_diagnosis]] · [[feedback_cmo_mission_dashboard_normalization]] · [[reference_guidehub_concurrent_commit_corruption]](원샷 커밋 필수).
