---
name: feedback_inline_content_not_jump_links
description: "GM은 페이지에서 앵커 점프/'~참조'로 타고 넘어가는 걸 싫어함 — 필요한 내용은 그 자리로 직접 인라인 배치"
metadata:
  node_type: memory
  type: feedback
  originSessionId: f473f4b7-788a-4030-bbff-6564ce545024
---

GM 지시(2026-07-18): "난 이렇게 타고 넘어가는거 별로 안좋아해 — 그냥 아래 있는 내용을 제작 라인으로 가지고와."

- **점프 링크·앵커 스크롤·'아래 ○○ 참조' 패턴 지양.** 필요한 규칙·내용은 **쓰이는 그 자리(예: 제작 섹션)로 직접 가져와 인라인** 배치.
- 예: M1 '제작할 때 참고' 칩(표기 규칙 등으로 scrollIntoView 점프)을 만들었더니 GM이 반려 → 표기 규칙 내용 자체를 제작 라인에 넣으라.

**Why:** 화면에서 이리저리 타고 넘어가며 찾는 UX를 싫어함. 한 흐름 안에서 필요한 게 바로 보이길 원함(decide/read in place).
**How to apply:** 콘텐츠를 배치할 때 "여기서 필요한 내용인가?" → 맞으면 링크 말고 그 자리에 직접. 중복이 걱정되면 원본을 그 자리로 **이동**(양쪽 유지 금지). 관련 [[feedback_readability_tables_for_structured_data]] · [[feedback_gm_reports_short_scannable]].
