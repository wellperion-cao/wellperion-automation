---
name: reference_wp_page_inject_draftpage_not_publishpage
description: WP 페이지 본문(vc_raw_html 블록) 주입은 draft-page 모드 · publish-page는 슬러그·발행만
metadata: 
  node_type: memory
  type: reference
  originSessionId: 5a0d4d2b-79fe-424b-b4c9-53d392c9f800
---

wordpress_admin_playwright.py 의 WP 페이지 갱신은 **모드 2개가 역할이 다르다**:
- `--mode draft-page --page <key> --post-id <id>` = **본문(vc_raw_html 블록) 실제 주입**. 이미 발행된 페이지면 "업데이트로 저장(발행 유지)"→즉시 라이브.
- `--mode publish-page ...` = **슬러그 설정 + 발행 상태만** 손댐. **본문은 안 바꾼다.** 이미 발행된 페이지에 이것만 돌리면 옛 본문 그대로 재발행됨(변경 0).

★함정: 새 블록을 라이브에 반영하려면 반드시 **draft-page**(주입) 실행. publish-page만 돌리면 "발행했습니다" 떠도 내용 안 바뀜(라이브 마커로 반드시 검증). 순서=draft-page(주입·발행유지)로 끝. 발행이 안 돼 있던 신규만 publish-page 추가.

검증법: 라이브 페이지를 신버전 전용 마커로 curl grep(구버전에 없는 문자열). body class `page-id-XXXX`로 post_id 확인(nav 매칭 주의—`<body` 라인만).

습득물 페이지 post_id: 접수(lost-found-register)=8464 · 보기(lost-found)=8462 · 종합접수처(reception)=8434 · 문의(inquiry)=8394. LF_PAGE_SPECS: lf-register / lf-gallery.

관련: [[reference_wp_published_page_edit_goes_live_immediately]] [[reference_wp_reception_inline_copy_drift]] [[reference_clasp_webapp_redeploy]] [[project_cpo_inquiry_system_unification]]
