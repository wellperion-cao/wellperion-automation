---
name: feedback_facility_check_metric_is_event_not_percent
description: 시설부 점검 현황 지표=%(입력률/완료율) 부차적 · 핵심=회차·이상유무·이상내용·해결내역
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 4e0b0ec3-c79a-428c-a92b-f553983b7c08
---

**시설부 점검 현황은 %(입력률·완료율)가 중요하지 않다** (GM 2026-07-13). 시설부에서 GM이 보고 싶은 핵심 4가지:
1. **몇 번 점검했는지** (회차·sessionCount)
2. **점검했을 때 문제가 없었는지** (이상 유무)
3. **문제가 있었으면 어떤 문제였는지** (이상 내용)
4. **어떻게 해결했는지** (조치·해결 내역)

**Why:** 시설부는 "다 찍었나(입력률)"가 아니라 "이상을 잡고·처리했나"가 본질인 안전/설비 점검. %는 실무 완전입력 습관 지표일 뿐 현황의 핵심이 아니다. 지원부(완료율)와 지표 체계가 다름 — 억지 통일 금지.

**How to apply:** 시설부 현황(시설부 체계.html·12시 알림·home 카드·월간 집계)은 회차·무이상/이상·이상내용·해결을 앞세워 렌더. %는 빼거나 부차 병기. 특히 ④해결 내역은 "이상 감지→조치→종결" 폐루프 추적이 필요(이전 검수에서 이상 7건 감지되나 해소 추적 안 보임 확인). 지표 정의 정본 = [[reference_dept_check_metric_map]] 갱신 대상. 관련 [[reference_facility_closed_days_2nd_4th_sunday]]·배 700(시설부 점검 정리).
