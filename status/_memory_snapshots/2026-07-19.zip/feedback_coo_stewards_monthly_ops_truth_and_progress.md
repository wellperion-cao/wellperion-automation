---
name: feedback_coo_stewards_monthly_ops_truth_and_progress
description: 시우=월간운영계획 데이터·실무진 업무의 책임 스튜어드 · 진실 데이터만 · 진행은 놓친것+잘한것 둘 다 선제 보고
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2fc893f6-945f-4033-b228-e0462998af13
---

GM 지시(2026-07-14): "월간운영계획에 있는 데이터들이나 실무진 업무내용들은 정말 중요한거라 너가 잘 챙겨야 해. 진실된 데이터만 있어야 해. 그리고 진행 관련해서도 놓치면 알려주고, 잘하면 그것도 알려주고."

**시우(COO)가 월간운영계획.html의 데이터·실무진 업무 내용의 책임 스튜어드.** 정말 중요한 자료 → 상시 챙김.

**Why:** 이 페이지는 전사 회의·의사결정의 실데이터 근거. 틀린 숫자 하나가 잘못된 경영판단으로 직결. 진실성이 최우선 가치.

**How to apply:**
- **진실된 데이터만.** 지어낸 값·목업·[예시]·하드코딩 숫자 절대 금지. 미측정/부분/추정은 정직 꼬리표로 명시(예 '(상반기까지)'·'가짜값 없음'·'측정 개통 전'). 데이터가 있는데 버려서 공란 두는 과침묵도 결함 — 있으면 정직표기로 채운다.
- 소스는 라이브 정본만(sales_targets.json·team_sales_h1·kpi_values 등). 소스 단일·분모 정합 상시 점검(참조 [[reference_check_completion_rate_untrustworthy_multisource]]·[[reference_stage_funnel_source_composition_trap]]).
- **진행 상황 양방향 선제 보고:** 놓친 것(미반영·표류·데이터 흠집)을 발견 즉시 GM에 알린다. 동시에 **잘 돌아가는 것·성과도 알린다**(문제만 보고하지 말 것). [[project_gm_aide_autonomy]]의 포착·선제 원칙을 월간운영계획에 적용.
- 100% 단정 금지 — 코드·배포 검증은 내가, 최종 시각·값 확인은 GM 인코그니토([[feedback_no_100pct_overclaim_report_actual_progress.md]]).

[[feedback_default_proceed_ambiguous_deepinterview]] [[feedback_cmo_mission_dashboard_normalization]] [[feedback_clevel_proactive_proposal_welcomed]]
