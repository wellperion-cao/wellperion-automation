---
name: reference_lesson_main_importrange_source_no_rowdelete
description: 강습 메인4시트는 6종목 팀시트의 IMPORTRANGE 원본 — 메인에서 행삭제(deleteRow)하면 팀시트 정렬이 밀려 손상. 파괴적 시트작업 금지 원칙.
metadata: 
  node_type: memory
  type: reference
  originSessionId: 8f835629-cc25-482f-9342-4d3086a1f79e
---

강습 메인 스프레드시트 `1b0XU1oTHlXzBhEzUOar5GEm44vjopdO25qfsh-awDXw`(성인강습 111889422·성인영 311319200·유소년 268994754·유소년영 931249179)은 **6종목 팀시트(10rjNd 수영·1mRTWB PT·1NbML3 필라·1vH9To 스쿼시·1-Ubck 골프·1ZqsKz 체조)의 IMPORTRANGE 원본**이다. 팀시트는 이름·전화·종목을 메인에서 IMPORTRANGE(수식)로 끌어오고, **지정강사·Contact·비고·진행상황은 팀장이 직접 타이핑한 고정값**이다.

**절대 규칙 — 메인 강습시트에서 행삭제(deleteRow)·행이동 금지.** 메인 행수를 바꾸면(중복삭제 등) 팀시트의 IMPORTRANGE 이름칸이 위로 밀리는데 고정 지정강사는 안 밀려 **전 팀시트의 이름↔담당이 어긋난다(정렬 손상).** 2026-07-14 dedup(deleteRow 73행)이 이 사고를 냈고, 유일한 복구는 **메인 스프레드시트 버전기록 복원**(파일>버전기록>행삭제 이전 시점)이었다. 팀시트 복원은 소용없음(IMPORTRANGE가 밀린 메인을 다시 끌어옴). 복원=시트 소유자(GM)만 가능.

추가 교훈:
- deleteRow 루프는 클라이언트 curl 타임아웃(2분)에 중간에 끊기면 **부분 삭제**로 남고, 재실행 시 stale 스냅샷 기준이면 **유니크 행 오삭제** 위험(그날 유소년 3행 손실→복구). 파괴적 대량작업은 배치·타임아웃·멱등 반드시 검증.
- 안전한 관리컬럼 채우기(이관)는 **행삭제 없이 · 빈칸만 setValues · 단일종목만(다종목 오염 방지) · 2026 등 범위 한정**으로. 이건 정렬 안 밀림.
- 강습 status 폴러 `_notifyLessonStatusChanges_`는 팀시트 감시 → 메인 대량변경이 IMPORTRANGE로 흘러가면 오알림 폭주. `LESSON_POLLER_OFF` kill-switch로 정지함(레거시).
- 종목 팀시트 담당컬럼명 상이: 수영·체조=`지정 강사`·PT=`지정 P.T`·필라=`지정 P.L`·스쿼시=`지정 코치`·골프=`지정 프로`(공통접두 `지정 `). 접수담당자(I열)≠지정강사(K열) — greedy '담당' 매칭 주의.

**Why:** 되돌리기 어려운 데이터 사고를 다시 내지 않기 위해. **How to apply:** 강습 시트 정리·중복처리는 deleteRow 대신 표시·플래그로. 정말 삭제 필요하면 GM 백업/버전확인 후, IMPORTRANGE 영향 명시하고 GM go. 관련 [[feedback_no_destructive_git_in_shared_worktree]]·[[reference_guidehub_concurrent_commit_corruption]].
