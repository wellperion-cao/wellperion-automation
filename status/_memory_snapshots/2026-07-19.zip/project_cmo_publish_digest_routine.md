---
name: project-cmo-publish-digest-routine
description: 발행완료 시 5채널 통합 리치요약을 「문의·컨택·등록 알림」방에 자동 발신하는 CMO 루틴 + GM 확정 포맷
metadata: 
  node_type: memory
  type: project
  originSessionId: bb3e33cc-feed-49e3-b161-c4f1fc905d8a
---

발행 완료 시 **콘텐츠 1건 = 5채널 통합 리치 요약 한 장**을 「문의·컨택·등록 알림」방(`TELEGRAM_INQUIRY_CHAT_ID`)에 자동 발신한다. 채널별로 5조각 보내지 말 것(콘텐츠 단위로 그룹핑).

**확정 포맷 (2026-07-15 GM 아티팩트로 확정):**
- `📢 웰페리온 공식 · {제목} 발행 완료 — 응원 부탁드려요!` 머리말
- 한 줄 설명 + `❤️ 좋아요 · 💬 댓글` 응원 CTA
- 채널 이모지+링크: 📷 인스타 / 📝 블로그 / ☕ 카페 / 💬 카카오 / 🥕 당근 (고정 순서, post_url 있는 것만)
- **인스타 게시물 미리보기 카드**(link_preview_options: 인스타 post_url·prefer_large_media·show_above_text) = 본문 위 큰 이미지
- 마무리 `좋아요·댓글로 응원 부탁드립니다 🙏`
- `digest_title`·`digest_intro` 필드로 콘텐츠별 맞춤, 없으면 기본 문구 폴백

**위치:** 서버 `scripts/publish_digest.py`(group_published·build_digest·send_publish_digest·_instagram_preview_url) · 배선 `scripts/ig_review_publish_watcher.py` 런 끝 `_dispatch_publish_digest`(이번 런 발행완료건만) · 멱등 원장 `scripts/.publish_digest_sent.json`(1콘텐츠 1회) · 프론트 등록부 `status/module_registry.json` `cmo-publish-digest`(자율현황 렌더) · 테스트 `tests/test_publish_digest.py`(8통과). 커밋 de98561d(리치)·746e2758(미리보기).

발신 주의는 [[reference-telegram-burst-send-flood]] 참조.
