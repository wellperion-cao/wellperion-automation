---
name: reference_lesson_status_alert_poller
description: 강습 컨택/등록 텔레그램 알림 = 팀시트 상태 폴러(Survey.js) + 종목 이모지 · GAS 밑줄함수 함정
metadata: 
  node_type: memory
  type: reference
  originSessionId: 3840ce49-bb96-4930-befc-e78bfcf1093e
---

텔레그램 **문의알림방**(TELEGRAM_INQUIRY_CHAT_ID, 폴백 -5516675010) 알림.

**멤버십 vs 강습 알림 경로 차이(핵심):** 멤버십은 문의회원.html 페이지→GAS action으로 상태변경돼 컨택/등록 알림이 발화(`_maSet`/`_muSet` 핸들러). 강습은 팀장이 **팀 스프레드시트(LESSON_TEAM_SHEETS 12개: P.T·필라·스쿼시·골프·수영·아쿠아·체조 성인/유소년) 직접 처리**라 GAS를 안 거쳐 감지 경로가 없었음.

**해결(2026-07-14 GM go, 커밋 2bcf3766):** `.deploy-funnel/Survey.js`에 `_notifyLessonStatusChanges_()` 신설. 5분 트리거(`_notifyNewInquiries_` 말미에서 호출·별도 트리거 불필요)로 각 팀시트 읽어 상태열(휴리스틱: 고유값 2~30 + `_isLessonStatusVal_` 최다 열)에서 **컨택(/컨택|응대|연락|통화|문자|회신/)·등록(`_isLessonReg_`=SUC)으로 전환된 행만** 알림. 중복방지=ScriptProperties `LESSON_NOTIFIED_<ssId>_<gid>`에 'rowKey(이름)|bucket' 집합 저장. **최초 실행=baseline만 저장·무알림**(기존분 폭주 방지). 실행 검증: 18초·오류0·baseline 저장(2026-07-14 16:13).

**종목 이모지(커밋 eb1616cc):** `_teamChip(sport)`을 색깔네모(🟦🟥)→**종목 이모지·부분매칭**으로 교체: 수영🏊·아쿠아💦·P.T/PT🏋️·필라/P.L🧘·스쿼시🎾·골프⛳·체조/트램폴린🤸·멤버십🎫·뮤지컬🎭. 부분매칭이라 '성인 수영 (개인레슨)'도 잡힘. 신규문의·등록전환·컨택 알림 전부 이 함수 재사용.

**★GAS 함정 2개:** ①**밑줄(`_`)로 시작하는 함수는 GAS 실행 드롭다운에서 '비공개'로 숨겨져 수동 실행 불가** — 트리거·타 함수 호출은 정상이나, GM이 에디터에서 직접 못 돌림 → 밑줄 없는 공개 래퍼(`testLessonStatusCheck`) 추가. ②**트리거·수동실행 반영은 Ctrl+S 저장만으로 되나, 웹앱 /exec 동작 변경은 '새 버전 배포' 필요**([[reference_clasp_webapp_redeploy]]).

Survey.js scriptId=`1A77oDRaa21K25c3-M1AgewNfUzfW-zamfRhYWjlYUrvIdPCYazs8KQru`([[reference_funnel_gas_script_id]]). 배포=[[feedback_gas_deploy_notepad_chrome_pair]](메모장 복사→앱스크립트 크롬 붙여넣기→저장/배포). 관련 [[reference_lesson_inquiry_gas]]·[[reference_inquiry_telegram_alert_needs_trigger]].
