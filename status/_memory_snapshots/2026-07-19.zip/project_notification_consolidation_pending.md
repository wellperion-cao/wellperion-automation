---
name: project_notification_consolidation_pending
description: "알림 통합 — 2026-07-15 GM 결정: 대대적 통합 불필요·현행유지, 자율현황 '알림 스케줄 보드'로 가시화(구축완료). 큰 통합 재시도 금지"
metadata: 
  node_type: memory
  type: project
  originSessionId: 3840ce49-bb96-4930-befc-e78bfcf1093e
---

★ **2026-07-15 GM 결정 (deep-interview 결과):** 대대적 통합/재설계는 **불필요**. GM은 알림 흐름을 "지금처럼" 유지하고 싶고, 진짜 니즈는 "무엇이 언제 누구에게 가는지·잘 가고 있는지를 한눈에 보고 안심"이었음(초반 확인 불안). → 알림 발송 로직 **무변경**, 자율현황.html에 **'전체 알림 스케줄 보드'** 구축완료(배 cto-alert-schedule-board·10항목·시점/채널/수신/마지막발송/health·측정불가 정직표기·커밋 9cd0d7c8). **미래 세션에서 '큰 알림 통합'을 다시 제안·시도하지 말 것** — GM이 현행유지로 명시했음. 후속(선택)=각 방별 last-send 로그 집계 배선(발송 로직 무변경 전제·브릿지 NEXT-20260715-102240). 아래 인벤토리는 참고용 보존.

**카카오톡 알림 3종:** ①07:30 ★운영부 아침 운영 다이제스트 ②09:30 3방(회장님·관리부·★운영부) 매출 이미지 ③23:00 ★운영+시설+지원+주차 밤 점검 마감. 상세=[[project_ops_daily_digest_operations]]. 자율현황 CTO 카드에 "카톡 자동화 3종" 요약표 있음.

**텔레그램 알림(흩어져 있음 — 정리 대상):**
- 문의알림방(TELEGRAM_INQUIRY_CHAT_ID·폴백 -5516675010): 신규문의(5분폴링·onFormSubmit)+멤버십 컨택/등록+강습 컨택/등록(팀시트 폴러 [[reference_lesson_status_alert_poller]]) · 종목 이모지
- 핵심 3방(점검/문의/종합접수처) [[project_telegram_3room_split]]
- 08:00 CEO 통합 보고(ceo_morning_pipeline) · 12시 점검 슬롯 알림 · 13시 헬스체크+drift가드 [[reference_telegram_alert_healthcheck_and_gas_diag]]
- C-Level module_reporter 자동보고(bot_id별) · 완료 시 GM채널 1줄(notify_gm_progress) [[feedback_completion_telegram_report]]
- 북극성 06:30 추천 카드(봇) · @namuki_report_bot 업무보고

**정리 방향(GM 미정 — 재문의 시 확정):** 중복·과다 알림 통합? 채널별 역할 정리? 카톡↔텔레그램 경계? deep-interview로 모호성 좁힌 뒤 착수 권장.

**미결(별건):** 헌법한장 GM(김남욱) 일 흐름 시간 오류 = ①22:00 취침이 22:30·23:00 일과 앞에 있음(취침을 맨끝으로) ②7:00 '직원 공유카드'=★운영부 다이제스트면 07:30으로. 정본=`3. 웰페리온 가이드/coo/bootsetup_matrix.json` gm.dims[1]. **GM이 clear 후 재결정 예정 — 아직 미수정.**
