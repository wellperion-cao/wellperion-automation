---
name: reference_kakao_inapp_strips_query_use_ascii_stub
description: 카톡 인앱브라우저가 ?query 유실 → 딥링크는 ASCII 쿼리없는 스텁 페이지로
metadata: 
  node_type: memory
  type: reference
  originSessionId: a427f5ca-b1ed-4d4f-a474-ac3dc298b308
---

카카오톡 인앱브라우저(웹뷰)로 링크를 열면 **`?manage=lesson` 같은 쿼리스트링이 유실**되는 사례 확인(2026-07-15). 증상: `문의회원.html?manage=lesson`를 카톡에 붙여 열면 강습이 아니라 멤버십(기본값)으로 뜸.

**진단(evidence):** Playwright 3시나리오 — 쿼리 O+게이트통과 → 강습 ✅ / 게이트 선통과 → 강습 ✅ / **쿼리 없는 URL → 멤버십**(GM 증상 재현). 즉 코드·게이트·reload 다 정상, 카톡이 쿼리를 안 넘기는 것. 서버·페이지가 값을 아예 못 받으므로 **코드로 복구 불가**.

**해법:** 쿼리·한글 없는 **ASCII 스텁 페이지**(`cpo/member/lesson.html`)를 만들어 카톡에 붙인다. 스텁이 브라우저 내부에서 `location.replace('문의회원.html?manage=lesson')` — **클라이언트 이동은 카톡 링크핸들러를 안 거쳐 쿼리 보존**. 게이트 pass()가 reload 전 URL의 manage를 sessionStorage(mi_manage_pending)에 캡처해 reload 유실도 방어. e2e 라이브 통과.

**교훈:** 카톡에 붙일 딥링크는 쿼리에 의존 금지 → ①ASCII 쿼리없는 스텁 경유 or ②해시(#) 사용(해시는 카톡도 대체로 보존). 한글 파일명+쿼리 조합이 특히 취약. 관련: [[project_lesson_register_ledger_sync_on_load]] · [[reference_naver_cafe_deleted_post_returns_200]](채널별 특성 함정).
