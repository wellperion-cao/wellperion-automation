---
name: feedback_completion_telegram_report
description: GM은 진행 완료건을 텔레그램으로 완료마다 1줄 보고받길 원함(핸드폰 원격 추적)
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 0a128379-3fb9-4eef-8ea2-5140aef2bb62
---

GM은 웰리·C-Level이 **진행하는 일의 완료를 텔레그램으로 완료마다 1줄** 보고받길 원한다(2026-07-13). 핸드폰만 봐도 무슨 일이 끝났는지 따라오기 위함.

**Why:** GM이 CLI 앞에 없어도 원격으로 진행을 추적. "참여 최소화"와 별개 — 진행 가시성은 원함(단 스팸은 싫음).

**How to apply:**
- 채널 = @namuki_report_bot, chat_id **8254867551**(GM 개인·오늘의 항로/승인카드 오는 방·2026-07-13 실측 검증). telegram_bot/.env TELEGRAM_BOT_TOKEN.
- **C-Level·예약 러너 완료** = `wellperion-agents/scripts/clevel_post_action.py`가 이미 완료 시 GM 채널로 1줄 보고(휴면 아님).
- **웰리 세션 오케스트레이션 완료** = 의미 있는 딜리버러블 완료 때마다 `python scripts/notify_gm_progress.py "요약" [증거링크]` 호출(완료마다 1줄).
- **스팸 방지 필수:** 루틴·자동로그·chore(auto-log/chore(queue)/chore(erp)/mirror/ADHOC 마커)는 보고 제외(`notify_gm_progress.is_routine`·clevel_post_action 필터). 실제 feat/fix/의미완료만.
- 굵기 = '완료마다 1줄'(GM 택, 이정표만/다이제스트 아님). dedup 60분·하루 cap 40.
- 게이트 `PROGRESS_REPORT_LIVE`(기본 ON·킬스위치 =0). 관련 [[project_welly_auto_runner]]·[[feedback_gm_reports_short_scannable]]·[[feedback_minimize_gm_participation_batch_auth]].
