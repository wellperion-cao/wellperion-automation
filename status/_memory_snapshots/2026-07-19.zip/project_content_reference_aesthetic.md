---
name: project_content_reference_aesthetic
description: GM이 고른 IG 디자인 느낌 + 콘텐츠 접근 기준(레퍼런스 2게시물) — 두 계정 콘텐츠의 목표 미감·구조
metadata: 
  node_type: memory
  type: project
  originSessionId: b368d183-91d4-401e-a773-db2c30fddffb
---

GM이 2026-07-13에 준(07-14 재확인) IG 레퍼런스 2개 = 우리 콘텐츠가 지향할 **느낌(디자인) + 내용(구조)** 기준. 출처=@real_man_mindset.

- **디자인 레퍼런스**: instagram.com/p/Dah7bs_mLJE/ — "느낌은 저렇게"(namuk 개인 + 공식 둘 다 적용)
- **내용 레퍼런스**: instagram.com/p/DaSTwrxmAXW/ — "천천히 루틴 만드는 내용"(필수 테마)

**디자인 느낌 핵심(재현 요소):**
1. 따뜻한 **종이 질감 배경**(크래프트/저널·플랫 색 아님·~#B5AC9E 톤)
2. 볼드 한글 고딕, **왼쪽 정렬·위쪽 여백 크게(~35-40%)**·저밀도(1-2줄)
3. ★**손으로 그린 듯한 마커 동그라미**로 핵심 문구 강조 = 그 "느낌"의 정체(깔끔한 기하학 원 아님·SVG rough path). namuk=에메랄드(#63BBA0) / 원본은 빨강
4. 조용한 태그라인 + 최소 CTA(속삭이는 브랜딩·안 요란)
5. 슬라이드마다 같은 템플릿 반복

**콘텐츠 접근:** 한 방 밀어붙이기 X → **번호로 쪼갠 작은 습관(한 슬라이드=한 영역) 체크리스트** = "천천히 루틴 만들기" 구조. 단 원본 말투("~해라" 강압)는 버리고 **"~해보세요/천천히" 부드러운 톤**으로. 강습은 항상 압박 없이 "한남동에 성인 전문 강습 있다" 정도만 알림([[feedback_content_tone_gentle_inform_not_sell]]).

**계정 적용:** namuk=에메랄드 마커원 / 공식=기존 베이지 템플릿에 마커원·여백 확장(리디자인 아닌 연장). 이 새 느낌(종이+마커원+에디토리얼 여백)은 HTML/CSS 렌더가 강점(기존 Pillow 대비). 관련: [[project_lesson_series_L_replan]]·[[feedback_gm_prefers_designed_artifact_proposals]]·[[project_personal_account_signature_color_emerald]].
