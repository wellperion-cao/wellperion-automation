---
name: reference_gas_funnel_version_limit_200
description: "퍼널 GAS(Survey.js) 200 버전 상한 도달 — 배포 차단, 삭제 불가, 해결=새 스크립트 복사. 강습 자체폼 기존탭 전환 후속 대기"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 2337a338-f860-450d-9fcb-27b3bffb5823
---

2026-07-18 퍼널 GAS(scriptId `1A77oDR…`, `.deploy-funnel/Survey.js`)가 **버전 200개 상한 도달** → `clasp deploy`/`redeploy` 전부 "Cannot create more versions" 실패. **후속 GAS 배포 전면 차단.**

**막다른 길(확인됨):**
- clasp·Apps Script API 모두 **버전 삭제 기능 없음**. 현행 편집기 UI에도 버전 삭제 없음(배포관리=deployment 목록뿐, 지워도 version 안 줄음).
- **@HEAD/테스트 배포는 구글이 "소유자만" 강제** → 익명(모든 사용자) 불가. `AKfycbzeGDag…/exec` 익명 호출=로그인 페이지 반환. @HEAD 우회 불가(내가 GM에게 잘못 안내함).

**유일한 진짜 해결 = 새 스크립트 복사본**(새 scriptId, 버전 카운터 리셋) → push → 배포 → 페이지 GAS URL 재배선. ⚠️ **함정: Script Properties(INTAKE_SUBMIT_TOKEN·TELEGRAM_INQUIRY_CHAT_ID·PII 플래그·ACCESS_TOKEN 등)는 복사 안 됨** → 하나씩 이관 필요(코드에 fallback 있는 것 다수라 일부는 기본값으로 동작하나 전수 확인 필수). 라이브 엔드포인트 교체라 신중.

**현재 라이브 상태(안전):** 프로덕션 배포 `AKfycbzdwSC…` @200 = 강습 자체폼→기존탭 리라우팅 라이브(성인→1.성인강습·유소년/여름→2.WSC강습, 여름=유소년 고정 '여름방학특강 - {종목}'). 구글폼 경로·기존 화면 전부 정상.

**배포 대기 중인 후속 3건(상한 해소 후):** ①lesson_inquiry_list 캐시 수리(리라우팅 행이 페이지 목록에 미표시) ②테스트행 3건 삭제(전화 010-0000-7001/7002/7003 `[자동검증]`, 1.성인강습·2.WSC강습) ③`강습 신규문의` 17건 기존 탭 이관 후 탭 은퇴. 삭제 헬퍼 `cpo_lesson_test_delete` 코드에 배선됨(배포만 되면 실행 가능).

토큰=`wlp_intake_9f4c1b7e2a63`. 2026-07-18 GM이 이 인프라 해결을 웰리에게 위임. 연관 [[project_self_hosted_server_setup]]·[[reference_clasp_webapp_redeploy]].
