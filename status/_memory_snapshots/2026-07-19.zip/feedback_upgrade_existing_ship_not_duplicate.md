---
name: feedback_upgrade_existing_ship_not_duplicate
description: 한 기능의 하위단계는 기존 umbrella 배를 업그레이드(note 추가) — 서브작업마다 새 배 생성 금지
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 502e688d-53c3-460b-a290-16d3251e6e43
---

GM 2026-07-14 지적: 주간 페이지 위생 하나가 배 3척(979 umbrella·982 파이프빌드·998 config확장)으로 쪼개짐 — "배를 하나 더 만들어버리다니. 기존 건에 내용 추가해서 업그레이드하면 될 것을."

**Why:** [[feedback_update_existing_not_add_new]]의 배(ship) 버전. 한 기능/이니셔티브의 하위단계·후속수리는 **기존 umbrella 배의 note에 append**해 업그레이드해야지, 서브작업마다 새 배를 만들면 G1 항로가 중복배로 부풀어 GM이 읽기 어렵다.

**How to apply:**
- 신규 배 생성 전 자문: "이게 기존 배의 하위단계/후속인가?" → 맞으면 그 배 note 갱신·status 유지, 새 배 금지. 진짜 독립 이슈일 때만 새 배.
- 완료 훅(clevel_post_action --next·auto_log)이 완료마다 완료-배를 자동 생성 → 한 기능의 여러 서브에이전트가 각각 완료-배를 남기면 중복 폭증. 서브에이전트엔 "본 배(ship_no N)를 업데이트" 지시, 별도 완료-배 생성 억제.
- 중복 발견 시 즉시 병합(하위 note를 umbrella에 흡수)+중복 배 제거([[feedback_cleanup_merge_relocate_delete]]).
- ※ad-hoc 독립 작업을 G1에 자동기록하는 것([[feedback_log_adhoc_work_to_g1]]) 자체는 유지 — 문제는 '한 기능의 분할', 독립작업 로깅이 아님.
