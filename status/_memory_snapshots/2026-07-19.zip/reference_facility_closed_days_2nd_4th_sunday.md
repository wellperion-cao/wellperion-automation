---
name: reference_facility_closed_days_2nd_4th_sunday
description: 웰페리온 휴관일=매월 2·4주 일요일(+1/1) — 점검 불필요·완료율 분모 제외 대상
metadata: 
  node_type: memory
  type: reference
  originSessionId: 4e0b0ec3-c79a-428c-a92b-f553983b7c08
---

**휴관일 = 매월 2번째·4번째 일요일 (+ 1월 1일).** 휴관일엔 점검하지 않는다(GM 확인 2026-07-13). 예: 2026-07-12(2번째 일)·07-26(4번째 일).

규칙은 이미 프론트 코드에 정확히 박제됨: `지원부 체계.html` `getDayInfo()` (`dow===0 && (wk===2||wk===4)`, wk=`Math.ceil(date/7)`). 시설부 체계.html 공유.

**⚠️ 갭(정확성 함정):** 프론트 페이지는 휴관일을 알지만, 하류 소비자는 모름 —
- `telegram_bot/daily_scheduler.py` 12시/23시 점검 알림 = 휴관 스킵 로직 **없음** → 휴관 일요일에도 "0%" 헛알림 발신 우려.
- 완료율 KPI(ship 890 지원부 0%·home 집계)가 휴관일을 분모에 넣으면 완료율이 억울하게 깎임 → "정확한 완료율"은 휴관일을 분모에서 빼야 함.

**How to apply:** 점검 완료율·점검 알림을 다룰 땐 항상 `getDayInfo` 휴관 판정을 재사용해 휴관일을 제외. 관련 = [[reference_check_completion_rate_untrustworthy_multisource]] · 배 890(지원부 점검완료율 0% 진단).
