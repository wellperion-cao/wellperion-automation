# -*- coding: utf-8 -*-
"""AI_DIR\\CLAUDE.md 끝에 카카오톡 절을 한 번만 덧붙인다(설치 .bat 전용 내부 도구).

배치(.bat)의 echo 로 HTML 주석("<!-- ... -->")과 느낌표가 섞인 여러 줄을 직접 쓰면
콘솔 코드페이지·느낌표(delayed expansion) 문제로 줄이 깨지기 쉽다 — 실측(2026-09-10
설치 스크립트 검증 중 재현). 파이썬은 이 파일 자체를 UTF-8 로 그대로 읽으므로 그 위험이 없다.

  python _ai_claude_patch.py "<AI_DIR>" "<KAKAO_DIR>"

이미 붙어 있으면 아무것도 안 한다(멱등). 붙였으면 "added", 이미 있었으면 "skipped" 를 찍는다.
"""
import sys
from pathlib import Path

MARKER_START = "<!-- KAKAO_AI_SECTION_START -->"
MARKER_END = "<!-- KAKAO_AI_SECTION_END -->"


def build_section(kakao_dir: str) -> str:
    guide = str(Path(kakao_dir) / "카카오톡_AI전송.md")
    return (
        f"\n---\n{MARKER_START}\n"
        "## 카카오톡 전송 (이 PC 전용)\n"
        "이 PC 에는 카카오톡 자동 전송 도구가 설치돼 있다. 카톡으로 뭔가 보내 달라는 요청을\n"
        f"받으면 `{guide}` 를 읽고 그 절차대로 한다(보내기 전 무엇을·어느 방에 보내는지\n"
        "확인받은 뒤에만 보낸다).\n"
        f"{MARKER_END}\n"
    )


def main() -> int:
    if len(sys.argv) < 3:
        print("사용법: python _ai_claude_patch.py <AI_DIR> <KAKAO_DIR>")
        return 1
    claude_md = Path(sys.argv[1]) / "CLAUDE.md"
    kakao_dir = sys.argv[2]

    existing = claude_md.read_text(encoding="utf-8") if claude_md.exists() else ""
    if MARKER_START in existing:
        print("skipped")
        return 0

    with claude_md.open("a", encoding="utf-8") as f:
        f.write(build_section(kakao_dir))
    print("added")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
