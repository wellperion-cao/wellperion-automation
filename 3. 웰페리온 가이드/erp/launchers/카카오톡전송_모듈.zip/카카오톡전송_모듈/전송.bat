@echo off
chcp 65001 >nul
title 카카오톡 전송 모듈
setlocal enabledelayedexpansion

set "PY=C:\Python314\python.exe"
if not exist "%PY%" (
  for %%P in (python.exe) do if not "%%~$PATH:P"=="" set "PY=%%~$PATH:P"
)
if not exist "%PY%" set "PY=py"

"%PY%" -c "1" >nul 2>nul
if errorlevel 1 (
    echo 파이썬을 찾을 수 없습니다. https://python.org 에서 설치한 뒤 다시 실행하세요.
    pause
    exit /b 1
)

echo [1/3] 필요한 꾸러미를 확인합니다 (처음 한 번만, 몇십 초 걸립니다)...
"%PY%" -m pip install --quiet pywinauto pyautogui pyperclip pywin32 pillow
if errorlevel 1 (
    echo 꾸러미 설치에 실패했습니다. 인터넷 연결을 확인하고 다시 실행하세요.
    pause
    exit /b 1
)

echo.
echo [2/3] 보낼 내용을 적습니다.
echo   - 글만 보낼 거면 이미지 칸은 그냥 엔터를 치세요.
echo   - 방 이름은 kakao_rooms.json 에 적은 이름과 토씨 하나까지 같아야 합니다.
echo   - 카카오톡 PC 앱에 로그인돼 있어야 합니다.
echo.
set "IMG="
set "CAP="
set "ROOM="
set /p IMG=보낼 이미지 파일 경로 (없으면 엔터):
set /p CAP=보낼 글:
set /p ROOM=보낼 방 이름:

if "%ROOM%"=="" (
    echo.
    echo 방 이름을 안 적으셨습니다. 다시 실행해 주세요.
    pause
    exit /b 1
)

rem 이미지가 있으면 --image, 없으면 --message 로 글만 보낸다.
if "%IMG%"=="" (
    if "%CAP%"=="" (
        echo.
        echo 이미지도 글도 없습니다. 둘 중 하나는 있어야 합니다.
        pause
        exit /b 1
    )
    set "ARGS=--message "%CAP%""
) else (
    if not exist "%IMG%" (
        echo.
        echo 그 경로에 파일이 없습니다: %IMG%
        echo 파일을 이 창으로 끌어다 놓으면 경로가 자동으로 적힙니다.
        pause
        exit /b 1
    )
    set "ARGS=--image "%IMG%" --caption "%CAP%""
)

echo.
echo [3/3] 먼저 시험으로 돌립니다 — 방을 열어 미리보기까지만 하고 실제 전송은 안 합니다.
echo.
"%PY%" "%~dp0kakao_report_sender.py" !ARGS! --only-room "%ROOM%" --dry-run
if errorlevel 1 (
    echo.
    echo 시험이 실패했습니다. 위 줄을 확인하세요.
    pause
    exit /b 1
)

echo.
set "GO="
set /p GO=위 결과가 맞으면 실제로 보냅니다. 보낼까요? (y = 보냄 / 그 외 = 취소):
if /i not "%GO%"=="y" (
    echo 취소했습니다.
    pause
    exit /b 0
)

echo.
echo 보내는 중...
"%PY%" "%~dp0kakao_report_sender.py" !ARGS! --only-room "%ROOM%"
echo.
pause
