@echo off
chcp 65001 >nul
title 카카오톡 전송 모듈
setlocal

set "PY=C:\Python314\python.exe"
if not exist "%PY%" set "PY=py"

"%PY%" -c "1" >nul 2>nul
if errorlevel 1 (
    echo 파이썬을 찾을 수 없습니다. https://python.org 에서 설치한 뒤 다시 실행하세요.
    pause
    exit /b 1
)

echo [1/2] 필요한 패키지를 설치합니다 (처음 한 번만, 몇십 초 걸립니다)...
"%PY%" -m pip install --quiet pywinauto pyautogui pyperclip pywin32 pillow
if errorlevel 1 (
    echo 패키지 설치에 실패했습니다. 인터넷 연결을 확인하고 다시 실행하세요.
    pause
    exit /b 1
)

echo.
echo [2/2] 시험발송(--dry-run)으로 실행합니다 — 방에 미리보기까지만 하고 실제 전송은 안 합니다.
echo ⚠️ 미리 카카오톡 PC 앱에서 그 방을 열어 두세요.
echo ⚠️ 방 이름은 kakao_rooms.json 에 적은 이름과 토씨 하나까지 똑같아야 합니다.
echo.
set /p IMG=보낼 이미지 파일 경로(끌어다 놓아도 됩니다):
set /p CAP=같이 보낼 문구:
set /p ROOM=보낼 방 이름(kakao_rooms.json 에 적은 이름 그대로):

"%PY%" "%~dp0kakao_report_sender.py" --image "%IMG%" --caption "%CAP%" --only-room "%ROOM%" --dry-run

echo.
echo 위 결과를 확인하세요. 실제로 보내려면 아래 명령에서 --dry-run 만 빼고 다시 실행하세요.
echo   "%PY%" "%~dp0kakao_report_sender.py" --image "%IMG%" --caption "%CAP%" --only-room "%ROOM%"
echo.
pause
