@echo off
chcp 65001 >nul
title 카카오톡 전송 모듈 - AI 로 보내기 설치
setlocal

rem 시험용: 첫 인자를 주면 그 폴더에 설치한다(기본은 이 PC 의 Wellperion-AI 폴더).
if "%~1"=="" (
    set "AI_DIR=%USERPROFILE%\Wellperion-AI"
) else (
    set "AI_DIR=%~1"
)
set "KAKAO_DIR=%AI_DIR%\tools\kakao"

if not exist "%AI_DIR%" (
    echo.
    echo "%AI_DIR%" 폴더가 없습니다 - 먼저 ERP 다운로드의 "AI 서포트"를 설치해 주세요.
    pause
    exit /b 1
)

set "PY=C:\Python314\python.exe"
if not exist "%PY%" (
    for %%P in (python.exe) do if not "%%~$PATH:P"=="" set "PY=%%~$PATH:P"
)
if not exist "%PY%" set "PY=py"
"%PY%" -c "1" >nul 2>nul
if errorlevel 1 (
    echo 파이썬을 찾을 수 없습니다. https://python.org 에서 설치한 뒤 다시 실행하세요.
    pause
    exit /b 1
)

echo.
echo [1/3] 도구를 설치 자리로 복사합니다: %KAKAO_DIR%
if not exist "%KAKAO_DIR%" mkdir "%KAKAO_DIR%"
copy /Y "%~dp0kakao_report_sender.py" "%KAKAO_DIR%\" >nul
copy /Y "%~dp0방등록.py" "%KAKAO_DIR%\" >nul
copy /Y "%~dp0tg_outbound_log.py" "%KAKAO_DIR%\" >nul
copy /Y "%~dp0전송.bat" "%KAKAO_DIR%\" >nul
copy /Y "%~dp0카카오톡_AI전송.md" "%KAKAO_DIR%\" >nul
copy /Y "%~dp0AI로_보내기.md" "%KAKAO_DIR%\" >nul
rem 방 목록은 이미 등록해 둔 방이 있으면 덮어쓰지 않는다(재설치해도 등록분 보존).
if not exist "%KAKAO_DIR%\kakao_rooms.json" copy /Y "%~dp0kakao_rooms.json" "%KAKAO_DIR%\" >nul

echo.
echo [2/3] 필요한 꾸러미를 확인합니다(처음 한 번만, 몇십 초 걸립니다)...
"%PY%" -m pip install --quiet pywinauto pyautogui pyperclip pywin32 pillow
if errorlevel 1 (
    echo 꾸러미 설치에 실패했습니다. 인터넷 연결을 확인하고 다시 실행하세요.
    pause
    exit /b 1
)

echo.
echo [3/3] AI 가 읽을 지침을 CLAUDE.md 에 연결합니다...
"%PY%" "%~dp0_ai_claude_patch.py" "%AI_DIR%" "%KAKAO_DIR%"

echo.
echo 설치를 마쳤습니다.
echo.
echo 참고: "AI 서포트" 를 다시 열 때마다 CLAUDE.md 를 서버에서 새로 받아 오는데, 그 때
echo 이 카톡 절이 함께 지워질 수 있습니다. AI 에게 카톡 얘기를 했는데 못 알아들으면
echo 이 설치.bat 을 한 번 더 더블클릭하세요(몇십 초면 끝나고, 등록해 둔 방 목록은 그대로 남습니다).
echo.
pause
