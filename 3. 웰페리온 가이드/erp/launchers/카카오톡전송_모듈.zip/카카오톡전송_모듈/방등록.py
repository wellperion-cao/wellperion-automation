# -*- coding: utf-8 -*-
"""방 이름을 kakao_rooms.json 에 넣어 준다 — 쓰는 사람이 파일을 안 열어도 되게.

왜 있나 (2026-09-10): 받은 사람이 방 이름을 입력했는데 그 이름이 kakao_rooms.json 에
없으면 전송기가 "그런 방 없음"으로 끝난다. 파일을 직접 열어 적으라는 안내로 때우면
받아서 바로 못 쓴다. 전송 직전에 이 한 줄이 목록을 맞춰 준다.

  python 방등록.py "방 이름"

이미 있으면 아무것도 안 하고, 없으면 더한다. 예시 줄("여기에 실제 카톡 방 이름")은
처음 한 번 자동으로 걷어낸다.
"""
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOMS = HERE / "kakao_rooms.json"
PLACEHOLDER = "여기에 실제 카톡 방 이름"


def main() -> int:
    if len(sys.argv) < 2 or not sys.argv[1].strip():
        print("방 이름이 없습니다.")
        return 1
    name = sys.argv[1].strip()

    try:
        cfg = json.loads(ROOMS.read_text(encoding="utf-8"))
    except FileNotFoundError:
        print(f"kakao_rooms.json 을 못 찾았습니다: {ROOMS}")
        return 1
    except Exception as exc:
        print(f"kakao_rooms.json 을 읽지 못했습니다({exc}). 파일이 깨졌는지 확인하세요.")
        return 1

    rooms = cfg.get("rooms")
    if not isinstance(rooms, list):
        rooms = []

    # 예시 줄은 실제 방이 하나라도 생기면 걷어낸다.
    rooms = [r for r in rooms
             if not (isinstance(r, dict) and str(r.get("name", "")).strip() == PLACEHOLDER)]

    for r in rooms:
        if isinstance(r, dict) and str(r.get("name", "")).strip() == name:
            print(f"방 목록에 이미 있습니다 — {name}")
            return 0

    rooms.append({"name": name, "prefix": ""})
    cfg["rooms"] = rooms
    try:
        ROOMS.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as exc:
        print(f"kakao_rooms.json 에 쓰지 못했습니다({exc}).")
        return 1
    print(f"방 목록에 넣었습니다 — {name} (지금 {len(rooms)}개)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
